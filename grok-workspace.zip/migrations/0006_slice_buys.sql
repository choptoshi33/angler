alter table night_slices add column if not exists digest text;
alter table night_slices add column if not exists amount_out text;
