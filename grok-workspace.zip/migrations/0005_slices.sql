-- One night is bought in slices. The first opens at midnight. The rest open on a gap.
-- Only voters of the winning ticker are paid. Status flips when the Sui clock says so.
create table if not exists night_slices (
  night_start timestamptz not null references night_settlements (night_start),
  slice_index integer not null,
  opens_at timestamptz not null,
  sui_mist bigint not null,
  status text not null,
  primary key (night_start, slice_index)
);
