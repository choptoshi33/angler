create table if not exists coins (
  ticker     text primary key,
  name       text not null,
  contract   text not null unique,
  about      text,
  website    text,
  x_url      text,
  telegram   text,
  created_at timestamptz not null default now()
);

create table if not exists bites (
  id          text primary key,
  from_ticker text not null references coins (ticker),
  to_ticker   text not null references coins (ticker),
  trench_id   text not null,
  opening     boolean not null default false,
  created_at  timestamptz not null default now(),
  check (from_ticker <> to_ticker)
);

create index if not exists bites_created_idx on bites (created_at desc);
create index if not exists bites_to_idx on bites (to_ticker, created_at desc);
create index if not exists bites_trench_idx on bites (trench_id, created_at desc);

insert into coins (ticker, name, contract, about, website) values
  (
    'HIPPO',
    'sudeng',
    '0x8993129d72e733985f7f1a00396cbd055bad6f817fee36576ce483c8bbb8b87b::sudeng::SUDENG',
    'sudeng. No cats, no dogs.',
    'https://www.hippocto.meme/'
  ),
  (
    'BLUB',
    'BLUB',
    '0xfa7ac3951fdca92c5200d468d31a365eb03b2be9936fde615e69f0c1274ad3a0::BLUB::BLUB',
    'Water, fish. Sui, BLUB.',
    'https://blubsui.com/'
  ),
  (
    'LOFI',
    'LOFI',
    '0xf22da9a24ad027cccb5f2d496cbe91de953d363513db08a3a734d361c7c17503::LOFI::LOFI',
    'Woke up cold. Swims here anyway.',
    null
  ),
  (
    'FUD',
    'FUD',
    '0x76cb819b01abed502bee8a702b4c2d547532c12f25001c9dea795a5e631c26f1::fud::FUD',
    'The pug that showed up early.',
    null
  ),
  (
    'AXOL',
    'AXOLcoin',
    '0xf00eb7ab086967a33c04a853ad960e5c6b0955ef5a47d50b376d83856dc1215e::axol::AXOL',
    'Familia in a smaller pond.',
    null
  )
on conflict (ticker) do nothing;

-- Opening current: AXOL is one community short of lighting the lure.
insert into bites (id, from_ticker, to_ticker, trench_id, opening, created_at) values
  ('open-1', 'FUD', 'AXOL', 'opening-fud', true, now() - interval '20 minutes'),
  ('open-2', 'HIPPO', 'AXOL', 'opening-hippo', true, now() - interval '35 minutes'),
  ('open-3', 'BLUB', 'FUD', 'opening-blub', true, now() - interval '50 minutes'),
  ('open-4', 'LOFI', 'BLUB', 'opening-lofi', true, now() - interval '80 minutes'),
  ('open-5', 'AXOL', 'LOFI', 'opening-axol', true, now() - interval '100 minutes'),
  ('open-6', 'FUD', 'HIPPO', 'opening-fud-2', true, now() - interval '130 minutes')
on conflict (id) do nothing;
