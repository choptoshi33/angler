alter table bites add column if not exists x_user_id text;
alter table bites add column if not exists x_account_id text;
alter table bites add column if not exists x_name text;

create index if not exists bites_x_user_idx on bites (x_user_id, created_at desc);
