-- Paid, X-verified votes. One SUI each. A night is a UTC day.
create table if not exists night_votes (
  digest text primary key,
  sender text not null,
  ticker text not null references coins (ticker),
  x_user_id text not null,
  x_account_id text not null,
  x_name text not null,
  night_start timestamptz not null,
  created_at timestamptz not null default now()
);

create unique index if not exists night_votes_account_night_idx
  on night_votes (x_account_id, night_start);

create unique index if not exists night_votes_sender_night_idx
  on night_votes (sender, night_start);

create index if not exists night_votes_night_idx
  on night_votes (night_start, ticker);

-- Closed nights. The winner is what Al buys. Every payer that night gets an even share.
create table if not exists night_settlements (
  night_start timestamptz primary key,
  ends_at timestamptz not null,
  winner text,
  pot_votes integer not null,
  settled_at timestamptz not null default now()
);
