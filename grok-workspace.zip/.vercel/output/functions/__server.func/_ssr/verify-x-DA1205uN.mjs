import { t as authClient } from "./client-BhcLuWvF.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/verify-x-DA1205uN.js
var BEARER_KEY = "grok-auth.bearer-token";
/** Open X sign-in in a popup and keep it on the current session when one exists. */
function verifyWithX() {
	const popup = window.open(`${window.location.origin}/api/verify-x`, `angler-x-${Date.now()}`, "popup,width=520,height=700");
	if (!popup) return Promise.reject(/* @__PURE__ */ new Error("Pop-up blocked. Allow pop-ups and try again."));
	return waitForVerify(popup).then(async (message) => {
		if (message.error) throw new Error(message.error);
		if (!message.token) throw new Error("X verification did not finish.");
		try {
			window.sessionStorage.setItem(BEARER_KEY, message.token);
		} catch {}
		await authClient.getSession();
	});
}
function waitForVerify(popup) {
	return new Promise((resolve) => {
		const origin = window.location.origin;
		let settled = false;
		let closeTimer;
		const settle = (message) => {
			if (settled) return;
			settled = true;
			window.clearInterval(pollTimer);
			if (closeTimer !== void 0) window.clearTimeout(closeTimer);
			window.removeEventListener("message", onMessage);
			resolve(message);
		};
		const onMessage = (event) => {
			if (event.origin !== origin) return;
			const data = event.data;
			if (!data || data.source !== "angler-x") return;
			settle(data);
		};
		const pollTimer = window.setInterval(() => {
			if (!popup.closed) return;
			window.clearInterval(pollTimer);
			closeTimer = window.setTimeout(() => settle({
				source: "angler-x",
				token: null,
				error: "X window was closed."
			}), 400);
		}, 300);
		window.addEventListener("message", onMessage);
	});
}
//#endregion
export { verifyWithX as t };
