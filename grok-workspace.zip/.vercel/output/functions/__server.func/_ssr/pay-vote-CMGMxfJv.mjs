import { o as __toESM } from "../_runtime.mjs";
import { E as Transaction, F as require_react, P as require_jsx_runtime, a as useDisconnectWallet, i as useCurrentAccount, n as SuiClientProvider, o as useSignAndExecuteTransaction, r as WalletProvider, t as ConnectModal } from "../_libs/@mysten/dapp-kit+[...].mjs";
import { r as castNightVote } from "./router-CImQXKen.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/pay-vote-CMGMxfJv.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var RPC = "https://fullnode.mainnet.sui.io:443";
var ONE_SUI = 1e9;
function PayVote(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuiClientProvider, {
		networks: { mainnet: {
			url: RPC,
			network: "mainnet"
		} },
		defaultNetwork: "mainnet",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletProvider, {
			autoConnect: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayForm, { ...props })
		})
	});
}
function PayForm({ treasury, hold, feed, trench, ready, onResult }) {
	const account = useCurrentAccount();
	const disconnect = useDisconnectWallet();
	const sign = useSignAndExecuteTransaction();
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [digest, setDigest] = (0, import_react.useState)("");
	const canPay = Boolean(ready && treasury && hold && feed && hold !== feed && trench && account && !busy);
	async function submit(paidDigest) {
		if (!hold || !feed || !trench) return;
		setBusy(true);
		try {
			const result = await castNightVote({ data: {
				from: hold,
				to: feed,
				trench,
				digest: paidDigest
			} });
			onResult(result);
			if (result.ok) setDigest("");
		} catch {
			onResult({
				ok: false,
				status: 500,
				error: "The vote didn't go through. If you paid, paste the transaction below."
			});
		} finally {
			setBusy(false);
		}
	}
	async function pay() {
		if (!treasury || !canPay) return;
		setBusy(true);
		try {
			const tx = new Transaction();
			const [coin] = tx.splitCoins(tx.gas, [ONE_SUI]);
			tx.transferObjects([coin], treasury);
			const result = await sign.mutateAsync({ transaction: tx });
			setBusy(false);
			await submit(result.digest);
		} catch (error) {
			setBusy(false);
			onResult({
				ok: false,
				status: 400,
				error: error instanceof Error ? error.message : "The wallet didn't finish the payment."
			});
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [
			account ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "bite-btn",
				disabled: !canPay,
				onClick: () => void pay(),
				children: busy ? "Waiting for the wallet…" : feed ? `Pay 1 SUI and vote for $${feed}` : "Pay 1 SUI and vote"
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectModal, { trigger: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "bite-btn",
				disabled: !ready || busy,
				children: "Connect a Sui wallet"
			}) }),
			account ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
				type: "button",
				className: "mt-2 block text-sm text-mist underline decoration-line underline-offset-2",
				onClick: () => disconnect.mutate(),
				children: [
					account.address.slice(0, 6),
					"…",
					account.address.slice(-4),
					" · disconnect"
				]
			}) : null,
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("label", {
				className: "mt-3 block text-xs text-mist",
				htmlFor: "paid-digest",
				children: "Already paid? Paste the transaction id."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-1 flex flex-col gap-2 sm:flex-row",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					id: "paid-digest",
					value: digest,
					onChange: (event) => setDigest(event.target.value),
					placeholder: "Transaction id",
					className: "min-h-11 w-full rounded-full border border-line bg-panel px-4 text-sm text-foam outline-none",
					spellCheck: false
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip shrink-0",
					disabled: !ready || !hold || !feed || hold === feed || !trench || digest.trim().length < 32 || busy,
					onClick: () => void submit(digest.trim()),
					children: "Submit payment"
				})]
			})
		]
	});
}
//#endregion
export { PayVote };
