import { o as __toESM } from "../_runtime.mjs";
import { F as require_react, P as require_jsx_runtime, w as QueryClientProvider } from "../_libs/@mysten/dapp-kit+[...].mjs";
import { S as useRouter, _ as lazyRouteComponent, d as Scripts, f as HeadContent, g as Outlet, h as createRouter, v as createFileRoute, y as createRootRoute } from "../_libs/@tanstack/react-router+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn, s as __exportAll } from "./ssr.mjs";
import { L as string, N as number, P as object, R as union, j as literal } from "../_libs/@better-auth/core+[...].mjs";
import { t as auth } from "./server-CJ0w_Tzp.mjs";
import { t as authMiddleware } from "./middleware-DqNlfeV0.mjs";
import { t as QueryClient } from "../_libs/tanstack__query-core.mjs";
import { t as TriangleAlert } from "../_libs/lucide-react.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-CUqXE88B.js
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getLure = createServerFn({ method: "GET" }).handler(createSsrRpc("e28a29dc6ac4f7d8719ea378358ee321a3137a6f7786d7d7bf1bc8cfa5a290d7"));
createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("e1aa5d4bf839365e5dc510865a5779cfc870473d859cec437f4797ec5bba878d"));
var whoamiX = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("ce7e2332e5a443f0bcad40a66663b5439174ebd236eeb439be5591273643896d"));
createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("62be532792589d69d706b28c8eca5bc9c56f891c105d92801df6b9c73d6194ba"));
var myNight = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(createSsrRpc("b4b4cba7c498cc8b26d772c439bd14db0fc39e4943b47d638f2de290b228f3f5"));
var castNightVote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("a8e343fb72710acaaf829b980354390537246f3657f0c43fcf19a1ddb4f8560e"));
var listCoin = createServerFn({ method: "POST" }).validator((data) => data).handler(createSsrRpc("012ecf0ae0c0c46bfe57936c6bb8851383b70a1f945b4930e58b85c66acee2a8"));
//#endregion
//#region node_modules/.nitro/vite/services/ssr/assets/router-CImQXKen.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var FALLBACK_MESSAGE = "An unexpected error occurred. Try reloading the page.";
function errorMessage(error) {
	if (error instanceof Error && error.message) return error.message;
	if (typeof error === "string" && error) return error;
	return FALLBACK_MESSAGE;
}
function AppErrorComponent({ error }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "flex min-h-screen flex-col items-center justify-center gap-3 bg-abyss px-6 text-center text-foam",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-lure",
				"aria-hidden": "true",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TriangleAlert, {
					className: "size-10",
					strokeWidth: 2
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-lg font-semibold",
				children: "Something broke"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "max-w-md text-sm break-words text-mist",
				children: errorMessage(error)
			})
		]
	});
}
/**
* App-wide client provider mounted once near the root (in `src/routes/__root.tsx`):
*
*   <AuthProvider><Outlet /></AuthProvider>
*
* Better Auth's React client (`@/lib/auth/client`) needs NO context provider —
* its `useSession()` works standalone — so this is a passthrough today. It's
* kept as the single, stable mount point for any future client-side providers
* (e.g. a toast or theme provider) without churning the root shell.
*/
function AuthProvider({ children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children });
}
var CONNECTOR_TOKEN_READY_EVENT = "grok:connector-token-ready";
function isGrokEmbedderOrigin(origin) {
	try {
		const url = new URL(origin);
		if (url.protocol !== "https:" && url.protocol !== "http:") return false;
		const host = url.hostname.toLowerCase();
		if (host === "grok.com" || host.endsWith(".grok.com")) return true;
		if (host === "localhost" || host === "127.0.0.1" || host === "[::1]") return true;
		return false;
	} catch {
		return false;
	}
}
function isSandboxPreviewGuestHost(hostname) {
	const host = hostname.toLowerCase();
	return host === "grok-sandbox.com" || host.endsWith(".grok-sandbox.com");
}
function isRemintPreviewPair(guestHost, parentHost) {
	const guest = guestHost.toLowerCase();
	const parent = parentHost.toLowerCase();
	const i = guest.indexOf(".preview.");
	if (i <= 0) return false;
	const label = guest.slice(0, i);
	const rest = guest.slice(i + 9);
	if (label.includes(".") || !rest.includes(".")) return false;
	return parent === rest || parent === `grok.${rest}`;
}
function resolveParentEmbedderOrigin(parentIsSelf, referrer, ancestorOrigin, guestHostname = "") {
	if (parentIsSelf) return null;
	for (const candidate of [referrer, ancestorOrigin ?? ""].filter(Boolean)) try {
		const url = new URL(candidate.includes("://") ? candidate : `https://${candidate}`);
		if (url.protocol !== "https:" && url.protocol !== "http:") continue;
		if (isGrokEmbedderOrigin(url.origin)) return url.origin;
		if (isSandboxPreviewGuestHost(guestHostname) || isRemintPreviewPair(guestHostname, url.hostname)) return url.origin;
	} catch {}
	return null;
}
/**
* Guest side of the grok-web ↔ sandbox preview postMessage bridge.
*
* Activates only when this page is framed by an allowlisted Grok embedder.
* Top-level runs (download/export, local `npm run dev`, deployed sites) noop.
*/
var PREVIEW_BRIDGE_CHANNEL = "grok-preview-bridge";
var EnvelopeSchema = object({
	channel: literal(PREVIEW_BRIDGE_CHANNEL),
	version: number().int().positive(),
	type: string().min(1)
});
var HelloSchema = EnvelopeSchema.extend({ type: literal("hello") });
var NavigateSchema = EnvelopeSchema.extend({
	type: literal("navigate"),
	path: string().min(1)
});
var HistorySchema = EnvelopeSchema.extend({
	type: literal("history"),
	delta: union([literal(-1), literal(1)])
});
var ConnectorTokenReadySchema = EnvelopeSchema.extend({ type: literal("connector-token-ready") });
function isSafeBridgePath(path) {
	if (!path.startsWith("/") || path.startsWith("//") || path.includes("\\")) return false;
	try {
		return new URL(path, "https://preview.invalid").origin === "https://preview.invalid";
	} catch {
		return false;
	}
}
/**
* Origin of the Grok embedder framing this page, or null when the page runs
* top-level (download/export, local `npm run dev`, deployed sites) or under a
* non-Grok parent. Client-only; null during SSR.
*/
function resolveCurrentEmbedderOrigin() {
	if (typeof window === "undefined") return null;
	const ancestorOrigin = typeof location.ancestorOrigins !== "undefined" && location.ancestorOrigins.length > 0 ? location.ancestorOrigins[0] : null;
	return resolveParentEmbedderOrigin(window.parent === window, document.referrer, ancestorOrigin, window.location.hostname);
}
/**
* Install host↔guest messaging. Returns a dispose function.
* Noops (returns a no-op dispose) when not embedded under a Grok parent.
*/
function installPreviewHostBridge(options = {}) {
	const parentOrigin = resolveCurrentEmbedderOrigin();
	if (parentOrigin === null) return () => {};
	const ROOT_STATE_KEY = "__grokPreviewBridgeRoot";
	const originalPushState = window.history.pushState.bind(window.history);
	const originalReplaceState = window.history.replaceState.bind(window.history);
	const isAtHistoryRoot = () => {
		const state = window.history.state;
		return Boolean(state && typeof state === "object" && state[ROOT_STATE_KEY] === true);
	};
	try {
		const current = window.history.state;
		if (!(current !== null && typeof current === "object" && Object.prototype.hasOwnProperty.call(current, ROOT_STATE_KEY))) {
			const isRoot = window.history.length <= 1;
			originalReplaceState(current && typeof current === "object" ? {
				...current,
				[ROOT_STATE_KEY]: isRoot
			} : { [ROOT_STATE_KEY]: isRoot }, "", window.location.href);
		}
	} catch {}
	const post = (message) => {
		window.parent.postMessage(message, parentOrigin);
	};
	const reportLocation = () => {
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "location",
			path: window.location.pathname || "/",
			search: window.location.search,
			hash: window.location.hash
		});
	};
	const reportRoutes = () => {
		const paths = options.getRoutePaths?.() ?? [];
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "routes",
			paths
		});
	};
	const defaultNavigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		try {
			const url = new URL(path, window.location.origin);
			if (url.origin !== window.location.origin) return;
			const next = `${url.pathname}${url.search}${url.hash}`;
			window.history.pushState(window.history.state, "", next);
			window.dispatchEvent(new PopStateEvent("popstate", { state: window.history.state }));
		} catch {}
	};
	const navigate = (path) => {
		if (!isSafeBridgePath(path)) return;
		if (options.navigate) {
			options.navigate(path);
			return;
		}
		defaultNavigate(path);
	};
	const announce = () => {
		reportLocation();
		reportRoutes();
		post({
			channel: PREVIEW_BRIDGE_CHANNEL,
			version: 1,
			type: "ready"
		});
	};
	const onHello = (data) => {
		if (!HelloSchema.safeParse(data).success) return;
		announce();
	};
	const onNavigate = (data) => {
		const parsed = NavigateSchema.safeParse(data);
		if (!parsed.success) return;
		navigate(parsed.data.path);
		queueMicrotask(reportLocation);
	};
	const onHistory = (data) => {
		const parsed = HistorySchema.safeParse(data);
		if (!parsed.success) return;
		if (parsed.data.delta === -1 && isAtHistoryRoot()) return;
		window.history.go(parsed.data.delta);
	};
	const onConnectorTokenReady = (data) => {
		if (!ConnectorTokenReadySchema.safeParse(data).success) return;
		window.dispatchEvent(new Event(CONNECTOR_TOKEN_READY_EVENT));
	};
	const hostMessageHandlers = /* @__PURE__ */ new Map([
		["hello", onHello],
		["navigate", onNavigate],
		["history", onHistory],
		["connector-token-ready", onConnectorTokenReady]
	]);
	const onMessage = (event) => {
		if (event.source !== window.parent) return;
		if (event.origin !== parentOrigin) return;
		const envelope = EnvelopeSchema.safeParse(event.data);
		if (!envelope.success || envelope.data.version !== 1) return;
		hostMessageHandlers.get(envelope.data.type)?.(event.data);
	};
	const onPopState = () => {
		reportLocation();
	};
	const onHashChange = () => {
		reportLocation();
	};
	window.history.pushState = (data, unused, url) => {
		const next = data && typeof data === "object" ? {
			...data,
			[ROOT_STATE_KEY]: false
		} : data;
		originalPushState(next, unused, url);
		reportLocation();
	};
	window.history.replaceState = (data, unused, url) => {
		const next = isAtHistoryRoot() ? {
			...data && typeof data === "object" ? data : {},
			[ROOT_STATE_KEY]: true
		} : data;
		originalReplaceState(next, unused, url);
		reportLocation();
	};
	window.addEventListener("message", onMessage);
	window.addEventListener("popstate", onPopState);
	window.addEventListener("hashchange", onHashChange);
	announce();
	return () => {
		window.removeEventListener("message", onMessage);
		window.removeEventListener("popstate", onPopState);
		window.removeEventListener("hashchange", onHashChange);
		window.history.pushState = originalPushState;
		window.history.replaceState = originalReplaceState;
	};
}
/** Collect static path patterns from a TanStack route tree (best-effort). */
function collectRoutePathsFromTree(routeTree) {
	const paths = /* @__PURE__ */ new Set();
	const walk = (node) => {
		if (!node || typeof node !== "object") return;
		const record = node;
		const full = typeof record.fullPath === "string" ? record.fullPath : typeof record.path === "string" ? record.path : null;
		if (full !== null && full !== "") paths.add(full.startsWith("/") ? full : `/${full}`);
		else if (full === "") paths.add("/");
		const children = record.children;
		if (Array.isArray(children)) for (const child of children) walk(child);
		else if (children && typeof children === "object") for (const child of Object.values(children)) walk(child);
	};
	walk(routeTree);
	return [...paths];
}
/**
* Mount once in `__root.tsx` so the Grok preview chrome can drive navigation
* (and later receive registered routes). Noops when the app is not embedded.
*/
function PreviewHostBridge() {
	const router = useRouter();
	(0, import_react.useEffect)(() => {
		return installPreviewHostBridge({
			navigate: (path) => {
				router.history.push(path);
			},
			getRoutePaths: () => collectRoutePathsFromTree(router.routeTree)
		});
	}, [router]);
	return null;
}
var styles_default = "/assets/styles-DHTeN37A.css";
function makeQueryClient() {
	return new QueryClient({ defaultOptions: { queries: { retry: 1 } } });
}
var browserQueryClient;
function getQueryClient() {
	if (typeof window === "undefined") return makeQueryClient();
	if (!browserQueryClient) browserQueryClient = makeQueryClient();
	return browserQueryClient;
}
var Route$10 = createRootRoute({
	head: () => ({
		meta: [
			{ charSet: "utf-8" },
			{
				name: "viewport",
				content: "width=device-width, initial-scale=1"
			},
			{ title: "Angler" },
			{
				name: "description",
				content: "A verified vote costs 1 SUI. At midnight the Sui clock opens the buys. Only wallets that voted for the winner are paid."
			},
			{
				name: "theme-color",
				content: "#07141B"
			}
		],
		links: [
			{
				rel: "preconnect",
				href: "https://fonts.googleapis.com"
			},
			{
				rel: "preconnect",
				href: "https://fonts.gstatic.com",
				crossOrigin: "anonymous"
			},
			{
				rel: "stylesheet",
				href: "https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700&family=Oxanium:wght@500;600;700;800&display=swap"
			},
			{
				rel: "icon",
				type: "image/svg+xml",
				href: "/favicon.svg"
			},
			{
				rel: "stylesheet",
				href: styles_default
			},
			{
				rel: "manifest",
				href: "/__grok/manifest.webmanifest"
			},
			{
				rel: "apple-touch-icon",
				href: "/__grok/icon-180.png"
			}
		]
	}),
	component: Root
});
function Root() {
	const [queryClient] = (0, import_react.useState)(getQueryClient);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("html", {
		lang: "en",
		suppressHydrationWarning: true,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("head", { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeadContent, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("body", {
			className: "bg-abyss font-sans text-foam antialiased",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PreviewHostBridge, {}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AuthProvider, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientProvider, {
					client: queryClient,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
				}) }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scripts, {})
			]
		})]
	});
}
var $$splitComponentImporter$2 = () => import("./routes-BaX69ns6.mjs").then((n) => n.t);
var Route$9 = createFileRoute("/")({
	loader: () => getLure(),
	head: () => ({ meta: [{ title: "Angler — one night, one coin" }] }),
	component: lazyRouteComponent($$splitComponentImporter$2, "component")
});
var $$splitComponentImporter$1 = () => import("./docs-ChXsgcQA.mjs");
var Route$8 = createFileRoute("/docs")({
	head: () => ({ meta: [{ title: "API · Angler" }, {
		name: "description",
		content: "Read tonight's pot, the leader, and who paid. Votes cost 1 SUI and happen on the board."
	}] }),
	component: lazyRouteComponent($$splitComponentImporter$1, "component")
});
var $$splitComponentImporter = () => import("./login-qONxsoTh.mjs");
var Route$7 = createFileRoute("/login")({ component: lazyRouteComponent($$splitComponentImporter, "component") });
var SESSION_COOKIE = "__Host-grok-auth.session_token";
var Route$6 = createFileRoute("/api/verify-x")({ server: { handlers: { GET: ({ request }) => startOrFinish(request) } } });
async function startOrFinish(request) {
	const url = new URL(request.url);
	if (url.searchParams.get("done") === "1") {
		const errored = url.searchParams.has("error");
		const raw = url.searchParams.get("error");
		return donePage({
			source: "angler-x",
			token: errored ? null : readCookie(request, SESSION_COOKIE),
			error: errored ? raw && raw !== "1" ? raw : "X verification was cancelled." : void 0
		});
	}
	const done = `${url.origin}/api/verify-x?done=1`;
	const body = {
		providerId: "grok-x",
		callbackURL: done,
		errorCallbackURL: `${done}&error=1`
	};
	try {
		const { auth } = await import("./server-CJ0w_Tzp.mjs").then((n) => n.a).then((n) => n.r);
		const sessionRes = await auth.api.getSession({
			headers: request.headers,
			asResponse: true
		});
		const sessionCookies = sessionRes.headers.getSetCookie();
		const headers = new Headers(request.headers);
		if (sessionCookies.length) {
			const baked = sessionCookies.map((cookie) => cookie.split(";")[0]).join("; ");
			const prev = headers.get("cookie");
			headers.set("cookie", prev ? `${prev}; ${baked}` : baked);
		}
		const session = await sessionRes.json().catch(() => null);
		const api = auth.api;
		const apiRes = session?.user ? await api.oAuth2LinkAccount({
			body,
			headers,
			asResponse: true
		}) : await api.signInWithOAuth2({
			body,
			headers,
			asResponse: true
		});
		if (!apiRes.ok) return donePage({
			source: "angler-x",
			token: null,
			error: (await apiRes.text().catch(() => "")).slice(0, 180) || "Couldn't start X verification."
		});
		const payload = await apiRes.json().catch(() => null);
		if (!payload?.url) return donePage({
			source: "angler-x",
			token: null,
			error: "X did not return a sign-in link."
		});
		const redirectHeaders = new Headers({
			location: payload.url,
			"cache-control": "no-store"
		});
		for (const cookie of sessionCookies) redirectHeaders.append("set-cookie", cookie);
		for (const cookie of apiRes.headers.getSetCookie()) redirectHeaders.append("set-cookie", cookie);
		return new Response(null, {
			status: 302,
			headers: redirectHeaders
		});
	} catch (error) {
		return donePage({
			source: "angler-x",
			token: null,
			error: error instanceof Error ? error.message : "X verification failed."
		});
	}
}
function donePage(message) {
	const payload = JSON.stringify(message).replace(/</g, "\\u003c");
	const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Verifying X…</title>
<style>
  html,body{margin:0;min-height:100%;background:#07141b;color:#8eada3;font:15px/1.5 Outfit,sans-serif}
  main{min-height:100vh;display:grid;place-items:center;padding:1.5rem;text-align:center}
</style>
</head>
<body>
<main><p>${message.error ? "Could not verify X. You can close this window." : "X verified. You can close this window."}</p></main>
<script type="application/json" id="angler-x-msg">${payload}<\/script>
<script>
(function () {
  var el = document.getElementById("angler-x-msg");
  var msg = { source: "angler-x", token: null };
  try { if (el && el.textContent) msg = JSON.parse(el.textContent); } catch (e) {}
  try { if (window.opener) window.opener.postMessage(msg, window.location.origin); } catch (e) {}
  try { window.close(); } catch (e) {}
})();
<\/script>
</body>
</html>`;
	return new Response(html, {
		status: 200,
		headers: {
			"content-type": "text/html; charset=utf-8",
			"cache-control": "no-store"
		}
	});
}
function readCookie(request, name) {
	const header = request.headers.get("cookie");
	if (!header) return null;
	for (const part of header.split(";")) {
		const trimmed = part.trim();
		const eq = trimmed.indexOf("=");
		if (eq <= 0) continue;
		if (trimmed.slice(0, eq) !== name) continue;
		const raw = trimmed.slice(eq + 1);
		try {
			return decodeURIComponent(raw);
		} catch {
			return raw;
		}
	}
	return null;
}
var Route$5 = createFileRoute("/api/auth/$")({ server: { handlers: {
	GET: ({ request }) => auth.handler(request),
	POST: ({ request }) => auth.handler(request)
} } });
var HEADERS = {
	"content-type": "application/json; charset=utf-8",
	"access-control-allow-origin": "*",
	"access-control-allow-methods": "GET, POST, OPTIONS",
	"access-control-allow-headers": "content-type",
	"cache-control": "no-store"
};
function apiJson(body, status = 200) {
	return new Response(JSON.stringify(body), {
		status,
		headers: HEADERS
	});
}
function apiOptions() {
	return new Response(null, {
		status: 204,
		headers: {
			"access-control-allow-origin": "*",
			"access-control-allow-methods": "GET, POST, OPTIONS",
			"access-control-allow-headers": "content-type",
			"access-control-max-age": "86400"
		}
	});
}
async function readJson(request) {
	const text = await request.text();
	if (text.length > 8e3) return { __bad: "Body is too big." };
	if (!text.trim()) return {};
	try {
		return JSON.parse(text);
	} catch {
		return { __bad: "Body has to be JSON." };
	}
}
function badBody(value) {
	if (!value || typeof value !== "object" || Array.isArray(value)) return null;
	const mark = value.__bad;
	return typeof mark === "string" ? mark : null;
}
var Route$4 = createFileRoute("/api/v1/bite")({ server: { handlers: {
	OPTIONS: async () => apiOptions(),
	POST: async ({ request }) => {
		const body = await readJson(request);
		const bad = badBody(body);
		if (bad) return apiJson({ error: bad }, 400);
		const { placeBite } = await import("./core.server-brIc01r-.mjs");
		const result = await placeBite(body);
		if (!result.ok) return apiJson({
			error: result.error,
			retryAfterSec: result.retryAfterSec ?? null
		}, result.status);
		return apiJson({
			bite: result.bite,
			newSchool: result.newSchool,
			justLit: result.justLit,
			heat: result.heat,
			catch: result.lure.catch,
			coins: result.lure.coins
		}, 201);
	}
} } });
var Route$3 = createFileRoute("/api/v1/lure")({ server: { handlers: {
	OPTIONS: async () => apiOptions(),
	GET: async () => {
		try {
			const { getLureState } = await import("./core.server-brIc01r-.mjs");
			return apiJson(await getLureState());
		} catch (error) {
			console.error(error);
			return apiJson({ error: "Something broke. Try again." }, 500);
		}
	}
} } });
var Route$2 = createFileRoute("/api/v1/tape")({ server: { handlers: {
	OPTIONS: async () => apiOptions(),
	GET: async () => {
		try {
			const { getLureState } = await import("./core.server-brIc01r-.mjs");
			const lure = await getLureState();
			return apiJson({
				votes: lure.night.voters,
				potSui: lure.night.potSui,
				leader: lure.night.leader,
				endsAt: lure.night.endsAt
			});
		} catch (error) {
			console.error(error);
			return apiJson({ error: "Something broke. Try again." }, 500);
		}
	}
} } });
var Route$1 = createFileRoute("/api/v1/coins/")({ server: { handlers: {
	OPTIONS: async () => apiOptions(),
	GET: async () => {
		try {
			const { getLureState } = await import("./core.server-brIc01r-.mjs");
			return apiJson({ coins: (await getLureState()).coins });
		} catch (error) {
			console.error(error);
			return apiJson({ error: "Something broke. Try again." }, 500);
		}
	},
	POST: async ({ request }) => {
		const body = await readJson(request);
		const bad = badBody(body);
		if (bad) return apiJson({ error: bad }, 400);
		const { addCoin } = await import("./core.server-brIc01r-.mjs");
		const result = await addCoin(body);
		if (!result.ok) return apiJson({ error: result.error }, result.status);
		return apiJson({
			already: result.already,
			ticker: result.ticker,
			name: result.name
		}, result.already ? 200 : 201);
	}
} } });
var Route = createFileRoute("/api/v1/coins/$ticker")({ server: { handlers: {
	OPTIONS: async () => apiOptions(),
	GET: async ({ params }) => {
		const { getCoin } = await import("./core.server-brIc01r-.mjs");
		const result = await getCoin(params.ticker);
		if (!result.ok) return apiJson({ error: result.error }, result.status);
		return apiJson({
			coin: result.coin,
			recent: result.recent
		});
	}
} } });
var IndexRoute = Route$9.update({
	id: "/",
	path: "/",
	getParentRoute: () => Route$10
});
var DocsRoute = Route$8.update({
	id: "/docs",
	path: "/docs",
	getParentRoute: () => Route$10
});
var LoginRoute = Route$7.update({
	id: "/login",
	path: "/login",
	getParentRoute: () => Route$10
});
var ApiVerifyXRoute = Route$6.update({
	id: "/api/verify-x",
	path: "/api/verify-x",
	getParentRoute: () => Route$10
});
var ApiAuthSplatRoute = Route$5.update({
	id: "/api/auth/$",
	path: "/api/auth/$",
	getParentRoute: () => Route$10
});
var ApiV1BiteRoute = Route$4.update({
	id: "/api/v1/bite",
	path: "/api/v1/bite",
	getParentRoute: () => Route$10
});
var ApiV1LureRoute = Route$3.update({
	id: "/api/v1/lure",
	path: "/api/v1/lure",
	getParentRoute: () => Route$10
});
var ApiV1TapeRoute = Route$2.update({
	id: "/api/v1/tape",
	path: "/api/v1/tape",
	getParentRoute: () => Route$10
});
var ApiV1CoinsIndexRoute = Route$1.update({
	id: "/api/v1/coins/",
	path: "/api/v1/coins/",
	getParentRoute: () => Route$10
});
var rootRouteChildren = {
	IndexRoute,
	DocsRoute,
	LoginRoute,
	ApiVerifyXRoute,
	ApiAuthSplatRoute,
	ApiV1BiteRoute,
	ApiV1LureRoute,
	ApiV1TapeRoute,
	ApiV1CoinsTickerRoute: Route.update({
		id: "/api/v1/coins/$ticker",
		path: "/api/v1/coins/$ticker",
		getParentRoute: () => Route$10
	}),
	ApiV1CoinsIndexRoute
};
var routeTree = Route$10._addFileChildren(rootRouteChildren)._addFileTypes();
var router_exports = /* @__PURE__ */ __exportAll({ getRouter: () => getRouter });
function getRouter() {
	return createRouter({
		routeTree,
		defaultErrorComponent: AppErrorComponent,
		scrollRestoration: true
	});
}
//#endregion
export { listCoin as a, getLure as i, Route$9 as n, myNight as o, castNightVote as r, whoamiX as s, router_exports as t };
