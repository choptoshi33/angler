import { r as getSql } from "./db-BGrV67kG.mjs";
import { loadNight, t as readChainClockMs, treasuryAddress } from "./night.server-BpF6jCJi.mjs";
import { j as Transaction } from "../_libs/@mysten/dapp-kit+[...].mjs";
import { t as AggregatorClient } from "../_libs/@cetusprotocol/aggregator-sdk+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/buy.server-CFockzBs.js
var ADDRESS = /^0x[a-f0-9]{64}$/;
var DIGEST = /^[1-9A-HJ-NP-Za-km-z]{32,64}$/;
var SUI = "0x2::sui::SUI";
var RPC = "https://fullnode.mainnet.sui.io:443";
function fail(status, error) {
	return {
		ok: false,
		status,
		error
	};
}
function coinTail(type) {
	const at = type.indexOf("::");
	return (at >= 0 ? type.slice(at) : type).toLowerCase();
}
function ownerAddress(owner) {
	if (!owner || typeof owner !== "object") return null;
	const value = owner.AddressOwner;
	return typeof value === "string" ? value.toLowerCase() : null;
}
async function nextDue() {
	const clock = await readChainClockMs();
	if (clock == null) return {
		ok: false,
		error: fail(503, "The Sui clock didn't answer, so no buy can open.")
	};
	await loadNight();
	if (!treasuryAddress()) return {
		ok: false,
		error: fail(503, "The pot wallet is not saved, so a buy cannot spend the SUI.")
	};
	const sql = await getSql();
	const row = (await sql`
    select s.night_start, s.slice_index, s.opens_at, s.sui_mist, n.winner, c.contract
    from night_slices s
    join night_settlements n on n.night_start = s.night_start
    join coins c on c.ticker = n.winner
    where s.status = 'due'
    order by s.opens_at asc, s.slice_index asc
    limit 1
  `)[0];
	if (!row?.winner) return {
		ok: false,
		error: fail(409, "No buy is open.")
	};
	const nightStart = row.night_start instanceof Date ? row.night_start.toISOString() : new Date(String(row.night_start)).toISOString();
	const opensAt = row.opens_at instanceof Date ? row.opens_at.getTime() : new Date(String(row.opens_at)).getTime();
	if (!Number.isFinite(opensAt) || clock < opensAt) return {
		ok: false,
		error: fail(409, "The Sui clock has not opened this buy.")
	};
	const wallets = (await sql`
    select sender from night_votes
    where night_start = ${nightStart} and ticker = ${row.winner}
    order by created_at asc
  `).map((voter) => voter.sender.toLowerCase()).filter((wallet) => ADDRESS.test(wallet));
	if (!wallets.length) return {
		ok: false,
		error: fail(409, "Nobody who voted for the winner can be paid.")
	};
	return {
		ok: true,
		nightStart,
		index: Number(row.slice_index),
		opensAt,
		mist: BigInt(row.sui_mist),
		winner: row.winner,
		coinType: row.contract,
		voters: wallets
	};
}
async function prepareSliceBuy() {
	try {
		const due = await nextDue();
		if (!due.ok) return due.error;
		const treasury = treasuryAddress();
		if (!treasury) return fail(503, "The pot wallet is not saved, so a buy cannot spend the SUI.");
		const client = new AggregatorClient({ signer: treasury });
		const router = await client.findRouters({
			from: SUI,
			target: due.coinType,
			amount: due.mist,
			byAmountIn: true
		});
		if (!router) return fail(503, `No route for $${due.winner}. This buy waits.`);
		const each = BigInt(String(router.amountOut)) * BigInt(9900) / 10000n / BigInt(due.voters.length);
		if (each < 1n) return fail(409, "The quote is too small to pay every winner voter.");
		const tx = new Transaction();
		tx.setSender(treasury);
		const [input] = tx.splitCoins(tx.gas, [due.mist]);
		const bought = await client.routerSwap({
			router,
			inputCoin: input,
			slippage: 100 / 1e4,
			txb: tx
		});
		if (due.voters.length === 1) tx.transferObjects([bought], due.voters[0]);
		else {
			const parts = tx.splitCoins(bought, due.voters.slice(0, -1).map(() => each));
			due.voters.slice(0, -1).forEach((wallet, index) => {
				tx.transferObjects([parts[index]], wallet);
			});
			tx.transferObjects([bought], due.voters[due.voters.length - 1]);
		}
		return {
			ok: true,
			tx: await tx.toJSON()
		};
	} catch (error) {
		console.error(error);
		return fail(503, "The buy route didn't build. This slice stays open.");
	}
}
async function confirmSliceBuy(input) {
	try {
		const digest = typeof input === "object" && input && "digest" in input && typeof input.digest === "string" ? input.digest.trim() : "";
		if (!DIGEST.test(digest)) return fail(400, "That doesn't look like a Sui transaction.");
		const due = await nextDue();
		if (!due.ok) return due.error;
		const treasury = treasuryAddress();
		if (!treasury) return fail(503, "The pot wallet is not saved.");
		const res = await fetch(RPC, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				jsonrpc: "2.0",
				id: 1,
				method: "sui_getTransactionBlock",
				params: [digest, {
					showEffects: true,
					showInput: true,
					showBalanceChanges: true
				}]
			}),
			signal: AbortSignal.timeout(8e3)
		});
		if (!res.ok) return fail(503, "Sui didn't answer. Submit the same buy again.");
		const json = await res.json();
		const tx = json.result;
		if (json.error || !tx) return fail(json.error ? 503 : 400, json.error ? "Sui didn't answer." : "That transaction is not on Sui.");
		if (tx.effects?.status?.status !== "success") return fail(400, "That buy failed on Sui.");
		if ((tx.transaction?.data?.sender?.toLowerCase() ?? "") !== treasury) return fail(400, "That buy was not sent by the pot wallet.");
		const at = Number(tx.timestampMs);
		if (!Number.isFinite(at) || at < due.opensAt) return fail(400, "That buy is earlier than the Sui clock allows.");
		const tail = coinTail(due.coinType);
		const paid = /* @__PURE__ */ new Map();
		let spent = 0n;
		for (const change of tx.balanceChanges ?? []) {
			const owner = ownerAddress(change.owner);
			let amount = 0n;
			try {
				amount = BigInt(change.amount ?? "0");
			} catch {
				return fail(400, "That buy has a balance Sui couldn't read.");
			}
			if (change.coinType && coinTail(change.coinType) === "::sui::sui" && owner === treasury && amount < 0n) spent += -amount;
			if (change.coinType && coinTail(change.coinType) === tail && amount > 0n && owner) paid.set(owner, (paid.get(owner) ?? 0n) + amount);
		}
		if (spent < due.mist) return fail(400, "That transaction did not spend this slice.");
		const voters = new Set(due.voters);
		if (paid.size !== voters.size) return fail(400, "The buy did not pay only the winner's voters.");
		for (const wallet of paid.keys()) if (!voters.has(wallet)) return fail(400, "The buy paid a wallet that did not vote for the winner.");
		for (const wallet of voters) if ((paid.get(wallet) ?? 0n) < 1n) return fail(400, "A winner voter was left out of the payout.");
		const out = [...paid.values()].reduce((sum, amount) => sum + amount, 0n);
		if (!(await (await getSql())`
      update night_slices
      set status = 'bought', digest = ${digest}, amount_out = ${out.toString()}
      where night_start = ${due.nightStart}
        and slice_index = ${due.index}
        and status = 'due'
      returning slice_index
    `).length) return fail(409, "That buy was already recorded.");
		const { getLureState } = await import("./core.server-SPj1Ajak.mjs");
		return {
			ok: true,
			lure: await getLureState(),
			note: `Buy ${due.index} sent. $${due.winner} was paid to the ${due.voters.length} wallets that voted for it.`
		};
	} catch (error) {
		console.error(error);
		return fail(500, "The buy couldn't be checked. If it landed, submit it again.");
	}
}
//#endregion
export { confirmSliceBuy, prepareSliceBuy };
