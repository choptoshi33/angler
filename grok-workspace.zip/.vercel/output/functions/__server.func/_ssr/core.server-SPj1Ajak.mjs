import { r as getSql } from "./db-BGrV67kG.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/core.server-SPj1Ajak.js
var COOLDOWN_SEC = 8;
var PAIR_COOLDOWN_SEC = 900;
var HOUR_CAP = 40;
var TICKER = /^[A-Z0-9]{2,10}$/;
var TRENCH = /^[A-Za-z0-9_-]{8,64}$/;
var COIN_TYPE = /^0x[a-fA-F0-9]{1,64}::[A-Za-z_][A-Za-z0-9_]*::[A-Za-z_][A-Za-z0-9_]*$/;
var SUI_GRAPHQL = "https://graphql.mainnet.sui.io/graphql";
function fail(status, error, retryAfterSec) {
	return retryAfterSec ? {
		ok: false,
		status,
		error,
		retryAfterSec
	} : {
		ok: false,
		status,
		error
	};
}
function asRecord(v) {
	if (!v || typeof v !== "object" || Array.isArray(v)) return null;
	return v;
}
function parseTicker(v) {
	if (typeof v !== "string") return null;
	const t = v.trim().toUpperCase();
	return TICKER.test(t) ? t : null;
}
function jaw(bites, schools) {
	if (bites <= 0) return 0;
	const extra = Math.max(schools - 1, 0);
	return Math.round(bites * (1 + .5 * extra) * 10) / 10;
}
function schoolStatus(heat) {
	if (heat <= 0) return "dark";
	if (heat === 1) return "lonely";
	if (heat === 2) return "circling";
	if (heat === 3) return "schooled";
	if (heat === 4) return "hot";
	if (heat === 5) return "burn";
	return "fire";
}
function heatOf(bites, schools) {
	if (bites <= 0 || schools <= 0) return 0;
	return Math.min(6, schools);
}
function xProfile(accountId) {
	const handle = accountId.replace(/^@/, "");
	if (/^[A-Za-z0-9_]{1,15}$/.test(handle)) return `https://x.com/${handle}`;
	return null;
}
function jwtClaims(token) {
	if (!token) return null;
	const part = token.split(".")[1];
	if (!part) return null;
	try {
		const json = Buffer.from(part.replace(/-/g, "+").replace(/_/g, "/"), "base64").toString("utf8");
		const data = JSON.parse(json);
		if (!data || typeof data !== "object" || Array.isArray(data)) return null;
		return data;
	} catch {
		return null;
	}
}
function handleFromClaims(claims) {
	if (!claims) return null;
	const candidates = [
		claims.preferred_username,
		claims.username,
		claims.screen_name,
		claims.user_name
	];
	for (const value of candidates) {
		if (typeof value !== "string") continue;
		const handle = value.trim().replace(/^@/, "");
		if (/^[A-Za-z0-9_]{1,15}$/.test(handle)) return handle;
	}
	if (typeof claims.profile === "string") {
		const match = claims.profile.match(/^https:\/\/(?:x|twitter)\.com\/([A-Za-z0-9_]{1,15})\/?$/);
		if (match) return match[1];
	}
	return null;
}
function verifiedFrom(accountId, name) {
	if (!accountId) return null;
	return {
		name: cleanLine(name, 40) || "X account",
		profile: xProfile(accountId)
	};
}
function asIso(v) {
	if (v instanceof Date) return v.toISOString();
	if (typeof v === "string") {
		const d = new Date(v);
		if (!Number.isNaN(d.getTime())) return d.toISOString();
	}
	return (/* @__PURE__ */ new Date()).toISOString();
}
function secondsAgo(v) {
	const t = v instanceof Date ? v.getTime() : new Date(String(v)).getTime();
	if (Number.isNaN(t)) return Number.POSITIVE_INFINITY;
	return (Date.now() - t) / 1e3;
}
function cleanLine(v, max) {
	if (typeof v !== "string") return null;
	const text = v.replace(/[\u0000-\u001F]/g, " ").replace(/\s+/g, " ").trim();
	if (!text) return null;
	return text.slice(0, max);
}
function httpsUrl(v) {
	if (v == null) return null;
	if (typeof v !== "string") return "bad";
	const text = v.trim();
	if (!text) return null;
	if (text.length > 180 || !text.startsWith("https://") || /\s/.test(text)) return "bad";
	try {
		const url = new URL(text);
		if (url.protocol !== "https:") return "bad";
		return url.toString();
	} catch {
		return "bad";
	}
}
function isUnique(e) {
	const err = e;
	return err.code === "23505" || /unique|duplicate/i.test(err.message ?? "");
}
async function buildState() {
	const sql = await getSql();
	const [coinRows, pairRows, tapeRows, verifiedRows] = await Promise.all([
		sql`select ticker, name, contract, about, website, x_url, telegram from coins`,
		sql`
      select to_ticker, from_ticker, count(*) as n
      from bites
      where created_at > now() - interval '6 hours'
      group by to_ticker, from_ticker
    `,
		sql`
      select id, from_ticker, to_ticker, created_at, opening, x_account_id, x_name
      from bites
      order by created_at desc
      limit 24
    `,
		sql`
      select to_ticker, x_account_id, max(x_name) as x_name
      from bites
      where created_at > now() - interval '6 hours' and x_account_id is not null
      group by to_ticker, x_account_id
    `
	]);
	const inbound = /* @__PURE__ */ new Map();
	for (const row of pairRows) {
		const n = Number(row.n) || 0;
		const slot = inbound.get(row.to_ticker) ?? {
			bites: 0,
			feeders: []
		};
		slot.bites += n;
		slot.feeders.push({
			ticker: row.from_ticker,
			n
		});
		inbound.set(row.to_ticker, slot);
	}
	const verifiedByCoin = /* @__PURE__ */ new Map();
	for (const row of verifiedRows) {
		const vote = verifiedFrom(row.x_account_id, row.x_name);
		if (!vote) continue;
		const list = verifiedByCoin.get(row.to_ticker) ?? [];
		list.push(vote);
		verifiedByCoin.set(row.to_ticker, list);
	}
	const coins = coinRows.map((row) => {
		const slot = inbound.get(row.ticker);
		const bites = slot?.bites ?? 0;
		const feeders = (slot?.feeders ?? []).sort((a, b) => b.n - a.n || a.ticker.localeCompare(b.ticker)).map((f) => f.ticker);
		const schools = feeders.length;
		const heat = heatOf(bites, schools);
		const verified = (verifiedByCoin.get(row.ticker) ?? []).sort((a, b) => a.name.localeCompare(b.name));
		return {
			ticker: row.ticker,
			name: row.name,
			contract: row.contract,
			about: row.about,
			website: row.website,
			x: row.x_url,
			telegram: row.telegram,
			bites,
			schools,
			score: jaw(bites, schools),
			heat,
			status: schoolStatus(heat),
			feeders,
			verified
		};
	});
	coins.sort((a, b) => b.score - a.score || b.heat - a.heat || b.bites - a.bites || b.schools - a.schools || a.ticker.localeCompare(b.ticker));
	return {
		windowHours: 6,
		catch: coins.filter((c) => c.heat >= 3)[0] ?? coins.find((c) => c.bites > 0) ?? null,
		coins,
		tape: tapeRows.map((row) => ({
			id: row.id,
			from: row.from_ticker,
			to: row.to_ticker,
			at: asIso(row.created_at),
			opening: Boolean(row.opening),
			verified: verifiedFrom(row.x_account_id, row.x_name)
		}))
	};
}
async function getLureState() {
	const state = await buildState();
	const { loadNight } = await import("./night.server-BpF6jCJi.mjs");
	const night = await loadNight();
	const votes = new Map(night.standings.map((row) => [row.ticker, row.votes]));
	const coins = [...state.coins].sort((a, b) => {
		return (votes.get(b.ticker) ?? 0) - (votes.get(a.ticker) ?? 0) || a.ticker.localeCompare(b.ticker);
	});
	const leader = night.leader ? coins.find((coin) => coin.ticker === night.leader?.ticker) ?? null : null;
	return {
		...state,
		coins,
		catch: leader,
		night
	};
}
async function getCoin(tickerRaw) {
	const ticker = parseTicker(tickerRaw);
	if (!ticker) return fail(400, "Ticker is 2–10 letters or numbers.");
	const lure = await buildState();
	const coin = lure.coins.find((c) => c.ticker === ticker);
	if (!coin) return fail(404, `$${ticker} isn't on the board.`);
	return {
		ok: true,
		coin,
		recent: lure.tape.filter((b) => b.to === ticker || b.from === ticker).slice(0, 12)
	};
}
async function placeBiteInner(input, voter) {
	const body = asRecord(input);
	if (!body) return fail(400, "Send JSON with from, to, and trench.");
	const from = parseTicker(body.from);
	const to = parseTicker(body.to);
	const trench = typeof body.trench === "string" ? body.trench.trim() : "";
	if (!from || !to) return fail(400, "Tickers are 2–10 letters or numbers.");
	if (from === to) return fail(400, "You can't vote for the coin you hold.");
	if (!TRENCH.test(trench)) return fail(400, "Id must be 8–64 letters, numbers, _ or -.");
	const sql = await getSql();
	const known = await sql`select ticker from coins where ticker in (${from}, ${to})`;
	const have = new Set(known.map((r) => r.ticker));
	if (!have.has(from)) return fail(404, `$${from} isn't on the board yet.`);
	if (!have.has(to)) return fail(404, `$${to} isn't on the board yet.`);
	const recent = await sql`
    select created_at from bites where trench_id = ${trench} order by created_at desc limit 1
  `;
	if (recent[0]) {
		const elapsed = secondsAgo(recent[0].created_at);
		if (elapsed < COOLDOWN_SEC) return fail(429, "Too fast. Wait a few seconds.", Math.ceil(COOLDOWN_SEC - elapsed));
	}
	const samePair = await sql`
    select created_at from bites
    where trench_id = ${trench} and from_ticker = ${from} and to_ticker = ${to}
    order by created_at desc
    limit 1
  `;
	if (samePair[0]) {
		const elapsed = secondsAgo(samePair[0].created_at);
		if (elapsed < PAIR_COOLDOWN_SEC) return fail(429, "You already cast this vote. Wait 15 minutes.", Math.ceil(PAIR_COOLDOWN_SEC - elapsed));
	}
	const hour = await sql`
    select count(*) as n from bites
    where trench_id = ${trench} and created_at > now() - interval '1 hour'
  `;
	if ((Number(hour[0]?.n) || 0) >= HOUR_CAP) return fail(429, "Too many votes from this id. Try again in an hour.");
	if (voter) {
		const recentX = await sql`
      select created_at from bites where x_user_id = ${voter.userId} order by created_at desc limit 1
    `;
		if (recentX[0]) {
			const elapsed = secondsAgo(recentX[0].created_at);
			if (elapsed < COOLDOWN_SEC) return fail(429, "Too fast. Wait a few seconds.", Math.ceil(COOLDOWN_SEC - elapsed));
		}
		const pairX = await sql`
      select created_at from bites
      where x_user_id = ${voter.userId} and from_ticker = ${from} and to_ticker = ${to}
      order by created_at desc
      limit 1
    `;
		if (pairX[0]) {
			const elapsed = secondsAgo(pairX[0].created_at);
			if (elapsed < PAIR_COOLDOWN_SEC) return fail(429, "You already cast this vote. Wait 15 minutes.", Math.ceil(PAIR_COOLDOWN_SEC - elapsed));
		}
		const hourX = await sql`
      select count(*) as n from bites
      where x_user_id = ${voter.userId} and created_at > now() - interval '1 hour'
    `;
		if ((Number(hourX[0]?.n) || 0) >= HOUR_CAP) return fail(429, "Too many votes from this account. Try again in an hour.");
	}
	const targetBefore = (await getLureState()).coins.find((c) => c.ticker === to);
	const feedersBefore = new Set(targetBefore?.feeders ?? []);
	const wasBuy = (targetBefore?.heat ?? 0) >= 3;
	const id = crypto.randomUUID();
	await sql`
    insert into bites (id, from_ticker, to_ticker, trench_id, x_user_id, x_account_id, x_name)
    values (
      ${id},
      ${from},
      ${to},
      ${trench},
      ${voter?.userId ?? null},
      ${voter?.accountId ?? null},
      ${voter?.name ?? null}
    )
  `;
	const lure = await getLureState();
	const bite = lure.tape.find((b) => b.id === id) ?? {
		id,
		from,
		to,
		at: (/* @__PURE__ */ new Date()).toISOString(),
		opening: false,
		verified: voter ? verifiedFrom(voter.accountId, voter.name) : null
	};
	const nowHeat = lure.coins.find((c) => c.ticker === to)?.heat ?? 0;
	return {
		ok: true,
		bite,
		lure,
		newSchool: !feedersBefore.has(from),
		justLit: !wasBuy && nowHeat >= 3,
		heat: nowHeat
	};
}
async function placeBite(input, voter = null) {
	try {
		return await placeBiteInner(input, voter);
	} catch (error) {
		console.error(error);
		return fail(500, "Something broke. Try again.");
	}
}
async function xIdentity(userId) {
	const voter = await loadXVoter(userId);
	if (!voter) return { ok: false };
	return {
		ok: true,
		name: voter.name,
		profile: xProfile(voter.accountId)
	};
}
async function loadXVoter(userId) {
	const row = (await (await getSql())`
    select a."accountId" as "accountId", a."idToken" as "idToken", u."name" as name
    from "account" a
    join "user" u on u."id" = a."userId"
    where a."userId" = ${userId} and a."providerId" = 'grok-x'
    limit 1
  `)[0];
	if (!row?.accountId) return null;
	const providerAccountId = row.accountId.trim();
	if (!providerAccountId || providerAccountId.length > 128) return null;
	const handle = handleFromClaims(jwtClaims(row.idToken)) ?? (/^[A-Za-z0-9_]{1,15}$/.test(providerAccountId) ? providerAccountId : null);
	const display = cleanLine(row.name, 40) || "X account";
	if (handle) return {
		userId,
		accountId: handle,
		name: `@${handle}`
	};
	return {
		userId,
		accountId: providerAccountId,
		name: display
	};
}
async function lookupCoin(contract) {
	try {
		const res = await fetch(SUI_GRAPHQL, {
			method: "POST",
			headers: { "content-type": "application/json" },
			body: JSON.stringify({
				query: "query ($t: String!) { coinMetadata(coinType: $t) { name symbol } }",
				variables: { t: contract }
			}),
			signal: AbortSignal.timeout(6e3)
		});
		if (!res.ok) return "down";
		const json = await res.json();
		if (json.errors?.length && !json.data) return "down";
		const meta = json.data?.coinMetadata;
		if (!meta?.symbol) return null;
		return {
			name: (meta.name || meta.symbol).trim(),
			symbol: meta.symbol.trim()
		};
	} catch (error) {
		console.error(error);
		return "down";
	}
}
async function addCoin(input) {
	try {
		const body = asRecord(input);
		if (!body) return fail(400, "Send JSON with ticker and contract.");
		const ticker = parseTicker(body.ticker);
		if (!ticker) return fail(400, "Ticker is 2–10 letters or numbers.");
		const contract = typeof body.contract === "string" ? body.contract.trim() : "";
		if (!COIN_TYPE.test(contract)) return fail(400, "Coin type should look like 0x…::module::NAME from a Sui explorer.");
		const website = httpsUrl(body.website);
		const x = httpsUrl(body.x);
		const telegram = httpsUrl(body.telegram);
		if (website === "bad" || x === "bad" || telegram === "bad") return fail(400, "Links have to be https.");
		const about = cleanLine(body.about, 90);
		const nameInput = cleanLine(body.name, 40);
		const sql = await getSql();
		const existingContract = await sql`
      select ticker, name from coins where contract = ${contract} limit 1
    `;
		if (existingContract[0]) return {
			ok: true,
			already: true,
			ticker: existingContract[0].ticker,
			name: existingContract[0].name,
			lure: await getLureState()
		};
		if ((await sql`select ticker from coins where ticker = ${ticker} limit 1`)[0]) return fail(409, `Ticker $${ticker} is taken.`);
		const meta = await lookupCoin(contract);
		if (meta === "down") return fail(503, "Sui didn't answer. Try adding it again.");
		if (!meta) return fail(400, "That coin type isn't on Sui mainnet.");
		const name = nameInput || cleanLine(meta.name, 40) || ticker;
		try {
			await sql`
        insert into coins (ticker, name, contract, about, website, x_url, telegram)
        values (${ticker}, ${name}, ${contract}, ${about}, ${website}, ${x}, ${telegram})
      `;
		} catch (error) {
			if (!isUnique(error)) throw error;
			const again = await sql`
        select ticker, name from coins where contract = ${contract} or ticker = ${ticker} limit 1
      `;
			if (again[0]?.ticker === ticker && again[0]) return fail(409, `Ticker $${ticker} is taken.`);
			if (again[0]) return {
				ok: true,
				already: true,
				ticker: again[0].ticker,
				name: again[0].name,
				lure: await getLureState()
			};
			return fail(409, "That coin is already on the board.");
		}
		return {
			ok: true,
			already: false,
			ticker,
			name,
			lure: await getLureState()
		};
	} catch (error) {
		console.error(error);
		return fail(500, "Something broke. Try again.");
	}
}
//#endregion
export { addCoin, getCoin, getLureState, loadXVoter, placeBite, xIdentity };
