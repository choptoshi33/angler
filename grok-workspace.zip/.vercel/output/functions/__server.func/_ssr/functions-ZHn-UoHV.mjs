import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DqNlfeV0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/functions-ZHn-UoHV.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getLure_createServerFn_handler = createServerRpc({
	id: "e28a29dc6ac4f7d8719ea378358ee321a3137a6f7786d7d7bf1bc8cfa5a290d7",
	name: "getLure",
	filename: "src/lib/lure/functions.ts"
}, (opts) => getLure.__executeServer(opts));
var getLure = createServerFn({ method: "GET" }).handler(getLure_createServerFn_handler, async () => {
	const { getLureState } = await import("./core.server-brIc01r-.mjs");
	return getLureState();
});
var throwBite_createServerFn_handler = createServerRpc({
	id: "e1aa5d4bf839365e5dc510865a5779cfc870473d859cec437f4797ec5bba878d",
	name: "throwBite",
	filename: "src/lib/lure/functions.ts"
}, (opts) => throwBite.__executeServer(opts));
var throwBite = createServerFn({ method: "POST" }).validator((data) => data).handler(throwBite_createServerFn_handler, async ({ data }) => {
	const { placeBite } = await import("./core.server-brIc01r-.mjs");
	return placeBite(data);
});
var whoamiX_createServerFn_handler = createServerRpc({
	id: "ce7e2332e5a443f0bcad40a66663b5439174ebd236eeb439be5591273643896d",
	name: "whoamiX",
	filename: "src/lib/lure/functions.ts"
}, (opts) => whoamiX.__executeServer(opts));
var whoamiX = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(whoamiX_createServerFn_handler, async ({ context }) => {
	const { xIdentity } = await import("./core.server-brIc01r-.mjs");
	return xIdentity(context.userId);
});
var throwVerifiedBite_createServerFn_handler = createServerRpc({
	id: "62be532792589d69d706b28c8eca5bc9c56f891c105d92801df6b9c73d6194ba",
	name: "throwVerifiedBite",
	filename: "src/lib/lure/functions.ts"
}, (opts) => throwVerifiedBite.__executeServer(opts));
var throwVerifiedBite = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(throwVerifiedBite_createServerFn_handler, async ({ data, context }) => {
	const { loadXVoter, placeBite } = await import("./core.server-brIc01r-.mjs");
	const voter = await loadXVoter(context.userId);
	if (!voter) return {
		ok: false,
		status: 403,
		error: "Sign in with X to put your profile on this vote."
	};
	return placeBite(data, voter);
});
var myNight_createServerFn_handler = createServerRpc({
	id: "b4b4cba7c498cc8b26d772c439bd14db0fc39e4943b47d638f2de290b228f3f5",
	name: "myNight",
	filename: "src/lib/lure/functions.ts"
}, (opts) => myNight.__executeServer(opts));
var myNight = createServerFn({ method: "GET" }).middleware([authMiddleware]).handler(myNight_createServerFn_handler, async ({ context }) => {
	const { loadXVoter } = await import("./core.server-brIc01r-.mjs");
	const { alreadyVoted } = await import("./night.server-DPq2XuQZ.mjs");
	const voter = await loadXVoter(context.userId);
	if (!voter) return { voted: false };
	return { voted: await alreadyVoted(voter.accountId) };
});
var castNightVote_createServerFn_handler = createServerRpc({
	id: "a8e343fb72710acaaf829b980354390537246f3657f0c43fcf19a1ddb4f8560e",
	name: "castNightVote",
	filename: "src/lib/lure/functions.ts"
}, (opts) => castNightVote.__executeServer(opts));
var castNightVote = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(castNightVote_createServerFn_handler, async ({ data, context }) => {
	const { loadXVoter } = await import("./core.server-brIc01r-.mjs");
	const { placeNightVote } = await import("./night.server-DPq2XuQZ.mjs");
	const voter = await loadXVoter(context.userId);
	if (!voter) return {
		ok: false,
		status: 403,
		error: "Sign in with X before you pay 1 SUI."
	};
	return placeNightVote(data, voter);
});
var listCoin_createServerFn_handler = createServerRpc({
	id: "012ecf0ae0c0c46bfe57936c6bb8851383b70a1f945b4930e58b85c66acee2a8",
	name: "listCoin",
	filename: "src/lib/lure/functions.ts"
}, (opts) => listCoin.__executeServer(opts));
var listCoin = createServerFn({ method: "POST" }).validator((data) => data).handler(listCoin_createServerFn_handler, async ({ data }) => {
	const { addCoin } = await import("./core.server-brIc01r-.mjs");
	return addCoin(data);
});
//#endregion
export { castNightVote_createServerFn_handler, getLure_createServerFn_handler, listCoin_createServerFn_handler, myNight_createServerFn_handler, throwBite_createServerFn_handler, throwVerifiedBite_createServerFn_handler, whoamiX_createServerFn_handler };
