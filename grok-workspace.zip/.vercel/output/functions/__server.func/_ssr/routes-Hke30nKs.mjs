import { o as __toESM, r as __exportAll } from "../_runtime.mjs";
import { A as require_react, T as useQueryClient, c as useQuery, i as useCurrentAccount, j as Transaction, k as require_jsx_runtime, n as SuiClientProvider, o as useSignAndExecuteTransaction, r as WalletProvider, s as useMutation } from "../_libs/@mysten/dapp-kit+[...].mjs";
import { n as useCurrentUserState, t as Shell } from "./shell-ClKb0NLQ.mjs";
import { t as verifyWithX } from "./verify-x-DA1205uN.mjs";
import { a as getLure, c as prepareSliceBuy, i as confirmSliceBuy, l as whoamiX, n as Route$9, o as listCoin, s as myNight } from "./router-BoM9d5V0.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-Hke30nKs.js
var routes_Hke30nKs_exports = /* @__PURE__ */ __exportAll({ component: () => Home });
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var al_default = "/assets/al-C12GZqjo.jpg";
var RPC = "https://fullnode.mainnet.sui.io:443";
function AutoBuy({ night, onDone }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuiClientProvider, {
		networks: { mainnet: {
			url: RPC,
			network: "mainnet"
		} },
		defaultNetwork: "mainnet",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletProvider, {
			autoConnect: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Watch, {
				night,
				onDone
			})
		})
	});
}
function Watch({ night, onDone }) {
	const account = useCurrentAccount();
	const sign = useSignAndExecuteTransaction();
	const [line, setLine] = (0, import_react.useState)(null);
	const busy = (0, import_react.useRef)(false);
	const tried = (0, import_react.useRef)(null);
	const due = night.last?.slices.find((slice) => slice.status === "due") ?? null;
	const treasury = night.treasury;
	(0, import_react.useEffect)(() => {
		if (!due || !treasury || !account) return;
		if (account.address.toLowerCase() !== treasury) return;
		if (busy.current || tried.current === due.index) return;
		busy.current = true;
		tried.current = due.index;
		const slice = due.index;
		(async () => {
			setLine(`Sending buy ${slice}…`);
			try {
				const prepared = await prepareSliceBuy();
				if (!prepared.ok) {
					setLine(prepared.error);
					return;
				}
				const result = await sign.mutateAsync({ transaction: Transaction.from(prepared.tx) });
				const confirmed = await confirmSliceBuy({ data: { digest: result.digest } });
				if (!confirmed.ok) {
					setLine(confirmed.error);
					return;
				}
				setLine(confirmed.note);
				onDone();
			} catch (error) {
				const message = error instanceof Error ? error.message : "The pot wallet didn't approve the buy.";
				setLine(message);
			} finally {
				busy.current = false;
			}
		})();
	}, [
		account,
		due,
		onDone,
		sign,
		treasury
	]);
	if (!line) return null;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
		className: "text-sm text-mist",
		children: line
	});
}
function shortWallet(wallet) {
	if (wallet.length < 12) return wallet;
	return `${wallet.slice(0, 6)}…${wallet.slice(-4)}`;
}
function Dawn({ endsAt }) {
	const [label, setLabel] = (0, import_react.useState)("midnight UTC");
	(0, import_react.useEffect)(() => {
		const tick = () => {
			const ms = new Date(endsAt).getTime() - Date.now();
			if (ms <= 0) {
				setLabel("Now");
				return;
			}
			const hours = Math.floor(ms / 36e5);
			const minutes = Math.floor(ms % 36e5 / 6e4);
			const seconds = Math.floor(ms % 6e4 / 1e3);
			setLabel(`${hours}h ${String(minutes).padStart(2, "0")}m ${String(seconds).padStart(2, "0")}s`);
		};
		tick();
		const id = setInterval(tick, 1e3);
		return () => clearInterval(id);
	}, [endsAt]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "tabular-nums",
		children: label
	});
}
function Person({ voter }) {
	const wallet = shortWallet(voter.wallet);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [voter.profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
		className: "text-hot underline decoration-line underline-offset-2",
		href: voter.profile,
		target: "_blank",
		rel: "noreferrer",
		children: voter.name
	}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "text-hot",
		children: voter.name
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
		className: "text-mist",
		children: [" · ", wallet]
	})] });
}
function NightCard({ night }) {
	const treasury = night.treasury;
	const max = night.standings[0]?.votes ?? 0;
	const share = night.leader && night.leader.votes > 0 ? `1/${night.leader.votes}` : "—";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-deep p-4 sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs tracking-widest text-mist",
					children: "TONIGHT"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-display text-xs tracking-widest text-lure",
					children: ["CLOSES ", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dawn, { endsAt: night.endsAt })]
				})]
			}),
			night.leader ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h1", {
					className: "mt-2 font-display text-5xl font-bold text-foam sm:text-6xl",
					children: ["$", night.leader.ticker]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-mist",
					children: night.leader.name
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "mt-3 text-base text-foam",
					children: [
						night.leader.votes,
						" verified ",
						night.leader.votes === 1 ? "vote" : "votes",
						". If it is still ahead at midnight, the buys of $",
						night.leader.ticker,
						" start then. ",
						12,
						" buys, ",
						5,
						" minutes apart, each within",
						" ",
						1,
						"% of the first. Only wallets that voted for it are paid."
					]
				})
			] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "mt-2 font-display text-4xl font-bold text-foam sm:text-5xl",
				children: "No leader yet"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-3 text-base text-foam",
				children: "Nobody has paid tonight. The first verified vote puts 1 SUI in the pot and names a coin."
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-3 gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-panel px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-mist",
							children: "Pot"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dd", {
							className: "font-display text-2xl font-bold tabular-nums",
							children: [night.potSui, " SUI"]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-panel px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-mist",
							children: "Votes"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-display text-2xl font-bold tabular-nums",
							children: night.verifiedVotes
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-2xl bg-panel px-3 py-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
							className: "text-xs text-mist",
							children: "Winner share"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
							className: "font-display text-2xl font-bold tabular-nums",
							children: share
						})]
					})
				]
			}),
			night.standings.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
				className: "mt-4 flex flex-col gap-3",
				children: night.standings.map((row) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-baseline justify-between gap-3",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "font-display text-lg font-bold",
						children: ["$", row.ticker]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
						className: "text-sm tabular-nums text-mist",
						children: [
							row.votes,
							" ",
							row.votes === 1 ? "vote" : "votes"
						]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-1 h-1.5 overflow-hidden rounded-full bg-panel",
					"aria-hidden": "true",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "h-full rounded-full bg-lure",
						style: { width: `${max ? row.votes / max * 100 : 0}%` }
					})
				})] }, row.ticker))
			}) : null,
			treasury ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-xs text-mist",
				children: [
					"1 SUI goes to",
					" ",
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
						className: "text-foam underline decoration-line underline-offset-2",
						href: `https://suiscan.xyz/mainnet/account/${treasury}`,
						target: "_blank",
						rel: "noreferrer",
						children: shortWallet(treasury)
					}),
					". One vote per X account. One per wallet."
				]
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs text-mist",
				children: "The pot wallet is not saved yet. A vote cannot take 1 SUI until that address is in."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-xs text-mist",
				children: night.clockOk ? `Midnight is the Sui clock. 12 buys start then, one every 5 minutes, capped at 1% slippage. The pot wallet sends each one from this page, and that transaction pays only the winner's voters.` : "The Sui clock didn't answer, so no buy can open."
			}),
			night.last && night.last.potSui > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-4 border-t border-line pt-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-xs tracking-widest text-mist",
						children: "LAST NIGHT"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-2 text-sm text-foam",
						children: night.last.winner ? `$${night.last.winner} won. ${night.last.voters} ${night.last.voters === 1 ? "wallet that voted for it is paid" : "wallets that voted for it are paid"}. Other votes are not.` : "That night closed with no votes."
					}),
					night.last.slices.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
						className: "mt-2",
						children: night.last.slices.map((slice) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-baseline justify-between gap-3 border-b border-line py-1.5 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: ["Buy ", slice.index] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums text-mist",
								children: [
									slice.sui,
									" SUI · ",
									slice.status === "bought" ? "Bought" : slice.status === "due" ? "Open" : "Waiting"
								]
							})]
						}, slice.index))
					}) : null,
					night.last.shares.length ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "mt-2 text-sm text-mist",
						children: [
							"Paid only to the winner's voters:",
							" ",
							night.last.shares.map((voter, index) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [index > 0 ? " · " : null, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Person, { voter })] }, `${voter.wallet}-share`))
						]
					}) : null
				]
			}) : null
		]
	});
}
function PayVoteSlot(props) {
	const [Comp, setComp] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		if (!props.treasury) return;
		import("./pay-vote-DZtcHZ3f.mjs").then((mod) => setComp(() => mod.PayVote));
	}, [props.treasury]);
	if (!props.treasury) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "bite-btn mt-4",
		disabled: true,
		children: "Pot wallet isn't saved yet"
	});
	if (!Comp) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
		type: "button",
		className: "bite-btn mt-4",
		disabled: true,
		children: "Pay 1 SUI and vote"
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, { ...props });
}
function shortCa(contract) {
	const parts = contract.split("::");
	const head = contract.slice(0, 6);
	const tail = parts.slice(1).join("::");
	return tail ? `${head}…${tail}` : `${head}…`;
}
function chartUrl(contract) {
	return `https://dexscreener.com/sui/${encodeURI(contract)}`;
}
function scanUrl(contract) {
	return `https://suiscan.xyz/mainnet/coin/${encodeURI(contract)}`;
}
var KEY = "angler-trench";
function getTrench() {
	const existing = localStorage.getItem(KEY);
	if (existing && /^[A-Za-z0-9_-]{8,64}$/.test(existing)) return existing;
	const id = crypto.randomUUID();
	localStorage.setItem(KEY, id);
	return id;
}
function votesTonight(lure, ticker) {
	return lure.night.standings.find((row) => row.ticker === ticker)?.votes ?? 0;
}
function HomeScreen({ initial }) {
	const queryClient = useQueryClient();
	const lure = useQuery({
		queryKey: ["lure"],
		queryFn: () => getLure(),
		initialData: initial,
		initialDataUpdatedAt: 0,
		refetchInterval: 8e3
	}).data;
	const [trench, setTrench] = (0, import_react.useState)(null);
	const [hold, setHold] = (0, import_react.useState)(null);
	const [feed, setFeed] = (0, import_react.useState)(null);
	const [note, setNote] = (0, import_react.useState)(null);
	const [snap, setSnap] = (0, import_react.useState)(false);
	const [lockUntil, setLockUntil] = (0, import_react.useState)(0);
	const [now, setNow] = (0, import_react.useState)(0);
	const [copied, setCopied] = (0, import_react.useState)(null);
	const [mounted, setMounted] = (0, import_react.useState)(false);
	const { user, isPending: sessionPending } = useCurrentUserState();
	const xQuery = useQuery({
		queryKey: ["x-me", user?.id ?? "signed-out"],
		queryFn: () => whoamiX(),
		enabled: Boolean(user),
		retry: false
	});
	const xReady = Boolean(xQuery.data?.ok);
	const mineQuery = useQuery({
		queryKey: ["my-night", user?.id ?? "signed-out"],
		queryFn: () => myNight(),
		enabled: xReady
	});
	const alreadyVoted = Boolean(mineQuery.data?.voted);
	(0, import_react.useEffect)(() => {
		setTrench(getTrench());
		setMounted(true);
	}, []);
	(0, import_react.useEffect)(() => {
		if (!lockUntil) return;
		const id = setInterval(() => {
			if (Date.now() >= lockUntil) setLockUntil(0);
			else setNow(Date.now());
		}, 250);
		return () => clearInterval(id);
	}, [lockUntil]);
	(0, import_react.useEffect)(() => {
		if (!snap) return;
		const id = setTimeout(() => setSnap(false), 450);
		return () => clearInterval(id);
	}, [snap]);
	function onPaid(result) {
		if (!result.ok) {
			setNote(result.error);
			if (result.retryAfterSec) {
				const until = Date.now() + result.retryAfterSec * 1e3;
				setLockUntil(until);
				setNow(Date.now());
			}
			return;
		}
		queryClient.setQueryData(["lure"], result.lure);
		queryClient.invalidateQueries({ queryKey: ["my-night"] });
		setSnap(true);
		setFeed(null);
		setNote(result.note);
	}
	const wait = lockUntil ? Math.max(0, Math.ceil((lockUntil - now) / 1e3)) : 0;
	const maxVotes = lure.night.standings[0]?.votes ?? 0;
	async function copyCa(coin) {
		try {
			await navigator.clipboard.writeText(coin.contract);
			setCopied(coin.ticker);
			setTimeout(() => setCopied((cur) => cur === coin.ticker ? null : cur), 1400);
		} catch {
			setNote("Couldn't copy that contract.");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid items-start gap-5 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "overflow-hidden rounded-card border border-line bg-deep lg:col-span-1",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
						src: al_default,
						alt: "Al, an angler fish, lure glowing in the dark",
						width: 1152,
						height: 1728,
						className: `w-full ${snap ? "jaw-snap" : ""}`
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "border-t border-line p-4 sm:p-5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "font-display text-xs tracking-widest text-mist",
							children: "AL"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-2 text-sm text-foam",
							children: "Charts can be painted. Al doesn't watch candles. He watches a wallet spend 1 SUI on a coin it does not hold. That is the only light he can see in the dark. At midnight the buys start, in small slices, and only the wallets that voted for the winner are paid."
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-4 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NightCard, { night: lure.night }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(AutoBuy, {
							night: lure.night,
							onDone: () => {
								queryClient.invalidateQueries({ queryKey: ["lure"] });
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
							className: "rounded-card border border-line bg-panel p-4 sm:p-6",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
									className: "font-display text-lg font-bold",
									children: "Vote"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-1 text-sm text-mist",
									children: "Pick the coin you hold. Then pick a different coin. That second coin gets the vote. It costs 1 SUI. You are paid only if that coin wins."
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(XVerify, {
									pending: !mounted || sessionPending || Boolean(user && xQuery.isLoading),
									name: xQuery.data?.ok ? xQuery.data.name : null,
									profile: xQuery.data?.ok ? xQuery.data.profile : null,
									onVerified: () => {
										queryClient.invalidateQueries({ queryKey: ["x-me"] });
									},
									onError: setNote
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-display text-xs tracking-widest text-mist",
									children: "YOU HOLD"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: lure.coins.map((coin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "chip",
										"data-on": hold === coin.ticker,
										onClick: () => {
											setHold(coin.ticker);
											if (feed === coin.ticker) setFeed(null);
										},
										children: ["$", coin.ticker]
									}, `hold-${coin.ticker}`))
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-4 font-display text-xs tracking-widest text-mist",
									children: "YOU BACK"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "mt-2 flex flex-wrap gap-2",
									children: lure.coins.map((coin) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
										type: "button",
										className: "chip",
										"data-on": feed === coin.ticker,
										disabled: hold === coin.ticker,
										onClick: () => setFeed(coin.ticker),
										children: ["$", coin.ticker]
									}, `feed-${coin.ticker}`))
								}),
								alreadyVoted ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "bite-btn mt-4",
									disabled: true,
									children: "You already voted tonight"
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayVoteSlot, {
									treasury: lure.night.treasury,
									hold,
									feed,
									trench,
									ready: xReady && wait === 0,
									onResult: onPaid
								}),
								wait > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
									className: "mt-2 text-sm text-mist",
									children: [
										"Wait ",
										wait,
										"s"
									]
								}) : null,
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "mt-3 min-h-5 text-sm text-mist",
									role: "status",
									children: note
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-mist",
									children: "One vote per X account. One vote per wallet. Midnight UTC closes the night."
								})
							]
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-5 lg:grid-cols-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-card border border-line bg-deep p-4 sm:p-5 lg:col-span-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold",
							children: "Who paid"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mist",
							children: "Only wallets that voted for the winner are paid. A vote for a coin that loses still fills the pot."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ol", {
							className: "mt-2",
							children: [lure.night.voters.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
								className: "py-4 text-sm text-mist",
								children: "No one has paid tonight."
							}) : null, lure.night.voters.map((voter) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "border-b border-line py-3 text-sm",
								children: [voter.profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
									className: "text-hot underline decoration-line underline-offset-2",
									href: voter.profile,
									target: "_blank",
									rel: "noreferrer",
									children: voter.name
								}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
									className: "text-hot",
									children: voter.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "text-mist",
									children: [" voted $", voter.ticker]
								})]
							}, `${voter.wallet}-${voter.ticker}`))]
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-card border border-line bg-deep p-4 sm:p-5 lg:col-span-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-lg font-bold",
							children: "Coins"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mist",
							children: "Ranked by votes tonight. Zero can still win if the votes show up before midnight."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ol", {
							className: "mt-3 flex flex-col",
							children: lure.coins.map((coin, index) => {
								const votes = votesTonight(lure, coin.ticker);
								const backers = lure.night.voters.filter((voter) => voter.ticker === coin.ticker);
								return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
									className: "border-b border-line py-4 last:border-b-0",
									children: [
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "flex items-start justify-between gap-3",
											children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "min-w-0",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
													className: "font-display text-xl font-bold",
													children: [
														/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
															className: "mr-2 text-sm text-mist tabular-nums",
															children: String(index + 1).padStart(2, "0")
														}),
														"$",
														coin.ticker
													]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
													className: "mt-0.5 text-sm text-mist",
													children: coin.name
												})]
											}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
												className: "font-display text-sm tabular-nums text-foam",
												children: [
													votes,
													" ",
													votes === 1 ? "vote" : "votes"
												]
											})]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-2 text-sm text-mist",
											children: backers.length ? `Paid by ${backers.map((voter) => voter.name).join(", ")}` : "No paid votes tonight."
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
											className: "mt-2 h-1.5 overflow-hidden rounded-full bg-panel",
											"aria-hidden": "true",
											children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
												className: "h-full rounded-full bg-lure",
												style: { width: `${maxVotes ? votes / maxVotes * 100 : 0}%` }
											})
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
											className: "mt-3 flex flex-wrap gap-x-4 gap-y-2 text-sm",
											children: [
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
													type: "button",
													className: "min-h-11 text-lure underline decoration-line underline-offset-2",
													onClick: () => copyCa(coin),
													children: copied === coin.ticker ? "Copied" : "Copy contract"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													className: "inline-flex min-h-11 items-center text-foam underline decoration-line underline-offset-2",
													href: chartUrl(coin.contract),
													target: "_blank",
													rel: "noreferrer",
													children: "Chart"
												}),
												/* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													className: "inline-flex min-h-11 items-center text-foam underline decoration-line underline-offset-2",
													href: scanUrl(coin.contract),
													target: "_blank",
													rel: "noreferrer",
													children: "Explorer"
												}),
												coin.website ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
													className: "inline-flex min-h-11 items-center text-foam underline decoration-line underline-offset-2",
													href: coin.website,
													target: "_blank",
													rel: "noreferrer",
													children: "Site"
												}) : null
											]
										}),
										/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
											className: "mt-1 font-mono text-xs text-mist",
											children: shortCa(coin.contract)
										})
									]
								}, coin.ticker);
							})
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(HookForm, { onListed: (next, message) => {
				queryClient.setQueryData(["lure"], next);
				setNote(message);
			} })
		]
	});
}
function XVerify({ pending, name, profile, onVerified, onError }) {
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [localError, setLocalError] = (0, import_react.useState)(null);
	if (pending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "mt-4 h-11 animate-pulse rounded-full bg-deep" });
	if (name) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
		className: "mt-4 text-sm text-foam",
		children: [
			"Voting as",
			" ",
			profile ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
				className: "text-hot underline decoration-line underline-offset-2",
				href: profile,
				target: "_blank",
				rel: "noreferrer",
				children: name
			}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "text-hot",
				children: name
			}),
			". This account can vote once tonight. It costs 1 SUI."
		]
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mt-4",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "bite-btn",
			disabled: busy,
			onClick: () => {
				setLocalError(null);
				setBusy(true);
				verifyWithX().then(() => onVerified()).catch((err) => {
					const message = err instanceof Error ? err.message : "Sign-in failed.";
					setLocalError(message);
					onError(message);
				}).finally(() => setBusy(false));
			},
			children: busy ? "Waiting for X…" : "Verify with X"
		}), localError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-mist",
			role: "status",
			children: localError
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-2 text-sm text-mist",
			children: "Verify with X first. Then you can pay 1 SUI."
		})]
	});
}
function HookForm({ onListed }) {
	const [open, setOpen] = (0, import_react.useState)(false);
	const [ticker, setTicker] = (0, import_react.useState)("");
	const [contract, setContract] = (0, import_react.useState)("");
	const [name, setName] = (0, import_react.useState)("");
	const [about, setAbout] = (0, import_react.useState)("");
	const [website, setWebsite] = (0, import_react.useState)("");
	const [error, setError] = (0, import_react.useState)(null);
	const add = useMutation({
		mutationFn: () => listCoin({ data: {
			ticker,
			contract,
			name,
			about,
			website
		} }),
		onSuccess: (result) => {
			if (!result.ok) {
				setError(result.error);
				return;
			}
			setError(null);
			setTicker("");
			setContract("");
			setName("");
			setAbout("");
			setWebsite("");
			onListed(result.lure, result.already ? `$${result.ticker} is already on the board.` : `$${result.ticker} is on the board. A holder still can't vote for it.`);
		}
	});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-card border border-line bg-deep p-4 sm:p-5",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			className: "font-display text-lg font-bold",
			onClick: () => setOpen((v) => !v),
			children: open ? "Close" : "Add a coin"
		}), open ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("form", {
			className: "mt-3 flex flex-col gap-3",
			onSubmit: (event) => {
				event.preventDefault();
				add.mutate();
			},
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm text-mist",
					children: ["Ticker", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: ticker,
						onChange: (event) => setTicker(event.target.value),
						className: "mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm text-mist",
					children: ["Coin type", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: contract,
						onChange: (event) => setContract(event.target.value),
						placeholder: "0x…::module::NAME",
						className: "mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none",
						spellCheck: false
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm text-mist",
					children: ["Name", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: name,
						onChange: (event) => setName(event.target.value),
						className: "mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm text-mist",
					children: ["About", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: about,
						onChange: (event) => setAbout(event.target.value),
						className: "mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
					className: "text-sm text-mist",
					children: ["Site", /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
						value: website,
						onChange: (event) => setWebsite(event.target.value),
						placeholder: "https://",
						className: "mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
					})]
				}),
				error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-mist",
					children: error
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "submit",
					className: "bite-btn",
					disabled: add.isPending,
					children: add.isPending ? "Checking Sui…" : "Add it"
				})
			]
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-mist",
			children: "List a Sui coin so it can take votes tonight."
		})]
	});
}
function Home() {
	const initial = Route$9.useLoaderData();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HomeScreen, { initial }) });
}
//#endregion
export { Home as component, routes_Hke30nKs_exports as t };
