import { o as __toESM } from "../_runtime.mjs";
import { A as require_react, k as require_jsx_runtime } from "../_libs/@mysten/dapp-kit+[...].mjs";
import { t as Shell } from "./shell-ClKb0NLQ.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/docs-wcF6_4Ob.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function DocsScreen() {
	const [origin, setOrigin] = (0, import_react.useState)("");
	const [out, setOut] = (0, import_react.useState)("Response shows up here.");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const [copied, setCopied] = (0, import_react.useState)(null);
	const [night, setNight] = (0, import_react.useState)(null);
	(0, import_react.useEffect)(() => {
		setOrigin(window.location.origin);
		fetch("/api/v1/lure").then((res) => res.json()).then((body) => {
			if (body.night) setNight(body.night);
		}).catch(() => setOut("Couldn't reach /api/v1/lure."));
	}, []);
	const base = origin || "";
	async function copy(label, text) {
		try {
			await navigator.clipboard.writeText(text);
			setCopied(label);
			setTimeout(() => setCopied((cur) => cur === label ? null : cur), 1200);
		} catch {
			setCopied(null);
		}
	}
	async function send(path, init) {
		setBusy(true);
		try {
			const res = await fetch(path, init);
			const text = await res.text();
			let pretty = text;
			try {
				pretty = JSON.stringify(JSON.parse(text), null, 2);
			} catch {}
			setOut(`${res.status}\n${pretty}`);
		} catch {
			setOut("Request failed.");
		} finally {
			setBusy(false);
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xs tracking-widest text-mist",
					children: "THE API"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-2 font-display text-4xl font-bold sm:text-5xl",
					children: "Read the night."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 max-w-2xl text-base text-mist",
					children: "One score. A verified vote costs 1 SUI, and you cannot vote for the coin you hold. At midnight on the Sui clock the buys start: twelve of them, five minutes apart, each within 1% of the first. Only wallets that voted for the winning coin are paid, in that same transaction. The pot wallet sends the buy from the board. There is no separate payout."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "grid gap-3 sm:grid-cols-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
						n: "01",
						title: "Not your coin",
						body: "You can't vote for the coin you hold."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
						n: "02",
						title: "1 SUI",
						body: "Verify X, connect a wallet, pay 1 SUI. One vote per account and per wallet."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Rule, {
						n: "03",
						title: "Midnight",
						body: "The Sui clock opens 12 buys, five minutes apart. The pot wallet sends each one. Only the winner's voters are paid."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Endpoint, {
				method: "GET",
				path: "/api/v1/lure",
				body: "The night: pot, leader, standings, who paid, and when it closes. Coins are ranked by tonight's votes.",
				copied: copied === "lure",
				onCopy: () => copy("lure", `curl -s ${base}/api/v1/lure`)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Endpoint, {
				method: "GET",
				path: "/api/v1/tape",
				body: "Who paid tonight. Name, wallet, and the coin they voted for.",
				copied: copied === "tape",
				onCopy: () => copy("tape", `curl -s ${base}/api/v1/tape`)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Endpoint, {
				method: "GET",
				path: "/api/v1/coins",
				body: "Every coin, ranked by votes tonight.",
				copied: copied === "coins",
				onCopy: () => copy("coins", `curl -s ${base}/api/v1/coins`)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Endpoint, {
				method: "GET",
				path: "/api/v1/coins/AXOL",
				body: "One coin: name, contract, and links.",
				copied: copied === "one",
				onCopy: () => copy("one", `curl -s ${base}/api/v1/coins/AXOL`)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Endpoint, {
				method: "POST",
				path: "/api/v1/coins",
				body: "Add a Sui coin. Mainnet metadata is checked before it joins the night.",
				copied: copied === "add",
				onCopy: () => copy("add", `curl -s -X POST ${base}/api/v1/coins -H 'content-type: application/json' -d '{"ticker":"EXAMPLE","contract":"0x…::module::NAME"}'`)
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "rounded-card border border-line bg-deep p-4 sm:p-5",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-lg font-bold",
						children: "Tonight, from the API"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mist",
						children: night ? night.leader ? `$${night.leader.ticker} leads with ${night.leader.votes}. The pot is ${night.potSui} SUI.` : "No paid votes yet. The pot is empty." : "Loading the night…"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "bite-btn mt-3 sm:max-w-xs",
						disabled: busy,
						onClick: () => void send("/api/v1/lure"),
						children: busy ? "Reading…" : "GET lure"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("pre", {
						className: "mt-4 max-h-80 overflow-auto rounded-xl bg-abyss p-3 font-mono text-xs text-foam",
						children: out
					})
				]
			})
		]
	});
}
function Rule({ n, title, body }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-deep p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-sm text-lure",
				children: n
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "mt-1 font-display text-lg font-bold",
				children: title
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mist",
				children: body
			})
		]
	});
}
function Endpoint({ method, path, body, onCopy, copied, extra }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
		className: "rounded-card border border-line bg-panel p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "font-mono text-sm",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-lure",
							children: method
						}),
						" ",
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "text-foam",
							children: path
						})
					]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: "chip",
					onClick: onCopy,
					children: copied ? "Copied" : "Copy curl"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-mist",
				children: body
			}),
			extra
		]
	});
}
function Docs() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DocsScreen, {}) });
}
//#endregion
export { Docs as component };
