import { o as __toESM } from "../_runtime.mjs";
import { A as require_react, k as require_jsx_runtime } from "../_libs/@mysten/dapp-kit+[...].mjs";
import { x as useNavigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { t as Shell } from "./shell-ClKb0NLQ.mjs";
import { t as verifyWithX } from "./verify-x-DA1205uN.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-B61AnZw_.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const navigate = useNavigate();
	const [error, setError] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Shell, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "mx-auto flex w-full max-w-md flex-col gap-4 py-10",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "font-display text-xs tracking-widest text-mist",
				children: "VERIFY"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-4xl font-bold",
				children: "Sign in with X"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-mist",
				children: "A verified vote keeps your X profile on the board. Founders can open it and reward the account. The public API cannot attach a handle for you."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
				type: "button",
				className: "bite-btn",
				onClick: () => {
					setError(null);
					verifyWithX().then(() => navigate({ to: "/" })).catch((err) => {
						setError(err instanceof Error ? err.message : "Sign-in failed.");
					});
				},
				children: "Continue with X"
			}),
			error ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-sm text-mist",
				role: "status",
				children: error
			}) : null
		]
	}) });
}
//#endregion
export { Login as component };
