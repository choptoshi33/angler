//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-BOsatnpU.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/docs",
			"/login",
			"/api/verify-x",
			"/api/auth/$",
			"/api/v1/bite",
			"/api/v1/lure",
			"/api/v1/tape",
			"/api/v1/coins/$ticker",
			"/api/v1/coins/"
		],
		preloads: ["/assets/index-CUADaGP0.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-CUADaGP0.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		css: ["/assets/routes-CKt6WrJt.css"],
		preloads: [
			"/assets/routes-Cu5Y4ub4.js",
			"/assets/shell-CFiyK-sX.js",
			"/assets/verify-x-CmLpBeWc.js"
		]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: ["/assets/docs-oD3EEXz9.js", "/assets/shell-CFiyK-sX.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-ndF8NPGE.js",
			"/assets/shell-CFiyK-sX.js",
			"/assets/verify-x-CmLpBeWc.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
