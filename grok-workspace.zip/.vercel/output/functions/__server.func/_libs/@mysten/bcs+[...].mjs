//#region node_modules/@mysten/bcs/dist/uleb.mjs
function ulebEncode(num) {
	let bigNum = BigInt(num);
	const arr = [];
	let len = 0;
	if (bigNum === 0n) return [0];
	while (bigNum > 0) {
		arr[len] = Number(bigNum & 127n);
		bigNum >>= 7n;
		if (bigNum > 0n) arr[len] |= 128;
		len += 1;
	}
	return arr;
}
function ulebDecode(arr) {
	let total = 0n;
	let shift = 0n;
	let len = 0;
	while (true) {
		if (len >= arr.length) throw new Error("ULEB decode error: buffer overflow");
		const byte = arr[len];
		len += 1;
		total += BigInt(byte & 127) << shift;
		if ((byte & 128) === 0) {
			if (byte === 0 && len > 1) throw new Error("ULEB decode error: non-canonical encoding");
			break;
		}
		shift += 7n;
	}
	if (total > BigInt(Number.MAX_SAFE_INTEGER)) throw new Error("ULEB decode error: value exceeds MAX_SAFE_INTEGER");
	return {
		value: Number(total),
		length: len
	};
}
//#endregion
//#region node_modules/@mysten/bcs/dist/reader.mjs
/**
* Class used for reading BCS data chunk by chunk. Meant to be used
* by some wrapper, which will make sure that data is valid and is
* matching the desired format.
*
* @example
* // data for this example is:
* // { a: u8, b: u32, c: bool, d: u64 }
*
* let reader = new BcsReader("647f1a060001ffffe7890423c78a050102030405");
* let field1 = reader.read8();
* let field2 = reader.read32();
* let field3 = reader.read8() === '1'; // bool
* let field4 = reader.read64();
* // ....
*
* Reading vectors is another deal in bcs. To read a vector, you first need to read
* its length using {@link readULEB}. Here's an example:
* @example
* // data encoded: { field: [1, 2, 3, 4, 5] }
* let reader = new BcsReader("050102030405");
* let vec_length = reader.readULEB();
* let elements = [];
* for (let i = 0; i < vec_length; i++) {
*   elements.push(reader.read8());
* }
* console.log(elements); // [1,2,3,4,5]
*
* @param {String} data HEX-encoded data (serialized BCS)
*/
var BcsReader = class {
	/**
	* @param {Uint8Array} data Data to use as a buffer.
	*/
	constructor(data) {
		this.bytePosition = 0;
		this.dataView = new DataView(data.buffer, data.byteOffset, data.byteLength);
	}
	/**
	* Shift current cursor position by `bytes`.
	*
	* @param {Number} bytes Number of bytes to
	* @returns {this} Self for possible chaining.
	*/
	shift(bytes) {
		this.bytePosition += bytes;
		return this;
	}
	/**
	* Read U8 value from the buffer and shift cursor by 1.
	* @returns
	*/
	read8() {
		const value = this.dataView.getUint8(this.bytePosition);
		this.shift(1);
		return value;
	}
	/**
	* Read U16 value from the buffer and shift cursor by 2.
	* @returns
	*/
	read16() {
		const value = this.dataView.getUint16(this.bytePosition, true);
		this.shift(2);
		return value;
	}
	/**
	* Read U32 value from the buffer and shift cursor by 4.
	* @returns
	*/
	read32() {
		const value = this.dataView.getUint32(this.bytePosition, true);
		this.shift(4);
		return value;
	}
	/**
	* Read U64 value from the buffer and shift cursor by 8.
	* @returns
	*/
	read64() {
		const value1 = this.read32();
		const result = this.read32().toString(16) + value1.toString(16).padStart(8, "0");
		return BigInt("0x" + result).toString(10);
	}
	/**
	* Read U128 value from the buffer and shift cursor by 16.
	*/
	read128() {
		const value1 = BigInt(this.read64());
		const result = BigInt(this.read64()).toString(16) + value1.toString(16).padStart(16, "0");
		return BigInt("0x" + result).toString(10);
	}
	/**
	* Read U128 value from the buffer and shift cursor by 32.
	* @returns
	*/
	read256() {
		const value1 = BigInt(this.read128());
		const result = BigInt(this.read128()).toString(16) + value1.toString(16).padStart(32, "0");
		return BigInt("0x" + result).toString(10);
	}
	/**
	* Read `num` number of bytes from the buffer and shift cursor by `num`.
	* @param num Number of bytes to read.
	*/
	readBytes(num) {
		const start = this.bytePosition + this.dataView.byteOffset;
		const value = new Uint8Array(this.dataView.buffer, start, num);
		this.shift(num);
		return value;
	}
	/**
	* Read ULEB value - an integer of varying size. Used for enum indexes and
	* vector lengths.
	* @returns {Number} The ULEB value.
	*/
	readULEB() {
		const start = this.bytePosition + this.dataView.byteOffset;
		const { value, length } = ulebDecode(new Uint8Array(this.dataView.buffer, start));
		this.shift(length);
		return value;
	}
	/**
	* Read a BCS vector: read a length and then apply function `cb` X times
	* where X is the length of the vector, defined as ULEB in BCS bytes.
	* @param cb Callback to process elements of vector.
	* @returns {Array<Any>} Array of the resulting values, returned by callback.
	*/
	readVec(cb) {
		const length = this.readULEB();
		const result = [];
		for (let i = 0; i < length; i++) result.push(cb(this, i, length));
		return result;
	}
};
//#endregion
//#region node_modules/@scure/base/index.js
/*! scure-base - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var freeze = (fn) => Object.freeze(fn());
function isBytes(a) {
	return a instanceof Uint8Array || ArrayBuffer.isView(a) && a.constructor.name === "Uint8Array" && "BYTES_PER_ELEMENT" in a && a.BYTES_PER_ELEMENT === 1;
}
/** Asserts something is Uint8Array. */
function abytes(b) {
	if (!isBytes(b)) throw new TypeError("Uint8Array expected");
}
function isArrayOf(isString, arr) {
	if (!Array.isArray(arr)) return false;
	if (arr.length === 0) return true;
	if (isString) return arr.every((item) => typeof item === "string");
	else return arr.every((item) => Number.isSafeInteger(item));
}
function afn(input) {
	if (typeof input !== "function") throw new TypeError("function expected");
	return true;
}
function astr(label, input) {
	if (typeof input !== "string") throw new TypeError(`${label}: string expected`);
	return true;
}
function anumber(n, title = "number") {
	if (typeof n !== "number") throw new TypeError(`${title}: expected number, got ${typeof n}`);
	if (!Number.isSafeInteger(n)) throw new RangeError(`${title}: expected safe integer, got ${n}`);
}
function anumArr(label, input) {
	if (!isArrayOf(false, input)) throw new TypeError(`${label}: array of numbers expected`);
}
var powers = /* @__PURE__ */ (() => {
	let res = [];
	for (let i = 0; i < 40; i++) res.push(2 ** i);
	return res;
})();
function u8ToNumArr(u8, len = u8.length) {
	const res = new Array(len);
	for (let i = 0; i < len; i++) res[i] = u8[i];
	return res;
}
var asciiDecoder = /* @__PURE__ */ (() => {
	try {
		const decoder = new TextDecoder();
		return decoder.decode(Uint8Array.of(65, 48, 43, 127)) === "A0+" ? decoder : void 0;
	} catch (e) {
		return;
	}
})();
var B2S_CHUNK = 8192;
function charcodesToString(codes) {
	const len = codes.length;
	if (asciiDecoder !== void 0 && len >= 12) return asciiDecoder.decode(codes);
	if (len <= B2S_CHUNK) return String.fromCharCode.apply(null, codes);
	let res = "";
	for (let i = 0; i < len; i += B2S_CHUNK) res += String.fromCharCode.apply(null, codes.subarray(i, i + B2S_CHUNK));
	return res;
}
/**
* Linear 8 <-> bits regrouping (radix2Slow semantics), with Uint8Array digits and
* preallocated output.
*/
function radix2(bits) {
	anumber(bits);
	if (bits <= 0 || bits > 8) throw new RangeError("radix2: bits should be in (0..8]");
	const mask = powers[bits] - 1;
	return {
		encode: (bytes) => {
			abytes(bytes);
			const len = bytes.length;
			const res = new Uint8Array(Math.ceil(len * 8 / bits));
			let carry = 0;
			let pos = 0;
			let j = 0;
			for (let i = 0; i < len;) {
				if (i + 2 < len) {
					carry = carry << 24 | bytes[i] << 16 | bytes[i + 1] << 8 | bytes[i + 2];
					pos += 24;
					i += 3;
				} else {
					carry = (carry << 8 | bytes[i]) & 65535;
					pos += 8;
					i++;
				}
				for (;;) {
					pos -= bits;
					res[j++] = carry >> pos & mask;
					if (pos < bits) break;
				}
			}
			if (pos > 0) res[j] = carry << bits - pos & mask;
			return res;
		},
		decode: (digits) => {
			const len = digits.length;
			const res = new Uint8Array(Math.floor(len * bits / 8));
			let carry = 0;
			let pos = 0;
			let j = 0;
			for (let i = 0; i < len; i++) {
				carry = (carry << bits | digits[i]) & 65535;
				pos += bits;
				for (; pos >= 8; pos -= 8) res[j++] = carry >> pos - 8 & 255;
			}
			carry = carry << 8 - pos & 255;
			if (pos >= bits) throw new Error("Excess padding");
			if (carry > 0) throw new Error(`Non-zero padding: ${carry}`);
			return res;
		}
	};
}
/**
* Digit <-> letter mapping fused with string join (chain(alphabetSlow(letters), join(''))
* semantics), via char-code lookup tables.
*/
function alphabet(letters, aliases) {
	const len = letters.length;
	if (len > 128) throw new Error("alphabet: max 128 letters");
	const encTable = new Uint8Array(len);
	const decTable = (/* @__PURE__ */ new Int8Array(128)).fill(-1);
	for (let i = 0; i < len; i++) {
		const code = letters.charCodeAt(i);
		if (letters.codePointAt(i) !== code || code > 127) throw new Error("alphabet: single-char ASCII letters only");
		encTable[i] = code;
		decTable[code] = i;
	}
	if (aliases !== void 0) for (const alias of Object.keys(aliases)) {
		const code = alias.charCodeAt(0);
		const target = decTable[aliases[alias].charCodeAt(0)];
		if (alias.length !== 1 || code > 127 || target === void 0 || target === -1) throw new Error(`alphabet: invalid alias ${alias}`);
		decTable[code] = target;
	}
	return {
		encode: (digits) => {
			const codes = new Uint8Array(digits.length);
			for (let i = 0; i < digits.length; i++) {
				const d = digits[i];
				const code = encTable[d];
				if (code === void 0) throw new Error(`alphabet.encode: invalid digit ${d}`);
				codes[i] = code;
			}
			return charcodesToString(codes);
		},
		decode: (input) => {
			astr("decode", input);
			const slen = input.length;
			const digits = new Uint8Array(slen);
			for (let i = 0; i < slen; i++) {
				const code = input.charCodeAt(i);
				const digit = code < 128 ? decTable[code] : -1;
				if (digit === -1) throw new Error(`Unknown letter "${input[i]}". Allowed: ${letters}`);
				digits[i] = digit;
			}
			return digits;
		}
	};
}
function unsafeWrapper(fn) {
	afn(fn);
	return function(...args) {
		try {
			return fn.apply(null, args);
		} catch (e) {}
	};
}
var B58_GROUP = 656356768;
var RADIX_BASE_N_MAX_LENGTH = 65536;
var BASE_N_MAX_BYTES = 2048;
var BASE_N_MAX_CHARS = 4096;
var radixBaseN = (BASE, GROUP) => ({
	encode: (bytes) => {
		abytes(bytes);
		const blen = bytes.length;
		if (blen === 0) return /* @__PURE__ */ new Uint8Array(0);
		if (blen >= RADIX_BASE_N_MAX_LENGTH) throw new Error("invalid length");
		let zeros = 0;
		while (zeros < blen - 1 && bytes[zeros] === 0) zeros++;
		const nlimbs = Math.ceil(blen / 2);
		const limbs = new Uint16Array(nlimbs);
		const odd = blen & 1;
		if (odd) limbs[0] = bytes[0];
		for (let i = odd, j = odd; i < blen; i += 2, j++) limbs[j] = bytes[i] << 8 | bytes[i + 1];
		const groups = [];
		let pos = 0;
		while (pos < nlimbs) {
			let carry = 0;
			for (let i = pos; i < nlimbs; i++) {
				const cur = carry * 65536 + limbs[i];
				const q = Math.floor(cur / GROUP);
				carry = cur - q * GROUP;
				limbs[i] = q;
				if (q === 0 && i === pos) pos++;
			}
			groups.push(carry);
		}
		const top = groups.length - 1;
		let sig = top * 5;
		for (let v = groups[top];; v = Math.floor(v / BASE)) {
			sig++;
			if (v < BASE) break;
		}
		const res = new Uint8Array(zeros + sig);
		let j = res.length - 1;
		for (let g = 0; g < top; g++) {
			let v = groups[g];
			for (let k = 0; k < 5; k++) {
				res[j--] = v % BASE;
				v = Math.floor(v / BASE);
			}
		}
		for (let v = groups[top]; j >= zeros; v = Math.floor(v / BASE)) res[j--] = v % BASE;
		return res;
	},
	decode: (digits) => {
		abytes(digits);
		const dlen = digits.length;
		if (dlen === 0) return /* @__PURE__ */ new Uint8Array(0);
		if (dlen >= RADIX_BASE_N_MAX_LENGTH) throw new Error("invalid length");
		let zeros = 0;
		while (zeros < dlen - 1 && digits[zeros] === 0) zeros++;
		const limbs = new Uint16Array(Math.ceil(dlen * 6 / 16) + 1);
		let used = 0;
		let i = 0;
		let group = dlen % 5 || 5;
		while (i < dlen) {
			let gval = 0;
			let factor = 1;
			for (const end = i + group; i < end; i++) {
				const d = digits[i];
				if (d >= BASE) throw new Error(`invalid integer: ${d}`);
				gval = gval * BASE + d;
				factor *= BASE;
			}
			group = 5;
			let carry = gval;
			for (let k = 0; k < used; k++) {
				const cur = limbs[k] * factor + carry;
				carry = Math.floor(cur / 65536);
				limbs[k] = cur - carry * 65536;
			}
			for (; carry > 0; carry = Math.floor(carry / 65536)) limbs[used++] = carry % 65536;
		}
		const valueBytes = used === 0 ? 1 : used * 2 - (limbs[used - 1] < 256 ? 1 : 0);
		const res = new Uint8Array(zeros + valueBytes);
		let j = res.length - 1;
		for (let k = 0; k < used; k++) {
			const limb = limbs[k];
			res[j--] = limb & 255;
			if (j >= zeros) res[j--] = limb >> 8;
		}
		return res;
	}
});
var genBaseN = (radix, abc) => {
	const letters = alphabet(abc);
	return {
		encode(bytes) {
			abytes(bytes);
			if (bytes.length > BASE_N_MAX_BYTES) throw new Error("invalid length");
			return letters.encode(radix.encode(bytes));
		},
		decode(str) {
			astr("baseN.decode", str);
			if (str.length > BASE_N_MAX_CHARS) throw new Error("invalid length");
			return radix.decode(letters.decode(str));
		}
	};
};
var radix58 = /* @__PURE__ */ radixBaseN(58, B58_GROUP);
var genBase58 = (abc) => genBaseN(radix58, abc);
/**
* base58: base64 without ambigous characters +, /, 0, O, I, l.
* Quadratic (O(n^2)) - so, can't be used on large inputs.
* @example
* ```js
* const text = base58.encode(Uint8Array.from([0, 1, 2]));
* base58.decode(text);
* // => Uint8Array.from([0, 1, 2])
* ```
*/
var base58 = /* @__PURE__ */ freeze(() => genBase58("123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz"));
var BECH_ALPHABET = /* @__PURE__ */ alphabet("qpzry9x8gf2tvdw0s3jn54khce6mua7l");
var BECH_UPPERCASE_PRINTABLE = /^[\x21-\x60\x7b-\x7e]+$/;
function assertBech32Printable(label, value) {
	for (let i = 0; i < value.length; i++) {
		const c = value.charCodeAt(i);
		if (c < 33 || c > 126) throw new Error(`${label}: printable ASCII expected`);
	}
}
function wordsToU8(words) {
	const len = words.length;
	const res = new Uint8Array(len);
	for (let i = 0; i < len; i++) {
		const w = words[i];
		if (w < 0 || w >= 32) throw new Error(`alphabet.encode: invalid digit ${w}`);
		res[i] = w;
	}
	return res;
}
var POLYMOD_GENERATORS = [
	996825010,
	642813549,
	513874426,
	1027748829,
	705979059
];
function bech32Polymod(pre) {
	const b = pre >> 25;
	let chk = (pre & 33554431) << 5;
	for (let i = 0; i < POLYMOD_GENERATORS.length; i++) if ((b >> i & 1) === 1) chk ^= POLYMOD_GENERATORS[i];
	return chk;
}
function bechChecksum(prefix, words, encodingConst = 1) {
	const len = prefix.length;
	let chk = 1;
	for (let i = 0; i < len; i++) {
		const c = prefix.charCodeAt(i);
		if (c < 33 || c > 126) throw new Error(`Invalid prefix (${prefix})`);
		chk = bech32Polymod(chk) ^ c >> 5;
	}
	chk = bech32Polymod(chk);
	for (let i = 0; i < len; i++) chk = bech32Polymod(chk) ^ prefix.charCodeAt(i) & 31;
	for (let v of words) chk = bech32Polymod(chk) ^ v;
	for (let i = 0; i < 6; i++) chk = bech32Polymod(chk);
	chk ^= encodingConst;
	const sum = /* @__PURE__ */ new Uint8Array(6);
	for (let i = 0; i < 6; i++) sum[i] = chk >>> 5 * (5 - i) & 31;
	return BECH_ALPHABET.encode(sum);
}
function genBech32(encoding) {
	const ENCODING_CONST = encoding === "bech32" ? 1 : 734539939;
	const _words = radix2(5);
	const toWords = (from) => {
		abytes(from);
		const len = from.length;
		const res = new Array(Math.ceil(len * 8 / 5));
		let carry = 0;
		let pos = 0;
		let j = 0;
		for (let i = 0; i < len; i++) {
			carry = carry << 8 | from[i];
			pos += 8;
			for (; pos >= 5; pos -= 5) res[j++] = carry >> pos - 5 & 31;
		}
		if (pos > 0) res[j] = carry << 5 - pos & 31;
		return res;
	};
	const fromWords = (to) => {
		anumArr("radix2.decode", to);
		const len = to.length;
		const digits = new Uint8Array(len);
		for (let i = 0; i < len; i++) {
			const w = to[i];
			if (w < 0 || w >= 32) throw new Error(`convertRadix2: invalid word=${w}`);
			digits[i] = w;
		}
		return _words.decode(digits);
	};
	const fromWordsUnsafe = unsafeWrapper(fromWords);
	function encode(prefix, words, limit = 90) {
		astr("bech32.encode prefix", prefix);
		if (limit !== false) anumber(limit, "limit");
		if (isBytes(words)) words = u8ToNumArr(words);
		anumArr("bech32.encode", words);
		const plen = prefix.length;
		if (plen === 0) throw new TypeError(`Invalid prefix length ${plen}`);
		const actualLength = plen + 7 + words.length;
		if (limit !== false && actualLength > limit) throw new TypeError(`Length ${actualLength} exceeds limit ${limit}`);
		assertBech32Printable("bech32.encode prefix", prefix);
		const lowered = prefix.toLowerCase();
		const sum = bechChecksum(lowered, words, ENCODING_CONST);
		return `${lowered}1${BECH_ALPHABET.encode(wordsToU8(words))}${sum}`;
	}
	function decode(str, limit = 90) {
		astr("bech32.decode input", str);
		if (limit !== false) anumber(limit, "limit");
		const slen = str.length;
		if (slen < 8 || limit !== false && slen > limit) throw new TypeError(`invalid string length ${slen}, expected (8..${limit})`);
		const lowered = str.toLowerCase();
		if (str !== lowered) {
			if (!BECH_UPPERCASE_PRINTABLE.test(str)) {
				assertBech32Printable("bech32.decode input", str);
				throw new Error(`mixed-case string not allowed`);
			}
		}
		const sepIndex = lowered.lastIndexOf("1");
		if (sepIndex === 0 || sepIndex === -1) throw new Error(`invalid separator "1"`);
		const prefix = lowered.slice(0, sepIndex);
		const data = lowered.slice(sepIndex + 1);
		if (data.length < 6) throw new Error("invalid data length");
		const digits = BECH_ALPHABET.decode(data);
		const words = u8ToNumArr(digits, digits.length - 6);
		const sum = bechChecksum(prefix, words, ENCODING_CONST);
		if (!data.endsWith(sum)) throw new Error(`Invalid checksum in ${str}`);
		return {
			prefix,
			words
		};
	}
	const decodeUnsafe = unsafeWrapper(decode);
	function decodeToBytes(str, limit = 90) {
		const { prefix, words } = decode(str, limit);
		return {
			prefix,
			words,
			bytes: fromWords(words)
		};
	}
	function encodeFromBytes(prefix, bytes) {
		return encode(prefix, toWords(bytes));
	}
	return {
		encode,
		decode,
		encodeFromBytes,
		decodeToBytes,
		decodeUnsafe,
		fromWords,
		fromWordsUnsafe,
		toWords
	};
}
/**
* bech32 from BIP 173. Operates on words.
* For high-level helpers, check out {@link https://github.com/paulmillr/scure-btc-signer | scure-btc-signer}.
* @example
* Convert bytes to words, encode them, then decode back.
* ```ts
* const words = bech32.toWords(Uint8Array.from([1, 2, 3]));
* const text = bech32.encode('bc', words);
* bech32.decode(text);
* ```
*/
var bech32 = /* @__PURE__ */ freeze(() => genBech32("bech32"));
//#endregion
//#region node_modules/@mysten/utils/dist/b58.mjs
var toBase58 = (buffer) => base58.encode(buffer);
var fromBase58 = (str) => base58.decode(str);
//#endregion
//#region node_modules/@mysten/utils/dist/b64.mjs
function fromBase64(base64String) {
	return Uint8Array.from(atob(base64String), (char) => char.charCodeAt(0));
}
var CHUNK_SIZE = 8192;
function toBase64(bytes) {
	if (bytes.length < CHUNK_SIZE) return btoa(String.fromCharCode(...bytes));
	let output = "";
	for (var i = 0; i < bytes.length; i += CHUNK_SIZE) {
		const chunk = bytes.slice(i, i + CHUNK_SIZE);
		output += String.fromCharCode(...chunk);
	}
	return btoa(output);
}
//#endregion
//#region node_modules/@mysten/utils/dist/hex.mjs
function fromHex(hexStr) {
	const normalized = hexStr.startsWith("0x") ? hexStr.slice(2) : hexStr;
	const padded = normalized.length % 2 === 0 ? normalized : `0${normalized}`;
	const intArr = padded.match(/[0-9a-fA-F]{2}/g)?.map((byte) => parseInt(byte, 16)) ?? [];
	if (intArr.length !== padded.length / 2) throw new Error(`Invalid hex string ${hexStr}`);
	return Uint8Array.from(intArr);
}
function toHex(bytes) {
	return bytes.reduce((str, byte) => str + byte.toString(16).padStart(2, "0"), "");
}
//#endregion
//#region node_modules/@mysten/bcs/dist/utils.mjs
/**
* Encode data with either `hex` or `base64`.
*
* @param {Uint8Array} data Data to encode.
* @param {String} encoding Encoding to use: base64 or hex
* @returns {String} Encoded value.
*/
function encodeStr(data, encoding) {
	switch (encoding) {
		case "base58": return toBase58(data);
		case "base64": return toBase64(data);
		case "hex": return toHex(data);
		default: throw new Error("Unsupported encoding, supported values are: base64, hex");
	}
}
function splitGenericParameters(str, genericSeparators = ["<", ">"]) {
	const [left, right] = genericSeparators;
	const tok = [];
	let word = "";
	let nestedAngleBrackets = 0;
	for (let i = 0; i < str.length; i++) {
		const char = str[i];
		if (char === left) nestedAngleBrackets++;
		if (char === right) nestedAngleBrackets--;
		if (nestedAngleBrackets === 0 && char === ",") {
			tok.push(word.trim());
			word = "";
			continue;
		}
		word += char;
	}
	tok.push(word.trim());
	return tok;
}
//#endregion
//#region node_modules/@mysten/bcs/dist/writer.mjs
/**
* Class used to write BCS data into a buffer. Initializer requires
* some size of a buffer to init; default value for this buffer is 1KB.
*
* Most methods are chainable, so it is possible to write them in one go.
*
* @example
* let serialized = new BcsWriter()
*   .write8(10)
*   .write32(1000000)
*   .write64(10000001000000)
*   .hex();
*/
/**
* Set of methods that allows data encoding/decoding as standalone
* BCS value or a part of a composed structure/vector.
*/
var BcsWriter = class {
	constructor({ initialSize = 1024, maxSize = Infinity, allocateSize = 1024 } = {}) {
		this.bytePosition = 0;
		this.size = initialSize;
		this.maxSize = maxSize;
		this.allocateSize = allocateSize;
		this.dataView = new DataView(new ArrayBuffer(initialSize));
	}
	ensureSizeOrGrow(bytes) {
		const requiredSize = this.bytePosition + bytes;
		if (requiredSize > this.size) {
			const nextSize = Math.min(this.maxSize, Math.max(this.size + requiredSize, this.size + this.allocateSize));
			if (requiredSize > nextSize) throw new Error(`Attempting to serialize to BCS, but buffer does not have enough size. Allocated size: ${this.size}, Max size: ${this.maxSize}, Required size: ${requiredSize}`);
			this.size = nextSize;
			const nextBuffer = new ArrayBuffer(this.size);
			new Uint8Array(nextBuffer).set(new Uint8Array(this.dataView.buffer));
			this.dataView = new DataView(nextBuffer);
		}
	}
	/**
	* Shift current cursor position by `bytes`.
	*
	* @param {Number} bytes Number of bytes to
	* @returns {this} Self for possible chaining.
	*/
	shift(bytes) {
		this.bytePosition += bytes;
		return this;
	}
	/**
	* Write a U8 value into a buffer and shift cursor position by 1.
	* @param {Number} value Value to write.
	* @returns {this}
	*/
	write8(value) {
		this.ensureSizeOrGrow(1);
		this.dataView.setUint8(this.bytePosition, Number(value));
		return this.shift(1);
	}
	/**
	* Write a U8 value into a buffer and shift cursor position by 1.
	* @param {Number} value Value to write.
	* @returns {this}
	*/
	writeBytes(bytes) {
		this.ensureSizeOrGrow(bytes.length);
		for (let i = 0; i < bytes.length; i++) this.dataView.setUint8(this.bytePosition + i, bytes[i]);
		return this.shift(bytes.length);
	}
	/**
	* Write a U16 value into a buffer and shift cursor position by 2.
	* @param {Number} value Value to write.
	* @returns {this}
	*/
	write16(value) {
		this.ensureSizeOrGrow(2);
		this.dataView.setUint16(this.bytePosition, Number(value), true);
		return this.shift(2);
	}
	/**
	* Write a U32 value into a buffer and shift cursor position by 4.
	* @param {Number} value Value to write.
	* @returns {this}
	*/
	write32(value) {
		this.ensureSizeOrGrow(4);
		this.dataView.setUint32(this.bytePosition, Number(value), true);
		return this.shift(4);
	}
	/**
	* Write a U64 value into a buffer and shift cursor position by 8.
	* @param {bigint} value Value to write.
	* @returns {this}
	*/
	write64(value) {
		toLittleEndian(BigInt(value), 8).forEach((el) => this.write8(el));
		return this;
	}
	/**
	* Write a U128 value into a buffer and shift cursor position by 16.
	*
	* @param {bigint} value Value to write.
	* @returns {this}
	*/
	write128(value) {
		toLittleEndian(BigInt(value), 16).forEach((el) => this.write8(el));
		return this;
	}
	/**
	* Write a U256 value into a buffer and shift cursor position by 16.
	*
	* @param {bigint} value Value to write.
	* @returns {this}
	*/
	write256(value) {
		toLittleEndian(BigInt(value), 32).forEach((el) => this.write8(el));
		return this;
	}
	/**
	* Write a ULEB value into a buffer and shift cursor position by number of bytes
	* written.
	* @param {Number} value Value to write.
	* @returns {this}
	*/
	writeULEB(value) {
		ulebEncode(value).forEach((el) => this.write8(el));
		return this;
	}
	/**
	* Write a vector into a buffer by first writing the vector length and then calling
	* a callback on each passed value.
	*
	* @param {Array<Any>} vector Array of elements to write.
	* @param {WriteVecCb} cb Callback to call on each element of the vector.
	* @returns {this}
	*/
	writeVec(vector, cb) {
		this.writeULEB(vector.length);
		Array.from(vector).forEach((el, i) => cb(this, el, i, vector.length));
		return this;
	}
	/**
	* Adds support for iterations over the object.
	* @returns {Uint8Array}
	*/
	*[Symbol.iterator]() {
		for (let i = 0; i < this.bytePosition; i++) yield this.dataView.getUint8(i);
		return this.toBytes();
	}
	/**
	* Get underlying buffer taking only value bytes (in case initial buffer size was bigger).
	* @returns {Uint8Array} Resulting bcs.
	*/
	toBytes() {
		return new Uint8Array(this.dataView.buffer.slice(0, this.bytePosition));
	}
	/**
	* Represent data as 'hex' or 'base64'
	* @param encoding Encoding to use: 'base64' or 'hex'
	*/
	toString(encoding) {
		return encodeStr(this.toBytes(), encoding);
	}
};
function toLittleEndian(bigint, size) {
	const result = new Uint8Array(size);
	let i = 0;
	while (bigint > 0) {
		result[i] = Number(bigint % BigInt(256));
		bigint = bigint / BigInt(256);
		i += 1;
	}
	return result;
}
//#endregion
//#region node_modules/@mysten/bcs/dist/bcs-type.mjs
var BcsType = class BcsType {
	#write;
	#serialize;
	constructor(options) {
		this.name = options.name;
		this.read = options.read;
		this.serializedSize = options.serializedSize ?? (() => null);
		this.#write = options.write;
		this.#serialize = options.serialize ?? ((value, options$1) => {
			const writer = new BcsWriter({
				initialSize: this.serializedSize(value) ?? void 0,
				...options$1
			});
			this.#write(value, writer);
			return writer.toBytes();
		});
		this.validate = options.validate ?? (() => {});
	}
	write(value, writer) {
		this.validate(value);
		this.#write(value, writer);
	}
	serialize(value, options) {
		this.validate(value);
		return new SerializedBcs(this, this.#serialize(value, options));
	}
	parse(bytes) {
		const reader = new BcsReader(bytes);
		return this.read(reader);
	}
	fromHex(hex) {
		return this.parse(fromHex(hex));
	}
	fromBase58(b64) {
		return this.parse(fromBase58(b64));
	}
	fromBase64(b64) {
		return this.parse(fromBase64(b64));
	}
	transform({ name, input, output, validate }) {
		return new BcsType({
			name: name ?? this.name,
			read: (reader) => output ? output(this.read(reader)) : this.read(reader),
			write: (value, writer) => this.#write(input ? input(value) : value, writer),
			serializedSize: (value) => this.serializedSize(input ? input(value) : value),
			serialize: (value, options) => this.#serialize(input ? input(value) : value, options),
			validate: (value) => {
				validate?.(value);
				this.validate(input ? input(value) : value);
			}
		});
	}
};
var SERIALIZED_BCS_BRAND = Symbol.for("@mysten/serialized-bcs");
function isSerializedBcs(obj) {
	return !!obj && typeof obj === "object" && obj[SERIALIZED_BCS_BRAND] === true;
}
var SerializedBcs = class {
	#schema;
	#bytes;
	get [SERIALIZED_BCS_BRAND]() {
		return true;
	}
	constructor(schema, bytes) {
		this.#schema = schema;
		this.#bytes = bytes;
	}
	toBytes() {
		return this.#bytes;
	}
	toHex() {
		return toHex(this.#bytes);
	}
	toBase64() {
		return toBase64(this.#bytes);
	}
	toBase58() {
		return toBase58(this.#bytes);
	}
	parse() {
		return this.#schema.parse(this.#bytes);
	}
};
function fixedSizeBcsType({ size, ...options }) {
	return new BcsType({
		...options,
		serializedSize: () => size
	});
}
function uIntBcsType({ readMethod, writeMethod, ...options }) {
	return fixedSizeBcsType({
		...options,
		read: (reader) => reader[readMethod](),
		write: (value, writer) => writer[writeMethod](value),
		validate: (value) => {
			if (value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
			options.validate?.(value);
		}
	});
}
function bigUIntBcsType({ readMethod, writeMethod, ...options }) {
	return fixedSizeBcsType({
		...options,
		read: (reader) => reader[readMethod](),
		write: (value, writer) => writer[writeMethod](BigInt(value)),
		validate: (val) => {
			const value = BigInt(val);
			if (value < 0 || value > options.maxValue) throw new TypeError(`Invalid ${options.name} value: ${value}. Expected value in range 0-${options.maxValue}`);
			options.validate?.(value);
		}
	});
}
function dynamicSizeBcsType({ serialize, ...options }) {
	const type = new BcsType({
		...options,
		serialize,
		write: (value, writer) => {
			for (const byte of type.serialize(value).toBytes()) writer.write8(byte);
		}
	});
	return type;
}
function stringLikeBcsType({ toBytes, fromBytes, ...options }) {
	return new BcsType({
		...options,
		read: (reader) => {
			const length = reader.readULEB();
			return fromBytes(reader.readBytes(length));
		},
		write: (hex, writer) => {
			const bytes = toBytes(hex);
			writer.writeULEB(bytes.length);
			for (let i = 0; i < bytes.length; i++) writer.write8(bytes[i]);
		},
		serialize: (value) => {
			const bytes = toBytes(value);
			const size = ulebEncode(bytes.length);
			const result = new Uint8Array(size.length + bytes.length);
			result.set(size, 0);
			result.set(bytes, size.length);
			return result;
		},
		validate: (value) => {
			if (typeof value !== "string") throw new TypeError(`Invalid ${options.name} value: ${value}. Expected string`);
			options.validate?.(value);
		}
	});
}
function lazyBcsType(cb) {
	let lazyType = null;
	function getType() {
		if (!lazyType) lazyType = cb();
		return lazyType;
	}
	return new BcsType({
		name: "lazy",
		read: (data) => getType().read(data),
		serializedSize: (value) => getType().serializedSize(value),
		write: (value, writer) => getType().write(value, writer),
		serialize: (value, options) => getType().serialize(value, options).toBytes()
	});
}
var BcsStruct = class extends BcsType {
	constructor({ name, fields, ...options }) {
		const canonicalOrder = Object.entries(fields);
		super({
			name,
			serializedSize: (values) => {
				let total = 0;
				for (const [field, type] of canonicalOrder) {
					const size = type.serializedSize(values[field]);
					if (size == null) return null;
					total += size;
				}
				return total;
			},
			read: (reader) => {
				const result = {};
				for (const [field, type] of canonicalOrder) result[field] = type.read(reader);
				return result;
			},
			write: (value, writer) => {
				for (const [field, type] of canonicalOrder) type.write(value[field], writer);
			},
			...options,
			validate: (value) => {
				options?.validate?.(value);
				if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
			}
		});
	}
};
var BcsEnum = class extends BcsType {
	constructor({ fields, ...options }) {
		const canonicalOrder = Object.entries(fields);
		super({
			read: (reader) => {
				const index = reader.readULEB();
				const enumEntry = canonicalOrder[index];
				if (!enumEntry) throw new TypeError(`Unknown value ${index} for enum ${options.name}`);
				const [kind, type] = enumEntry;
				return {
					[kind]: type?.read(reader) ?? true,
					$kind: kind
				};
			},
			write: (value, writer) => {
				const [name, val] = Object.entries(value).filter(([name$1]) => Object.hasOwn(fields, name$1))[0];
				for (let i = 0; i < canonicalOrder.length; i++) {
					const [optionName, optionType] = canonicalOrder[i];
					if (optionName === name) {
						writer.writeULEB(i);
						optionType?.write(val, writer);
						return;
					}
				}
			},
			...options,
			validate: (value) => {
				options?.validate?.(value);
				if (typeof value !== "object" || value == null) throw new TypeError(`Expected object, found ${typeof value}`);
				const keys = Object.keys(value).filter((k) => value[k] !== void 0 && Object.hasOwn(fields, k));
				if (keys.length !== 1) throw new TypeError(`Expected object with one key, but found ${keys.length} for type ${options.name}}`);
				const [variant] = keys;
				if (!Object.hasOwn(fields, variant)) throw new TypeError(`Invalid enum variant ${variant}`);
			}
		});
	}
};
var BcsTuple = class extends BcsType {
	constructor({ fields, name, ...options }) {
		super({
			name: name ?? `(${fields.map((t) => t.name).join(", ")})`,
			serializedSize: (values) => {
				let total = 0;
				for (let i = 0; i < fields.length; i++) {
					const size = fields[i].serializedSize(values[i]);
					if (size == null) return null;
					total += size;
				}
				return total;
			},
			read: (reader) => {
				const result = [];
				for (const field of fields) result.push(field.read(reader));
				return result;
			},
			write: (value, writer) => {
				for (let i = 0; i < fields.length; i++) fields[i].write(value[i], writer);
			},
			...options,
			validate: (value) => {
				options?.validate?.(value);
				if (!Array.isArray(value)) throw new TypeError(`Expected array, found ${typeof value}`);
				if (value.length !== fields.length) throw new TypeError(`Expected array of length ${fields.length}, found ${value.length}`);
			}
		});
	}
};
//#endregion
//#region node_modules/@mysten/bcs/dist/bcs.mjs
function fixedArray(size, type, options) {
	return new BcsType({
		read: (reader) => {
			const result = new Array(size);
			for (let i = 0; i < size; i++) result[i] = type.read(reader);
			return result;
		},
		write: (value, writer) => {
			for (const item of value) type.write(item, writer);
		},
		...options,
		name: options?.name ?? `${type.name}[${size}]`,
		validate: (value) => {
			options?.validate?.(value);
			if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
			if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
		}
	});
}
function option(type) {
	return bcs.enum(`Option<${type.name}>`, {
		None: null,
		Some: type
	}).transform({
		input: (value) => {
			if (value == null) return { None: true };
			return { Some: value };
		},
		output: (value) => {
			if (value.$kind === "Some") return value.Some;
			return null;
		}
	});
}
function vector(type, options) {
	return new BcsType({
		read: (reader) => {
			const length = reader.readULEB();
			const result = new Array(length);
			for (let i = 0; i < length; i++) result[i] = type.read(reader);
			return result;
		},
		write: (value, writer) => {
			writer.writeULEB(value.length);
			for (const item of value) type.write(item, writer);
		},
		...options,
		name: options?.name ?? `vector<${type.name}>`,
		validate: (value) => {
			options?.validate?.(value);
			if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
		}
	});
}
/**
* Compares two byte arrays using lexicographic ordering.
* This matches Rust's Ord implementation for Vec<u8>/[u8] which is used for BTreeMap key ordering.
* Comparison is done byte-by-byte first, then by length if all compared bytes are equal.
*/
function compareBcsBytes(a, b) {
	for (let i = 0; i < Math.min(a.length, b.length); i++) if (a[i] !== b[i]) return a[i] - b[i];
	return a.length - b.length;
}
function map(keyType, valueType) {
	return new BcsType({
		name: `Map<${keyType.name}, ${valueType.name}>`,
		read: (reader) => {
			const length = reader.readULEB();
			const result = /* @__PURE__ */ new Map();
			for (let i = 0; i < length; i++) result.set(keyType.read(reader), valueType.read(reader));
			return result;
		},
		write: (value, writer) => {
			const entries = [...value.entries()].map(([key, val]) => [keyType.serialize(key).toBytes(), val]);
			entries.sort(([a], [b]) => compareBcsBytes(a, b));
			writer.writeULEB(entries.length);
			for (const [keyBytes, val] of entries) {
				writer.writeBytes(keyBytes);
				valueType.write(val, writer);
			}
		}
	});
}
var bcs = {
	u8(options) {
		return uIntBcsType({
			readMethod: "read8",
			writeMethod: "write8",
			size: 1,
			maxValue: 255,
			...options,
			name: options?.name ?? "u8"
		});
	},
	u16(options) {
		return uIntBcsType({
			readMethod: "read16",
			writeMethod: "write16",
			size: 2,
			maxValue: 2 ** 16 - 1,
			...options,
			name: options?.name ?? "u16"
		});
	},
	u32(options) {
		return uIntBcsType({
			readMethod: "read32",
			writeMethod: "write32",
			size: 4,
			maxValue: 2 ** 32 - 1,
			...options,
			name: options?.name ?? "u32"
		});
	},
	u64(options) {
		return bigUIntBcsType({
			readMethod: "read64",
			writeMethod: "write64",
			size: 8,
			maxValue: 2n ** 64n - 1n,
			...options,
			name: options?.name ?? "u64"
		});
	},
	u128(options) {
		return bigUIntBcsType({
			readMethod: "read128",
			writeMethod: "write128",
			size: 16,
			maxValue: 2n ** 128n - 1n,
			...options,
			name: options?.name ?? "u128"
		});
	},
	u256(options) {
		return bigUIntBcsType({
			readMethod: "read256",
			writeMethod: "write256",
			size: 32,
			maxValue: 2n ** 256n - 1n,
			...options,
			name: options?.name ?? "u256"
		});
	},
	bool(options) {
		return fixedSizeBcsType({
			size: 1,
			read: (reader) => {
				const value = reader.read8();
				if (value > 1) throw new TypeError(`Invalid bool value: expected 0 or 1, found ${value}`);
				return value === 1;
			},
			write: (value, writer) => writer.write8(value ? 1 : 0),
			...options,
			name: options?.name ?? "bool",
			validate: (value) => {
				options?.validate?.(value);
				if (typeof value !== "boolean") throw new TypeError(`Expected boolean, found ${typeof value}`);
			}
		});
	},
	uleb128(options) {
		return dynamicSizeBcsType({
			read: (reader) => reader.readULEB(),
			serialize: (value) => {
				return Uint8Array.from(ulebEncode(value));
			},
			...options,
			name: options?.name ?? "uleb128"
		});
	},
	bytes(size, options) {
		return fixedSizeBcsType({
			size,
			read: (reader) => reader.readBytes(size),
			write: (value, writer) => {
				writer.writeBytes(new Uint8Array(value));
			},
			...options,
			name: options?.name ?? `bytes[${size}]`,
			validate: (value) => {
				options?.validate?.(value);
				if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
				if (value.length !== size) throw new TypeError(`Expected array of length ${size}, found ${value.length}`);
			}
		});
	},
	byteVector(options) {
		return new BcsType({
			read: (reader) => {
				const length = reader.readULEB();
				return reader.readBytes(length);
			},
			write: (value, writer) => {
				const array = new Uint8Array(value);
				writer.writeULEB(array.length);
				writer.writeBytes(array);
			},
			...options,
			name: options?.name ?? "vector<u8>",
			serializedSize: (value) => {
				const length = "length" in value ? value.length : null;
				return length == null ? null : ulebEncode(length).length + length;
			},
			validate: (value) => {
				options?.validate?.(value);
				if (!value || typeof value !== "object" || !("length" in value)) throw new TypeError(`Expected array, found ${typeof value}`);
			}
		});
	},
	string(options) {
		return stringLikeBcsType({
			toBytes: (value) => new TextEncoder().encode(value),
			fromBytes: (bytes) => new TextDecoder("utf-8", {
				fatal: true,
				ignoreBOM: true
			}).decode(bytes),
			...options,
			name: options?.name ?? "string"
		});
	},
	fixedArray,
	option,
	vector,
	tuple(fields, options) {
		return new BcsTuple({
			fields,
			...options
		});
	},
	struct(name, fields, options) {
		return new BcsStruct({
			name,
			fields,
			...options
		});
	},
	enum(name, fields, options) {
		return new BcsEnum({
			name,
			fields,
			...options
		});
	},
	map,
	lazy(cb) {
		return lazyBcsType(cb);
	}
};
//#endregion
export { toHex as a, fromBase58 as c, fromHex as i, toBase58 as l, isSerializedBcs as n, fromBase64 as o, splitGenericParameters as r, toBase64 as s, bcs as t, bech32 as u };
