import { a as __toCommonJS, n as __esmMin, o as __toESM, r as __exportAll, t as __commonJSMin } from "../../_runtime.mjs";
import { $ as picklist, A as concatBytes$1, B as bigint, C as aexists, D as bytesToHex$1, E as aoutput, F as kdfInputToBytes, G as lazy, H as check, I as oidNist, J as nullish, K as literal, L as randomBytes$1, M as createView, N as hexToBytes$1, O as checkOpts, P as isBytes$1, Q as parse$2, R as rotr, S as abytes$1, T as anumber$1, U as integer, V as boolean, W as is, X as object, Y as number, Z as optional, _ as rotrSH, _t as fromBase64, a as Maj, at as tuple, b as shrSL, bt as toBase58, c as add, ct as uuid, d as add4H, dt as isSerializedBcs, et as pipe, f as add4L, ft as splitGenericParameters, g as rotrBL, gt as toHex, h as rotrBH, ht as fromHex, i as HashMD, it as transform, j as createHasher, k as clean, l as add3H, lt as variant, m as add5L, mt as chunk, n as blake2b, nt as safeParse, o as SHA256_IV, ot as union, p as add5H, pt as DataLoader, q as nullable, r as Chi, rt as string, s as SHA512_IV, st as unknown, tt as record, u as add3L, ut as bcs, v as rotrSL, vt as toBase64, w as ahash, x as split, xt as bech32, y as shrSH, yt as fromBase58, z as array } from "../@cetusprotocol/aggregator-sdk+[...].mjs";
import { U as decodeJwt } from "../@better-auth/core+[...].mjs";
import { t as require_emotion_hash_cjs } from "../emotion__hash.mjs";
import { __assign, __rest, __spreadArray } from "tslib";
//#region node_modules/@mysten/sui/dist/utils/suins.mjs
var SUI_NS_NAME_REGEX = /^(?!.*(^(?!@)|[-.@])($|[-.@]))(?:[a-z0-9-]{0,63}(?:\.[a-z0-9-]{0,63})*)?@[a-z0-9-]{0,63}$/i;
var SUI_NS_DOMAIN_REGEX = /^(?!.*(^|[-.])($|[-.]))(?:[a-z0-9-]{0,63}\.)+sui$/i;
var MAX_SUI_NS_NAME_LENGTH = 235;
function isValidSuiNSName(name) {
	if (name.length > MAX_SUI_NS_NAME_LENGTH) return false;
	if (name.includes("@")) return SUI_NS_NAME_REGEX.test(name);
	return SUI_NS_DOMAIN_REGEX.test(name);
}
function normalizeSuiNSName(name, format = "at") {
	const lowerCase = name.toLowerCase();
	let parts;
	if (lowerCase.includes("@")) {
		if (!SUI_NS_NAME_REGEX.test(lowerCase)) throw new Error(`Invalid SuiNS name ${name}`);
		const [labels, domain] = lowerCase.split("@");
		parts = [...labels ? labels.split(".") : [], domain];
	} else {
		if (!SUI_NS_DOMAIN_REGEX.test(lowerCase)) throw new Error(`Invalid SuiNS name ${name}`);
		parts = lowerCase.split(".").slice(0, -1);
	}
	if (format === "dot") return `${parts.join(".")}.sui`;
	return `${parts.slice(0, -1).join(".")}@${parts[parts.length - 1]}`;
}
//#endregion
//#region node_modules/@mysten/sui/dist/utils/named-packages.mjs
/** The pattern to find an optionally versioned name */
var NAME_PATTERN = /^([a-z0-9]+(?:-[a-z0-9]+)*)$/;
/** The pattern for a valid version number */
var VERSION_REGEX = /^\d+$/;
/** The maximum size for an app */
var MAX_APP_SIZE = 64;
var isValidNamedPackage = (name) => {
	const parts = name.split("/");
	if (parts.length < 2 || parts.length > 3) return false;
	const [org, app, version] = parts;
	if (version !== void 0 && !VERSION_REGEX.test(version)) return false;
	if (!isValidSuiNSName(org)) return false;
	return NAME_PATTERN.test(app) && app.length < MAX_APP_SIZE;
};
//#endregion
//#region node_modules/@mysten/utils/dist/with-resolver.mjs
function promiseWithResolvers() {
	let resolver;
	let rejecter;
	return {
		promise: new Promise((resolve, reject) => {
			resolver = resolve;
			rejecter = reject;
		}),
		resolve: resolver,
		reject: rejecter
	};
}
//#endregion
//#region node_modules/@mysten/utils/dist/mitt.mjs
/**
* Mitt: Tiny (~200b) functional event emitter / pubsub.
* @name mitt
* @returns {Mitt}
*/
function mitt(all) {
	all = all || /* @__PURE__ */ new Map();
	return {
		all,
		on(type, handler) {
			const handlers = all.get(type);
			if (handlers) handlers.push(handler);
			else all.set(type, [handler]);
		},
		off(type, handler) {
			const handlers = all.get(type);
			if (handlers) if (handler) handlers.splice(handlers.indexOf(handler) >>> 0, 1);
			else all.set(type, []);
		},
		emit(type, evt) {
			let handlers = all.get(type);
			if (handlers) handlers.slice().map((handler) => {
				handler(evt);
			});
			handlers = all.get("*");
			if (handlers) handlers.slice().map((handler) => {
				handler(type, evt);
			});
		}
	};
}
//#endregion
//#region node_modules/@mysten/sui/dist/utils/sui-types.mjs
var TX_DIGEST_LENGTH = 32;
/** Returns whether the tx digest is valid based on the serialization format */
function isValidTransactionDigest(value) {
	try {
		return fromBase58(value).length === TX_DIGEST_LENGTH;
	} catch {
		return false;
	}
}
function isValidSuiAddress(value) {
	return isHex(value) && getHexByteLength(value) === 32;
}
function isValidSuiObjectId(value) {
	return isValidSuiAddress(value);
}
var MOVE_IDENTIFIER_REGEX = /^[a-zA-Z][a-zA-Z0-9_]*$/;
function isValidMoveIdentifier(name) {
	return MOVE_IDENTIFIER_REGEX.test(name);
}
var PRIMITIVE_TYPE_TAGS = [
	"bool",
	"u8",
	"u16",
	"u32",
	"u64",
	"u128",
	"u256",
	"address",
	"signer"
];
var VECTOR_TYPE_REGEX = /^vector<(.+)>$/;
function isValidTypeTag(type) {
	if (PRIMITIVE_TYPE_TAGS.includes(type)) return true;
	const vectorMatch = type.match(VECTOR_TYPE_REGEX);
	if (vectorMatch) return isValidTypeTag(vectorMatch[1]);
	if (type.includes("::")) return isValidStructTag(type);
	return false;
}
function isValidParsedStructTag(tag) {
	if (!isValidSuiAddress(tag.address) && !isValidNamedPackage(tag.address)) return false;
	if (!isValidMoveIdentifier(tag.module) || !isValidMoveIdentifier(tag.name)) return false;
	return tag.typeParams.every((param) => {
		if (typeof param === "string") return isValidTypeTag(param);
		return isValidParsedStructTag(param);
	});
}
function isValidStructTag(type) {
	try {
		return isValidParsedStructTag(parseStructTag(type));
	} catch {
		return false;
	}
}
function parseTypeTag(type) {
	if (type.startsWith("vector<")) {
		if (!type.endsWith(">")) throw new Error(`Invalid type tag: ${type}`);
		const inner = type.slice(7, -1);
		if (!inner) throw new Error(`Invalid type tag: ${type}`);
		const parsed = parseTypeTag(inner);
		if (typeof parsed === "string") return `vector<${parsed}>`;
		return `vector<${normalizeStructTag(parsed)}>`;
	}
	if (!type.includes("::")) return type;
	return parseStructTag(type);
}
function parseStructTag(type) {
	const parts = type.split("::");
	if (parts.length < 3) throw new Error(`Invalid struct tag: ${type}`);
	const [address, module] = parts;
	if (!address || !module) throw new Error(`Invalid struct tag: ${type}`);
	const isMvrPackage = isValidNamedPackage(address);
	const rest = type.slice(address.length + module.length + 4);
	const name = rest.includes("<") ? rest.slice(0, rest.indexOf("<")) : rest;
	if (!name || rest.includes("<") && !rest.endsWith(">")) throw new Error(`Invalid struct tag: ${type}`);
	const typeParams = rest.includes("<") ? splitGenericParameters(rest.slice(rest.indexOf("<") + 1, rest.lastIndexOf(">"))).map((typeParam) => parseTypeTag(typeParam.trim())) : [];
	return {
		address: isMvrPackage ? address : normalizeSuiAddress(address),
		module,
		name,
		typeParams
	};
}
function normalizeStructTag(type) {
	if (typeof type === "string" && type.startsWith("vector<")) throw new Error("normalizeStructTag does not support vector types. Use normalizeTypeTag instead.");
	const { address, module, name, typeParams } = typeof type === "string" ? parseStructTag(type) : type;
	return `${address}::${module}::${name}${typeParams?.length > 0 ? `<${typeParams.map((typeParam) => typeof typeParam === "string" ? typeParam : normalizeStructTag(typeParam)).join(",")}>` : ""}`;
}
/**
* Perform the following operations:
* 1. Make the address lower case
* 2. Prepend `0x` if the string does not start with `0x`.
* 3. Add more zeros if the length of the address(excluding `0x`) is less than `SUI_ADDRESS_LENGTH`
*
* WARNING: if the address value itself starts with `0x`, e.g., `0x0x`, the default behavior
* is to treat the first `0x` not as part of the address. The default behavior can be overridden by
* setting `forceAdd0x` to true
*
*/
function normalizeSuiAddress(value, forceAdd0x = false) {
	let address = value.toLowerCase();
	if (!forceAdd0x && address.startsWith("0x")) address = address.slice(2);
	return `0x${address.padStart(64, "0")}`;
}
function normalizeSuiObjectId(value, forceAdd0x = false) {
	return normalizeSuiAddress(value, forceAdd0x);
}
function isHex(value) {
	return /^(0x|0X)?[a-fA-F0-9]+$/.test(value) && value.length % 2 === 0;
}
function getHexByteLength(value) {
	return /^(0x|0X)/.test(value) ? (value.length - 2) / 2 : value.length / 2;
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/data/internal.mjs
function safeEnum(options) {
	const schemas = Object.keys(options).map((key) => object({
		[key]: options[key],
		$kind: literal(key)
	}));
	return pipe(unknown(), check((input) => unsupportedEnumVariantMessage(input, options) === void 0, ({ input, message }) => unsupportedEnumVariantMessage(input, options) ?? message), transform(addMissingEnumKind), variant("$kind", schemas));
}
function getEnumKind(input) {
	if (typeof input !== "object" || input === null) return null;
	if ("$kind" in input && typeof input.$kind === "string") return input.$kind;
	return Object.keys(input).find((key) => key !== "$kind") ?? null;
}
function addMissingEnumKind(input) {
	if (typeof input !== "object" || input === null || "$kind" in input) return input;
	const kind = getEnumKind(input);
	return kind === null ? input : {
		...input,
		$kind: kind
	};
}
function unsupportedEnumVariantMessage(input, options) {
	const kind = getEnumKind(input);
	if (kind === null || Object.hasOwn(options, kind)) return void 0;
	return `Unsupported enum variant "${kind}". Expected one of: ${Object.keys(options).map((key) => `"${key}"`).join(", ")}.`;
}
function withKind(key, schema) {
	return pipe(object({
		...schema.entries,
		$kind: optional(literal(key))
	}), transform((value) => ({
		...value,
		$kind: key
	})));
}
var SuiAddress = pipe(string(), transform((value) => normalizeSuiAddress(value)), check(isValidSuiAddress));
var ObjectID = SuiAddress;
var BCSBytes = string();
var JsonU64 = pipe(union([string(), pipe(number(), integer())]), check((val) => {
	try {
		BigInt(val);
		return BigInt(val) >= 0 && BigInt(val) <= 18446744073709551615n;
	} catch {
		return false;
	}
}, "Invalid u64"));
var U32 = pipe(number(), integer(), check((val) => val >= 0 && val < 2 ** 32, "Invalid u32"));
var ObjectRefSchema = object({
	objectId: SuiAddress,
	version: JsonU64,
	digest: string()
});
var ArgumentSchema = union([
	withKind("GasCoin", object({ GasCoin: literal(true) })),
	withKind("Input", object({
		Input: pipe(number(), integer()),
		type: optional(union([
			literal("pure"),
			literal("object"),
			literal("withdrawal")
		]))
	})),
	withKind("Result", object({ Result: pipe(number(), integer()) })),
	withKind("NestedResult", object({ NestedResult: tuple([pipe(number(), integer()), pipe(number(), integer())]) }))
]);
var GasDataSchema = object({
	budget: nullable(JsonU64),
	price: nullable(JsonU64),
	owner: nullable(SuiAddress),
	payment: nullable(array(ObjectRefSchema))
});
object({
	address: string(),
	module: string(),
	name: string(),
	typeParams: array(string())
});
var OpenSignatureBodySchema = union([
	object({ $kind: literal("address") }),
	object({ $kind: literal("bool") }),
	object({ $kind: literal("u8") }),
	object({ $kind: literal("u16") }),
	object({ $kind: literal("u32") }),
	object({ $kind: literal("u64") }),
	object({ $kind: literal("u128") }),
	object({ $kind: literal("u256") }),
	object({ $kind: literal("unknown") }),
	object({
		$kind: literal("vector"),
		vector: lazy(() => OpenSignatureBodySchema)
	}),
	object({
		$kind: literal("datatype"),
		datatype: object({
			typeName: string(),
			typeParameters: array(lazy(() => OpenSignatureBodySchema))
		})
	}),
	object({
		$kind: literal("typeParameter"),
		index: pipe(number(), integer())
	})
]);
var OpenSignatureSchema = object({
	reference: nullable(union([
		literal("mutable"),
		literal("immutable"),
		literal("unknown")
	])),
	body: OpenSignatureBodySchema
});
var ProgrammableMoveCallSchema = object({
	package: ObjectID,
	module: string(),
	function: string(),
	typeArguments: array(string()),
	arguments: array(ArgumentSchema),
	_argumentTypes: optional(nullable(array(OpenSignatureSchema)))
});
var $Intent$1 = object({
	name: string(),
	inputs: record(string(), union([ArgumentSchema, array(ArgumentSchema)])),
	data: record(string(), unknown())
});
var CommandSchema = safeEnum({
	MoveCall: ProgrammableMoveCallSchema,
	TransferObjects: object({
		objects: array(ArgumentSchema),
		address: ArgumentSchema
	}),
	SplitCoins: object({
		coin: ArgumentSchema,
		amounts: array(ArgumentSchema)
	}),
	MergeCoins: object({
		destination: ArgumentSchema,
		sources: array(ArgumentSchema)
	}),
	Publish: object({
		modules: array(BCSBytes),
		dependencies: array(ObjectID)
	}),
	MakeMoveVec: object({
		type: nullable(string()),
		elements: array(ArgumentSchema)
	}),
	Upgrade: object({
		modules: array(BCSBytes),
		dependencies: array(ObjectID),
		package: ObjectID,
		ticket: ArgumentSchema
	}),
	$Intent: $Intent$1
});
var ObjectArgSchema = safeEnum({
	ImmOrOwnedObject: ObjectRefSchema,
	SharedObject: object({
		objectId: ObjectID,
		initialSharedVersion: JsonU64,
		mutable: boolean()
	}),
	Receiving: ObjectRefSchema
});
var ReservationSchema = safeEnum({ MaxAmountU64: JsonU64 });
var WithdrawalTypeArgSchema = safeEnum({ Balance: string() });
var WithdrawFromSchema = safeEnum({
	Sender: literal(true),
	Sponsor: literal(true),
	SenderAllowance: object({
		funder: SuiAddress,
		allowance: ObjectID
	})
});
var FundsWithdrawalArgSchema = object({
	reservation: ReservationSchema,
	typeArg: WithdrawalTypeArgSchema,
	withdrawFrom: WithdrawFromSchema
});
var CallArgSchema = safeEnum({
	Object: ObjectArgSchema,
	Pure: object({ bytes: BCSBytes }),
	UnresolvedPure: object({ value: unknown() }),
	UnresolvedObject: object({
		objectId: ObjectID,
		version: optional(nullable(JsonU64)),
		digest: optional(nullable(string())),
		initialSharedVersion: optional(nullable(JsonU64)),
		mutable: optional(nullable(boolean()))
	}),
	FundsWithdrawal: FundsWithdrawalArgSchema
});
var NormalizedCallArg$1 = safeEnum({
	Object: ObjectArgSchema,
	Pure: object({ bytes: BCSBytes })
});
var ValidDuringSchema = object({
	minEpoch: nullable(JsonU64),
	maxEpoch: nullable(JsonU64),
	minTimestamp: nullable(JsonU64),
	maxTimestamp: nullable(JsonU64),
	chain: string(),
	nonce: U32
});
var AllowedProposersSchema = object({
	epoch: JsonU64,
	proposers: pipe(array(U32), check((proposers) => proposers.length > 0, "Allowed proposers must not be empty"))
});
var ValiditySchema = object({
	...ValidDuringSchema.entries,
	allowedProposers: nullable(AllowedProposersSchema)
});
var TransactionExpiration$3 = safeEnum({
	None: literal(true),
	Epoch: JsonU64,
	ValidDuring: ValidDuringSchema,
	Validity: ValiditySchema
});
var TransactionDataSchema = object({
	version: literal(2),
	sender: nullish(SuiAddress),
	expiration: nullish(TransactionExpiration$3),
	gasData: GasDataSchema,
	inputs: array(CallArgSchema),
	commands: array(CommandSchema)
});
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/utils.mjs
function getIdFromCallArg(arg) {
	if (typeof arg === "string") return normalizeSuiAddress(arg);
	if (arg.Object) {
		if (arg.Object.ImmOrOwnedObject) return normalizeSuiAddress(arg.Object.ImmOrOwnedObject.objectId);
		if (arg.Object.Receiving) return normalizeSuiAddress(arg.Object.Receiving.objectId);
		return normalizeSuiAddress(arg.Object.SharedObject.objectId);
	}
	if (arg.UnresolvedObject) return normalizeSuiAddress(arg.UnresolvedObject.objectId);
}
function remapCommandArguments(command, inputMapping, commandMapping) {
	const remapArg = (arg) => {
		switch (arg.$kind) {
			case "Input": {
				const newInputIndex = inputMapping.get(arg.Input);
				if (newInputIndex === void 0) throw new Error(`Input ${arg.Input} not found in input mapping`);
				return {
					...arg,
					Input: newInputIndex
				};
			}
			case "Result": {
				const newCommandIndex = commandMapping.get(arg.Result);
				if (newCommandIndex !== void 0) return {
					...arg,
					Result: newCommandIndex
				};
				return arg;
			}
			case "NestedResult": {
				const newCommandIndex = commandMapping.get(arg.NestedResult[0]);
				if (newCommandIndex !== void 0) return {
					...arg,
					NestedResult: [newCommandIndex, arg.NestedResult[1]]
				};
				return arg;
			}
			default: return arg;
		}
	};
	switch (command.$kind) {
		case "MoveCall":
			command.MoveCall.arguments = command.MoveCall.arguments.map(remapArg);
			break;
		case "TransferObjects":
			command.TransferObjects.objects = command.TransferObjects.objects.map(remapArg);
			command.TransferObjects.address = remapArg(command.TransferObjects.address);
			break;
		case "SplitCoins":
			command.SplitCoins.coin = remapArg(command.SplitCoins.coin);
			command.SplitCoins.amounts = command.SplitCoins.amounts.map(remapArg);
			break;
		case "MergeCoins":
			command.MergeCoins.destination = remapArg(command.MergeCoins.destination);
			command.MergeCoins.sources = command.MergeCoins.sources.map(remapArg);
			break;
		case "MakeMoveVec":
			command.MakeMoveVec.elements = command.MakeMoveVec.elements.map(remapArg);
			break;
		case "Upgrade":
			command.Upgrade.ticket = remapArg(command.Upgrade.ticket);
			break;
		case "$Intent": {
			const inputs = command.$Intent.inputs;
			command.$Intent.inputs = {};
			for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map(remapArg) : remapArg(value);
			break;
		}
	}
}
//#endregion
//#region node_modules/@mysten/sui/dist/bcs/type-tag-serializer.mjs
var VECTOR_REGEX = /^vector<(.+)>$/;
var STRUCT_REGEX = /^([^:]+)::([^:]+)::([^<]+)(<(.+)>)?/;
var TypeTagSerializer = class TypeTagSerializer {
	static parseFromStr(str, normalizeAddress = false) {
		if (str === "address") return { address: null };
		else if (str === "bool") return { bool: null };
		else if (str === "u8") return { u8: null };
		else if (str === "u16") return { u16: null };
		else if (str === "u32") return { u32: null };
		else if (str === "u64") return { u64: null };
		else if (str === "u128") return { u128: null };
		else if (str === "u256") return { u256: null };
		else if (str === "signer") return { signer: null };
		const vectorMatch = str.match(VECTOR_REGEX);
		if (vectorMatch) return { vector: TypeTagSerializer.parseFromStr(vectorMatch[1], normalizeAddress) };
		const structMatch = str.match(STRUCT_REGEX);
		if (structMatch) return { struct: {
			address: normalizeAddress ? normalizeSuiAddress(structMatch[1]) : structMatch[1],
			module: structMatch[2],
			name: structMatch[3],
			typeParams: structMatch[5] === void 0 ? [] : TypeTagSerializer.parseStructTypeArgs(structMatch[5], normalizeAddress)
		} };
		throw new Error(`Encountered unexpected token when parsing type args for ${str}`);
	}
	static parseStructTypeArgs(str, normalizeAddress = false) {
		return splitGenericParameters(str).map((tok) => TypeTagSerializer.parseFromStr(tok, normalizeAddress));
	}
	static tagToString(tag) {
		if ("bool" in tag) return "bool";
		if ("u8" in tag) return "u8";
		if ("u16" in tag) return "u16";
		if ("u32" in tag) return "u32";
		if ("u64" in tag) return "u64";
		if ("u128" in tag) return "u128";
		if ("u256" in tag) return "u256";
		if ("address" in tag) return "address";
		if ("signer" in tag) return "signer";
		if ("vector" in tag) return `vector<${TypeTagSerializer.tagToString(tag.vector)}>`;
		if ("struct" in tag) {
			const struct = tag.struct;
			const typeParams = struct.typeParams.map(TypeTagSerializer.tagToString).join(", ");
			return `${struct.address}::${struct.module}::${struct.name}${typeParams ? `<${typeParams}>` : ""}`;
		}
		throw new Error("Invalid TypeTag");
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/bcs/bcs.mjs
function unsafe_u64(options) {
	return bcs.u64({
		name: "unsafe_u64",
		...options
	}).transform({
		input: (val) => val,
		output: (val) => Number(val)
	});
}
function optionEnum(type) {
	return bcs.enum("Option", {
		None: null,
		Some: type
	});
}
var Address = bcs.bytes(32).transform({
	validate: (val) => {
		const address = typeof val === "string" ? val : toHex(val);
		if (!address || !isValidSuiAddress(normalizeSuiAddress(address))) throw new Error(`Invalid Sui address ${address}`);
	},
	input: (val) => typeof val === "string" ? fromHex(normalizeSuiAddress(val)) : val,
	output: (val) => normalizeSuiAddress(toHex(val))
});
var ObjectDigest = bcs.byteVector().transform({
	name: "ObjectDigest",
	input: (value) => fromBase58(value),
	output: (value) => toBase58(new Uint8Array(value)),
	validate: (value) => {
		if (fromBase58(value).length !== 32) throw new Error("ObjectDigest must be 32 bytes");
	}
});
var SuiObjectRef = bcs.struct("SuiObjectRef", {
	objectId: Address,
	version: bcs.u64(),
	digest: ObjectDigest
});
var SharedObjectRef = bcs.struct("SharedObjectRef", {
	objectId: Address,
	initialSharedVersion: bcs.u64(),
	mutable: bcs.bool()
});
var ObjectArg$1 = bcs.enum("ObjectArg", {
	ImmOrOwnedObject: SuiObjectRef,
	SharedObject: SharedObjectRef,
	Receiving: SuiObjectRef
});
var Owner = bcs.enum("Owner", {
	AddressOwner: Address,
	ObjectOwner: Address,
	Shared: bcs.struct("Shared", { initialSharedVersion: bcs.u64() }),
	Immutable: null,
	ConsensusAddressOwner: bcs.struct("ConsensusAddressOwner", {
		startVersion: bcs.u64(),
		owner: Address
	})
});
var Reservation = bcs.enum("Reservation", { MaxAmountU64: bcs.u64() });
var WithdrawalType = bcs.enum("WithdrawalType", { Balance: bcs.lazy(() => TypeTag$1) });
var WithdrawFrom = bcs.enum("WithdrawFrom", {
	Sender: null,
	Sponsor: null,
	SenderAllowance: bcs.struct("SenderAllowance", {
		funder: Address,
		allowance: Address
	})
});
var FundsWithdrawal = bcs.struct("FundsWithdrawal", {
	reservation: Reservation,
	typeArg: WithdrawalType,
	withdrawFrom: WithdrawFrom
});
var CallArg$1 = bcs.enum("CallArg", {
	Pure: bcs.struct("Pure", { bytes: bcs.byteVector().transform({
		input: (val) => typeof val === "string" ? fromBase64(val) : val,
		output: (val) => toBase64(new Uint8Array(val))
	}) }),
	Object: ObjectArg$1,
	FundsWithdrawal
});
var InnerTypeTag = bcs.enum("TypeTag", {
	bool: null,
	u8: null,
	u64: null,
	u128: null,
	address: null,
	signer: null,
	vector: bcs.lazy(() => InnerTypeTag),
	struct: bcs.lazy(() => StructTag$1),
	u16: null,
	u32: null,
	u256: null
});
var TypeTag$1 = InnerTypeTag.transform({
	input: (typeTag) => typeof typeTag === "string" ? TypeTagSerializer.parseFromStr(typeTag, true) : typeTag,
	output: (typeTag) => TypeTagSerializer.tagToString(typeTag)
});
var Argument$1 = bcs.enum("Argument", {
	GasCoin: null,
	Input: bcs.u16(),
	Result: bcs.u16(),
	NestedResult: bcs.tuple([bcs.u16(), bcs.u16()])
});
var ProgrammableMoveCall$1 = bcs.struct("ProgrammableMoveCall", {
	package: Address,
	module: bcs.string(),
	function: bcs.string(),
	typeArguments: bcs.vector(TypeTag$1),
	arguments: bcs.vector(Argument$1)
});
var Command$1 = bcs.enum("Command", {
	MoveCall: ProgrammableMoveCall$1,
	TransferObjects: bcs.struct("TransferObjects", {
		objects: bcs.vector(Argument$1),
		address: Argument$1
	}),
	SplitCoins: bcs.struct("SplitCoins", {
		coin: Argument$1,
		amounts: bcs.vector(Argument$1)
	}),
	MergeCoins: bcs.struct("MergeCoins", {
		destination: Argument$1,
		sources: bcs.vector(Argument$1)
	}),
	Publish: bcs.struct("Publish", {
		modules: bcs.vector(bcs.byteVector().transform({
			input: (val) => typeof val === "string" ? fromBase64(val) : val,
			output: (val) => toBase64(new Uint8Array(val))
		})),
		dependencies: bcs.vector(Address)
	}),
	MakeMoveVec: bcs.struct("MakeMoveVec", {
		type: optionEnum(TypeTag$1).transform({
			input: (val) => val === null ? { None: true } : { Some: val },
			output: (val) => val.Some ?? null
		}),
		elements: bcs.vector(Argument$1)
	}),
	Upgrade: bcs.struct("Upgrade", {
		modules: bcs.vector(bcs.byteVector().transform({
			input: (val) => typeof val === "string" ? fromBase64(val) : val,
			output: (val) => toBase64(new Uint8Array(val))
		})),
		dependencies: bcs.vector(Address),
		package: Address,
		ticket: Argument$1
	})
});
var ProgrammableTransaction = bcs.struct("ProgrammableTransaction", {
	inputs: bcs.vector(CallArg$1),
	commands: bcs.vector(Command$1)
});
var ValidDuring = bcs.struct("ValidDuring", {
	minEpoch: bcs.option(bcs.u64()),
	maxEpoch: bcs.option(bcs.u64()),
	minTimestamp: bcs.option(bcs.u64()),
	maxTimestamp: bcs.option(bcs.u64()),
	chain: ObjectDigest,
	nonce: bcs.u32()
});
function assertAllowedProposersNotEmpty(proposers) {
	if (proposers.length === 0) throw new Error("Allowed proposers must not be empty");
	return proposers;
}
function assertAllowedProposersStrictlyIncreasing(proposers) {
	assertAllowedProposersNotEmpty(proposers);
	for (let i = 1; i < proposers.length; i++) if (proposers[i] <= proposers[i - 1]) throw new Error("Allowed proposers must be strictly increasing");
	return proposers;
}
var AllowedProposerIndices = bcs.vector(bcs.u32()).transform({
	input: assertAllowedProposersStrictlyIncreasing,
	output: assertAllowedProposersNotEmpty
});
var AllowedProposers = bcs.struct("AllowedProposers", {
	epoch: bcs.u64(),
	proposers: AllowedProposerIndices
});
var Validity = bcs.struct("Validity", {
	minEpoch: bcs.option(bcs.u64()),
	maxEpoch: bcs.option(bcs.u64()),
	minTimestamp: bcs.option(bcs.u64()),
	maxTimestamp: bcs.option(bcs.u64()),
	chain: ObjectDigest,
	nonce: bcs.u32(),
	allowedProposers: bcs.option(AllowedProposers)
});
var TransactionExpiration$2 = bcs.enum("TransactionExpiration", {
	None: null,
	Epoch: unsafe_u64(),
	ValidDuring,
	Validity
});
var StructTag$1 = bcs.struct("StructTag", {
	address: Address,
	module: bcs.string(),
	name: bcs.string(),
	typeParams: bcs.vector(InnerTypeTag)
});
var GasData$1 = bcs.struct("GasData", {
	payment: bcs.vector(SuiObjectRef),
	owner: Address,
	price: bcs.u64(),
	budget: bcs.u64()
});
var IntentScope = bcs.enum("IntentScope", {
	TransactionData: null,
	TransactionEffects: null,
	CheckpointSummary: null,
	PersonalMessage: null
});
var IntentVersion = bcs.enum("IntentVersion", { V0: null });
var AppId = bcs.enum("AppId", { Sui: null });
var Intent = bcs.struct("Intent", {
	scope: IntentScope,
	version: IntentVersion,
	appId: AppId
});
function IntentMessage(T) {
	return bcs.struct(`IntentMessage<${T.name}>`, {
		intent: Intent,
		value: T
	});
}
var CompressedSignature = bcs.enum("CompressedSignature", {
	ED25519: bcs.bytes(64),
	Secp256k1: bcs.bytes(64),
	Secp256r1: bcs.bytes(64),
	ZkLogin: bcs.byteVector(),
	Passkey: bcs.byteVector()
});
var PublicKey$1 = bcs.enum("PublicKey", {
	ED25519: bcs.bytes(32),
	Secp256k1: bcs.bytes(33),
	Secp256r1: bcs.bytes(33),
	ZkLogin: bcs.byteVector(),
	Passkey: bcs.bytes(33)
});
var MultiSigPkMap = bcs.struct("MultiSigPkMap", {
	pubKey: PublicKey$1,
	weight: bcs.u8()
});
var MultiSigPublicKey = bcs.struct("MultiSigPublicKey", {
	pk_map: bcs.vector(MultiSigPkMap),
	threshold: bcs.u16()
});
var MultiSig = bcs.struct("MultiSig", {
	sigs: bcs.vector(CompressedSignature),
	bitmap: bcs.u16(),
	multisig_pk: MultiSigPublicKey
});
var base64String = bcs.byteVector().transform({
	input: (val) => typeof val === "string" ? fromBase64(val) : val,
	output: (val) => toBase64(new Uint8Array(val))
});
var PasskeyAuthenticator = bcs.struct("PasskeyAuthenticator", {
	authenticatorData: bcs.byteVector(),
	clientDataJson: bcs.string(),
	userSignature: bcs.byteVector()
});
var MoveObjectType = bcs.enum("MoveObjectType", {
	Other: StructTag$1,
	GasCoin: null,
	StakedSui: null,
	Coin: TypeTag$1,
	AccumulatorBalanceWrapper: null
});
var TypeOrigin = bcs.struct("TypeOrigin", {
	moduleName: bcs.string(),
	datatypeName: bcs.string(),
	package: Address
});
var UpgradeInfo = bcs.struct("UpgradeInfo", {
	upgradedId: Address,
	upgradedVersion: bcs.u64()
});
var MovePackage = bcs.struct("MovePackage", {
	id: Address,
	version: bcs.u64(),
	moduleMap: bcs.map(bcs.string(), bcs.byteVector()),
	typeOriginTable: bcs.vector(TypeOrigin),
	linkageTable: bcs.map(Address, UpgradeInfo)
});
var MoveObject = bcs.struct("MoveObject", {
	type: MoveObjectType,
	hasPublicTransfer: bcs.bool(),
	version: bcs.u64(),
	contents: bcs.byteVector()
});
var Data = bcs.enum("Data", {
	Move: MoveObject,
	Package: MovePackage
});
var ObjectInner = bcs.struct("ObjectInner", {
	data: Data,
	owner: Owner,
	previousTransaction: ObjectDigest,
	storageRebate: bcs.u64()
});
//#endregion
//#region node_modules/@mysten/sui/dist/bcs/transactions.mjs
var ChangeEpoch = bcs.struct("ChangeEpoch", {
	epoch: bcs.u64(),
	protocolVersion: bcs.u64(),
	storageCharge: bcs.u64(),
	computationCharge: bcs.u64(),
	storageRebate: bcs.u64(),
	nonRefundableStorageFee: bcs.u64(),
	epochStartTimestampMs: bcs.u64(),
	systemPackages: bcs.vector(bcs.tuple([
		bcs.u64(),
		bcs.vector(bcs.byteVector()),
		bcs.vector(Address)
	]))
});
var GenesisObject = bcs.enum("GenesisObject", { RawObject: bcs.struct("RawObject", {
	data: Data,
	owner: Owner
}) });
var GenesisTransaction = bcs.struct("GenesisTransaction", { objects: bcs.vector(GenesisObject) });
var ConsensusCommitPrologue = bcs.struct("ConsensusCommitPrologue", {
	epoch: bcs.u64(),
	round: bcs.u64(),
	commitTimestampMs: bcs.u64()
});
var ConsensusCommitPrologueV2 = bcs.struct("ConsensusCommitPrologueV2", {
	epoch: bcs.u64(),
	round: bcs.u64(),
	commitTimestampMs: bcs.u64(),
	consensusCommitDigest: ObjectDigest
});
var ConsensusDeterminedVersionAssignments = bcs.enum("ConsensusDeterminedVersionAssignments", {
	CancelledTransactions: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([Address, bcs.u64()]))])),
	CancelledTransactionsV2: bcs.vector(bcs.tuple([ObjectDigest, bcs.vector(bcs.tuple([bcs.tuple([Address, bcs.u64()]), bcs.u64()]))]))
});
var ConsensusCommitPrologueV3 = bcs.struct("ConsensusCommitPrologueV3", {
	epoch: bcs.u64(),
	round: bcs.u64(),
	subDagIndex: bcs.option(bcs.u64()),
	commitTimestampMs: bcs.u64(),
	consensusCommitDigest: ObjectDigest,
	consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments
});
var ConsensusCommitPrologueV4 = bcs.struct("ConsensusCommitPrologueV4", {
	epoch: bcs.u64(),
	round: bcs.u64(),
	subDagIndex: bcs.option(bcs.u64()),
	commitTimestampMs: bcs.u64(),
	consensusCommitDigest: ObjectDigest,
	consensusDeterminedVersionAssignments: ConsensusDeterminedVersionAssignments,
	additionalStateDigest: ObjectDigest
});
var ActiveJwk = bcs.struct("ActiveJwk", {
	jwkId: bcs.struct("JwkId", {
		iss: bcs.string(),
		kid: bcs.string()
	}),
	jwk: bcs.struct("JWK", {
		kty: bcs.string(),
		e: bcs.string(),
		n: bcs.string(),
		alg: bcs.string()
	}),
	epoch: bcs.u64()
});
var AuthenticatorStateUpdate = bcs.struct("AuthenticatorStateUpdate", {
	epoch: bcs.u64(),
	round: bcs.u64(),
	newActiveJwks: bcs.vector(ActiveJwk),
	authenticatorObjInitialSharedVersion: bcs.u64()
});
var RandomnessStateUpdate = bcs.struct("RandomnessStateUpdate", {
	epoch: bcs.u64(),
	randomnessRound: bcs.u64(),
	randomBytes: bcs.byteVector(),
	randomnessObjInitialSharedVersion: bcs.u64()
});
var AuthenticatorStateExpire = bcs.struct("AuthenticatorStateExpire", {
	minEpoch: bcs.u64(),
	authenticatorObjInitialSharedVersion: bcs.u64()
});
var ExecutionTimeObservationKey = bcs.enum("ExecutionTimeObservationKey", {
	MoveEntryPoint: bcs.struct("MoveEntryPoint", {
		package: Address,
		module: bcs.string(),
		function: bcs.string(),
		typeArguments: bcs.vector(TypeTag$1)
	}),
	TransferObjects: null,
	SplitCoins: null,
	MergeCoins: null,
	Publish: null,
	MakeMoveVec: null,
	Upgrade: null
});
var StoredExecutionTimeObservations = bcs.enum("StoredExecutionTimeObservations", { V1: bcs.vector(bcs.tuple([ExecutionTimeObservationKey, bcs.vector(bcs.tuple([bcs.byteVector(), bcs.struct("Duration", {
	secs: bcs.u64(),
	nanos: bcs.u32()
})]))])) });
var WriteAccumulatorStorageCost = bcs.struct("WriteAccumulatorStorageCost", { storageCost: bcs.u64() });
var EndOfEpochTransactionKind = bcs.enum("EndOfEpochTransactionKind", {
	ChangeEpoch,
	AuthenticatorStateCreate: null,
	AuthenticatorStateExpire,
	RandomnessStateCreate: null,
	DenyListStateCreate: null,
	BridgeStateCreate: ObjectDigest,
	BridgeCommitteeInit: bcs.u64(),
	StoreExecutionTimeObservations: StoredExecutionTimeObservations,
	AccumulatorRootCreate: null,
	CoinRegistryCreate: null,
	DisplayRegistryCreate: null,
	AddressAliasStateCreate: null,
	WriteAccumulatorStorageCost,
	ForwardingAddressRegistryCreate: null
});
var TransactionKind = bcs.enum("TransactionKind", {
	ProgrammableTransaction,
	ChangeEpoch,
	Genesis: GenesisTransaction,
	ConsensusCommitPrologue,
	AuthenticatorStateUpdate,
	EndOfEpochTransaction: bcs.vector(EndOfEpochTransactionKind),
	RandomnessStateUpdate,
	ConsensusCommitPrologueV2,
	ConsensusCommitPrologueV3,
	ConsensusCommitPrologueV4,
	ProgrammableSystemTransaction: ProgrammableTransaction
});
var TransactionDataV1 = bcs.struct("TransactionDataV1", {
	kind: TransactionKind,
	sender: Address,
	gasData: GasData$1,
	expiration: TransactionExpiration$2
});
var TransactionData = bcs.enum("TransactionData", { V1: TransactionDataV1 });
var SenderSignedTransaction = bcs.struct("SenderSignedTransaction", {
	intentMessage: IntentMessage(TransactionData),
	txSignatures: bcs.vector(base64String)
});
var SenderSignedData = bcs.vector(SenderSignedTransaction, { name: "SenderSignedData" });
//#endregion
//#region node_modules/@mysten/sui/dist/bcs/effects.mjs
var PackageUpgradeError = bcs.enum("PackageUpgradeError", {
	UnableToFetchPackage: bcs.struct("UnableToFetchPackage", { packageId: Address }),
	NotAPackage: bcs.struct("NotAPackage", { objectId: Address }),
	IncompatibleUpgrade: null,
	DigestDoesNotMatch: bcs.struct("DigestDoesNotMatch", { digest: bcs.byteVector() }),
	UnknownUpgradePolicy: bcs.struct("UnknownUpgradePolicy", { policy: bcs.u8() }),
	PackageIDDoesNotMatch: bcs.struct("PackageIDDoesNotMatch", {
		packageId: Address,
		ticketId: Address
	})
});
var ModuleId = bcs.struct("ModuleId", {
	address: Address,
	name: bcs.string()
});
var MoveLocation = bcs.struct("MoveLocation", {
	module: ModuleId,
	function: bcs.u16(),
	instruction: bcs.u16(),
	functionName: bcs.option(bcs.string())
});
var CommandArgumentError = bcs.enum("CommandArgumentError", {
	TypeMismatch: null,
	InvalidBCSBytes: null,
	InvalidUsageOfPureArg: null,
	InvalidArgumentToPrivateEntryFunction: null,
	IndexOutOfBounds: bcs.struct("IndexOutOfBounds", { idx: bcs.u16() }),
	SecondaryIndexOutOfBounds: bcs.struct("SecondaryIndexOutOfBounds", {
		resultIdx: bcs.u16(),
		secondaryIdx: bcs.u16()
	}),
	InvalidResultArity: bcs.struct("InvalidResultArity", { resultIdx: bcs.u16() }),
	InvalidGasCoinUsage: null,
	InvalidValueUsage: null,
	InvalidObjectByValue: null,
	InvalidObjectByMutRef: null,
	SharedObjectOperationNotAllowed: null,
	InvalidArgumentArity: null,
	InvalidTransferObject: null,
	InvalidMakeMoveVecNonObjectArgument: null,
	ArgumentWithoutValue: null,
	CannotMoveBorrowedValue: null,
	CannotWriteToExtendedReference: null,
	InvalidReferenceArgument: null,
	InvalidTxContext: null
});
var TypeArgumentError = bcs.enum("TypeArgumentError", {
	TypeNotFound: null,
	ConstraintNotSatisfied: null
});
var ExecutionFailureStatus = bcs.enum("ExecutionFailureStatus", {
	InsufficientGas: null,
	InvalidGasObject: null,
	InvariantViolation: null,
	FeatureNotYetSupported: null,
	MoveObjectTooBig: bcs.struct("MoveObjectTooBig", {
		objectSize: bcs.u64(),
		maxObjectSize: bcs.u64()
	}),
	MovePackageTooBig: bcs.struct("MovePackageTooBig", {
		objectSize: bcs.u64(),
		maxObjectSize: bcs.u64()
	}),
	CircularObjectOwnership: bcs.struct("CircularObjectOwnership", { object: Address }),
	InsufficientCoinBalance: null,
	CoinBalanceOverflow: null,
	PublishErrorNonZeroAddress: null,
	SuiMoveVerificationError: null,
	MovePrimitiveRuntimeError: bcs.option(MoveLocation),
	MoveAbort: bcs.tuple([MoveLocation, bcs.u64()]),
	VMVerificationOrDeserializationError: null,
	VMInvariantViolation: null,
	FunctionNotFound: null,
	ArityMismatch: null,
	TypeArityMismatch: null,
	NonEntryFunctionInvoked: null,
	CommandArgumentError: bcs.struct("CommandArgumentError", {
		argIdx: bcs.u16(),
		kind: CommandArgumentError
	}),
	TypeArgumentError: bcs.struct("TypeArgumentError", {
		argumentIdx: bcs.u16(),
		kind: TypeArgumentError
	}),
	UnusedValueWithoutDrop: bcs.struct("UnusedValueWithoutDrop", {
		resultIdx: bcs.u16(),
		secondaryIdx: bcs.u16()
	}),
	InvalidPublicFunctionReturnType: bcs.struct("InvalidPublicFunctionReturnType", { idx: bcs.u16() }),
	InvalidTransferObject: null,
	EffectsTooLarge: bcs.struct("EffectsTooLarge", {
		currentSize: bcs.u64(),
		maxSize: bcs.u64()
	}),
	PublishUpgradeMissingDependency: null,
	PublishUpgradeDependencyDowngrade: null,
	PackageUpgradeError: bcs.struct("PackageUpgradeError", { upgradeError: PackageUpgradeError }),
	WrittenObjectsTooLarge: bcs.struct("WrittenObjectsTooLarge", {
		currentSize: bcs.u64(),
		maxSize: bcs.u64()
	}),
	CertificateDenied: null,
	SuiMoveVerificationTimedout: null,
	SharedObjectOperationNotAllowed: null,
	InputObjectDeleted: null,
	ExecutionCancelledDueToSharedObjectCongestion: bcs.struct("ExecutionCancelledDueToSharedObjectCongestion", { congested_objects: bcs.vector(Address) }),
	AddressDeniedForCoin: bcs.struct("AddressDeniedForCoin", {
		address: Address,
		coinType: bcs.string()
	}),
	CoinTypeGlobalPause: bcs.struct("CoinTypeGlobalPause", { coinType: bcs.string() }),
	ExecutionCancelledDueToRandomnessUnavailable: null,
	MoveVectorElemTooBig: bcs.struct("MoveVectorElemTooBig", {
		valueSize: bcs.u64(),
		maxScaledSize: bcs.u64()
	}),
	MoveRawValueTooBig: bcs.struct("MoveRawValueTooBig", {
		valueSize: bcs.u64(),
		maxScaledSize: bcs.u64()
	}),
	InvalidLinkage: null,
	InsufficientBalanceForWithdraw: null,
	NonExclusiveWriteInputObjectModified: bcs.struct("NonExclusiveWriteInputObjectModified", { id: Address })
});
var ExecutionStatus = bcs.enum("ExecutionStatus", {
	Success: null,
	Failure: bcs.struct("Failure", {
		error: ExecutionFailureStatus,
		command: bcs.option(bcs.u64())
	})
});
var GasCostSummary = bcs.struct("GasCostSummary", {
	computationCost: bcs.u64(),
	storageCost: bcs.u64(),
	storageRebate: bcs.u64(),
	nonRefundableStorageFee: bcs.u64()
});
var TransactionEffectsV1 = bcs.struct("TransactionEffectsV1", {
	status: ExecutionStatus,
	executedEpoch: bcs.u64(),
	gasUsed: GasCostSummary,
	modifiedAtVersions: bcs.vector(bcs.tuple([Address, bcs.u64()])),
	sharedObjects: bcs.vector(SuiObjectRef),
	transactionDigest: ObjectDigest,
	created: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
	mutated: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
	unwrapped: bcs.vector(bcs.tuple([SuiObjectRef, Owner])),
	deleted: bcs.vector(SuiObjectRef),
	unwrappedThenDeleted: bcs.vector(SuiObjectRef),
	wrapped: bcs.vector(SuiObjectRef),
	gasObject: bcs.tuple([SuiObjectRef, Owner]),
	eventsDigest: bcs.option(ObjectDigest),
	dependencies: bcs.vector(ObjectDigest)
});
var VersionDigest = bcs.tuple([bcs.u64(), ObjectDigest]);
var ObjectIn = bcs.enum("ObjectIn", {
	NotExist: null,
	Exist: bcs.tuple([VersionDigest, Owner])
});
var AccumulatorAddress = bcs.struct("AccumulatorAddress", {
	address: Address,
	ty: TypeTag$1
});
var AccumulatorOperation = bcs.enum("AccumulatorOperation", {
	Merge: null,
	Split: null
});
var AccumulatorValue = bcs.enum("AccumulatorValue", {
	Integer: bcs.u64(),
	IntegerTuple: bcs.tuple([bcs.u64(), bcs.u64()]),
	EventDigest: bcs.vector(bcs.tuple([bcs.u64(), ObjectDigest]))
});
var AccumulatorWriteV1 = bcs.struct("AccumulatorWriteV1", {
	address: AccumulatorAddress,
	operation: AccumulatorOperation,
	value: AccumulatorValue
});
var ObjectOut = bcs.enum("ObjectOut", {
	NotExist: null,
	ObjectWrite: bcs.tuple([ObjectDigest, Owner]),
	PackageWrite: VersionDigest,
	AccumulatorWriteV1
});
var IDOperation = bcs.enum("IDOperation", {
	None: null,
	Created: null,
	Deleted: null
});
var EffectsObjectChange = bcs.struct("EffectsObjectChange", {
	inputState: ObjectIn,
	outputState: ObjectOut,
	idOperation: IDOperation
});
var UnchangedConsensusKind = bcs.enum("UnchangedConsensusKind", {
	ReadOnlyRoot: VersionDigest,
	MutateConsensusStreamEnded: bcs.u64(),
	ReadConsensusStreamEnded: bcs.u64(),
	Cancelled: bcs.u64(),
	PerEpochConfig: null
});
var TransactionEffectsV2 = bcs.struct("TransactionEffectsV2", {
	status: ExecutionStatus,
	executedEpoch: bcs.u64(),
	gasUsed: GasCostSummary,
	transactionDigest: ObjectDigest,
	gasObjectIndex: bcs.option(bcs.u32()),
	eventsDigest: bcs.option(ObjectDigest),
	dependencies: bcs.vector(ObjectDigest),
	lamportVersion: bcs.u64(),
	changedObjects: bcs.vector(bcs.tuple([Address, EffectsObjectChange])),
	unchangedConsensusObjects: bcs.vector(bcs.tuple([Address, UnchangedConsensusKind])),
	auxDataDigest: bcs.option(ObjectDigest)
});
var TransactionEffects = bcs.enum("TransactionEffects", {
	V1: TransactionEffectsV1,
	V2: TransactionEffectsV2
});
//#endregion
//#region node_modules/@mysten/sui/dist/bcs/pure.mjs
function pureBcsSchemaFromTypeName(name) {
	switch (name) {
		case "u8": return bcs.u8();
		case "u16": return bcs.u16();
		case "u32": return bcs.u32();
		case "u64": return bcs.u64();
		case "u128": return bcs.u128();
		case "u256": return bcs.u256();
		case "bool": return bcs.bool();
		case "string": return bcs.string();
		case "id":
		case "address": return Address;
	}
	const generic = name.match(/^(vector|option)<(.+)>$/);
	if (generic) {
		const [kind, inner] = generic.slice(1);
		if (kind === "vector") return bcs.vector(pureBcsSchemaFromTypeName(inner));
		else return bcs.option(pureBcsSchemaFromTypeName(inner));
	}
	throw new Error(`Invalid Pure type name: ${name}`);
}
//#endregion
//#region node_modules/@mysten/sui/dist/bcs/index.mjs
var suiBcs = {
	...bcs,
	U8: bcs.u8(),
	U16: bcs.u16(),
	U32: bcs.u32(),
	U64: bcs.u64(),
	U128: bcs.u128(),
	U256: bcs.u256(),
	ULEB128: bcs.uleb128(),
	Bool: bcs.bool(),
	String: bcs.string(),
	Address,
	AppId,
	Argument: Argument$1,
	CallArg: CallArg$1,
	Command: Command$1,
	CompressedSignature,
	Data,
	GasData: GasData$1,
	Intent,
	IntentMessage,
	IntentScope,
	IntentVersion,
	MoveObject,
	MoveObjectType,
	MovePackage,
	MultiSig,
	MultiSigPkMap,
	MultiSigPublicKey,
	Object: ObjectInner,
	ObjectArg: ObjectArg$1,
	ObjectDigest,
	Owner,
	PasskeyAuthenticator,
	ProgrammableMoveCall: ProgrammableMoveCall$1,
	ProgrammableTransaction,
	PublicKey: PublicKey$1,
	SenderSignedData,
	SenderSignedTransaction,
	SharedObjectRef,
	StructTag: StructTag$1,
	SuiObjectRef,
	TransactionData,
	TransactionDataV1,
	TransactionEffects,
	TransactionExpiration: TransactionExpiration$2,
	TransactionKind,
	TypeOrigin,
	TypeTag: TypeTag$1,
	UpgradeInfo
};
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/data/v1.mjs
var ObjectRef = object({
	digest: string(),
	objectId: string(),
	version: union([
		pipe(number(), integer()),
		string(),
		bigint()
	])
});
var NormalizedCallArg = safeEnum({
	Object: safeEnum({
		ImmOrOwned: ObjectRef,
		Shared: object({
			objectId: ObjectID,
			initialSharedVersion: JsonU64,
			mutable: boolean()
		}),
		Receiving: ObjectRef
	}),
	Pure: array(pipe(number(), integer()))
});
var TransactionInput = union([object({
	kind: literal("Input"),
	index: pipe(number(), integer()),
	value: unknown(),
	type: optional(literal("object"))
}), object({
	kind: literal("Input"),
	index: pipe(number(), integer()),
	value: unknown(),
	type: literal("pure")
})]);
var TransactionExpiration$1 = union([
	object({ Epoch: pipe(number(), integer()) }),
	object({ None: nullable(literal(true)) }),
	object({ ValidDuring: ValidDuringSchema }),
	object({ Validity: ValiditySchema })
]);
function expirationToV1(expiration) {
	if (!expiration) return null;
	switch (expiration.$kind) {
		case "Epoch": return { Epoch: Number(expiration.Epoch) };
		case "ValidDuring": return { ValidDuring: expiration.ValidDuring };
		case "Validity": return { Validity: expiration.Validity };
		case "None": return { None: true };
		default: throw new Error(`Unknown transaction expiration: ${JSON.stringify(expiration)}`);
	}
}
function expirationFromV1(expiration) {
	if (!expiration) return null;
	if ("Epoch" in expiration) return { Epoch: expiration.Epoch };
	if ("ValidDuring" in expiration) return { ValidDuring: expiration.ValidDuring };
	if ("Validity" in expiration) return { Validity: expiration.Validity };
	if ("None" in expiration) return { None: true };
	throw new Error(`Unknown transaction expiration in v1 transaction data: ${Object.keys(expiration).join(", ")}`);
}
var StringEncodedBigint = pipe(union([
	number(),
	string(),
	bigint()
]), check((val) => {
	if (![
		"string",
		"number",
		"bigint"
	].includes(typeof val)) return false;
	try {
		BigInt(val);
		return true;
	} catch {
		return false;
	}
}));
var TypeTag = union([
	object({ bool: nullable(literal(true)) }),
	object({ u8: nullable(literal(true)) }),
	object({ u64: nullable(literal(true)) }),
	object({ u128: nullable(literal(true)) }),
	object({ address: nullable(literal(true)) }),
	object({ signer: nullable(literal(true)) }),
	object({ vector: lazy(() => TypeTag) }),
	object({ struct: lazy(() => StructTag) }),
	object({ u16: nullable(literal(true)) }),
	object({ u32: nullable(literal(true)) }),
	object({ u256: nullable(literal(true)) })
]);
var StructTag = object({
	address: string(),
	module: string(),
	name: string(),
	typeParams: array(TypeTag)
});
var GasConfig = object({
	budget: optional(StringEncodedBigint),
	price: optional(StringEncodedBigint),
	payment: optional(array(ObjectRef)),
	owner: optional(string())
});
var TransactionArgumentTypes = [
	TransactionInput,
	object({ kind: literal("GasCoin") }),
	object({
		kind: literal("Result"),
		index: pipe(number(), integer())
	}),
	object({
		kind: literal("NestedResult"),
		index: pipe(number(), integer()),
		resultIndex: pipe(number(), integer())
	})
];
var TransactionArgument = union([...TransactionArgumentTypes]);
var MoveCallTransaction = object({
	kind: literal("MoveCall"),
	target: pipe(string(), check((target) => target.split("::").length === 3)),
	typeArguments: array(string()),
	arguments: array(TransactionArgument)
});
var TransferObjectsTransaction = object({
	kind: literal("TransferObjects"),
	objects: array(TransactionArgument),
	address: TransactionArgument
});
var SplitCoinsTransaction = object({
	kind: literal("SplitCoins"),
	coin: TransactionArgument,
	amounts: array(TransactionArgument)
});
var MergeCoinsTransaction = object({
	kind: literal("MergeCoins"),
	destination: TransactionArgument,
	sources: array(TransactionArgument)
});
var MakeMoveVecTransaction = object({
	kind: literal("MakeMoveVec"),
	type: union([object({ Some: TypeTag }), object({ None: nullable(literal(true)) })]),
	objects: array(TransactionArgument)
});
var TransactionType = union([...[
	MoveCallTransaction,
	TransferObjectsTransaction,
	SplitCoinsTransaction,
	MergeCoinsTransaction,
	object({
		kind: literal("Publish"),
		modules: array(array(pipe(number(), integer()))),
		dependencies: array(string())
	}),
	object({
		kind: literal("Upgrade"),
		modules: array(array(pipe(number(), integer()))),
		dependencies: array(string()),
		packageId: string(),
		ticket: TransactionArgument
	}),
	MakeMoveVecTransaction
]]);
object({
	version: literal(1),
	sender: optional(string()),
	expiration: nullish(TransactionExpiration$1),
	gasConfig: GasConfig,
	inputs: array(TransactionInput),
	transactions: array(TransactionType)
});
function serializeV1TransactionData(transactionData) {
	const inputs = transactionData.inputs.map((input, index) => {
		if (input.Object) return {
			kind: "Input",
			index,
			value: { Object: input.Object.ImmOrOwnedObject ? { ImmOrOwned: input.Object.ImmOrOwnedObject } : input.Object.Receiving ? { Receiving: {
				digest: input.Object.Receiving.digest,
				version: input.Object.Receiving.version,
				objectId: input.Object.Receiving.objectId
			} } : { Shared: {
				mutable: input.Object.SharedObject.mutable,
				initialSharedVersion: input.Object.SharedObject.initialSharedVersion,
				objectId: input.Object.SharedObject.objectId
			} } },
			type: "object"
		};
		if (input.Pure) return {
			kind: "Input",
			index,
			value: { Pure: Array.from(fromBase64(input.Pure.bytes)) },
			type: "pure"
		};
		if (input.UnresolvedPure) return {
			kind: "Input",
			type: "pure",
			index,
			value: input.UnresolvedPure.value
		};
		if (input.UnresolvedObject) return {
			kind: "Input",
			type: "object",
			index,
			value: input.UnresolvedObject.objectId
		};
		throw new Error("Invalid input");
	});
	return {
		version: 1,
		sender: transactionData.sender ?? void 0,
		expiration: expirationToV1(transactionData.expiration),
		gasConfig: {
			owner: transactionData.gasData.owner ?? void 0,
			budget: transactionData.gasData.budget ?? void 0,
			price: transactionData.gasData.price ?? void 0,
			payment: transactionData.gasData.payment ?? void 0
		},
		inputs,
		transactions: transactionData.commands.map((command) => {
			if (command.MakeMoveVec) return {
				kind: "MakeMoveVec",
				type: command.MakeMoveVec.type === null ? { None: true } : { Some: TypeTagSerializer.parseFromStr(command.MakeMoveVec.type) },
				objects: command.MakeMoveVec.elements.map((arg) => convertTransactionArgument(arg, inputs))
			};
			if (command.MergeCoins) return {
				kind: "MergeCoins",
				destination: convertTransactionArgument(command.MergeCoins.destination, inputs),
				sources: command.MergeCoins.sources.map((arg) => convertTransactionArgument(arg, inputs))
			};
			if (command.MoveCall) return {
				kind: "MoveCall",
				target: `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`,
				typeArguments: command.MoveCall.typeArguments,
				arguments: command.MoveCall.arguments.map((arg) => convertTransactionArgument(arg, inputs))
			};
			if (command.Publish) return {
				kind: "Publish",
				modules: command.Publish.modules.map((mod) => Array.from(fromBase64(mod))),
				dependencies: command.Publish.dependencies
			};
			if (command.SplitCoins) return {
				kind: "SplitCoins",
				coin: convertTransactionArgument(command.SplitCoins.coin, inputs),
				amounts: command.SplitCoins.amounts.map((arg) => convertTransactionArgument(arg, inputs))
			};
			if (command.TransferObjects) return {
				kind: "TransferObjects",
				objects: command.TransferObjects.objects.map((arg) => convertTransactionArgument(arg, inputs)),
				address: convertTransactionArgument(command.TransferObjects.address, inputs)
			};
			if (command.Upgrade) return {
				kind: "Upgrade",
				modules: command.Upgrade.modules.map((mod) => Array.from(fromBase64(mod))),
				dependencies: command.Upgrade.dependencies,
				packageId: command.Upgrade.package,
				ticket: convertTransactionArgument(command.Upgrade.ticket, inputs)
			};
			throw new Error(`Unknown transaction ${Object.keys(command)}`);
		})
	};
}
function convertTransactionArgument(arg, inputs) {
	if (arg.$kind === "GasCoin") return { kind: "GasCoin" };
	if (arg.$kind === "Result") return {
		kind: "Result",
		index: arg.Result
	};
	if (arg.$kind === "NestedResult") return {
		kind: "NestedResult",
		index: arg.NestedResult[0],
		resultIndex: arg.NestedResult[1]
	};
	if (arg.$kind === "Input") return inputs[arg.Input];
	throw new Error(`Invalid argument ${Object.keys(arg)}`);
}
function transactionDataFromV1(data) {
	return parse$2(TransactionDataSchema, {
		version: 2,
		sender: data.sender ?? null,
		expiration: expirationFromV1(data.expiration),
		gasData: {
			owner: data.gasConfig.owner ?? null,
			budget: data.gasConfig.budget?.toString() ?? null,
			price: data.gasConfig.price?.toString() ?? null,
			payment: data.gasConfig.payment?.map((ref) => ({
				digest: ref.digest,
				objectId: ref.objectId,
				version: ref.version.toString()
			})) ?? null
		},
		inputs: data.inputs.map((input) => {
			if (input.kind === "Input") {
				if (is(NormalizedCallArg, input.value)) {
					const value = parse$2(NormalizedCallArg, input.value);
					if (value.Object) {
						if (value.Object.ImmOrOwned) return { Object: { ImmOrOwnedObject: {
							objectId: value.Object.ImmOrOwned.objectId,
							version: String(value.Object.ImmOrOwned.version),
							digest: value.Object.ImmOrOwned.digest
						} } };
						if (value.Object.Shared) return { Object: { SharedObject: {
							mutable: value.Object.Shared.mutable ?? null,
							initialSharedVersion: value.Object.Shared.initialSharedVersion,
							objectId: value.Object.Shared.objectId
						} } };
						if (value.Object.Receiving) return { Object: { Receiving: {
							digest: value.Object.Receiving.digest,
							version: String(value.Object.Receiving.version),
							objectId: value.Object.Receiving.objectId
						} } };
						throw new Error("Invalid object input");
					}
					return { Pure: { bytes: toBase64(new Uint8Array(value.Pure)) } };
				}
				if (input.type === "object") return { UnresolvedObject: { objectId: input.value } };
				return { UnresolvedPure: { value: input.value } };
			}
			throw new Error("Invalid input");
		}),
		commands: data.transactions.map((transaction) => {
			switch (transaction.kind) {
				case "MakeMoveVec": return { MakeMoveVec: {
					type: "Some" in transaction.type ? TypeTagSerializer.tagToString(transaction.type.Some) : null,
					elements: transaction.objects.map((arg) => parseV1TransactionArgument(arg))
				} };
				case "MergeCoins": return { MergeCoins: {
					destination: parseV1TransactionArgument(transaction.destination),
					sources: transaction.sources.map((arg) => parseV1TransactionArgument(arg))
				} };
				case "MoveCall": {
					const [pkg, mod, fn] = transaction.target.split("::");
					return { MoveCall: {
						package: pkg,
						module: mod,
						function: fn,
						typeArguments: transaction.typeArguments,
						arguments: transaction.arguments.map((arg) => parseV1TransactionArgument(arg))
					} };
				}
				case "Publish": return { Publish: {
					modules: transaction.modules.map((mod) => toBase64(Uint8Array.from(mod))),
					dependencies: transaction.dependencies
				} };
				case "SplitCoins": return { SplitCoins: {
					coin: parseV1TransactionArgument(transaction.coin),
					amounts: transaction.amounts.map((arg) => parseV1TransactionArgument(arg))
				} };
				case "TransferObjects": return { TransferObjects: {
					objects: transaction.objects.map((arg) => parseV1TransactionArgument(arg)),
					address: parseV1TransactionArgument(transaction.address)
				} };
				case "Upgrade": return { Upgrade: {
					modules: transaction.modules.map((mod) => toBase64(Uint8Array.from(mod))),
					dependencies: transaction.dependencies,
					package: transaction.packageId,
					ticket: parseV1TransactionArgument(transaction.ticket)
				} };
			}
			throw new Error(`Unknown transaction ${Object.keys(transaction)}`);
		})
	});
}
function parseV1TransactionArgument(arg) {
	switch (arg.kind) {
		case "GasCoin": return { GasCoin: true };
		case "Result": return { Result: arg.index };
		case "NestedResult": return { NestedResult: [arg.index, arg.resultIndex] };
		case "Input": return { Input: arg.index };
	}
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/hash.mjs
/**
* Generates a Blake2b hash of typed data as a base64 string.
*
* @param typeTag type tag (e.g. TransactionData, SenderSignedData)
* @param data data to hash
*/
function hashTypedData(typeTag, data) {
	const typeTagBytes = Array.from(`${typeTag}::`).map((e) => e.charCodeAt(0));
	const dataWithTag = new Uint8Array(typeTagBytes.length + data.length);
	dataWithTag.set(typeTagBytes);
	dataWithTag.set(data, typeTagBytes.length);
	return blake2b(dataWithTag, { dkLen: 32 });
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/TransactionData.mjs
function prepareSuiAddress(address) {
	return normalizeSuiAddress(address).replace("0x", "");
}
var TransactionDataBuilder = class TransactionDataBuilder {
	static fromKindBytes(bytes) {
		const programmableTx = suiBcs.TransactionKind.parse(bytes).ProgrammableTransaction;
		if (!programmableTx) throw new Error("Unable to deserialize from bytes.");
		return TransactionDataBuilder.restore({
			version: 2,
			sender: null,
			expiration: null,
			gasData: {
				budget: null,
				owner: null,
				payment: null,
				price: null
			},
			inputs: programmableTx.inputs,
			commands: programmableTx.commands
		});
	}
	static fromBytes(bytes) {
		const data = suiBcs.TransactionData.parse(bytes)?.V1;
		const programmableTx = data.kind.ProgrammableTransaction;
		if (!data || !programmableTx) throw new Error("Unable to deserialize from bytes.");
		return TransactionDataBuilder.restore({
			version: 2,
			sender: data.sender,
			expiration: data.expiration,
			gasData: data.gasData,
			inputs: programmableTx.inputs,
			commands: programmableTx.commands
		});
	}
	static restore(data) {
		if (data.version === 2) return new TransactionDataBuilder(parse$2(TransactionDataSchema, data));
		else return new TransactionDataBuilder(parse$2(TransactionDataSchema, transactionDataFromV1(data)));
	}
	/**
	* Generate transaction digest.
	*
	* @param bytes BCS serialized transaction data
	* @returns transaction digest.
	*/
	static getDigestFromBytes(bytes) {
		return toBase58(hashTypedData("TransactionData", bytes));
	}
	constructor(clone) {
		this.version = 2;
		this.sender = clone?.sender ?? null;
		this.expiration = clone?.expiration ?? null;
		this.inputs = clone?.inputs ?? [];
		this.commands = clone?.commands ?? [];
		this.gasData = clone?.gasData ?? {
			budget: null,
			price: null,
			owner: null,
			payment: null
		};
	}
	build({ maxSizeBytes = Infinity, overrides, onlyTransactionKind } = {}) {
		const inputs = this.inputs;
		const commands = this.commands;
		const kind = { ProgrammableTransaction: {
			inputs,
			commands
		} };
		if (onlyTransactionKind) return suiBcs.TransactionKind.serialize(kind, { maxSize: maxSizeBytes }).toBytes();
		const expiration = overrides?.expiration ?? this.expiration;
		const sender = overrides?.sender ?? this.sender;
		const gasData = {
			...this.gasData,
			...overrides?.gasData
		};
		if (!sender) throw new Error("Missing transaction sender");
		if (!gasData.budget) throw new Error("Missing gas budget");
		if (!gasData.payment) throw new Error("Missing gas payment");
		if (!gasData.price) throw new Error("Missing gas price");
		const transactionData = {
			sender: prepareSuiAddress(sender),
			expiration: expiration ? expiration : { None: true },
			gasData: {
				payment: gasData.payment,
				owner: prepareSuiAddress(this.gasData.owner ?? sender),
				price: BigInt(gasData.price),
				budget: BigInt(gasData.budget)
			},
			kind: { ProgrammableTransaction: {
				inputs,
				commands
			} }
		};
		return suiBcs.TransactionData.serialize({ V1: transactionData }, { maxSize: maxSizeBytes }).toBytes();
	}
	addInput(type, arg) {
		const index = this.inputs.length;
		this.inputs.push(arg);
		return {
			Input: index,
			type,
			$kind: "Input"
		};
	}
	getInputUses(index, fn) {
		this.mapArguments((arg, command) => {
			if (arg.$kind === "Input" && arg.Input === index) fn(arg, command);
			return arg;
		});
	}
	mapCommandArguments(index, fn) {
		const command = this.commands[index];
		switch (command.$kind) {
			case "MoveCall":
				command.MoveCall.arguments = command.MoveCall.arguments.map((arg) => fn(arg, command, index));
				break;
			case "TransferObjects":
				command.TransferObjects.objects = command.TransferObjects.objects.map((arg) => fn(arg, command, index));
				command.TransferObjects.address = fn(command.TransferObjects.address, command, index);
				break;
			case "SplitCoins":
				command.SplitCoins.coin = fn(command.SplitCoins.coin, command, index);
				command.SplitCoins.amounts = command.SplitCoins.amounts.map((arg) => fn(arg, command, index));
				break;
			case "MergeCoins":
				command.MergeCoins.destination = fn(command.MergeCoins.destination, command, index);
				command.MergeCoins.sources = command.MergeCoins.sources.map((arg) => fn(arg, command, index));
				break;
			case "MakeMoveVec":
				command.MakeMoveVec.elements = command.MakeMoveVec.elements.map((arg) => fn(arg, command, index));
				break;
			case "Upgrade":
				command.Upgrade.ticket = fn(command.Upgrade.ticket, command, index);
				break;
			case "$Intent":
				const inputs = command.$Intent.inputs;
				command.$Intent.inputs = {};
				for (const [key, value] of Object.entries(inputs)) command.$Intent.inputs[key] = Array.isArray(value) ? value.map((arg) => fn(arg, command, index)) : fn(value, command, index);
				break;
			case "Publish": break;
			default: throw new Error(`Unexpected transaction kind: ${command.$kind}`);
		}
	}
	mapArguments(fn) {
		for (const commandIndex of this.commands.keys()) this.mapCommandArguments(commandIndex, fn);
	}
	replaceCommand(index, replacement, resultIndex = index) {
		if (!Array.isArray(replacement)) {
			this.commands[index] = replacement;
			return;
		}
		const sizeDiff = replacement.length - 1;
		this.commands.splice(index, 1, ...structuredClone(replacement));
		this.mapArguments((arg, _command, commandIndex) => {
			if (commandIndex < index + replacement.length) return arg;
			if (typeof resultIndex !== "number") {
				if (arg.$kind === "Result" && arg.Result === index || arg.$kind === "NestedResult" && arg.NestedResult[0] === index) if (!("NestedResult" in arg) || arg.NestedResult[1] === 0) return parse$2(ArgumentSchema, structuredClone(resultIndex));
				else throw new Error(`Cannot replace command ${index} with a specific result type: NestedResult[${index}, ${arg.NestedResult[1]}] references a nested element that cannot be mapped to the replacement result`);
			}
			switch (arg.$kind) {
				case "Result":
					if (arg.Result === index && typeof resultIndex === "number") arg.Result = resultIndex;
					if (arg.Result > index) arg.Result += sizeDiff;
					break;
				case "NestedResult":
					if (arg.NestedResult[0] === index && typeof resultIndex === "number") return {
						$kind: "NestedResult",
						NestedResult: [resultIndex, arg.NestedResult[1]]
					};
					if (arg.NestedResult[0] > index) arg.NestedResult[0] += sizeDiff;
			}
			return arg;
		});
	}
	replaceCommandWithTransaction(index, otherTransaction, result) {
		if (result.$kind !== "Result" && result.$kind !== "NestedResult") throw new Error("Result must be of kind Result or NestedResult");
		this.insertTransaction(index, otherTransaction);
		this.replaceCommand(index + otherTransaction.commands.length, [], "Result" in result ? { NestedResult: [result.Result + index, 0] } : { NestedResult: [result.NestedResult[0] + index, result.NestedResult[1]] });
	}
	insertTransaction(atCommandIndex, otherTransaction) {
		const inputMapping = /* @__PURE__ */ new Map();
		const commandMapping = /* @__PURE__ */ new Map();
		for (let i = 0; i < otherTransaction.inputs.length; i++) {
			const otherInput = otherTransaction.inputs[i];
			const id = getIdFromCallArg(otherInput);
			let existingIndex = -1;
			if (id !== void 0) {
				existingIndex = this.inputs.findIndex((input) => getIdFromCallArg(input) === id);
				if (existingIndex !== -1 && this.inputs[existingIndex].Object?.SharedObject && otherInput.Object?.SharedObject) this.inputs[existingIndex].Object.SharedObject.mutable = this.inputs[existingIndex].Object.SharedObject.mutable || otherInput.Object.SharedObject.mutable;
			}
			if (existingIndex !== -1) inputMapping.set(i, existingIndex);
			else {
				const newIndex = this.inputs.length;
				this.inputs.push(otherInput);
				inputMapping.set(i, newIndex);
			}
		}
		for (let i = 0; i < otherTransaction.commands.length; i++) commandMapping.set(i, atCommandIndex + i);
		const remappedCommands = [];
		for (let i = 0; i < otherTransaction.commands.length; i++) {
			const command = structuredClone(otherTransaction.commands[i]);
			remapCommandArguments(command, inputMapping, commandMapping);
			remappedCommands.push(command);
		}
		this.commands.splice(atCommandIndex, 0, ...remappedCommands);
		const sizeDiff = remappedCommands.length;
		if (sizeDiff > 0) this.mapArguments((arg, _command, commandIndex) => {
			if (commandIndex >= atCommandIndex && commandIndex < atCommandIndex + remappedCommands.length) return arg;
			switch (arg.$kind) {
				case "Result":
					if (arg.Result >= atCommandIndex) arg.Result += sizeDiff;
					break;
				case "NestedResult": if (arg.NestedResult[0] >= atCommandIndex) arg.NestedResult[0] += sizeDiff;
			}
			return arg;
		});
	}
	getDigest() {
		const bytes = this.build({ onlyTransactionKind: false });
		return TransactionDataBuilder.getDigestFromBytes(bytes);
	}
	snapshot() {
		return parse$2(TransactionDataSchema, this);
	}
	getData() {
		return this.snapshot();
	}
	shallowClone() {
		return new TransactionDataBuilder({
			version: this.version,
			sender: this.sender,
			expiration: this.expiration,
			gasData: { ...this.gasData },
			inputs: [...this.inputs],
			commands: [...this.commands]
		});
	}
	applyResolvedData(resolved) {
		if (!this.sender) this.sender = resolved.sender ?? null;
		if (!this.expiration) this.expiration = resolved.expiration ?? null;
		if (!this.gasData.budget) this.gasData.budget = resolved.gasData.budget;
		if (!this.gasData.owner) this.gasData.owner = resolved.gasData.owner ?? null;
		if (!this.gasData.payment) this.gasData.payment = resolved.gasData.payment;
		if (!this.gasData.price) this.gasData.price = resolved.gasData.price;
		for (let i = 0; i < this.inputs.length; i++) {
			const input = this.inputs[i];
			const resolvedInput = resolved.inputs[i];
			switch (input.$kind) {
				case "UnresolvedPure":
					if (resolvedInput.$kind !== "Pure") throw new Error(`Expected input at index ${i} to resolve to a Pure argument, but got ${JSON.stringify(resolvedInput)}`);
					this.inputs[i] = resolvedInput;
					break;
				case "UnresolvedObject":
					if (resolvedInput.$kind !== "Object") throw new Error(`Expected input at index ${i} to resolve to an Object argument, but got ${JSON.stringify(resolvedInput)}`);
					if (resolvedInput.Object.$kind === "ImmOrOwnedObject" || resolvedInput.Object.$kind === "Receiving") {
						const original = input.UnresolvedObject;
						const resolved$1 = resolvedInput.Object.ImmOrOwnedObject ?? resolvedInput.Object.Receiving;
						if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.version != null && original.version !== resolved$1.version || original.digest != null && original.digest !== resolved$1.digest || original.mutable != null || original.initialSharedVersion != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
					} else if (resolvedInput.Object.$kind === "SharedObject") {
						const original = input.UnresolvedObject;
						const resolved$1 = resolvedInput.Object.SharedObject;
						if (normalizeSuiAddress(original.objectId) !== normalizeSuiAddress(resolved$1.objectId) || original.initialSharedVersion != null && original.initialSharedVersion !== resolved$1.initialSharedVersion || original.mutable != null && original.mutable !== resolved$1.mutable || original.version != null || original.digest != null) throw new Error(`Input at index ${i} did not match unresolved object. ${JSON.stringify(original)} is not compatible with ${JSON.stringify(resolved$1)}`);
					} else throw new Error(`Input at index ${i} resolved to an unexpected Object kind: ${JSON.stringify(resolvedInput.Object)}`);
					this.inputs[i] = resolvedInput;
			}
		}
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/Commands.mjs
/**
* Simple helpers used to construct transactions:
*/
var TransactionCommands = {
	MoveCall(input) {
		const [pkg, mod = "", fn = ""] = "target" in input ? input.target.split("::") : [
			input.package,
			input.module,
			input.function
		];
		return {
			$kind: "MoveCall",
			MoveCall: {
				package: pkg,
				module: mod,
				function: fn,
				typeArguments: input.typeArguments ?? [],
				arguments: input.arguments ?? []
			}
		};
	},
	TransferObjects(objects, address) {
		return {
			$kind: "TransferObjects",
			TransferObjects: {
				objects: objects.map((o) => parse$2(ArgumentSchema, o)),
				address: parse$2(ArgumentSchema, address)
			}
		};
	},
	SplitCoins(coin, amounts) {
		return {
			$kind: "SplitCoins",
			SplitCoins: {
				coin: parse$2(ArgumentSchema, coin),
				amounts: amounts.map((o) => parse$2(ArgumentSchema, o))
			}
		};
	},
	MergeCoins(destination, sources) {
		return {
			$kind: "MergeCoins",
			MergeCoins: {
				destination: parse$2(ArgumentSchema, destination),
				sources: sources.map((o) => parse$2(ArgumentSchema, o))
			}
		};
	},
	Publish({ modules, dependencies }) {
		return {
			$kind: "Publish",
			Publish: {
				modules: modules.map((module) => typeof module === "string" ? module : toBase64(new Uint8Array(module))),
				dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep))
			}
		};
	},
	Upgrade({ modules, dependencies, package: packageId, ticket }) {
		return {
			$kind: "Upgrade",
			Upgrade: {
				modules: modules.map((module) => typeof module === "string" ? module : toBase64(new Uint8Array(module))),
				dependencies: dependencies.map((dep) => normalizeSuiObjectId(dep)),
				package: packageId,
				ticket: parse$2(ArgumentSchema, ticket)
			}
		};
	},
	MakeMoveVec({ type, elements }) {
		return {
			$kind: "MakeMoveVec",
			MakeMoveVec: {
				type: type ?? null,
				elements: elements.map((o) => parse$2(ArgumentSchema, o))
			}
		};
	},
	Intent({ name, inputs = {}, data = {} }) {
		return {
			$kind: "$Intent",
			$Intent: {
				name,
				inputs: Object.fromEntries(Object.entries(inputs).map(([key, value]) => [key, Array.isArray(value) ? value.map((o) => parse$2(ArgumentSchema, o)) : parse$2(ArgumentSchema, value)])),
				data
			}
		};
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/Inputs.mjs
function Pure(data) {
	return {
		$kind: "Pure",
		Pure: { bytes: data instanceof Uint8Array ? toBase64(data) : data.toBase64() }
	};
}
var Inputs = {
	Pure,
	ObjectRef({ objectId, digest, version }) {
		return {
			$kind: "Object",
			Object: {
				$kind: "ImmOrOwnedObject",
				ImmOrOwnedObject: {
					digest,
					version,
					objectId: normalizeSuiAddress(objectId)
				}
			}
		};
	},
	SharedObjectRef({ objectId, mutable, initialSharedVersion }) {
		return {
			$kind: "Object",
			Object: {
				$kind: "SharedObject",
				SharedObject: {
					mutable,
					initialSharedVersion,
					objectId: normalizeSuiAddress(objectId)
				}
			}
		};
	},
	ReceivingRef({ objectId, digest, version }) {
		return {
			$kind: "Object",
			Object: {
				$kind: "Receiving",
				Receiving: {
					digest,
					version,
					objectId: normalizeSuiAddress(objectId)
				}
			}
		};
	},
	FundsWithdrawal({ reservation, typeArg, withdrawFrom }) {
		return {
			$kind: "FundsWithdrawal",
			FundsWithdrawal: {
				reservation,
				typeArg,
				withdrawFrom
			}
		};
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/utils/constants.mjs
var MOVE_STDLIB_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000001";
var SUI_FRAMEWORK_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000002";
var SUI_SYSTEM_ADDRESS = "0x0000000000000000000000000000000000000000000000000000000000000003";
var SUI_CLOCK_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000006";
var SUI_TYPE_ARG = `${SUI_FRAMEWORK_ADDRESS}::sui::SUI`;
var SUI_SYSTEM_STATE_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000005";
var SUI_RANDOM_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000008";
var SUI_DENY_LIST_OBJECT_ID = "0x0000000000000000000000000000000000000000000000000000000000000403";
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/serializer.mjs
/**
* Parses a type name like "0x2::tx_context::TxContext" into package, module, and name parts.
*/
function parseTypeName(typeName) {
	const parts = typeName.split("::");
	if (parts.length !== 3) throw new Error(`Invalid type name format: ${typeName}`);
	return {
		package: parts[0],
		module: parts[1],
		name: parts[2]
	};
}
function isTxContext(param) {
	if (param.body.$kind !== "datatype") return false;
	const { package: pkg, module, name } = parseTypeName(param.body.datatype.typeName);
	return normalizeSuiAddress(pkg) === "0x0000000000000000000000000000000000000000000000000000000000000002" && module === "tx_context" && name === "TxContext";
}
function getPureBcsSchema(typeSignature) {
	switch (typeSignature.$kind) {
		case "address": return suiBcs.Address;
		case "bool": return suiBcs.Bool;
		case "u8": return suiBcs.U8;
		case "u16": return suiBcs.U16;
		case "u32": return suiBcs.U32;
		case "u64": return suiBcs.U64;
		case "u128": return suiBcs.U128;
		case "u256": return suiBcs.U256;
		case "vector": {
			if (typeSignature.vector.$kind === "u8") return suiBcs.byteVector().transform({
				input: (val) => typeof val === "string" ? new TextEncoder().encode(val) : val,
				output: (val) => val
			});
			const type = getPureBcsSchema(typeSignature.vector);
			return type ? suiBcs.vector(type) : null;
		}
		case "datatype": {
			const { package: pkg, module, name } = parseTypeName(typeSignature.datatype.typeName);
			const normalizedPkg = normalizeSuiAddress(pkg);
			if (normalizedPkg === "0x0000000000000000000000000000000000000000000000000000000000000001") {
				if (module === "ascii" && name === "String") return suiBcs.String;
				if (module === "string" && name === "String") return suiBcs.String;
				if (module === "option" && name === "Option") {
					const type = getPureBcsSchema(typeSignature.datatype.typeParameters[0]);
					return type ? suiBcs.vector(type) : null;
				}
			}
			if (normalizedPkg === "0x0000000000000000000000000000000000000000000000000000000000000002") {
				if (module === "object" && name === "ID") return suiBcs.Address;
			}
			return null;
		}
		case "typeParameter":
		case "unknown": return null;
	}
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/intents/BalanceIntentNames.mjs
var ALLOWANCE_BALANCE = "AllowanceBalance";
var COIN_WITH_BALANCE = "CoinWithBalance";
//#endregion
//#region node_modules/@mysten/sui/dist/utils/move-registry.mjs
/**
* Checks if a type contains valid named packages and is a valid Move struct tag.
*/
var isValidNamedType = (type) => {
	const splitType = type.split(/::|<|>|,/);
	for (const t of splitType) if (t.includes("/") && !isValidNamedPackage(t)) return false;
	return isValidStructTag(type);
};
//#endregion
//#region node_modules/@mysten/sui/dist/version.mjs
var PACKAGE_VERSION = "2.35.0";
//#endregion
//#region node_modules/@mysten/sui/dist/client/mvr.mjs
var NAME_SEPARATOR = "/";
var MVR_API_HEADER = { "Mvr-Source": `@mysten/sui@${PACKAGE_VERSION}` };
var MvrClient = class {
	#cache;
	#url;
	#pageSize;
	#overrides;
	constructor({ cache, url, pageSize = 50, overrides }) {
		this.#cache = cache;
		this.#url = url;
		this.#pageSize = pageSize;
		this.#overrides = {
			packages: overrides?.packages,
			types: overrides?.types
		};
		validateOverrides(this.#overrides);
	}
	get #mvrPackageDataLoader() {
		return this.#cache.readSync(["#mvrPackageDataLoader", this.#url ?? ""], () => {
			const loader = new DataLoader(async (packages) => {
				if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${packages.join(", ")})`);
				const resolved = await this.#resolvePackages(packages);
				return packages.map((pkg) => resolved[pkg] ?? /* @__PURE__ */ new Error(`Failed to resolve package: ${pkg}`));
			});
			const overrides = this.#overrides?.packages;
			if (overrides) for (const [pkg, id] of Object.entries(overrides)) loader.prime(pkg, id);
			return loader;
		});
	}
	get #mvrTypeDataLoader() {
		return this.#cache.readSync(["#mvrTypeDataLoader", this.#url ?? ""], () => {
			const loader = new DataLoader(async (types) => {
				if (!this.#url) throw new Error(`MVR Api URL is not set for the current client (resolving ${types.join(", ")})`);
				const resolved = await this.#resolveTypes(types);
				return types.map((type) => resolved[type] ?? /* @__PURE__ */ new Error(`Failed to resolve type: ${type}`));
			});
			const overrides = this.#overrides?.types;
			if (overrides) for (const [type, id] of Object.entries(overrides)) loader.prime(type, id);
			return loader;
		});
	}
	async #resolvePackages(packages) {
		if (packages.length === 0) return {};
		const batches = chunk(packages, this.#pageSize);
		const results = {};
		await Promise.all(batches.map(async (batch) => {
			const data = await this.#fetch("/v1/resolution/bulk", { names: batch });
			if (!data?.resolution) return;
			for (const pkg of Object.keys(data?.resolution)) {
				const pkgData = data.resolution[pkg]?.package_id;
				if (!pkgData) continue;
				results[pkg] = pkgData;
			}
		}));
		return results;
	}
	async #resolveTypes(types) {
		if (types.length === 0) return {};
		const batches = chunk(types, this.#pageSize);
		const results = {};
		await Promise.all(batches.map(async (batch) => {
			const data = await this.#fetch("/v1/struct-definition/bulk", { types: batch });
			if (!data?.resolution) return;
			for (const type of Object.keys(data?.resolution)) {
				const typeData = data.resolution[type]?.type_tag;
				if (!typeData) continue;
				results[type] = typeData;
			}
		}));
		return results;
	}
	async #fetch(url, body) {
		if (!this.#url) throw new Error("MVR Api URL is not set for the current client");
		const response = await fetch(`${this.#url}${url}`, {
			method: "POST",
			headers: {
				"Content-Type": "application/json",
				...MVR_API_HEADER
			},
			body: JSON.stringify(body)
		});
		if (!response.ok) {
			const errorBody = await response.json().catch(() => ({}));
			throw new Error(`Failed to resolve types: ${errorBody?.message}`);
		}
		return response.json();
	}
	async resolvePackage({ package: name, signal }) {
		signal?.throwIfAborted();
		if (!hasMvrName(name)) return { package: name };
		return { package: await raceSignal(this.#mvrPackageDataLoader.load(name), signal) };
	}
	async resolveType({ type, signal }) {
		signal?.throwIfAborted();
		if (!hasMvrName(type)) return { type };
		const mvrTypes = [...extractMvrTypes(type)];
		const resolvedTypes = await raceSignal(this.#mvrTypeDataLoader.loadMany(mvrTypes), signal);
		const typeMap = {};
		for (let i = 0; i < mvrTypes.length; i++) {
			const resolvedType = resolvedTypes[i];
			if (resolvedType instanceof Error) throw resolvedType;
			typeMap[mvrTypes[i]] = resolvedType;
		}
		return { type: replaceMvrNames(type, typeMap) };
	}
	async resolve({ types = [], packages = [], signal }) {
		signal?.throwIfAborted();
		const mvrTypes = /* @__PURE__ */ new Set();
		for (const type of types ?? []) extractMvrTypes(type, mvrTypes);
		const typesArray = [...mvrTypes];
		const [resolvedTypes, resolvedPackages] = await raceSignal(Promise.all([typesArray.length > 0 ? this.#mvrTypeDataLoader.loadMany(typesArray) : [], packages.length > 0 ? this.#mvrPackageDataLoader.loadMany(packages) : []]), signal);
		const typeMap = { ...this.#overrides?.types };
		for (const [i, type] of typesArray.entries()) {
			const resolvedType = resolvedTypes[i];
			if (resolvedType instanceof Error) throw resolvedType;
			typeMap[type] = resolvedType;
		}
		const replacedTypes = {};
		for (const type of types ?? []) replacedTypes[type] = { type: replaceMvrNames(type, typeMap) };
		const replacedPackages = {};
		for (const [i, pkg] of (packages ?? []).entries()) {
			const resolvedPkg = this.#overrides?.packages?.[pkg] ?? resolvedPackages[i];
			if (resolvedPkg instanceof Error) throw resolvedPkg;
			replacedPackages[pkg] = { package: resolvedPkg };
		}
		return {
			types: replacedTypes,
			packages: replacedPackages
		};
	}
};
function validateOverrides(overrides) {
	if (overrides?.packages) for (const [pkg, id] of Object.entries(overrides.packages)) {
		if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
		if (!isValidSuiAddress(normalizeSuiAddress(id))) throw new Error(`Invalid package ID: ${id}`);
	}
	if (overrides?.types) for (const [type, val] of Object.entries(overrides.types)) {
		if (parseStructTag(type).typeParams.length > 0) throw new Error("Type overrides must be first-level only. If you want to supply generic types, just pass each type individually.");
		if (!isValidSuiAddress(parseStructTag(val).address)) throw new Error(`Invalid type: ${val}`);
	}
}
/**
* Extracts all named types from a given type.
*/
function extractMvrTypes(type, types = /* @__PURE__ */ new Set()) {
	if (typeof type === "string" && !hasMvrName(type)) return types;
	if (typeof type === "string" && type.startsWith("vector<") && type.endsWith(">")) return extractMvrTypes(type.slice(7, -1), types);
	const tag = isStructTag(type) ? type : parseStructTag(type);
	if (hasMvrName(tag.address)) types.add(`${tag.address}::${tag.module}::${tag.name}`);
	for (const param of tag.typeParams) extractMvrTypes(param, types);
	return types;
}
/**
* Traverses a type, and replaces any found names with their resolved equivalents,
* based on the supplied type cache.
*/
function replaceMvrNames(tag, typeCache) {
	if (typeof tag === "string" && !tag.includes("::")) return tag;
	if (typeof tag === "string" && tag.startsWith("vector<") && tag.endsWith(">")) return `vector<${replaceMvrNames(tag.slice(7, -1), typeCache)}>`;
	const type = isStructTag(tag) ? tag : parseStructTag(tag);
	const cacheHit = typeCache[`${type.address}::${type.module}::${type.name}`];
	return normalizeStructTag({
		...type,
		address: cacheHit ? cacheHit.split("::")[0] : type.address,
		typeParams: type.typeParams.map((param) => replaceMvrNames(param, typeCache))
	});
}
function hasMvrName(nameOrType) {
	return nameOrType.includes(NAME_SEPARATOR) || nameOrType.includes("@") || nameOrType.includes(".sui");
}
/**
* Races a promise against an optional AbortSignal. MVR resolution batches lookups
* from independent callers into a single request via a shared DataLoader, so a
* caller's signal cannot cancel the shared network request without affecting other
* callers. Instead, this rejects the awaiting caller as soon as its signal aborts
* (the underlying request continues in the background).
*
* The same isolation applies to any shared/cached request (e.g. `cache.read`).
*/
function raceSignal(promise, signal) {
	if (!signal) return promise;
	if (signal.aborted) return Promise.reject(signal.reason);
	return new Promise((resolve, reject) => {
		const onAbort = () => reject(signal.reason);
		signal.addEventListener("abort", onAbort, { once: true });
		promise.then(resolve, reject).finally(() => {
			signal.removeEventListener("abort", onAbort);
		});
	});
}
function isStructTag(type) {
	return typeof type === "object" && "address" in type && "module" in type && "name" in type && "typeParams" in type;
}
/**
* Looks up all `.move` names in a transaction block.
* Returns a list of all the names found.
*/
function findNamesInTransaction(builder) {
	const packages = /* @__PURE__ */ new Set();
	const types = /* @__PURE__ */ new Set();
	for (const command of builder.commands) switch (command.$kind) {
		case "MakeMoveVec":
			if (command.MakeMoveVec.type) getNamesFromTypeList([command.MakeMoveVec.type]).forEach((type) => {
				types.add(type);
			});
			break;
		case "MoveCall":
			const moveCall = command.MoveCall;
			const pkg = moveCall.package.split("::")[0];
			if (hasMvrName(pkg)) {
				if (!isValidNamedPackage(pkg)) throw new Error(`Invalid package name: ${pkg}`);
				packages.add(pkg);
			}
			getNamesFromTypeList(moveCall.typeArguments ?? []).forEach((type) => {
				types.add(type);
			});
	}
	return {
		packages: [...packages],
		types: [...types]
	};
}
/**
* Replace all names & types in a transaction block
* with their resolved names/types.
*/
function replaceNames(builder, resolved) {
	for (const command of builder.commands) {
		if (command.MakeMoveVec?.type) {
			if (!hasMvrName(command.MakeMoveVec.type)) continue;
			if (!resolved.types[command.MakeMoveVec.type]) throw new Error(`No resolution found for type: ${command.MakeMoveVec.type}`);
			command.MakeMoveVec.type = resolved.types[command.MakeMoveVec.type].type;
		}
		const tx = command.MoveCall;
		if (!tx) continue;
		const nameParts = tx.package.split("::");
		const name = nameParts[0];
		if (hasMvrName(name) && !resolved.packages[name]) throw new Error(`No address found for package: ${name}`);
		if (hasMvrName(name)) {
			nameParts[0] = resolved.packages[name].package;
			tx.package = nameParts.join("::");
		}
		const types = tx.typeArguments;
		if (!types) continue;
		for (let i = 0; i < types.length; i++) {
			if (!hasMvrName(types[i])) continue;
			if (!resolved.types[types[i]]) throw new Error(`No resolution found for type: ${types[i]}`);
			types[i] = resolved.types[types[i]].type;
		}
		tx.typeArguments = types;
	}
}
/**
* Returns a list of unique types that include a name
* from the given list. This list is retrieved from the Transaction Data.
*/
function getNamesFromTypeList(types) {
	const names = /* @__PURE__ */ new Set();
	for (const type of types) if (hasMvrName(type)) {
		if (!isValidNamedType(type)) throw new Error(`Invalid type with names: ${type}`);
		names.add(type);
	}
	return names;
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/resolution-utils.mjs
function transactionUsesGasCoin(transactionData) {
	let usesGasCoin = false;
	transactionData.mapArguments((arg) => {
		if (arg.$kind === "GasCoin") usesGasCoin = true;
		return arg;
	});
	return usesGasCoin;
}
//#endregion
//#region node_modules/@mysten/sui/dist/client/errors.mjs
var SuiClientError = class extends Error {};
var SimulationError = class extends SuiClientError {
	constructor(message, options) {
		super(message, { cause: options?.cause });
		this.executionError = options?.executionError;
	}
};
/** An error returned for an individual object lookup. */
var ObjectError = class extends SuiClientError {
	constructor(code, message, options) {
		super(message, { cause: options?.cause });
		this.code = code;
		this.reason = options?.reason ?? "unknown";
		this.objectId = options?.objectId;
	}
};
var TRANSACTION_ERROR_MESSAGES = { notFound: (digest) => `Transaction ${digest} not found` };
/** An error returned by a transaction lookup. */
var TransactionError = class extends SuiClientError {
	constructor(reason, digest, options) {
		super(TRANSACTION_ERROR_MESSAGES[reason](digest), options);
		this.reason = reason;
		this.digest = digest;
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/utils/dynamic-fields.mjs
function deriveDynamicFieldID(parentId, typeTag, key) {
	const address = suiBcs.Address.serialize(parentId).toBytes();
	const tag = suiBcs.TypeTag.serialize(typeTag).toBytes();
	const keyLength = suiBcs.u64().serialize(key.length).toBytes();
	const hash = blake2b.create({ dkLen: 32 });
	hash.update(new Uint8Array([240]));
	hash.update(address);
	hash.update(keyLength);
	hash.update(key);
	hash.update(tag);
	return `0x${toHex(hash.digest().slice(0, 32))}`;
}
//#endregion
//#region node_modules/@mysten/sui/dist/utils/coin-reservation.mjs
var SUI_ACCUMULATOR_ROOT_OBJECT_ID = normalizeSuiAddress("0xacc");
var ACCUMULATOR_KEY_TYPE_TAG = TypeTagSerializer.parseFromStr("0x2::accumulator::Key<0x2::balance::Balance<0x2::sui::SUI>>");
var COIN_RESERVATION_MAGIC = new Uint8Array([
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172,
	172
]);
function isCoinReservationDigest(digestBase58) {
	return fromBase58(digestBase58).slice(12, 32).every((byte, i) => byte === COIN_RESERVATION_MAGIC[i]);
}
/**
* Derives the accumulator dynamic field object ID for the given owner,
* then XORs it with the chain identifier bytes to produce the objectId
* for the coin reservation ref.
*/
function deriveReservationObjectId(owner, chainIdentifier) {
	const accBytes = fromHex(deriveDynamicFieldID(SUI_ACCUMULATOR_ROOT_OBJECT_ID, ACCUMULATOR_KEY_TYPE_TAG, suiBcs.Address.serialize(owner).toBytes()).slice(2));
	const chainBytes = fromBase58(chainIdentifier);
	if (chainBytes.length !== 32) throw new Error(`Invalid chain identifier length: expected 32 bytes, got ${chainBytes.length}`);
	const xored = /* @__PURE__ */ new Uint8Array(32);
	for (let i = 0; i < 32; i++) xored[i] = accBytes[i] ^ chainBytes[i];
	return `0x${toHex(xored)}`;
}
function createCoinReservationRef(reservedBalance, owner, chainIdentifier, epoch) {
	const digestBytes = /* @__PURE__ */ new Uint8Array(32);
	const view = new DataView(digestBytes.buffer);
	view.setBigUint64(0, reservedBalance, true);
	const epochNum = Number(epoch);
	if (!Number.isSafeInteger(epochNum) || epochNum < 0 || epochNum > 4294967295) throw new Error(`Epoch ${epoch} out of u32 range for coin reservation digest`);
	view.setUint32(8, epochNum, true);
	digestBytes.set(COIN_RESERVATION_MAGIC, 12);
	return parse$2(ObjectRefSchema, {
		objectId: deriveReservationObjectId(owner, chainIdentifier),
		version: "0",
		digest: toBase58(digestBytes)
	});
}
//#endregion
//#region node_modules/@mysten/sui/dist/client/core-resolver.mjs
var MAX_OBJECTS_PER_FETCH = 50;
var MAX_GAS_PAYMENT_OBJECTS = 256;
var GAS_SAFE_OVERHEAD = 1000n;
var MAX_GAS$1 = 5e10;
/** Compute a gas budget from gasUsed effects data. */
function computeGasBudget(gasUsed, gasPrice = 1n) {
	const safeOverhead = GAS_SAFE_OVERHEAD * BigInt(gasPrice);
	const baseComputationCostWithOverhead = BigInt(gasUsed.computationCost) + safeOverhead;
	const gasBudget = baseComputationCostWithOverhead + BigInt(gasUsed.storageCost) - BigInt(gasUsed.storageRebate);
	return String(gasBudget > baseComputationCostWithOverhead ? gasBudget : baseComputationCostWithOverhead);
}
function getClient$1(options) {
	if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
	return options.client;
}
async function coreClientResolveTransactionPlugin(transactionData, options, next) {
	const client = getClient$1(options);
	const needsGasPrice = !options.onlyTransactionKind && !transactionData.gasData.price;
	const needsPayment = !options.onlyTransactionKind && !transactionData.gasData.payment;
	const gasPayer = transactionData.gasData.owner ?? transactionData.sender;
	const usesGasCoin = transactionUsesGasCoin(transactionData);
	let withdrawals = 0n;
	const normalizedGasPayer = gasPayer ? normalizeSuiAddress(gasPayer) : null;
	for (const input of transactionData.inputs) {
		if (input.$kind !== "FundsWithdrawal" || !normalizedGasPayer) continue;
		if (normalizeStructTag(input.FundsWithdrawal.typeArg.Balance) !== SUI_TYPE_ARG) continue;
		const source = input.FundsWithdrawal.withdrawFrom;
		const withdrawalOwner = source.SenderAllowance ? source.SenderAllowance.funder : source.Sender ? transactionData.sender : gasPayer;
		if (withdrawalOwner && normalizeSuiAddress(withdrawalOwner) === normalizedGasPayer && input.FundsWithdrawal.reservation.$kind === "MaxAmountU64") withdrawals += BigInt(input.FundsWithdrawal.reservation.MaxAmountU64);
	}
	const needsSimulateExpiration = !options.onlyTransactionKind && !transactionData.expiration && !transactionData.gasData.budget;
	const needsSystemState = needsGasPrice || needsPayment && usesGasCoin || needsSimulateExpiration;
	const needsChainId = needsPayment && usesGasCoin || needsSimulateExpiration;
	const [, systemStateResult, balanceResult, coinsResult, chainIdResult] = await Promise.all([
		normalizeInputs(transactionData, client),
		needsSystemState ? client.core.getCurrentSystemState() : null,
		needsPayment && gasPayer ? client.core.getBalance({ owner: gasPayer }) : null,
		needsPayment && gasPayer ? client.core.listCoins({
			owner: gasPayer,
			coinType: SUI_TYPE_ARG
		}) : null,
		needsChainId ? client.core.getChainIdentifier() : null
	]);
	await resolveObjectReferences(transactionData, client);
	if (!options.onlyTransactionKind) {
		const systemState = systemStateResult?.systemState ?? null;
		const chainIdentifier = chainIdResult?.chainIdentifier ?? null;
		if (systemState && !transactionData.gasData.price) transactionData.gasData.price = systemState.referenceGasPrice;
		await setGasBudget(transactionData, client, needsSimulateExpiration && systemState && chainIdentifier ? buildValidDuringExpiration(systemState, chainIdentifier) : void 0);
		if (needsPayment) {
			if (!balanceResult || !coinsResult) throw new Error("Could not resolve gas payment: a gas owner or sender must be set to fetch balance and coins.");
			setGasPayment({
				transactionData,
				balance: balanceResult,
				coins: coinsResult,
				usesGasCoin,
				withdrawals,
				gasPayer,
				chainIdentifier,
				epoch: systemState?.epoch ?? null
			});
		}
		if (!transactionData.expiration && transactionData.gasData.payment?.length === 0) await setExpiration(transactionData, client, systemState, chainIdentifier);
	}
	return await next();
}
async function setGasBudget(transactionData, client, simulateExpiration) {
	if (transactionData.gasData.budget) return;
	const simulateResult = await client.core.simulateTransaction({
		transaction: transactionData.build({ overrides: {
			gasData: {
				budget: String(MAX_GAS$1),
				payment: []
			},
			...simulateExpiration && { expiration: simulateExpiration }
		} }),
		include: { effects: true },
		doGasSelection: false
	});
	if (simulateResult.$kind === "FailedTransaction") {
		const executionError = simulateResult.FailedTransaction.status.error ?? void 0;
		throw new SimulationError(`Transaction resolution failed: ${executionError?.message ?? "Unknown error"}`, {
			cause: simulateResult,
			executionError
		});
	}
	transactionData.gasData.budget = computeGasBudget(simulateResult.Transaction.effects.gasUsed, transactionData.gasData.price ? String(transactionData.gasData.price) : void 0);
}
function setGasPayment({ transactionData, balance, coins, usesGasCoin, withdrawals, gasPayer, chainIdentifier, epoch }) {
	const budget = BigInt(transactionData.gasData.budget);
	const addressBalance = BigInt(balance.balance.addressBalance);
	if (budget === 0n || !usesGasCoin && addressBalance >= budget + withdrawals) {
		transactionData.gasData.payment = [];
		return;
	}
	const filteredCoins = coins.objects.filter((coin) => {
		return !transactionData.inputs.find((input) => {
			if (input.Object?.ImmOrOwnedObject) return coin.objectId === input.Object.ImmOrOwnedObject.objectId;
			return false;
		});
	});
	const paymentCoins = filteredCoins.map((coin) => ({
		objectId: coin.objectId,
		digest: coin.digest,
		version: coin.version
	}));
	const reservationAmount = addressBalance - withdrawals;
	if (usesGasCoin && reservationAmount > 0n && chainIdentifier && epoch) transactionData.gasData.payment = [createCoinReservationRef(reservationAmount, gasPayer, chainIdentifier, epoch), ...paymentCoins.slice(0, 255)];
	else if (!filteredCoins.length) throw new Error("No valid gas coins found for the transaction.");
	else transactionData.gasData.payment = paymentCoins.slice(0, MAX_GAS_PAYMENT_OBJECTS);
}
async function setExpiration(transactionData, client, systemState, existingChainIdentifier = null) {
	const [chainIdentifier, resolvedSystemState] = await Promise.all([existingChainIdentifier ?? client.core.getChainIdentifier().then((r) => r.chainIdentifier), systemState ?? client.core.getCurrentSystemState().then((r) => r.systemState)]);
	transactionData.expiration = buildValidDuringExpiration(resolvedSystemState, chainIdentifier);
}
function buildValidDuringExpiration(systemState, chainIdentifier) {
	const currentEpoch = BigInt(systemState.epoch);
	return {
		$kind: "ValidDuring",
		ValidDuring: {
			minEpoch: String(currentEpoch),
			maxEpoch: String(currentEpoch + 1n),
			minTimestamp: null,
			maxTimestamp: null,
			chain: chainIdentifier,
			nonce: Math.random() * 4294967296 >>> 0
		}
	};
}
async function resolveObjectReferences(transactionData, client) {
	const objectsToResolve = transactionData.inputs.filter((input) => {
		return input.UnresolvedObject && !(input.UnresolvedObject.version || input.UnresolvedObject?.initialSharedVersion);
	});
	const dedupedIds = [...new Set(objectsToResolve.map((input) => normalizeSuiObjectId(input.UnresolvedObject.objectId)))];
	const objectChunks = dedupedIds.length ? chunk(dedupedIds, MAX_OBJECTS_PER_FETCH) : [];
	const resolved = (await Promise.all(objectChunks.map((chunkIds) => client.core.getObjects({ objectIds: chunkIds })))).flatMap((result) => result.objects);
	const responsesById = new Map(dedupedIds.map((id, index) => {
		return [id, resolved[index]];
	}));
	const invalidObjects = Array.from(responsesById).filter(([_, obj]) => obj instanceof Error).map(([_, obj]) => obj.message);
	if (invalidObjects.length) throw new Error(`The following input objects are invalid: ${invalidObjects.join(", ")}`);
	const objects = resolved.map((object) => {
		if (object instanceof Error) throw new Error(`Failed to fetch object: ${object.message}`);
		const owner = object.owner;
		const initialSharedVersion = owner && typeof owner === "object" ? owner.$kind === "Shared" ? owner.Shared.initialSharedVersion : owner.$kind === "ConsensusAddressOwner" ? owner.ConsensusAddressOwner.startVersion : null : null;
		return {
			objectId: object.objectId,
			digest: object.digest,
			version: object.version,
			initialSharedVersion
		};
	});
	const objectsById = new Map(dedupedIds.map((id, index) => {
		return [id, objects[index]];
	}));
	for (const [index, input] of transactionData.inputs.entries()) {
		if (!input.UnresolvedObject) continue;
		let updated;
		const id = normalizeSuiAddress(input.UnresolvedObject.objectId);
		const object = objectsById.get(id);
		if (input.UnresolvedObject.initialSharedVersion ?? object?.initialSharedVersion) updated = Inputs.SharedObjectRef({
			objectId: id,
			initialSharedVersion: input.UnresolvedObject.initialSharedVersion || object?.initialSharedVersion,
			mutable: input.UnresolvedObject.mutable || isUsedAsMutable(transactionData, index)
		});
		else if (isUsedAsReceiving(transactionData, index)) updated = Inputs.ReceivingRef({
			objectId: id,
			digest: input.UnresolvedObject.digest ?? object?.digest,
			version: input.UnresolvedObject.version ?? object?.version
		});
		transactionData.inputs[transactionData.inputs.indexOf(input)] = updated ?? Inputs.ObjectRef({
			objectId: id,
			digest: input.UnresolvedObject.digest ?? object?.digest,
			version: input.UnresolvedObject.version ?? object?.version
		});
	}
}
async function normalizeInputs(transactionData, client) {
	const { inputs, commands } = transactionData;
	const moveCallsToResolve = [];
	const moveFunctionsToResolve = /* @__PURE__ */ new Set();
	commands.forEach((command) => {
		if (command.MoveCall) {
			if (command.MoveCall._argumentTypes) return;
			if (command.MoveCall.arguments.map((arg) => {
				if (arg.$kind === "Input") return transactionData.inputs[arg.Input];
				return null;
			}).some((input) => input?.UnresolvedPure || input?.UnresolvedObject && typeof input?.UnresolvedObject.mutable !== "boolean")) {
				const functionName = `${command.MoveCall.package}::${command.MoveCall.module}::${command.MoveCall.function}`;
				moveFunctionsToResolve.add(functionName);
				moveCallsToResolve.push(command.MoveCall);
			}
		}
	});
	const moveFunctionParameters = /* @__PURE__ */ new Map();
	if (moveFunctionsToResolve.size > 0) await Promise.all([...moveFunctionsToResolve].map(async (functionName) => {
		const [packageId, moduleName, name] = functionName.split("::");
		const { function: def } = await client.core.getMoveFunction({
			packageId,
			moduleName,
			name
		});
		moveFunctionParameters.set(functionName, def.parameters);
	}));
	if (moveCallsToResolve.length) await Promise.all(moveCallsToResolve.map(async (moveCall) => {
		const parameters = moveFunctionParameters.get(`${moveCall.package}::${moveCall.module}::${moveCall.function}`);
		if (!parameters) return;
		moveCall._argumentTypes = parameters.length > 0 && isTxContext(parameters.at(-1)) ? parameters.slice(0, parameters.length - 1) : parameters;
	}));
	commands.forEach((command) => {
		if (!command.MoveCall) return;
		const moveCall = command.MoveCall;
		const fnName = `${moveCall.package}::${moveCall.module}::${moveCall.function}`;
		const params = moveCall._argumentTypes;
		if (!params) return;
		if (params.length !== command.MoveCall.arguments.length) throw new Error(`Incorrect number of arguments for ${fnName}`);
		params.forEach((param, i) => {
			const arg = moveCall.arguments[i];
			if (arg.$kind !== "Input") return;
			const input = inputs[arg.Input];
			if (!input.UnresolvedPure && !input.UnresolvedObject) return;
			const inputValue = input.UnresolvedPure?.value ?? input.UnresolvedObject?.objectId;
			const schema = getPureBcsSchema(param.body);
			if (schema) {
				arg.type = "pure";
				inputs[inputs.indexOf(input)] = Inputs.Pure(schema.serialize(inputValue));
				return;
			}
			if (typeof inputValue !== "string") throw new Error(`Expect the argument to be an object id string, got ${JSON.stringify(inputValue, null, 2)}`);
			arg.type = "object";
			const unresolvedObject = input.UnresolvedPure ? {
				$kind: "UnresolvedObject",
				UnresolvedObject: { objectId: inputValue }
			} : input;
			inputs[arg.Input] = unresolvedObject;
		});
	});
}
function isUsedAsMutable(transactionData, index) {
	let usedAsMutable = false;
	transactionData.getInputUses(index, (arg, tx) => {
		if (tx.MoveCall && tx.MoveCall._argumentTypes) {
			const argIndex = tx.MoveCall.arguments.indexOf(arg);
			usedAsMutable = tx.MoveCall._argumentTypes[argIndex].reference !== "immutable" || usedAsMutable;
		}
		if (tx.$kind === "MakeMoveVec" || tx.$kind === "MergeCoins" || tx.$kind === "SplitCoins" || tx.$kind === "TransferObjects") usedAsMutable = true;
	});
	return usedAsMutable;
}
function isUsedAsReceiving(transactionData, index) {
	let usedAsReceiving = false;
	transactionData.getInputUses(index, (arg, tx) => {
		if (tx.MoveCall && tx.MoveCall._argumentTypes) {
			const argIndex = tx.MoveCall.arguments.indexOf(arg);
			usedAsReceiving = isReceivingType(tx.MoveCall._argumentTypes[argIndex]) || usedAsReceiving;
		}
	});
	return usedAsReceiving;
}
var RECEIVING_TYPE = "0x0000000000000000000000000000000000000000000000000000000000000002::transfer::Receiving";
function isReceivingType(type) {
	if (type.body.$kind !== "datatype") return false;
	return type.body.datatype.typeName === RECEIVING_TYPE;
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/resolve.mjs
function needsTransactionResolution(data, options) {
	if (data.inputs.some((input) => {
		return input.UnresolvedObject || input.UnresolvedPure;
	})) return true;
	if (!options.onlyTransactionKind) {
		if (!data.gasData.price || !data.gasData.budget) return true;
		if (!data.gasData.payment) {
			if (!(options.assumeSufficientAddressBalances && !transactionUsesGasCoin(data)) || data.expiration?.$kind !== "ValidDuring" && data.expiration?.$kind !== "Validity") return true;
		} else if (data.gasData.payment.length === 0 && !data.expiration) return true;
	}
	return false;
}
async function resolveTransactionPlugin(transactionData, options, next) {
	normalizeRawArguments(transactionData);
	if (!needsTransactionResolution(transactionData, options)) {
		if (!options.onlyTransactionKind && !transactionData.gasData.payment) transactionData.gasData.payment = [];
		await validate(transactionData);
		return next();
	}
	return (getClient(options).core?.resolveTransactionPlugin() ?? coreClientResolveTransactionPlugin)(transactionData, options, async () => {
		await validate(transactionData);
		await next();
	});
}
function validate(transactionData) {
	transactionData.inputs.forEach((input, index) => {
		if (input.$kind !== "Object" && input.$kind !== "Pure" && input.$kind !== "FundsWithdrawal") throw new Error(`Input at index ${index} has not been resolved.  Expected a Pure, Object, or FundsWithdrawal input, but found ${JSON.stringify(input)}`);
	});
}
function getClient(options) {
	if (!options.client) throw new Error(`No sui client passed to Transaction#build, but transaction data was not sufficient to build offline.`);
	return options.client;
}
function normalizeRawArguments(transactionData) {
	for (const command of transactionData.commands) switch (command.$kind) {
		case "SplitCoins":
			command.SplitCoins.amounts.forEach((amount) => {
				normalizeRawArgument(amount, suiBcs.U64, transactionData);
			});
			break;
		case "TransferObjects": normalizeRawArgument(command.TransferObjects.address, suiBcs.Address, transactionData);
	}
}
function normalizeRawArgument(arg, schema, transactionData) {
	if (arg.$kind !== "Input") return;
	const input = transactionData.inputs[arg.Input];
	if (input.$kind !== "UnresolvedPure") return;
	transactionData.inputs[arg.Input] = Inputs.Pure(schema.serialize(input.UnresolvedPure.value));
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/intents/AllowanceBalance.mjs
var AllowanceBalanceData = object({
	objectId: string(),
	funder: optional(string()),
	appType: optional(string()),
	type: string(),
	amount: string(),
	outputKind: picklist(["coin", "balance"])
});
var AllowanceMetadata = suiBcs.struct("AllowanceMetadata", {
	id: suiBcs.Address,
	funder: suiBcs.Address,
	spender: suiBcs.option(suiBcs.Address),
	app: suiBcs.option(suiBcs.string())
});
function allowanceBalance({ allowance, amount, type = "0x2::sui::SUI", outputKind }) {
	suiBcs.U64.validate(amount);
	const objectId = normalizeSuiAddress(typeof allowance === "string" ? allowance : allowance.objectId);
	const reference = typeof allowance === "string" ? { objectId } : allowance;
	return (tx) => {
		tx.addIntentResolver(ALLOWANCE_BALANCE, resolveBalances);
		return tx.add(TransactionCommands.Intent({
			name: ALLOWANCE_BALANCE,
			inputs: {
				allowance: tx.object(objectId),
				clock: tx.object.clock(),
				...reference.app ? { permit: tx.object(reference.app.permit) } : {}
			},
			data: {
				objectId,
				funder: reference.funder ? normalizeSuiAddress(reference.funder) : void 0,
				appType: reference.app ? normalizeStructTag(reference.app.type) : void 0,
				type: normalizeStructTag(type),
				amount: String(amount),
				outputKind
			}
		}));
	};
}
var resolveAllowanceBalance = async (transactionData, options, next) => {
	const ids = /* @__PURE__ */ new Set();
	const namedTypes = /* @__PURE__ */ new Set();
	for (const command of transactionData.commands) {
		if (command.$kind !== "$Intent" || command.$Intent.name !== "AllowanceBalance") continue;
		const data = parse$2(AllowanceBalanceData, command.$Intent.data);
		if (!data.funder) ids.add(data.objectId);
		for (const type of [data.type, data.appType]) if (type && hasMvrName(type)) namedTypes.add(type);
	}
	const [resolvedTypes, objects] = await Promise.all([namedTypes.size ? getClient(options).core.mvr.resolve({ types: [...namedTypes] }) : void 0, ids.size ? getClient(options).core.getObjects({
		objectIds: [...ids],
		include: { content: true }
	}).then((result) => result.objects) : []]);
	const allowances = /* @__PURE__ */ new Map();
	for (const object$1 of objects) {
		if (object$1 instanceof Error) throw object$1;
		allowances.set(object$1.objectId, object$1);
	}
	for (let index = 0; index < transactionData.commands.length; index++) {
		const command = transactionData.commands[index];
		if (command.$kind !== "$Intent" || command.$Intent.name !== "AllowanceBalance") continue;
		const data = parse$2(AllowanceBalanceData, command.$Intent.data);
		if (hasMvrName(data.type)) {
			const resolved = resolvedTypes?.types[data.type];
			if (!resolved) throw new Error(`No resolution found for type: ${data.type}`);
			data.type = normalizeStructTag(resolved.type);
		}
		if (data.appType && hasMvrName(data.appType)) {
			const resolved = resolvedTypes?.types[data.appType];
			if (!resolved) throw new Error(`No resolution found for type: ${data.appType}`);
			data.appType = normalizeStructTag(resolved.type);
		}
		let funder = data.funder;
		if (!funder) {
			const allowance = allowances.get(data.objectId);
			const expectedType = normalizeStructTag(`0x2::allowance::Allowance<0x2::balance::Balance<${data.type}>>`);
			if (!allowance || allowance.type !== expectedType || allowance.owner.$kind !== "Shared") throw new Error(`Expected a shared ${expectedType} allowance at ${data.objectId}`);
			const metadata = AllowanceMetadata.parse(allowance.content);
			if (metadata.app !== null && !data.appType) throw new Error(`Allowance ${data.objectId} is app-bound; pass allowance.app with the app type and SpendPermit`);
			if (data.appType && (metadata.app === null || normalizeStructTag(metadata.app) !== data.appType)) throw new Error(`Allowance ${data.objectId} is not bound to app ${data.appType}`);
			funder = metadata.funder;
			const input = command.$Intent.inputs.allowance;
			if (input.$kind === "Input") transactionData.inputs[input.Input] = Inputs.SharedObjectRef({
				objectId: data.objectId,
				initialSharedVersion: allowance.owner.Shared.initialSharedVersion,
				mutable: true
			});
		}
		const allowanceArgument = command.$Intent.inputs.allowance;
		if (allowanceArgument.$kind === "Input") {
			const input = transactionData.inputs[allowanceArgument.Input];
			if (input.Object?.SharedObject) input.Object.SharedObject.mutable = true;
			if (input.UnresolvedObject) input.UnresolvedObject.mutable = true;
		}
		const withdrawal = transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
			reservation: {
				$kind: "MaxAmountU64",
				MaxAmountU64: data.amount
			},
			typeArg: {
				$kind: "Balance",
				Balance: data.type
			},
			withdrawFrom: {
				$kind: "SenderAllowance",
				SenderAllowance: {
					funder,
					allowance: data.objectId
				}
			}
		}));
		const commands = [TransactionCommands.MoveCall({
			target: data.appType ? "0x2::allowance::app_balance_spend" : "0x2::allowance::balance_spend",
			typeArguments: data.appType ? [data.type, data.appType] : [data.type],
			arguments: [
				command.$Intent.inputs.allowance,
				...data.appType ? [command.$Intent.inputs.permit] : [],
				withdrawal,
				command.$Intent.inputs.clock
			]
		})];
		if (data.outputKind === "coin") commands.push(TransactionCommands.MoveCall({
			target: "0x2::coin::from_balance",
			typeArguments: [data.type],
			arguments: [{
				$kind: "Result",
				Result: index
			}]
		}));
		transactionData.replaceCommand(index, commands, { NestedResult: [index + commands.length - 1, 0] });
		index += commands.length - 1;
	}
	return next();
};
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/intents/ResolveBalances.mjs
async function resolveBalances(transactionData, options, next) {
	const intents = new Set(options.intentNames ?? ["AllowanceBalance", "CoinWithBalance"]);
	const shouldResolve = (name) => intents.has(name) && !options.supportedIntents?.includes(name) && transactionData.commands.some((command) => command.$Intent?.name === name);
	if (shouldResolve("AllowanceBalance")) await resolveAllowanceBalance(transactionData, options, async () => {});
	if (shouldResolve("CoinWithBalance")) await resolveCoinBalance(transactionData, options, async () => {});
	await next();
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/intents/CoinWithBalance.mjs
var SUI_TYPE = normalizeStructTag("0x2::sui::SUI");
function coinWithBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
	let coinResult = null;
	return (tx) => {
		if (coinResult) return coinResult;
		tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
		const coinType = type === "gas" ? type : normalizeStructTag(type);
		coinResult = tx.add(TransactionCommands.Intent({
			name: COIN_WITH_BALANCE,
			inputs: {},
			data: {
				type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
				balance: BigInt(balance),
				outputKind: "coin"
			}
		}));
		return coinResult;
	};
}
function createBalance({ type = SUI_TYPE, balance, useGasCoin = true }) {
	let balanceResult = null;
	return (tx) => {
		if (balanceResult) return balanceResult;
		tx.addIntentResolver(COIN_WITH_BALANCE, resolveBalances);
		const coinType = type === "gas" ? type : normalizeStructTag(type);
		balanceResult = tx.add(TransactionCommands.Intent({
			name: COIN_WITH_BALANCE,
			inputs: {},
			data: {
				type: coinType === SUI_TYPE && useGasCoin ? "gas" : coinType,
				balance: BigInt(balance),
				outputKind: "balance"
			}
		}));
		return balanceResult;
	};
}
var CoinWithBalanceData = object({
	type: string(),
	balance: pipe(union([
		bigint(),
		string(),
		pipe(number(), integer())
	]), transform((value) => BigInt(value))),
	outputKind: optional(picklist(["coin", "balance"]))
});
async function resolveCoinBalance(transactionData, buildOptions, next) {
	const coinTypes = /* @__PURE__ */ new Set();
	const totalByType = /* @__PURE__ */ new Map();
	const intentsByType = /* @__PURE__ */ new Map();
	if (!transactionData.sender) throw new Error("Sender must be set to resolve CoinWithBalance");
	if (transactionData.commands.some((command) => command.$Intent?.name === "AllowanceBalance")) throw new Error("Resolve AllowanceBalance together with CoinWithBalance, or preserve both intents");
	const reservedByType = /* @__PURE__ */ new Map();
	for (const input of transactionData.inputs) {
		if (!input.FundsWithdrawal) continue;
		const { withdrawFrom, typeArg, reservation } = input.FundsWithdrawal;
		if (normalizeSuiAddress(withdrawFrom.SenderAllowance?.funder ?? (withdrawFrom.Sender ? transactionData.sender : transactionData.gasData.owner ?? transactionData.sender)) !== normalizeSuiAddress(transactionData.sender)) continue;
		const type = normalizeStructTag(typeArg.Balance);
		reservedByType.set(type, (reservedByType.get(type) ?? 0n) + BigInt(reservation.MaxAmountU64));
	}
	for (const [i, command] of transactionData.commands.entries()) {
		if (command.$kind !== "$Intent" || command.$Intent.name !== "CoinWithBalance") continue;
		const { type, balance, outputKind } = parse$2(CoinWithBalanceData, command.$Intent.data);
		if (balance === 0n) {
			const coinType = type === "gas" ? SUI_TYPE : type;
			transactionData.replaceCommand(i, TransactionCommands.MoveCall({
				target: (outputKind ?? "coin") === "balance" ? "0x2::balance::zero" : "0x2::coin::zero",
				typeArguments: [coinType]
			}));
			continue;
		}
		if (type !== "gas") coinTypes.add(type);
		totalByType.set(type, (totalByType.get(type) ?? 0n) + balance);
		if (!intentsByType.has(type)) intentsByType.set(type, []);
		intentsByType.get(type).push({
			balance,
			outputKind: outputKind ?? "coin"
		});
	}
	if (totalByType.has("gas") && totalByType.has(SUI_TYPE)) throw new Error("Cannot mix SUI CoinWithBalance intents that use the gas coin with ones that do not (useGasCoin: false). Use one or the other.");
	const usedIds = /* @__PURE__ */ new Set();
	for (const input of transactionData.inputs) {
		if (input.Object?.ImmOrOwnedObject) usedIds.add(input.Object.ImmOrOwnedObject.objectId);
		if (input.UnresolvedObject?.objectId) usedIds.add(input.UnresolvedObject.objectId);
	}
	const coinsByType = /* @__PURE__ */ new Map();
	const addressBalanceByType = /* @__PURE__ */ new Map();
	const client = buildOptions.client;
	const assumeSufficientAddressBalances = buildOptions.assumeSufficientAddressBalances;
	if (!client && !assumeSufficientAddressBalances) throw new Error("Client must be provided to build or serialize transactions with CoinWithBalance intents");
	if (assumeSufficientAddressBalances) for (const [coinType, balance] of totalByType) addressBalanceByType.set(coinType, balance);
	else await Promise.all([...[...coinTypes].map(async (coinType) => {
		const { coins, addressBalance } = await getCoinsAndBalanceOfType({
			coinType,
			balance: totalByType.get(coinType),
			client,
			owner: transactionData.sender,
			usedIds,
			reserved: reservedByType.get(coinType) ?? 0n
		});
		coinsByType.set(coinType, coins);
		addressBalanceByType.set(coinType, addressBalance);
	}), totalByType.has("gas") ? await client.core.getBalance({
		owner: transactionData.sender,
		coinType: SUI_TYPE
	}).then(({ balance }) => {
		addressBalanceByType.set("gas", availableAddressBalance(balance.addressBalance, reservedByType.get(SUI_TYPE) ?? 0n));
	}) : null]);
	const exactBalanceByType = /* @__PURE__ */ new Map();
	const usedAddressBalance = /* @__PURE__ */ new Set();
	const typeState = /* @__PURE__ */ new Map();
	let index = 0;
	while (index < transactionData.commands.length) {
		const transaction = transactionData.commands[index];
		if (transaction.$kind !== "$Intent" || transaction.$Intent.name !== "CoinWithBalance") {
			index++;
			continue;
		}
		const { type, balance } = parse$2(CoinWithBalanceData, transaction.$Intent.data);
		const coinType = type === "gas" ? SUI_TYPE : type;
		const totalRequired = totalByType.get(type);
		const addressBalance = addressBalanceByType.get(type) ?? 0n;
		const commands = [];
		let intentResult;
		const intentsForType = intentsByType.get(type) ?? [];
		if (intentsForType.every((i) => i.outputKind === "balance") && addressBalance >= totalRequired) {
			commands.push(TransactionCommands.MoveCall({
				target: "0x2::balance::redeem_funds",
				typeArguments: [coinType],
				arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
					reservation: {
						$kind: "MaxAmountU64",
						MaxAmountU64: String(balance)
					},
					typeArg: {
						$kind: "Balance",
						Balance: coinType
					},
					withdrawFrom: {
						$kind: "Sender",
						Sender: true
					}
				}))]
			}));
			intentResult = {
				$kind: "NestedResult",
				NestedResult: [index + commands.length - 1, 0]
			};
		} else {
			if (!typeState.has(type)) {
				const intents = intentsForType;
				const sources = [];
				if (addressBalance >= totalRequired) {
					usedAddressBalance.add(type);
					commands.push(TransactionCommands.MoveCall({
						target: "0x2::coin::redeem_funds",
						typeArguments: [coinType],
						arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
							reservation: {
								$kind: "MaxAmountU64",
								MaxAmountU64: String(totalRequired)
							},
							typeArg: {
								$kind: "Balance",
								Balance: coinType
							},
							withdrawFrom: {
								$kind: "Sender",
								Sender: true
							}
						}))]
					}));
					sources.push({
						$kind: "Result",
						Result: index + commands.length - 1
					});
				} else if (type === "gas") sources.push({
					$kind: "GasCoin",
					GasCoin: true
				});
				else {
					const coins = coinsByType.get(type);
					const loadedCoinBalance = coins.reduce((sum, c) => sum + BigInt(c.balance), 0n);
					const abNeeded = totalRequired > loadedCoinBalance ? totalRequired - loadedCoinBalance : 0n;
					exactBalanceByType.set(type, loadedCoinBalance + abNeeded === totalRequired);
					for (const coin of coins) sources.push(transactionData.addInput("object", Inputs.ObjectRef({
						objectId: coin.objectId,
						digest: coin.digest,
						version: coin.version
					})));
					if (abNeeded > 0n) {
						usedAddressBalance.add(type);
						commands.push(TransactionCommands.MoveCall({
							target: "0x2::coin::redeem_funds",
							typeArguments: [coinType],
							arguments: [transactionData.addInput("withdrawal", Inputs.FundsWithdrawal({
								reservation: {
									$kind: "MaxAmountU64",
									MaxAmountU64: String(abNeeded)
								},
								typeArg: {
									$kind: "Balance",
									Balance: coinType
								},
								withdrawFrom: {
									$kind: "Sender",
									Sender: true
								}
							}))]
						}));
						sources.push({
							$kind: "Result",
							Result: index + commands.length - 1
						});
					}
				}
				const baseCoin = sources[0];
				const rest = sources.slice(1);
				for (let i = 0; i < rest.length; i += 500) commands.push(TransactionCommands.MergeCoins(baseCoin, rest.slice(i, i + 500)));
				const splitCmdIndex = index + commands.length;
				commands.push(TransactionCommands.SplitCoins(baseCoin, intents.map((i) => transactionData.addInput("pure", Inputs.Pure(suiBcs.u64().serialize(i.balance))))));
				const results = [];
				for (let i = 0; i < intents.length; i++) {
					const splitResult = {
						$kind: "NestedResult",
						NestedResult: [splitCmdIndex, i]
					};
					if (intents[i].outputKind === "balance") {
						commands.push(TransactionCommands.MoveCall({
							target: "0x2::coin::into_balance",
							typeArguments: [coinType],
							arguments: [splitResult]
						}));
						results.push({
							$kind: "NestedResult",
							NestedResult: [index + commands.length - 1, 0]
						});
					} else results.push(splitResult);
				}
				if (type !== "gas" || usedAddressBalance.has(type)) {
					const hasBalanceIntent = intents.some((intent) => intent.outputKind === "balance");
					const sourcedFromAB = usedAddressBalance.has(type);
					if (hasBalanceIntent || sourcedFromAB) commands.push(TransactionCommands.MoveCall({
						target: "0x2::coin::send_funds",
						typeArguments: [coinType],
						arguments: [baseCoin, transactionData.addInput("pure", Inputs.Pure(suiBcs.Address.serialize(transactionData.sender)))]
					}));
					else if (exactBalanceByType.get(type)) commands.push(TransactionCommands.MoveCall({
						target: "0x2::coin::destroy_zero",
						typeArguments: [coinType],
						arguments: [baseCoin]
					}));
				}
				typeState.set(type, {
					results,
					nextIntent: 0
				});
			}
			const state = typeState.get(type);
			intentResult = state.results[state.nextIntent++];
		}
		transactionData.replaceCommand(index, commands, intentResult);
		index += commands.length;
	}
	return next();
}
async function getCoinsAndBalanceOfType({ coinType, balance, client, owner, usedIds, reserved }) {
	let remainingBalance = balance;
	const coins = [];
	const balanceRequest = client.core.getBalance({
		owner,
		coinType
	}).then(({ balance: balance$1 }) => {
		const addressBalance = availableAddressBalance(balance$1.addressBalance, reserved);
		remainingBalance -= addressBalance;
		return {
			...balance$1,
			addressBalance: String(addressBalance),
			balance: String(BigInt(balance$1.balance) - reserved)
		};
	});
	const [allCoins, balanceResponse] = await Promise.all([loadMoreCoins(), balanceRequest]);
	if (BigInt(balanceResponse.balance) < balance) throw new Error(`Insufficient balance of ${coinType} for owner ${owner}. Required: ${balance}, Available: ${balance - remainingBalance}`);
	return {
		coins: allCoins,
		balance: BigInt(balanceResponse.coinBalance),
		addressBalance: BigInt(balanceResponse.addressBalance),
		coinBalance: BigInt(balanceResponse.coinBalance)
	};
	async function loadMoreCoins(cursor = null) {
		const { objects, hasNextPage, cursor: nextCursor } = await client.core.listCoins({
			owner,
			coinType,
			cursor
		});
		await balanceRequest;
		for (const coin of objects) {
			if (usedIds.has(coin.objectId)) continue;
			coins.push(coin);
			remainingBalance -= BigInt(coin.balance);
		}
		if (remainingBalance > 0n && hasNextPage) return loadMoreCoins(nextCursor);
		return coins;
	}
}
function availableAddressBalance(balance, reserved) {
	const available = BigInt(balance) - reserved;
	if (available < 0n) throw new Error(`Insufficient address balance for existing withdrawals. Required: ${reserved}, Available: ${balance}`);
	return available;
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/data/v2.mjs
function enumUnion(options) {
	return union(Object.entries(options).map(([key, value]) => object({ [key]: value })));
}
var Argument = enumUnion({
	GasCoin: literal(true),
	Input: pipe(number(), integer()),
	Result: pipe(number(), integer()),
	NestedResult: tuple([pipe(number(), integer()), pipe(number(), integer())])
});
var GasData = object({
	budget: nullable(JsonU64),
	price: nullable(JsonU64),
	owner: nullable(SuiAddress),
	payment: nullable(array(ObjectRefSchema))
});
var ProgrammableMoveCall = object({
	package: ObjectID,
	module: string(),
	function: string(),
	typeArguments: array(string()),
	arguments: array(Argument)
});
var $Intent = object({
	name: string(),
	inputs: record(string(), union([Argument, array(Argument)])),
	data: record(string(), unknown())
});
var Command = enumUnion({
	MoveCall: ProgrammableMoveCall,
	TransferObjects: object({
		objects: array(Argument),
		address: Argument
	}),
	SplitCoins: object({
		coin: Argument,
		amounts: array(Argument)
	}),
	MergeCoins: object({
		destination: Argument,
		sources: array(Argument)
	}),
	Publish: object({
		modules: array(BCSBytes),
		dependencies: array(ObjectID)
	}),
	MakeMoveVec: object({
		type: nullable(string()),
		elements: array(Argument)
	}),
	Upgrade: object({
		modules: array(BCSBytes),
		dependencies: array(ObjectID),
		package: ObjectID,
		ticket: Argument
	}),
	$Intent
});
var CallArg = enumUnion({
	Object: enumUnion({
		ImmOrOwnedObject: ObjectRefSchema,
		SharedObject: object({
			objectId: ObjectID,
			initialSharedVersion: JsonU64,
			mutable: boolean()
		}),
		Receiving: ObjectRefSchema
	}),
	Pure: object({ bytes: BCSBytes }),
	UnresolvedPure: object({ value: unknown() }),
	UnresolvedObject: object({
		objectId: ObjectID,
		version: optional(nullable(JsonU64)),
		digest: optional(nullable(string())),
		initialSharedVersion: optional(nullable(JsonU64)),
		mutable: optional(nullable(boolean()))
	}),
	FundsWithdrawal: FundsWithdrawalArgSchema
});
var TransactionExpiration = enumUnion({
	None: literal(true),
	Epoch: JsonU64,
	ValidDuring: ValidDuringSchema,
	Validity: ValiditySchema
});
var SerializedTransactionDataV2Schema = object({
	version: literal(2),
	sender: nullish(SuiAddress),
	expiration: nullish(TransactionExpiration),
	gasData: GasData,
	inputs: array(CallArg),
	commands: array(Command),
	digest: optional(nullable(string()))
});
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/object.mjs
function createObjectMethods(makeObject) {
	function object(value) {
		return makeObject(value);
	}
	object.system = (options) => {
		const mutable = options?.mutable;
		if (mutable !== void 0) return object(Inputs.SharedObjectRef({
			objectId: SUI_SYSTEM_STATE_OBJECT_ID,
			initialSharedVersion: 1,
			mutable
		}));
		return object({
			$kind: "UnresolvedObject",
			UnresolvedObject: {
				objectId: SUI_SYSTEM_STATE_OBJECT_ID,
				initialSharedVersion: 1
			}
		});
	};
	object.clock = () => object(Inputs.SharedObjectRef({
		objectId: SUI_CLOCK_OBJECT_ID,
		initialSharedVersion: 1,
		mutable: false
	}));
	object.random = () => object({
		$kind: "UnresolvedObject",
		UnresolvedObject: {
			objectId: SUI_RANDOM_OBJECT_ID,
			mutable: false
		}
	});
	object.denyList = (options) => {
		return object({
			$kind: "UnresolvedObject",
			UnresolvedObject: {
				objectId: SUI_DENY_LIST_OBJECT_ID,
				mutable: options?.mutable
			}
		});
	};
	object.option = ({ type, value }) => (tx) => tx.moveCall({
		typeArguments: [type],
		target: `${MOVE_STDLIB_ADDRESS}::option::${value === null ? "none" : "some"}`,
		arguments: value === null ? [] : [tx.object(value)]
	});
	return object;
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/pure.mjs
function createPure(makePure) {
	function pure(typeOrSerializedValue, value) {
		if (typeof typeOrSerializedValue === "string") return makePure(pureBcsSchemaFromTypeName(typeOrSerializedValue).serialize(value));
		if (typeOrSerializedValue instanceof Uint8Array || isSerializedBcs(typeOrSerializedValue)) return makePure(typeOrSerializedValue);
		throw new Error("tx.pure must be called either a bcs type name, or a serialized bcs value");
	}
	pure.u8 = (value) => makePure(suiBcs.U8.serialize(value));
	pure.u16 = (value) => makePure(suiBcs.U16.serialize(value));
	pure.u32 = (value) => makePure(suiBcs.U32.serialize(value));
	pure.u64 = (value) => makePure(suiBcs.U64.serialize(value));
	pure.u128 = (value) => makePure(suiBcs.U128.serialize(value));
	pure.u256 = (value) => makePure(suiBcs.U256.serialize(value));
	pure.bool = (value) => makePure(suiBcs.Bool.serialize(value));
	pure.string = (value) => makePure(suiBcs.String.serialize(value));
	pure.address = (value) => makePure(suiBcs.Address.serialize(value));
	pure.id = pure.address;
	pure.vector = (type, value) => {
		return makePure(suiBcs.vector(pureBcsSchemaFromTypeName(type)).serialize(value));
	};
	pure.option = (type, value) => {
		return makePure(suiBcs.option(pureBcsSchemaFromTypeName(type)).serialize(value));
	};
	return pure;
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/plugins/NamedPackagesPlugin.mjs
/**
* Internal plugin that automatically resolves MVR names in transactions.
* This plugin is automatically added to all transactions and uses the client's
* MVR resolver to convert .move names to on-chain addresses.
*/
function namedPackagesPlugin() {
	return async (transactionData, buildOptions, next) => {
		const names = findNamesInTransaction(transactionData);
		if (names.types.length === 0 && names.packages.length === 0) return next();
		if (!buildOptions.client) throw new Error(`Transaction contains MVR names but no client was provided to resolve them. Please pass a client to Transaction#build()`);
		replaceNames(transactionData, await buildOptions.client.core.mvr.resolve({
			types: names.types,
			packages: names.packages
		}));
		await next();
	};
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/intents/BalanceOptions.mjs
function normalizeBalance(options) {
	if (options.allowance !== void 0 && options.useGasCoin !== void 0) throw new Error("useGasCoin cannot be combined with allowance");
	const amount = options.balance;
	if (typeof amount === "string" && !/^[0-9]+$/.test(amount)) throw new Error("Amount must be a non-empty string of decimal digits");
	if (typeof amount === "number" && !Number.isSafeInteger(amount)) throw new Error("Amount must be a safe integer; use bigint or a string for larger amounts");
	return BigInt(amount);
}
//#endregion
//#region node_modules/@mysten/sui/dist/transactions/Transaction.mjs
function createTransactionResult(index, length = Infinity) {
	const baseResult = {
		$kind: "Result",
		get Result() {
			return typeof index === "function" ? index() : index;
		}
	};
	const nestedResults = [];
	const nestedResultFor = (resultIndex) => nestedResults[resultIndex] ??= {
		$kind: "NestedResult",
		get NestedResult() {
			return [typeof index === "function" ? index() : index, resultIndex];
		}
	};
	return new Proxy(baseResult, {
		set() {
			throw new Error("The transaction result is a proxy, and does not support setting properties directly");
		},
		get(target, property) {
			if (property in target) return Reflect.get(target, property);
			if (property === Symbol.iterator) return function* () {
				let i = 0;
				while (i < length) {
					yield nestedResultFor(i);
					i++;
				}
			};
			if (typeof property === "symbol") return;
			const resultIndex = parseInt(property, 10);
			if (Number.isNaN(resultIndex) || resultIndex < 0) return;
			return nestedResultFor(resultIndex);
		}
	});
}
var TRANSACTION_BRAND = Symbol.for("@mysten/transaction");
function isTransaction(obj) {
	return !!obj && typeof obj === "object" && obj[TRANSACTION_BRAND] === true;
}
/**
* Transaction Builder
*/
var Transaction = class Transaction {
	#serializationPlugins;
	#buildPlugins;
	#intentResolvers = /* @__PURE__ */ new Map();
	#inputSection = [];
	#commandSection = [];
	#availableResults = /* @__PURE__ */ new Set();
	#pendingPromises = /* @__PURE__ */ new Set();
	#added = /* @__PURE__ */ new Map();
	/**
	* Converts from a serialize transaction kind (built with `build({ onlyTransactionKind: true })`) to a `Transaction` class.
	* Supports either a byte array, or base64-encoded bytes.
	*/
	static fromKind(serialized) {
		const tx = new Transaction();
		tx.#data = TransactionDataBuilder.fromKindBytes(typeof serialized === "string" ? fromBase64(serialized) : serialized);
		tx.#inputSection = tx.#data.inputs.slice();
		tx.#commandSection = tx.#data.commands.slice();
		tx.#availableResults = new Set(tx.#commandSection.map((_, i) => i));
		return tx;
	}
	/**
	* Converts from a serialized transaction format to a `Transaction` class.
	* There are two supported serialized formats:
	* - A string returned from `Transaction#serialize`. The serialized format must be compatible, or it will throw an error.
	* - A byte array (or base64-encoded bytes) containing BCS transaction data.
	*
	* It can also copy an existing `Transaction` or `TransactionDataBuilder` instance. The data is
	* copied, so changes to the new transaction do not affect the original.
	*
	* When copying an in-memory transaction that uses custom intents, pass resolvers for those intents
	* via `options.intentResolvers` so the copy can be created synchronously without first awaiting
	* `prepareForSerialization`. Built-in intents (such as `CoinWithBalance`) are handled automatically.
	*/
	static from(transaction, options = {}) {
		const newTransaction = new Transaction();
		if (typeof transaction === "object" && "getData" in transaction) newTransaction.#data = TransactionDataBuilder.restore(transaction.getData());
		else if (typeof transaction !== "string" || !transaction.startsWith("{")) newTransaction.#data = TransactionDataBuilder.fromBytes(typeof transaction === "string" ? fromBase64(transaction) : transaction);
		else newTransaction.#data = TransactionDataBuilder.restore(JSON.parse(transaction));
		newTransaction.#inputSection = newTransaction.#data.inputs.slice();
		newTransaction.#commandSection = newTransaction.#data.commands.slice();
		newTransaction.#availableResults = new Set(newTransaction.#commandSection.map((_, i) => i));
		const intentResolvers = new Map([
			[COIN_WITH_BALANCE, resolveBalances],
			[ALLOWANCE_BALANCE, resolveBalances],
			...Object.entries(options.intentResolvers ?? {})
		]);
		if (!newTransaction.isPreparedForSerialization({ supportedIntents: [...intentResolvers.keys()] })) throw new Error("Transaction has unresolved intents or async thunks. Provide resolvers for any custom intents via the `intentResolvers` option, or call `prepareForSerialization` before copying.");
		for (const [intent, resolver] of intentResolvers) newTransaction.addIntentResolver(intent, resolver);
		return newTransaction;
	}
	addSerializationPlugin(step) {
		this.#serializationPlugins.push(step);
	}
	addBuildPlugin(step) {
		this.#buildPlugins.push(step);
	}
	addIntentResolver(intent, resolver) {
		if (this.#intentResolvers.has(intent) && this.#intentResolvers.get(intent) !== resolver) throw new Error(`Intent resolver for ${intent} already exists`);
		this.#intentResolvers.set(intent, resolver);
	}
	setSender(sender) {
		this.#data.sender = sender;
	}
	/**
	* Sets the sender only if it has not already been set.
	* This is useful for sponsored transaction flows where the sender may not be the same as the signer address.
	*/
	setSenderIfNotSet(sender) {
		if (!this.#data.sender) this.#data.sender = sender;
	}
	setExpiration(expiration) {
		this.#data.expiration = expiration ? parse$2(TransactionExpiration$3, expiration) : null;
	}
	setGasPrice(price) {
		this.#data.gasData.price = String(price);
	}
	setGasBudget(budget) {
		this.#data.gasData.budget = String(budget);
	}
	setGasBudgetIfNotSet(budget) {
		if (this.#data.gasData.budget == null) this.#data.gasData.budget = String(budget);
	}
	setGasOwner(owner) {
		this.#data.gasData.owner = owner;
	}
	setGasPayment(payments) {
		this.#data.gasData.payment = payments.map((payment) => parse$2(ObjectRefSchema, payment));
	}
	#data;
	/** Get a snapshot of the transaction data, in JSON form: */
	getData() {
		return this.#data.snapshot();
	}
	get [TRANSACTION_BRAND]() {
		return true;
	}
	get pure() {
		Object.defineProperty(this, "pure", {
			enumerable: false,
			value: createPure((value) => {
				if (isSerializedBcs(value)) return this.#addInput("pure", {
					$kind: "Pure",
					Pure: { bytes: value.toBase64() }
				});
				return this.#addInput("pure", is(NormalizedCallArg$1, value) ? parse$2(NormalizedCallArg$1, value) : value instanceof Uint8Array ? Inputs.Pure(value) : {
					$kind: "UnresolvedPure",
					UnresolvedPure: { value }
				});
			})
		});
		return this.pure;
	}
	constructor() {
		this.object = createObjectMethods((value) => {
			if (typeof value === "function") return this.object(this.add(value));
			if (typeof value === "object" && is(ArgumentSchema, value)) return value;
			const id = getIdFromCallArg(value);
			const inserted = this.#data.inputs.find((i) => id === getIdFromCallArg(i));
			if (inserted?.Object?.SharedObject && typeof value === "object" && value.Object?.SharedObject) inserted.Object.SharedObject.mutable = inserted.Object.SharedObject.mutable || value.Object.SharedObject.mutable;
			return inserted ? {
				$kind: "Input",
				Input: this.#data.inputs.indexOf(inserted),
				type: "object"
			} : this.#addInput("object", typeof value === "string" ? {
				$kind: "UnresolvedObject",
				UnresolvedObject: { objectId: normalizeSuiAddress(value) }
			} : value);
		});
		this.#data = new TransactionDataBuilder();
		this.#buildPlugins = [];
		this.#serializationPlugins = [];
	}
	/** Returns an argument for the gas coin, to be used in a transaction. */
	get gas() {
		return {
			$kind: "GasCoin",
			GasCoin: true
		};
	}
	/**
	* Creates a Coin<T> of the specified type and amount (defaults to SUI).
	* Sourced from address balance when available, falling back to owned coins. For SUI, falls back
	* to the gas coin instead unless `useGasCoin` is `false`.
	* With `allowance`, spends only from the funder's address balance under that allowance.
	* Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
	*/
	coin(options) {
		const amount = normalizeBalance(options);
		return this.add(options.allowance !== void 0 ? allowanceBalance({
			...options,
			amount,
			outputKind: "coin"
		}) : coinWithBalance({
			...options,
			balance: amount
		}));
	}
	/**
	* Creates a Balance<T> of the specified type and amount (defaults to SUI).
	* Sourced from address balance when available, falling back to owned coins. For SUI, falls back
	* to the gas coin instead unless `useGasCoin` is `false`.
	* With `allowance`, spends only from the funder's address balance under that allowance.
	* Allowance IDs are resolved using the build client; app-bound allowances also require an app type and SpendPermit.
	*/
	balance(options) {
		const amount = normalizeBalance(options);
		return this.add(options.allowance !== void 0 ? allowanceBalance({
			...options,
			amount,
			outputKind: "balance"
		}) : createBalance({
			...options,
			balance: amount
		}));
	}
	/**
	* Add a new object input to the transaction using the fully-resolved object reference.
	* If you only have an object ID, use `builder.object(id)` instead.
	*/
	objectRef(...args) {
		return this.object(Inputs.ObjectRef(...args));
	}
	/**
	* Add a new receiving input to the transaction using the fully-resolved object reference.
	* If you only have an object ID, use `builder.object(id)` instead.
	*/
	receivingRef(...args) {
		return this.object(Inputs.ReceivingRef(...args));
	}
	/**
	* Add a new shared object input to the transaction using the fully-resolved shared object reference.
	* If you only have an object ID, use `builder.object(id)` instead.
	*/
	sharedObjectRef(...args) {
		return this.object(Inputs.SharedObjectRef(...args));
	}
	#fork() {
		const fork = new Transaction();
		fork.#data = this.#data;
		fork.#serializationPlugins = this.#serializationPlugins;
		fork.#buildPlugins = this.#buildPlugins;
		fork.#intentResolvers = this.#intentResolvers;
		fork.#pendingPromises = this.#pendingPromises;
		fork.#availableResults = new Set(this.#availableResults);
		fork.#added = this.#added;
		this.#inputSection.push(fork.#inputSection);
		this.#commandSection.push(fork.#commandSection);
		return fork;
	}
	add(command) {
		if (typeof command === "function") {
			if (this.#added.has(command)) return this.#added.get(command);
			const fork = this.#fork();
			const result = command(fork);
			if (!(result && typeof result === "object" && "then" in result)) {
				this.#availableResults = fork.#availableResults;
				this.#added.set(command, result);
				return result;
			}
			const placeholder = this.#addCommand({
				$kind: "$Intent",
				$Intent: {
					name: "AsyncTransactionThunk",
					inputs: {},
					data: {
						resultIndex: this.#data.commands.length,
						result: null
					}
				}
			});
			this.#pendingPromises.add(Promise.resolve(result).then((result$1) => {
				placeholder.$Intent.data.result = result$1;
			}));
			const txResult = createTransactionResult(() => placeholder.$Intent.data.resultIndex);
			this.#added.set(command, txResult);
			return txResult;
		} else this.#addCommand(command);
		return createTransactionResult(this.#data.commands.length - 1);
	}
	#addCommand(command) {
		const resultIndex = this.#data.commands.length;
		this.#commandSection.push(command);
		this.#availableResults.add(resultIndex);
		this.#data.commands.push(command);
		this.#data.mapCommandArguments(resultIndex, (arg) => {
			if (arg.$kind === "Result" && !this.#availableResults.has(arg.Result)) throw new Error(`Result { Result: ${arg.Result} } is not available to use in the current transaction`);
			if (arg.$kind === "NestedResult" && !this.#availableResults.has(arg.NestedResult[0])) throw new Error(`Result { NestedResult: [${arg.NestedResult[0]}, ${arg.NestedResult[1]}] } is not available to use in the current transaction`);
			if (arg.$kind === "Input" && arg.Input >= this.#data.inputs.length) throw new Error(`Input { Input: ${arg.Input} } references an input that does not exist in the current transaction`);
			return arg;
		});
		return command;
	}
	#addInput(type, input) {
		this.#inputSection.push(input);
		return this.#data.addInput(type, input);
	}
	#normalizeTransactionArgument(arg) {
		if (isSerializedBcs(arg)) return this.pure(arg);
		return this.#resolveArgument(arg);
	}
	#resolveArgument(arg) {
		if (typeof arg === "function") {
			const resolved = this.add(arg);
			if (typeof resolved === "function") return this.#resolveArgument(resolved);
			return parse$2(ArgumentSchema, resolved);
		}
		return parse$2(ArgumentSchema, arg);
	}
	splitCoins(coin, amounts) {
		const command = TransactionCommands.SplitCoins(typeof coin === "string" ? this.object(coin) : this.#resolveArgument(coin), amounts.map((amount) => typeof amount === "number" || typeof amount === "bigint" || typeof amount === "string" ? this.pure.u64(amount) : this.#normalizeTransactionArgument(amount)));
		this.#addCommand(command);
		return createTransactionResult(this.#data.commands.length - 1, amounts.length);
	}
	mergeCoins(destination, sources) {
		return this.add(TransactionCommands.MergeCoins(this.object(destination), sources.map((src) => this.object(src))));
	}
	publish({ modules, dependencies }) {
		return this.add(TransactionCommands.Publish({
			modules,
			dependencies
		}));
	}
	upgrade({ modules, dependencies, package: packageId, ticket }) {
		return this.add(TransactionCommands.Upgrade({
			modules,
			dependencies,
			package: packageId,
			ticket: this.object(ticket)
		}));
	}
	moveCall({ arguments: args, ...input }) {
		return this.add(TransactionCommands.MoveCall({
			...input,
			arguments: args?.map((arg) => this.#normalizeTransactionArgument(arg))
		}));
	}
	transferObjects(objects, address) {
		return this.add(TransactionCommands.TransferObjects(objects.map((obj) => this.object(obj)), typeof address === "string" ? this.pure.address(address) : this.#normalizeTransactionArgument(address)));
	}
	makeMoveVec({ type, elements }) {
		return this.add(TransactionCommands.MakeMoveVec({
			type,
			elements: elements.map((obj) => this.object(obj))
		}));
	}
	/**
	* Creates a FundsWithdrawal input for withdrawing Balance<T> from an address balance.
	*
	* @param options.amount - The amount to withdraw (u64).
	* @param options.type - The coin type T (e.g., "0x2::sui::SUI"), not Balance<T>. Defaults to SUI.
	* @param options.from - The withdrawal source. Defaults to the transaction sender.
	* @param options.allowance - The allowance ID, required when from is 'allowance'.
	* @param options.funder - The funder's address, required when from is 'allowance'.
	*/
	withdrawal(options) {
		const input = {
			$kind: "FundsWithdrawal",
			FundsWithdrawal: {
				reservation: {
					$kind: "MaxAmountU64",
					MaxAmountU64: String(options.amount)
				},
				typeArg: {
					$kind: "Balance",
					Balance: options.type ?? "0x2::sui::SUI"
				},
				withdrawFrom: options.from === "allowance" ? {
					$kind: "SenderAllowance",
					SenderAllowance: {
						funder: normalizeSuiAddress(options.funder),
						allowance: normalizeSuiAddress(options.allowance)
					}
				} : options.from === "sponsor" ? {
					$kind: "Sponsor",
					Sponsor: true
				} : {
					$kind: "Sender",
					Sender: true
				}
			}
		};
		return this.#addInput("object", input);
	}
	/**
	* @deprecated Use toJSON instead.
	* For synchronous serialization, you can use `getData()`
	* */
	serialize() {
		return JSON.stringify(serializeV1TransactionData(this.#data.snapshot()));
	}
	async toJSON(options = {}) {
		await this.prepareForSerialization(options);
		const fullyResolved = this.isFullyResolved();
		return JSON.stringify(parse$2(SerializedTransactionDataV2Schema, fullyResolved ? {
			...this.#data.snapshot(),
			digest: this.#data.getDigest()
		} : this.#data.snapshot()), (_key, value) => typeof value === "bigint" ? value.toString() : value, 2);
	}
	/** Build the transaction to BCS bytes, and sign it with the provided keypair. */
	async sign(options) {
		const { signer, ...buildOptions } = options;
		const bytes = await this.build(buildOptions);
		return signer.signTransaction(bytes);
	}
	/**
	* Checks if the transaction is prepared for serialization to JSON.
	* This means:
	*  - All async thunks have been fully resolved
	*  - All transaction intents have been resolved (unless in supportedIntents)
	*
	* Unlike `isFullyResolved()`, this does not require the sender, gas payment,
	* budget, or object versions to be set.
	*/
	isPreparedForSerialization(options = {}) {
		if (this.#pendingPromises.size > 0) return false;
		if (this.#data.commands.some((cmd) => cmd.$Intent && !options.supportedIntents?.includes(cmd.$Intent.name))) return false;
		return true;
	}
	/**
	*  Ensures that:
	*  - All objects have been fully resolved to a specific version
	*  - All pure inputs have been serialized to bytes
	*  - All async thunks have been fully resolved
	*  - All transaction intents have been resolved
	* 	- The gas payment, budget, and price have been set
	*  - The transaction sender has been set
	*
	*  When true, the transaction will always be built to the same bytes and digest (unless the transaction is mutated)
	*/
	isFullyResolved() {
		if (!this.isPreparedForSerialization()) return false;
		if (!this.#data.sender) return false;
		if (needsTransactionResolution(this.#data, {})) return false;
		return true;
	}
	/** Build the transaction to BCS bytes. */
	async build(options = {}) {
		await this.prepareForSerialization(options);
		await this.#prepareBuild(options);
		return this.#data.build({ onlyTransactionKind: options.onlyTransactionKind });
	}
	/** Derive transaction digest */
	async getDigest(options = {}) {
		await this.prepareForSerialization(options);
		await this.#prepareBuild(options);
		return this.#data.getDigest();
	}
	/**
	* Prepare the transaction by validating the transaction data and resolving all inputs
	* so that it can be built into bytes.
	*/
	async #prepareBuild(options) {
		if (!options.onlyTransactionKind && !this.#data.sender) throw new Error("Missing transaction sender");
		await this.#runPlugins([...this.#buildPlugins, resolveTransactionPlugin], options);
	}
	async #runPlugins(plugins, options) {
		try {
			const createNext = (i) => {
				if (i >= plugins.length) return () => {};
				const plugin = plugins[i];
				return async () => {
					const next = createNext(i + 1);
					let calledNext = false;
					let nextResolved = false;
					await plugin(this.#data, options, async () => {
						if (calledNext) throw new Error(`next() was call multiple times in TransactionPlugin ${i}`);
						calledNext = true;
						await next();
						nextResolved = true;
					});
					if (!calledNext) throw new Error(`next() was not called in TransactionPlugin ${i}`);
					if (!nextResolved) throw new Error(`next() was not awaited in TransactionPlugin ${i}`);
				};
			};
			await createNext(0)();
		} finally {
			this.#inputSection = this.#data.inputs.slice();
			this.#commandSection = this.#data.commands.slice();
			this.#availableResults = new Set(this.#commandSection.map((_, i) => i));
		}
	}
	async #waitForPendingTasks() {
		while (this.#pendingPromises.size > 0) {
			const newPromise = Promise.all(this.#pendingPromises);
			this.#pendingPromises.clear();
			this.#pendingPromises.add(newPromise);
			await newPromise;
			this.#pendingPromises.delete(newPromise);
		}
	}
	#sortCommandsAndInputs() {
		const unorderedCommands = this.#data.commands;
		const unorderedInputs = this.#data.inputs;
		const orderedCommands = this.#commandSection.flat(Infinity);
		const orderedInputs = this.#inputSection.flat(Infinity);
		if (orderedCommands.length !== unorderedCommands.length) throw new Error("Unexpected number of commands found in transaction data");
		if (orderedInputs.length !== unorderedInputs.length) throw new Error("Unexpected number of inputs found in transaction data");
		const filteredCommands = orderedCommands.filter((cmd) => cmd.$Intent?.name !== "AsyncTransactionThunk");
		this.#data.commands = filteredCommands;
		this.#data.inputs = orderedInputs;
		this.#commandSection = filteredCommands;
		this.#inputSection = orderedInputs;
		this.#availableResults = new Set(filteredCommands.map((_, i) => i));
		function getOriginalIndex(index) {
			const command = unorderedCommands[index];
			if (command.$Intent?.name === "AsyncTransactionThunk") {
				const result = command.$Intent.data.result;
				if (result == null) throw new Error("AsyncTransactionThunk has not been resolved");
				return getOriginalIndex(result.Result);
			}
			const updated = filteredCommands.indexOf(command);
			if (updated === -1) throw new Error("Unable to find original index for command");
			return updated;
		}
		this.#data.mapArguments((arg) => {
			if (arg.$kind === "Input") {
				const updated = orderedInputs.indexOf(unorderedInputs[arg.Input]);
				if (updated === -1) throw new Error("Input has not been resolved");
				return {
					...arg,
					Input: updated
				};
			} else if (arg.$kind === "Result") {
				const updated = getOriginalIndex(arg.Result);
				return {
					...arg,
					Result: updated
				};
			} else if (arg.$kind === "NestedResult") {
				const updated = getOriginalIndex(arg.NestedResult[0]);
				return {
					...arg,
					NestedResult: [updated, arg.NestedResult[1]]
				};
			}
			return arg;
		});
		for (const [i, cmd] of unorderedCommands.entries()) if (cmd.$Intent?.name === "AsyncTransactionThunk") try {
			cmd.$Intent.data.resultIndex = getOriginalIndex(i);
		} catch {}
	}
	async prepareForSerialization(options) {
		await this.#waitForPendingTasks();
		this.#sortCommandsAndInputs();
		const intents = /* @__PURE__ */ new Set();
		for (const command of this.#data.commands) if (command.$Intent) intents.add(command.$Intent.name);
		const steps = [...this.#serializationPlugins];
		const resolverIntents = /* @__PURE__ */ new Map();
		for (const intent of intents) {
			if (options.supportedIntents?.includes(intent)) continue;
			const resolver = this.#intentResolvers.get(intent);
			if (!resolver) throw new Error(`Missing intent resolver for ${intent}`);
			const names = resolverIntents.get(resolver) ?? [];
			names.push(intent);
			resolverIntents.set(resolver, names);
		}
		for (const [resolver, intentNames] of resolverIntents) steps.push((data, buildOptions, next) => {
			return resolver(data, {
				...buildOptions,
				intentNames
			}, next);
		});
		steps.push(namedPackagesPlugin());
		await this.#runPlugins(steps, options);
	}
};
//#endregion
//#region node_modules/react/cjs/react.production.js
/**
* @license React
* react.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
	var REACT_PORTAL_TYPE = Symbol.for("react.portal");
	var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	var REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode");
	var REACT_PROFILER_TYPE = Symbol.for("react.profiler");
	var REACT_CONSUMER_TYPE = Symbol.for("react.consumer");
	var REACT_CONTEXT_TYPE = Symbol.for("react.context");
	var REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref");
	var REACT_SUSPENSE_TYPE = Symbol.for("react.suspense");
	var REACT_MEMO_TYPE = Symbol.for("react.memo");
	var REACT_LAZY_TYPE = Symbol.for("react.lazy");
	var REACT_ACTIVITY_TYPE = Symbol.for("react.activity");
	var REACT_VIEW_TRANSITION_TYPE = Symbol.for("react.view_transition");
	var MAYBE_ITERATOR_SYMBOL = Symbol.iterator;
	function getIteratorFn(maybeIterable) {
		if (null === maybeIterable || "object" !== typeof maybeIterable) return null;
		maybeIterable = MAYBE_ITERATOR_SYMBOL && maybeIterable[MAYBE_ITERATOR_SYMBOL] || maybeIterable["@@iterator"];
		return "function" === typeof maybeIterable ? maybeIterable : null;
	}
	var ReactNoopUpdateQueue = {
		isMounted: function() {
			return !1;
		},
		enqueueForceUpdate: function() {},
		enqueueReplaceState: function() {},
		enqueueSetState: function() {}
	};
	var assign = Object.assign;
	var emptyObject = {};
	function Component(props, context, updater) {
		this.props = props;
		this.context = context;
		this.refs = emptyObject;
		this.updater = updater || ReactNoopUpdateQueue;
	}
	Component.prototype.isReactComponent = {};
	Component.prototype.setState = function(partialState, callback) {
		if ("object" !== typeof partialState && "function" !== typeof partialState && null != partialState) throw Error("takes an object of state variables to update or a function which returns an object of state variables.");
		this.updater.enqueueSetState(this, partialState, callback, "setState");
	};
	Component.prototype.forceUpdate = function(callback) {
		this.updater.enqueueForceUpdate(this, callback, "forceUpdate");
	};
	function ComponentDummy() {}
	ComponentDummy.prototype = Component.prototype;
	function PureComponent(props, context, updater) {
		this.props = props;
		this.context = context;
		this.refs = emptyObject;
		this.updater = updater || ReactNoopUpdateQueue;
	}
	var pureComponentPrototype = PureComponent.prototype = new ComponentDummy();
	pureComponentPrototype.constructor = PureComponent;
	assign(pureComponentPrototype, Component.prototype);
	pureComponentPrototype.isPureReactComponent = !0;
	var isArrayImpl = Array.isArray;
	function noop() {}
	var ReactSharedInternals = {
		H: null,
		A: null,
		T: null,
		S: null
	};
	var hasOwnProperty = Object.prototype.hasOwnProperty;
	function ReactElement(type, key, props) {
		var refProp = props.ref;
		return {
			$$typeof: REACT_ELEMENT_TYPE,
			type,
			key,
			ref: void 0 !== refProp ? refProp : null,
			props
		};
	}
	function cloneAndReplaceKey(oldElement, newKey) {
		return ReactElement(oldElement.type, newKey, oldElement.props);
	}
	function isValidElement(object) {
		return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
	}
	function escape(key) {
		var escaperLookup = {
			"=": "=0",
			":": "=2"
		};
		return "$" + key.replace(/[=:]/g, function(match) {
			return escaperLookup[match];
		});
	}
	var userProvidedKeyEscapeRegex = /\/+/g;
	function getElementKey(element, index) {
		return "object" === typeof element && null !== element && null != element.key ? escape("" + element.key) : index.toString(36);
	}
	function resolveThenable(thenable) {
		switch (thenable.status) {
			case "fulfilled": return thenable.value;
			case "rejected": throw thenable.reason;
			default: switch ("string" === typeof thenable.status ? thenable.then(noop, noop) : (thenable.status = "pending", thenable.then(function(fulfilledValue) {
				"pending" === thenable.status && (thenable.status = "fulfilled", thenable.value = fulfilledValue);
			}, function(error) {
				"pending" === thenable.status && (thenable.status = "rejected", thenable.reason = error);
			})), thenable.status) {
				case "fulfilled": return thenable.value;
				case "rejected": throw thenable.reason;
			}
		}
		throw thenable;
	}
	function mapIntoArray(children, array, escapedPrefix, nameSoFar, callback) {
		var type = typeof children;
		if ("undefined" === type || "boolean" === type) children = null;
		var invokeCallback = !1;
		if (null === children) invokeCallback = !0;
		else switch (type) {
			case "bigint":
			case "string":
			case "number":
				invokeCallback = !0;
				break;
			case "object": switch (children.$$typeof) {
				case REACT_ELEMENT_TYPE:
				case REACT_PORTAL_TYPE:
					invokeCallback = !0;
					break;
				case REACT_LAZY_TYPE: return invokeCallback = children._init, mapIntoArray(invokeCallback(children._payload), array, escapedPrefix, nameSoFar, callback);
			}
		}
		if (invokeCallback) return callback = callback(children), invokeCallback = "" === nameSoFar ? "." + getElementKey(children, 0) : nameSoFar, isArrayImpl(callback) ? (escapedPrefix = "", null != invokeCallback && (escapedPrefix = invokeCallback.replace(userProvidedKeyEscapeRegex, "$&/") + "/"), mapIntoArray(callback, array, escapedPrefix, "", function(c) {
			return c;
		})) : null != callback && (isValidElement(callback) && (callback = cloneAndReplaceKey(callback, escapedPrefix + (null == callback.key || children && children.key === callback.key ? "" : ("" + callback.key).replace(userProvidedKeyEscapeRegex, "$&/") + "/") + invokeCallback)), array.push(callback)), 1;
		invokeCallback = 0;
		var nextNamePrefix = "" === nameSoFar ? "." : nameSoFar + ":";
		if (isArrayImpl(children)) for (var i = 0; i < children.length; i++) nameSoFar = children[i], type = nextNamePrefix + getElementKey(nameSoFar, i), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
		else if (i = getIteratorFn(children), "function" === typeof i) for (children = i.call(children), i = 0; !(nameSoFar = children.next()).done;) nameSoFar = nameSoFar.value, type = nextNamePrefix + getElementKey(nameSoFar, i++), invokeCallback += mapIntoArray(nameSoFar, array, escapedPrefix, type, callback);
		else if ("object" === type) {
			if ("function" === typeof children.then) return mapIntoArray(resolveThenable(children), array, escapedPrefix, nameSoFar, callback);
			array = String(children);
			throw Error("Objects are not valid as a React child (found: " + ("[object Object]" === array ? "object with keys {" + Object.keys(children).join(", ") + "}" : array) + "). If you meant to render a collection of children, use an array instead.");
		}
		return invokeCallback;
	}
	function mapChildren(children, func, context) {
		if (null == children) return children;
		var result = [], count = 0;
		mapIntoArray(children, result, "", "", function(child) {
			return func.call(context, child, count++);
		});
		return result;
	}
	function lazyInitializer(payload) {
		if (-1 === payload._status) {
			var ctor = payload._result, thenable = ctor();
			thenable.then(function(moduleObject) {
				if (0 === payload._status || -1 === payload._status) payload._status = 1, payload._result = moduleObject, void 0 === thenable.status && (thenable.status = "fulfilled", thenable.value = moduleObject);
			}, function(error) {
				if (0 === payload._status || -1 === payload._status) payload._status = 2, payload._result = error, void 0 === thenable.status && (thenable.status = "rejected", thenable.reason = error);
			});
			-1 === payload._status && (payload._status = 0, payload._result = thenable);
		}
		if (1 === payload._status) return payload._result.default;
		throw payload._result;
	}
	var reportGlobalError = "function" === typeof reportError ? reportError : function(error) {
		if ("object" === typeof window && "function" === typeof window.ErrorEvent) {
			var event = new window.ErrorEvent("error", {
				bubbles: !0,
				cancelable: !0,
				message: "object" === typeof error && null !== error && "string" === typeof error.message ? String(error.message) : String(error),
				error
			});
			if (!window.dispatchEvent(event)) return;
		} else if ("object" === typeof process && "function" === typeof process.emit) {
			process.emit("uncaughtException", error);
			return;
		}
		console.error(error);
	};
	function startTransition(scope) {
		var prevTransition = ReactSharedInternals.T, currentTransition = {};
		currentTransition.types = null !== prevTransition ? prevTransition.types : null;
		ReactSharedInternals.T = currentTransition;
		try {
			var returnValue = scope(), onStartTransitionFinish = ReactSharedInternals.S;
			null !== onStartTransitionFinish && onStartTransitionFinish(currentTransition, returnValue);
			"object" === typeof returnValue && null !== returnValue && "function" === typeof returnValue.then && returnValue.then(noop, reportGlobalError);
		} catch (error) {
			reportGlobalError(error);
		} finally {
			null !== prevTransition && null !== currentTransition.types && (prevTransition.types = currentTransition.types), ReactSharedInternals.T = prevTransition;
		}
	}
	function addTransitionType(type) {
		var transition = ReactSharedInternals.T;
		if (null !== transition) {
			var transitionTypes = transition.types;
			null === transitionTypes ? transition.types = [type] : -1 === transitionTypes.indexOf(type) && transitionTypes.push(type);
		} else startTransition(addTransitionType.bind(null, type));
	}
	var Children = {
		map: mapChildren,
		forEach: function(children, forEachFunc, forEachContext) {
			mapChildren(children, function() {
				forEachFunc.apply(this, arguments);
			}, forEachContext);
		},
		count: function(children) {
			var n = 0;
			mapChildren(children, function() {
				n++;
			});
			return n;
		},
		toArray: function(children) {
			return mapChildren(children, function(child) {
				return child;
			}) || [];
		},
		only: function(children) {
			if (!isValidElement(children)) throw Error("React.Children.only expected to receive a single React element child.");
			return children;
		}
	};
	exports.Activity = REACT_ACTIVITY_TYPE;
	exports.Children = Children;
	exports.Component = Component;
	exports.Fragment = REACT_FRAGMENT_TYPE;
	exports.Profiler = REACT_PROFILER_TYPE;
	exports.PureComponent = PureComponent;
	exports.StrictMode = REACT_STRICT_MODE_TYPE;
	exports.Suspense = REACT_SUSPENSE_TYPE;
	exports.ViewTransition = REACT_VIEW_TRANSITION_TYPE;
	exports.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = ReactSharedInternals;
	exports.__COMPILER_RUNTIME = {
		__proto__: null,
		c: function(size) {
			return ReactSharedInternals.H.useMemoCache(size);
		}
	};
	exports.addTransitionType = addTransitionType;
	exports.cache = function(fn) {
		return function() {
			return fn.apply(null, arguments);
		};
	};
	exports.cacheSignal = function() {
		return null;
	};
	exports.cloneElement = function(element, config, children) {
		if (null === element || void 0 === element) throw Error("The argument must be a React element, but you passed " + element + ".");
		var props = assign({}, element.props), key = element.key;
		if (null != config) for (propName in void 0 !== config.key && (key = "" + config.key), config) !hasOwnProperty.call(config, propName) || "key" === propName || "__self" === propName || "__source" === propName || "ref" === propName && void 0 === config.ref || (props[propName] = config[propName]);
		var propName = arguments.length - 2;
		if (1 === propName) props.children = children;
		else if (1 < propName) {
			for (var childArray = Array(propName), i = 0; i < propName; i++) childArray[i] = arguments[i + 2];
			props.children = childArray;
		}
		return ReactElement(element.type, key, props);
	};
	exports.createContext = function(defaultValue) {
		defaultValue = {
			$$typeof: REACT_CONTEXT_TYPE,
			_currentValue: defaultValue,
			_currentValue2: defaultValue,
			_threadCount: 0,
			Provider: null,
			Consumer: null
		};
		defaultValue.Provider = defaultValue;
		defaultValue.Consumer = {
			$$typeof: REACT_CONSUMER_TYPE,
			_context: defaultValue
		};
		return defaultValue;
	};
	exports.createElement = function(type, config, children) {
		var propName, props = {}, key = null;
		if (null != config) for (propName in void 0 !== config.key && (key = "" + config.key), config) hasOwnProperty.call(config, propName) && "key" !== propName && "__self" !== propName && "__source" !== propName && (props[propName] = config[propName]);
		var childrenLength = arguments.length - 2;
		if (1 === childrenLength) props.children = children;
		else if (1 < childrenLength) {
			for (var childArray = Array(childrenLength), i = 0; i < childrenLength; i++) childArray[i] = arguments[i + 2];
			props.children = childArray;
		}
		if (type && type.defaultProps) for (propName in childrenLength = type.defaultProps, childrenLength) void 0 === props[propName] && (props[propName] = childrenLength[propName]);
		return ReactElement(type, key, props);
	};
	exports.createRef = function() {
		return { current: null };
	};
	exports.forwardRef = function(render) {
		return {
			$$typeof: REACT_FORWARD_REF_TYPE,
			render
		};
	};
	exports.isValidElement = isValidElement;
	exports.lazy = function(ctor) {
		return {
			$$typeof: REACT_LAZY_TYPE,
			_payload: {
				_status: -1,
				_result: ctor
			},
			_init: lazyInitializer
		};
	};
	exports.memo = function(type, compare) {
		return {
			$$typeof: REACT_MEMO_TYPE,
			type,
			compare: void 0 === compare ? null : compare
		};
	};
	exports.startTransition = startTransition;
	exports.unstable_useCacheRefresh = function() {
		return ReactSharedInternals.H.useCacheRefresh();
	};
	exports.use = function(usable) {
		return ReactSharedInternals.H.use(usable);
	};
	exports.useActionState = function(action, initialState, permalink) {
		return ReactSharedInternals.H.useActionState(action, initialState, permalink);
	};
	exports.useCallback = function(callback, deps) {
		return ReactSharedInternals.H.useCallback(callback, deps);
	};
	exports.useContext = function(Context) {
		return ReactSharedInternals.H.useContext(Context);
	};
	exports.useDebugValue = function() {};
	exports.useDeferredValue = function(value, initialValue) {
		return ReactSharedInternals.H.useDeferredValue(value, initialValue);
	};
	exports.useEffect = function(create, deps) {
		return ReactSharedInternals.H.useEffect(create, deps);
	};
	exports.useEffectEvent = function(callback) {
		return ReactSharedInternals.H.useEffectEvent(callback);
	};
	exports.useId = function() {
		return ReactSharedInternals.H.useId();
	};
	exports.useImperativeHandle = function(ref, create, deps) {
		return ReactSharedInternals.H.useImperativeHandle(ref, create, deps);
	};
	exports.useInsertionEffect = function(create, deps) {
		return ReactSharedInternals.H.useInsertionEffect(create, deps);
	};
	exports.useLayoutEffect = function(create, deps) {
		return ReactSharedInternals.H.useLayoutEffect(create, deps);
	};
	exports.useMemo = function(create, deps) {
		return ReactSharedInternals.H.useMemo(create, deps);
	};
	exports.useOptimistic = function(passthrough, reducer) {
		return ReactSharedInternals.H.useOptimistic(passthrough, reducer);
	};
	exports.useReducer = function(reducer, initialArg, init) {
		return ReactSharedInternals.H.useReducer(reducer, initialArg, init);
	};
	exports.useRef = function(initialValue) {
		return ReactSharedInternals.H.useRef(initialValue);
	};
	exports.useState = function(initialState) {
		return ReactSharedInternals.H.useState(initialState);
	};
	exports.useSyncExternalStore = function(subscribe, getSnapshot, getServerSnapshot) {
		return ReactSharedInternals.H.useSyncExternalStore(subscribe, getSnapshot, getServerSnapshot);
	};
	exports.useTransition = function() {
		return ReactSharedInternals.H.useTransition();
	};
	exports.version = "19.3.0";
}));
//#endregion
//#region node_modules/react/index.js
var require_react = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_production();
}));
//#endregion
//#region node_modules/react/cjs/react-jsx-runtime.production.js
/**
* @license React
* react-jsx-runtime.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_jsx_runtime_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element");
	var REACT_FRAGMENT_TYPE = Symbol.for("react.fragment");
	function jsxProd(type, config, maybeKey) {
		var key = null;
		void 0 !== maybeKey && (key = "" + maybeKey);
		void 0 !== config.key && (key = "" + config.key);
		if ("key" in config) {
			maybeKey = {};
			for (var propName in config) "key" !== propName && (maybeKey[propName] = config[propName]);
		} else maybeKey = config;
		config = maybeKey.ref;
		return {
			$$typeof: REACT_ELEMENT_TYPE,
			type,
			key,
			ref: void 0 !== config ? config : null,
			props: maybeKey
		};
	}
	exports.Fragment = REACT_FRAGMENT_TYPE;
	exports.jsx = jsxProd;
	exports.jsxs = jsxProd;
}));
//#endregion
//#region node_modules/react/jsx-runtime.js
var require_jsx_runtime = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_react_jsx_runtime_production();
}));
//#endregion
//#region node_modules/react-dom/cjs/react-dom.production.js
/**
* @license React
* react-dom.production.js
*
* Copyright (c) Meta Platforms, Inc. and affiliates.
*
* This source code is licensed under the MIT license found in the
* LICENSE file in the root directory of this source tree.
*/
var require_react_dom_production = /* @__PURE__ */ __commonJSMin(((exports) => {
	var React = require_react();
	function formatProdErrorMessage(code) {
		var url = "https://react.dev/errors/" + code;
		if (1 < arguments.length) {
			url += "?args[]=" + encodeURIComponent(arguments[1]);
			for (var i = 2; i < arguments.length; i++) url += "&args[]=" + encodeURIComponent(arguments[i]);
		}
		return "Minified React error #" + code + "; visit " + url + " for the full message or use the non-minified dev environment for full errors and additional helpful warnings.";
	}
	function noop() {}
	var Internals = {
		d: {
			f: noop,
			r: function() {
				throw Error(formatProdErrorMessage(522));
			},
			D: noop,
			C: noop,
			L: noop,
			m: noop,
			X: noop,
			S: noop,
			M: noop
		},
		p: 0,
		findDOMNode: null
	};
	var REACT_PORTAL_TYPE = Symbol.for("react.portal");
	var REACT_RECOVERABLE_TYPE = Symbol.for("react.recoverable");
	var REACT_OPTIMISTIC_KEY = Symbol.for("react.optimistic_key");
	function createPortal$1(children, containerInfo, implementation) {
		var key = 3 < arguments.length && void 0 !== arguments[3] ? arguments[3] : null;
		return {
			$$typeof: REACT_PORTAL_TYPE,
			key: null == key ? null : key === REACT_OPTIMISTIC_KEY ? REACT_OPTIMISTIC_KEY : "" + key,
			children,
			containerInfo,
			implementation
		};
	}
	var ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE;
	function getCrossOriginStringAs(as, input) {
		if ("font" === as) return "";
		if ("string" === typeof input) return "use-credentials" === input ? input : "";
	}
	exports.__DOM_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE = Internals;
	exports.browser = function(reason) {
		return {
			$$typeof: REACT_RECOVERABLE_TYPE,
			_reason: reason
		};
	};
	exports.createPortal = function(children, container) {
		var key = 2 < arguments.length && void 0 !== arguments[2] ? arguments[2] : null;
		if (!container || 1 !== container.nodeType && 9 !== container.nodeType && 11 !== container.nodeType) throw Error(formatProdErrorMessage(299));
		return createPortal$1(children, container, null, key);
	};
	exports.flushSync = function(fn) {
		var previousTransition = ReactSharedInternals.T, previousUpdatePriority = Internals.p;
		try {
			if (ReactSharedInternals.T = null, Internals.p = 2, fn) return fn();
		} finally {
			ReactSharedInternals.T = previousTransition, Internals.p = previousUpdatePriority, Internals.d.f();
		}
	};
	exports.preconnect = function(href, options) {
		"string" === typeof href && (options ? (options = options.crossOrigin, options = "string" === typeof options ? "use-credentials" === options ? options : "" : void 0) : options = null, Internals.d.C(href, options));
	};
	exports.prefetchDNS = function(href) {
		"string" === typeof href && Internals.d.D(href);
	};
	exports.preinit = function(href, options) {
		if ("string" === typeof href && options && "string" === typeof options.as) {
			var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin), integrity = "string" === typeof options.integrity ? options.integrity : void 0, fetchPriority = "string" === typeof options.fetchPriority ? options.fetchPriority : void 0;
			"style" === as ? Internals.d.S(href, "string" === typeof options.precedence ? options.precedence : void 0, {
				crossOrigin,
				integrity,
				fetchPriority
			}) : "script" === as && Internals.d.X(href, {
				crossOrigin,
				integrity,
				fetchPriority,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0
			});
		}
	};
	exports.preinitModule = function(href, options) {
		if ("string" === typeof href) if ("object" === typeof options && null !== options) {
			if (null == options.as || "script" === options.as) {
				var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
				Internals.d.M(href, {
					crossOrigin,
					integrity: "string" === typeof options.integrity ? options.integrity : void 0,
					nonce: "string" === typeof options.nonce ? options.nonce : void 0,
					fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0
				});
			}
		} else options ?? Internals.d.M(href);
	};
	exports.preload = function(href, options) {
		if ("string" === typeof href && "object" === typeof options && null !== options && "string" === typeof options.as) {
			var as = options.as, crossOrigin = getCrossOriginStringAs(as, options.crossOrigin);
			Internals.d.L(href, as, {
				crossOrigin,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0,
				type: "string" === typeof options.type ? options.type : void 0,
				fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0,
				referrerPolicy: "string" === typeof options.referrerPolicy ? options.referrerPolicy : void 0,
				imageSrcSet: "string" === typeof options.imageSrcSet ? options.imageSrcSet : void 0,
				imageSizes: "string" === typeof options.imageSizes ? options.imageSizes : void 0,
				media: "string" === typeof options.media ? options.media : void 0
			});
		}
	};
	exports.preloadModule = function(href, options) {
		if ("string" === typeof href) if (options) {
			var crossOrigin = getCrossOriginStringAs(options.as, options.crossOrigin);
			Internals.d.m(href, {
				as: "string" === typeof options.as && "script" !== options.as ? options.as : void 0,
				crossOrigin,
				integrity: "string" === typeof options.integrity ? options.integrity : void 0,
				nonce: "string" === typeof options.nonce ? options.nonce : void 0,
				fetchPriority: "string" === typeof options.fetchPriority ? options.fetchPriority : void 0
			});
		} else Internals.d.m(href);
	};
	exports.requestFormReset = function(form) {
		Internals.d.r(form);
	};
	exports.unstable_batchedUpdates = function(fn, a) {
		return fn(a);
	};
	exports.useFormState = function(action, initialState, permalink) {
		return ReactSharedInternals.H.useFormState(action, initialState, permalink);
	};
	exports.useFormStatus = function() {
		return ReactSharedInternals.H.useHostTransitionStatus();
	};
	exports.version = "19.3.0";
}));
//#endregion
//#region node_modules/react-dom/index.js
var require_react_dom = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	function checkDCE() {
		if (typeof __REACT_DEVTOOLS_GLOBAL_HOOK__ === "undefined" || typeof __REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE !== "function") return;
		try {
			__REACT_DEVTOOLS_GLOBAL_HOOK__.checkDCE(checkDCE);
		} catch (err) {
			console.error(err);
		}
	}
	checkDCE();
	module.exports = require_react_dom_production();
}));
//#endregion
//#region node_modules/@noble/hashes/hmac.js
var import_react = /* @__PURE__ */ __toESM(require_react(), 1);
var import_jsx_runtime = require_jsx_runtime();
/**
* HMAC: RFC2104 message authentication code.
* @module
*/
/**
* Internal class for HMAC.
* Accepts any byte key, although RFC 2104 §3 recommends keys at least
* `HashLen` bytes long.
*/
var _HMAC = class {
	oHash;
	iHash;
	blockLen;
	outputLen;
	canXOF = false;
	finished = false;
	destroyed = false;
	constructor(hash, key) {
		ahash(hash);
		abytes$1(key, void 0, "key");
		this.iHash = hash.create();
		if (typeof this.iHash.update !== "function") throw new Error("expected Hash instance");
		this.blockLen = this.iHash.blockLen;
		this.outputLen = this.iHash.outputLen;
		const blockLen = this.blockLen;
		const pad = new Uint8Array(blockLen);
		pad.set(key.length > blockLen ? hash.create().update(key).digest() : key);
		for (let i = 0; i < pad.length; i++) pad[i] ^= 54;
		this.iHash.update(pad);
		this.oHash = hash.create();
		for (let i = 0; i < pad.length; i++) pad[i] ^= 106;
		this.oHash.update(pad);
		clean(pad);
	}
	update(buf) {
		aexists(this);
		this.iHash.update(buf);
		return this;
	}
	digestInto(out) {
		aexists(this);
		aoutput(out, this);
		this.finished = true;
		const buf = out.subarray(0, this.outputLen);
		this.iHash.digestInto(buf);
		this.oHash.update(buf);
		this.oHash.digestInto(buf);
		this.destroy();
	}
	digest() {
		const out = new Uint8Array(this.oHash.outputLen);
		this.digestInto(out);
		return out;
	}
	_cloneInto(to) {
		to ||= Object.create(Object.getPrototypeOf(this), {});
		const { oHash, iHash, finished, destroyed, blockLen, outputLen, canXOF } = this;
		to = to;
		to.finished = finished;
		to.destroyed = destroyed;
		to.blockLen = blockLen;
		to.outputLen = outputLen;
		to.canXOF = canXOF;
		to.oHash = oHash._cloneInto(to.oHash);
		to.iHash = iHash._cloneInto(to.iHash);
		return to;
	}
	clone() {
		return this._cloneInto();
	}
	destroy() {
		this.destroyed = true;
		this.oHash.destroy();
		this.iHash.destroy();
	}
};
var hmac = /* @__PURE__ */ (() => {
	const hmac_ = ((hash, key, message) => new _HMAC(hash, key).update(message).digest());
	hmac_.create = (hash, key) => new _HMAC(hash, key);
	return hmac_;
})();
//#endregion
//#region node_modules/@noble/hashes/sha2.js
/**
* SHA2 hash function. A.k.a. sha256, sha384, sha512, sha512_224, sha512_256.
* SHA256 is the fastest hash implementable in JS, even faster than Blake3.
* Check out {@link https://www.rfc-editor.org/rfc/rfc4634 | RFC 4634} and
* {@link https://nvlpubs.nist.gov/nistpubs/FIPS/NIST.FIPS.180-4.pdf | FIPS 180-4}.
* @module
*/
/**
* SHA-224 / SHA-256 round constants from RFC 6234 §5.1: the first 32 bits
* of the cube roots of the first 64 primes (2..311).
*/
var SHA256_K = /* @__PURE__ */ Uint32Array.from([
	1116352408,
	1899447441,
	3049323471,
	3921009573,
	961987163,
	1508970993,
	2453635748,
	2870763221,
	3624381080,
	310598401,
	607225278,
	1426881987,
	1925078388,
	2162078206,
	2614888103,
	3248222580,
	3835390401,
	4022224774,
	264347078,
	604807628,
	770255983,
	1249150122,
	1555081692,
	1996064986,
	2554220882,
	2821834349,
	2952996808,
	3210313671,
	3336571891,
	3584528711,
	113926993,
	338241895,
	666307205,
	773529912,
	1294757372,
	1396182291,
	1695183700,
	1986661051,
	2177026350,
	2456956037,
	2730485921,
	2820302411,
	3259730800,
	3345764771,
	3516065817,
	3600352804,
	4094571909,
	275423344,
	430227734,
	506948616,
	659060556,
	883997877,
	958139571,
	1322822218,
	1537002063,
	1747873779,
	1955562222,
	2024104815,
	2227730452,
	2361852424,
	2428436474,
	2756734187,
	3204031479,
	3329325298
]);
/** Reusable SHA-224 / SHA-256 message schedule buffer `W_t` from RFC 6234 §6.2 step 1. */
var SHA256_W = /* @__PURE__ */ new Uint32Array(64);
/** Internal SHA-224 / SHA-256 compression engine from RFC 6234 §6.2. */
var SHA2_32B = class extends HashMD {
	A = 0;
	B = 0;
	C = 0;
	D = 0;
	E = 0;
	F = 0;
	G = 0;
	H = 0;
	constructor(outputLen, IV) {
		super(64, outputLen, 8, false);
		this.A = IV[0] | 0;
		this.B = IV[1] | 0;
		this.C = IV[2] | 0;
		this.D = IV[3] | 0;
		this.E = IV[4] | 0;
		this.F = IV[5] | 0;
		this.G = IV[6] | 0;
		this.H = IV[7] | 0;
	}
	get() {
		const { A, B, C, D, E, F, G, H } = this;
		return [
			A,
			B,
			C,
			D,
			E,
			F,
			G,
			H
		];
	}
	set(A, B, C, D, E, F, G, H) {
		this.A = A | 0;
		this.B = B | 0;
		this.C = C | 0;
		this.D = D | 0;
		this.E = E | 0;
		this.F = F | 0;
		this.G = G | 0;
		this.H = H | 0;
	}
	_cloneInto(to) {
		(to ||= new this.constructor()).set(...this.get());
		return this._cloneIntoMeta(to);
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) SHA256_W[i] = view.getUint32(offset, false);
		for (let i = 16; i < 64; i++) {
			const W15 = SHA256_W[i - 15];
			const W2 = SHA256_W[i - 2];
			const s0 = rotr(W15, 7) ^ rotr(W15, 18) ^ W15 >>> 3;
			const s1 = rotr(W2, 17) ^ rotr(W2, 19) ^ W2 >>> 10;
			SHA256_W[i] = s1 + SHA256_W[i - 7] + s0 + SHA256_W[i - 16] | 0;
		}
		let { A, B, C, D, E, F, G, H } = this;
		for (let i = 0; i < 64; i++) {
			const sigma1 = rotr(E, 6) ^ rotr(E, 11) ^ rotr(E, 25);
			const T1 = H + sigma1 + Chi(E, F, G) + SHA256_K[i] + SHA256_W[i] | 0;
			const T2 = (rotr(A, 2) ^ rotr(A, 13) ^ rotr(A, 22)) + Maj(A, B, C) | 0;
			H = G;
			G = F;
			F = E;
			E = D + T1 | 0;
			D = C;
			C = B;
			B = A;
			A = T1 + T2 | 0;
		}
		A = A + this.A | 0;
		B = B + this.B | 0;
		C = C + this.C | 0;
		D = D + this.D | 0;
		E = E + this.E | 0;
		F = F + this.F | 0;
		G = G + this.G | 0;
		H = H + this.H | 0;
		this.set(A, B, C, D, E, F, G, H);
	}
	roundClean() {
		clean(SHA256_W);
	}
	destroy() {
		this.destroyed = true;
		this.set(0, 0, 0, 0, 0, 0, 0, 0);
		clean(this.buffer);
	}
};
/** Internal SHA-256 hash class grounded in RFC 6234 §6.2. */
var _SHA256 = class extends SHA2_32B {
	constructor() {
		super(32, SHA256_IV);
	}
};
var K512 = /* @__PURE__ */ (() => split([
	"0x428a2f98d728ae22",
	"0x7137449123ef65cd",
	"0xb5c0fbcfec4d3b2f",
	"0xe9b5dba58189dbbc",
	"0x3956c25bf348b538",
	"0x59f111f1b605d019",
	"0x923f82a4af194f9b",
	"0xab1c5ed5da6d8118",
	"0xd807aa98a3030242",
	"0x12835b0145706fbe",
	"0x243185be4ee4b28c",
	"0x550c7dc3d5ffb4e2",
	"0x72be5d74f27b896f",
	"0x80deb1fe3b1696b1",
	"0x9bdc06a725c71235",
	"0xc19bf174cf692694",
	"0xe49b69c19ef14ad2",
	"0xefbe4786384f25e3",
	"0x0fc19dc68b8cd5b5",
	"0x240ca1cc77ac9c65",
	"0x2de92c6f592b0275",
	"0x4a7484aa6ea6e483",
	"0x5cb0a9dcbd41fbd4",
	"0x76f988da831153b5",
	"0x983e5152ee66dfab",
	"0xa831c66d2db43210",
	"0xb00327c898fb213f",
	"0xbf597fc7beef0ee4",
	"0xc6e00bf33da88fc2",
	"0xd5a79147930aa725",
	"0x06ca6351e003826f",
	"0x142929670a0e6e70",
	"0x27b70a8546d22ffc",
	"0x2e1b21385c26c926",
	"0x4d2c6dfc5ac42aed",
	"0x53380d139d95b3df",
	"0x650a73548baf63de",
	"0x766a0abb3c77b2a8",
	"0x81c2c92e47edaee6",
	"0x92722c851482353b",
	"0xa2bfe8a14cf10364",
	"0xa81a664bbc423001",
	"0xc24b8b70d0f89791",
	"0xc76c51a30654be30",
	"0xd192e819d6ef5218",
	"0xd69906245565a910",
	"0xf40e35855771202a",
	"0x106aa07032bbd1b8",
	"0x19a4c116b8d2d0c8",
	"0x1e376c085141ab53",
	"0x2748774cdf8eeb99",
	"0x34b0bcb5e19b48a8",
	"0x391c0cb3c5c95a63",
	"0x4ed8aa4ae3418acb",
	"0x5b9cca4f7763e373",
	"0x682e6ff3d6b2b8a3",
	"0x748f82ee5defb2fc",
	"0x78a5636f43172f60",
	"0x84c87814a1f0ab72",
	"0x8cc702081a6439ec",
	"0x90befffa23631e28",
	"0xa4506cebde82bde9",
	"0xbef9a3f7b2c67915",
	"0xc67178f2e372532b",
	"0xca273eceea26619c",
	"0xd186b8c721c0c207",
	"0xeada7dd6cde0eb1e",
	"0xf57d4f7fee6ed178",
	"0x06f067aa72176fba",
	"0x0a637dc5a2c898a6",
	"0x113f9804bef90dae",
	"0x1b710b35131c471b",
	"0x28db77f523047d84",
	"0x32caab7b40c72493",
	"0x3c9ebe0a15c9bebc",
	"0x431d67c49c100d4c",
	"0x4cc5d4becb3e42b6",
	"0x597f299cfc657e2a",
	"0x5fcb6fab3ad6faec",
	"0x6c44198c4a475817"
].map((n) => BigInt(n))))();
var SHA512_Kh = /* @__PURE__ */ (() => K512[0])();
var SHA512_Kl = /* @__PURE__ */ (() => K512[1])();
var SHA512_W_H = /* @__PURE__ */ new Uint32Array(80);
var SHA512_W_L = /* @__PURE__ */ new Uint32Array(80);
/** Internal SHA-384 / SHA-512 compression engine from RFC 6234 §6.4. */
var SHA2_64B = class extends HashMD {
	Ah = 0;
	Al = 0;
	Bh = 0;
	Bl = 0;
	Ch = 0;
	Cl = 0;
	Dh = 0;
	Dl = 0;
	Eh = 0;
	El = 0;
	Fh = 0;
	Fl = 0;
	Gh = 0;
	Gl = 0;
	Hh = 0;
	Hl = 0;
	constructor(outputLen, IV) {
		super(128, outputLen, 16, false);
		this.Ah = IV[0] | 0;
		this.Al = IV[1] | 0;
		this.Bh = IV[2] | 0;
		this.Bl = IV[3] | 0;
		this.Ch = IV[4] | 0;
		this.Cl = IV[5] | 0;
		this.Dh = IV[6] | 0;
		this.Dl = IV[7] | 0;
		this.Eh = IV[8] | 0;
		this.El = IV[9] | 0;
		this.Fh = IV[10] | 0;
		this.Fl = IV[11] | 0;
		this.Gh = IV[12] | 0;
		this.Gl = IV[13] | 0;
		this.Hh = IV[14] | 0;
		this.Hl = IV[15] | 0;
	}
	get() {
		const { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		return [
			Ah,
			Al,
			Bh,
			Bl,
			Ch,
			Cl,
			Dh,
			Dl,
			Eh,
			El,
			Fh,
			Fl,
			Gh,
			Gl,
			Hh,
			Hl
		];
	}
	set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl) {
		this.Ah = Ah | 0;
		this.Al = Al | 0;
		this.Bh = Bh | 0;
		this.Bl = Bl | 0;
		this.Ch = Ch | 0;
		this.Cl = Cl | 0;
		this.Dh = Dh | 0;
		this.Dl = Dl | 0;
		this.Eh = Eh | 0;
		this.El = El | 0;
		this.Fh = Fh | 0;
		this.Fl = Fl | 0;
		this.Gh = Gh | 0;
		this.Gl = Gl | 0;
		this.Hh = Hh | 0;
		this.Hl = Hl | 0;
	}
	_cloneInto(to) {
		(to ||= new this.constructor()).set(...this.get());
		return this._cloneIntoMeta(to);
	}
	process(view, offset) {
		for (let i = 0; i < 16; i++, offset += 4) {
			SHA512_W_H[i] = view.getUint32(offset);
			SHA512_W_L[i] = view.getUint32(offset += 4);
		}
		for (let i = 16; i < 80; i++) {
			const W15h = SHA512_W_H[i - 15] | 0;
			const W15l = SHA512_W_L[i - 15] | 0;
			const s0h = rotrSH(W15h, W15l, 1) ^ rotrSH(W15h, W15l, 8) ^ shrSH(W15h, W15l, 7);
			const s0l = rotrSL(W15h, W15l, 1) ^ rotrSL(W15h, W15l, 8) ^ shrSL(W15h, W15l, 7);
			const W2h = SHA512_W_H[i - 2] | 0;
			const W2l = SHA512_W_L[i - 2] | 0;
			const s1h = rotrSH(W2h, W2l, 19) ^ rotrBH(W2h, W2l, 61) ^ shrSH(W2h, W2l, 6);
			const s1l = rotrSL(W2h, W2l, 19) ^ rotrBL(W2h, W2l, 61) ^ shrSL(W2h, W2l, 6);
			const SUMl = add4L(s0l, s1l, SHA512_W_L[i - 7], SHA512_W_L[i - 16]);
			const SUMh = add4H(SUMl, s0h, s1h, SHA512_W_H[i - 7], SHA512_W_H[i - 16]);
			SHA512_W_H[i] = SUMh | 0;
			SHA512_W_L[i] = SUMl | 0;
		}
		let { Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl } = this;
		for (let i = 0; i < 80; i++) {
			const sigma1h = rotrSH(Eh, El, 14) ^ rotrSH(Eh, El, 18) ^ rotrBH(Eh, El, 41);
			const sigma1l = rotrSL(Eh, El, 14) ^ rotrSL(Eh, El, 18) ^ rotrBL(Eh, El, 41);
			const CHIh = Eh & Fh ^ ~Eh & Gh;
			const CHIl = El & Fl ^ ~El & Gl;
			const T1ll = add5L(Hl, sigma1l, CHIl, SHA512_Kl[i], SHA512_W_L[i]);
			const T1h = add5H(T1ll, Hh, sigma1h, CHIh, SHA512_Kh[i], SHA512_W_H[i]);
			const T1l = T1ll | 0;
			const sigma0h = rotrSH(Ah, Al, 28) ^ rotrBH(Ah, Al, 34) ^ rotrBH(Ah, Al, 39);
			const sigma0l = rotrSL(Ah, Al, 28) ^ rotrBL(Ah, Al, 34) ^ rotrBL(Ah, Al, 39);
			const MAJh = Ah & Bh ^ Ah & Ch ^ Bh & Ch;
			const MAJl = Al & Bl ^ Al & Cl ^ Bl & Cl;
			Hh = Gh | 0;
			Hl = Gl | 0;
			Gh = Fh | 0;
			Gl = Fl | 0;
			Fh = Eh | 0;
			Fl = El | 0;
			({h: Eh, l: El} = add(Dh | 0, Dl | 0, T1h | 0, T1l | 0));
			Dh = Ch | 0;
			Dl = Cl | 0;
			Ch = Bh | 0;
			Cl = Bl | 0;
			Bh = Ah | 0;
			Bl = Al | 0;
			const All = add3L(T1l, sigma0l, MAJl);
			Ah = add3H(All, T1h, sigma0h, MAJh);
			Al = All | 0;
		}
		({h: Ah, l: Al} = add(this.Ah | 0, this.Al | 0, Ah | 0, Al | 0));
		({h: Bh, l: Bl} = add(this.Bh | 0, this.Bl | 0, Bh | 0, Bl | 0));
		({h: Ch, l: Cl} = add(this.Ch | 0, this.Cl | 0, Ch | 0, Cl | 0));
		({h: Dh, l: Dl} = add(this.Dh | 0, this.Dl | 0, Dh | 0, Dl | 0));
		({h: Eh, l: El} = add(this.Eh | 0, this.El | 0, Eh | 0, El | 0));
		({h: Fh, l: Fl} = add(this.Fh | 0, this.Fl | 0, Fh | 0, Fl | 0));
		({h: Gh, l: Gl} = add(this.Gh | 0, this.Gl | 0, Gh | 0, Gl | 0));
		({h: Hh, l: Hl} = add(this.Hh | 0, this.Hl | 0, Hh | 0, Hl | 0));
		this.set(Ah, Al, Bh, Bl, Ch, Cl, Dh, Dl, Eh, El, Fh, Fl, Gh, Gl, Hh, Hl);
	}
	roundClean() {
		clean(SHA512_W_H, SHA512_W_L);
	}
	destroy() {
		this.destroyed = true;
		clean(this.buffer);
		this.set(0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0);
	}
};
/** Internal SHA-512 hash class grounded in RFC 6234 §6.3 and §6.4. */
var _SHA512 = class extends SHA2_64B {
	constructor() {
		super(64, SHA512_IV);
	}
};
/**
* SHA2-256 hash function from RFC 4634. In JS it's the fastest: even faster than Blake3. Some info:
*
* - Trying 2^128 hashes would get 50% chance of collision, using birthday attack.
* - BTC network is doing 2^70 hashes/sec (2^95 hashes/year) as per 2025.
* - Each sha256 hash is executing 2^18 bit operations.
* - Good 2024 ASICs can do 200Th/sec with 3500 watts of power, corresponding to 2^36 hashes/joule.
* @param msg - message bytes to hash
* @param opts - Reserved hash options.
* @returns Digest bytes.
* @example
* Hash a message with SHA2-256.
* ```ts
* sha256(new Uint8Array([97, 98, 99]));
* ```
*/
var sha256 = /* @__PURE__ */ createHasher(() => new _SHA256(), /* @__PURE__ */ oidNist(1));
/**
* SHA2-512 hash function from RFC 4634.
* @param msg - message bytes to hash
* @param opts - Reserved hash options.
* @returns Digest bytes.
* @example
* Hash a message with SHA2-512.
* ```ts
* sha512(new Uint8Array([97, 98, 99]));
* ```
*/
var sha512 = /* @__PURE__ */ createHasher(() => new _SHA512(), /* @__PURE__ */ oidNist(3));
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryClientProvider.js
/**
* The context that `useQueryClient` reads from. `QueryClientProvider` is the normal way to set it.
*/
var QueryClientContext = import_react.createContext(void 0);
/**
* The `useQueryClient` hook returns the current `QueryClient` instance.
*
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns The current `QueryClient` instance.
* @throws If no `queryClient` argument is passed and no `QueryClientProvider` is found in the component tree.
*/
var useQueryClient = (queryClient) => {
	const client = import_react.useContext(QueryClientContext);
	if (queryClient) return queryClient;
	if (!client) throw new Error("No QueryClient set, use QueryClientProvider to set one");
	return client;
};
/**
* Use the `QueryClientProvider` component to connect and provide a `QueryClient` to your application. Also
* calls `client.mount()`/`client.unmount()` as this component mounts/unmounts, which subscribes the client to
* focus/online events (resuming any paused mutations and refetching as needed when the app regains focus or
* comes back online).
*
* @returns The provided `children`, wrapped so they can read the `QueryClient` via `useQueryClient`.
*
* @example
* ```tsx
* import { QueryClient, QueryClientProvider } from '@tanstack/react-query'
*
* const queryClient = new QueryClient()
*
* function App() {
*   return <QueryClientProvider client={queryClient}>...</QueryClientProvider>
* }
* ```
*/
var QueryClientProvider = ({ client, children }) => {
	import_react.useEffect(() => {
		client.mount();
		return () => {
			client.unmount();
		};
	}, [client]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(QueryClientContext.Provider, {
		value: client,
		children
	});
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/timeoutManager.js
var defaultTimeoutProvider = {
	setTimeout: (callback, delay) => setTimeout(callback, delay),
	clearTimeout: (timeoutId) => clearTimeout(timeoutId),
	setInterval: (callback, delay) => setInterval(callback, delay),
	clearInterval: (intervalId) => clearInterval(intervalId)
};
/**
* Allows customization of how timeouts are created.
*
* @tanstack/query-core makes liberal use of timeouts to implement `staleTime`
* and `gcTime`. The default TimeoutManager provider uses the platform's global
* `setTimeout` implementation, which is known to have scalability issues with
* thousands of timeouts on the event loop.
*
* If you hit this limitation, consider providing a custom TimeoutProvider that
* coalesces timeouts.
*/
var TimeoutManager = class {
	#provider = defaultTimeoutProvider;
	#providerCalled = false;
	/**
	* `setTimeoutProvider` can be used to set a custom implementation of the
	* `setTimeout`, `clearTimeout`, `setInterval`, `clearInterval` functions,
	* called a `TimeoutProvider`.
	*
	* This may be useful if you notice event loop performance issues with
	* thousands of queries. A custom TimeoutProvider could also support timer
	* delays longer than the global `setTimeout` maximum delay value of about
	* 24 days.
	*
	* It is important to call `setTimeoutProvider` before creating a
	* QueryClient or queries, so that the same provider is used consistently
	* for all timers in the application, since different TimeoutProviders
	* cannot cancel each others' timers.
	*
	* @example
	* ```ts
	* import { timeoutManager, QueryClient } from '@tanstack/query-core'
	* import { CustomTimeoutProvider } from './CustomTimeoutProvider'
	*
	* timeoutManager.setTimeoutProvider(new CustomTimeoutProvider())
	*
	* export const queryClient = new QueryClient()
	* ```
	*/
	setTimeoutProvider(provider) {
		this.#provider = provider;
	}
	/**
	* `setTimeout` schedules a callback to run after approximately `delay`
	* milliseconds, like the global `setTimeout` function. The callback can be
	* canceled with `clearTimeout`.
	*
	* It returns a timer ID, which may be a number or an object that can be
	* coerced to a number via `Symbol.toPrimitive`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* const timeoutIdNumber: number = Number(timeoutId)
	* ```
	*/
	setTimeout(callback, delay) {
		return this.#provider.setTimeout(callback, delay);
	}
	/**
	* `clearTimeout` cancels a timeout callback scheduled with `setTimeout`,
	* like the global `clearTimeout` function. It should be called with a
	* timer ID returned by `setTimeout`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const timeoutId = timeoutManager.setTimeout(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearTimeout(timeoutId)
	* ```
	*/
	clearTimeout(timeoutId) {
		this.#provider.clearTimeout(timeoutId);
	}
	/**
	* `setInterval` schedules a callback to be called approximately every
	* `delay` milliseconds, like the global `setInterval` function.
	*
	* Like `setTimeout`, it returns a timer ID, which may be a number or an
	* object that can be coerced to a number via `Symbol.toPrimitive`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	* ```
	*/
	setInterval(callback, delay) {
		return this.#provider.setInterval(callback, delay);
	}
	/**
	* `clearInterval` can be used to cancel an interval, like the global
	* `clearInterval` function. It should be called with an interval ID
	* returned by `setInterval`.
	*
	* @example
	* ```ts
	* import { timeoutManager } from '@tanstack/query-core'
	*
	* const intervalId = timeoutManager.setInterval(
	*   () => console.log('ran at:', new Date()),
	*   1000,
	* )
	*
	* timeoutManager.clearInterval(intervalId)
	* ```
	*/
	clearInterval(intervalId) {
		this.#provider.clearInterval(intervalId);
	}
};
/**
* Singleton instance of {@link TimeoutManager}, used throughout TanStack Query to schedule and cancel timers.
*/
var timeoutManager = new TimeoutManager();
/**
* In many cases code wants to delay to the next event loop tick; this is not
* mediated by {@link timeoutManager}.
*
* This function is provided to make auditing the `tanstack/query-core` for
* incorrect use of system `setTimeout` easier.
*/
function systemSetTimeoutZero(callback) {
	setTimeout(callback, 0);
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/utils.js
/** @deprecated
* use `environmentManager.isServer()` instead.
*/
var isServer$1 = typeof window === "undefined" || "Deno" in globalThis;
function noop() {}
function functionalUpdate(updater, input) {
	return typeof updater === "function" ? updater(input) : updater;
}
function isValidTimeout(value) {
	return typeof value === "number" && value >= 0 && value !== Infinity;
}
function timeUntilStale(updatedAt, staleTime) {
	return Math.max(updatedAt + (staleTime || 0) - Date.now(), 0);
}
function resolveQueryValue(value, query) {
	return typeof value === "function" ? value(query) : value;
}
/**
* Checks whether a query matches the given {@link QueryFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
*
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
*
* const matchingQueries = queryCache
*   .getAll()
*   .filter((query) => matchQuery({ queryKey: ['posts'] }, query))
* ```
*/
function matchQuery(filters, query) {
	const { type = "all", exact, fetchStatus, predicate, queryKey, stale } = filters;
	if (queryKey) {
		if (exact) {
			if (query.queryHash !== hashQueryKeyByOptions(queryKey, query.options)) return false;
		} else if (!partialMatchKey(query.queryKey, queryKey)) return false;
	}
	if (type !== "all") {
		const isActive = query.isActive();
		if (type === "active" && !isActive) return false;
		if (type === "inactive" && isActive) return false;
	}
	if (typeof stale === "boolean" && query.isStale() !== stale) return false;
	if (fetchStatus && fetchStatus !== query.state.fetchStatus) return false;
	if (predicate && !predicate(query)) return false;
	return true;
}
/**
* Checks whether a mutation matches the given {@link MutationFilters}.
* Every filter that is specified must match; filters that are left unspecified are ignored.
* If a `mutationKey` filter is provided but the mutation has no `mutationKey` of its own, it does not match.
*
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const matchingMutations = mutationCache
*   .getAll()
*   .filter((mutation) => matchMutation({ mutationKey: ['addPost'] }, mutation))
* ```
*/
function matchMutation(filters, mutation) {
	const { exact, status, predicate, mutationKey } = filters;
	if (mutationKey) {
		if (!mutation.options.mutationKey) return false;
		if (exact) {
			if (hashKey(mutation.options.mutationKey) !== hashKey(mutationKey)) return false;
		} else if (!partialMatchKey(mutation.options.mutationKey, mutationKey)) return false;
	}
	if (status && mutation.state.status !== status) return false;
	if (predicate && !predicate(mutation)) return false;
	return true;
}
function hashQueryKeyByOptions(queryKey, options) {
	return (options?.queryKeyHashFn || hashKey)(queryKey);
}
/**
* Default query & mutation keys hash function.
* Hashes the value into a stable hash.
*
* @example
* ```ts
* // Object keys are sorted, so key order doesn't affect the hash:
* hashKey(['todos', { page: 1, filter: 'done' }]) // === '["todos",{"filter":"done","page":1}]'
* ```
*/
function hashKey(queryKey) {
	return JSON.stringify(queryKey, (_, val) => isPlainObject(val) ? Object.keys(val).sort().reduce((result, key) => {
		result[key] = val[key];
		return result;
	}, {}) : val);
}
function partialMatchKey(a, b) {
	if (a === b) return true;
	if (typeof a !== typeof b) return false;
	if (a && b && typeof a === "object" && typeof b === "object") {
		if (Array.isArray(a) && Array.isArray(b)) {
			if (b.length > a.length) return false;
			for (let i = 0; i < b.length; i++) if (!partialMatchKey(a[i], b[i])) return false;
			return true;
		}
		const bKeys = Object.keys(b);
		for (const key of bKeys) if (!partialMatchKey(a[key], b[key])) return false;
		return true;
	}
	return false;
}
var hasOwn = Object.prototype.hasOwnProperty;
function replaceEqualDeep(a, b, depth = 0) {
	if (a === b) return a;
	if (depth > 500) return b;
	const array = isPlainArray(a) && isPlainArray(b);
	if (!array && !(isPlainObject(a) && isPlainObject(b))) return b;
	const aSize = (array ? a : Object.keys(a)).length;
	const bItems = array ? b : Object.keys(b);
	const bSize = bItems.length;
	const copy = array ? new Array(bSize) : {};
	let equalItems = 0;
	for (let i = 0; i < bSize; i++) {
		const key = array ? i : bItems[i];
		const aItem = a[key];
		const bItem = b[key];
		if (aItem === bItem) {
			copy[key] = aItem;
			if (array ? i < aSize : hasOwn.call(a, key)) equalItems++;
			continue;
		}
		if (aItem === null || bItem === null || typeof aItem !== "object" || typeof bItem !== "object") {
			copy[key] = bItem;
			continue;
		}
		const v = replaceEqualDeep(aItem, bItem, depth + 1);
		copy[key] = v;
		if (v === aItem) equalItems++;
	}
	return aSize === bSize && equalItems === aSize ? a : copy;
}
/**
* Shallow compare objects.
*/
function shallowEqualObjects(a, b) {
	if (!b || Object.keys(a).length !== Object.keys(b).length) return false;
	for (const key in a) if (a[key] !== b[key]) return false;
	return true;
}
function isPlainArray(value) {
	return Array.isArray(value) && value.length === Object.keys(value).length;
}
function isPlainObject(o) {
	if (!hasObjectPrototype(o)) return false;
	const objectPrototype = Object.getPrototypeOf(o);
	const ctor = objectPrototype?.constructor;
	if (ctor === void 0) return true;
	if (typeof ctor !== "function") return false;
	const prot = ctor.prototype;
	if (!hasObjectPrototype(prot)) return false;
	if (!prot.hasOwnProperty("isPrototypeOf")) return false;
	if (objectPrototype !== Object.prototype) return false;
	return true;
}
function hasObjectPrototype(o) {
	return Object.prototype.toString.call(o) === "[object Object]";
}
function sleep(timeout) {
	return new Promise((resolve) => {
		timeoutManager.setTimeout(resolve, timeout);
	});
}
function replaceData(prevData, data, options) {
	if (typeof options.structuralSharing === "function") return options.structuralSharing(prevData, data);
	else if (options.structuralSharing !== false) return replaceEqualDeep(prevData, data);
	return data;
}
function addToEnd(items, item, max = 0) {
	const newItems = [...items, item];
	return max && newItems.length > max ? newItems.slice(1) : newItems;
}
function addToStart(items, item, max = 0) {
	const newItems = [item, ...items];
	return max && newItems.length > max ? newItems.slice(0, -1) : newItems;
}
/**
* Sentinel value that can be passed as a query's `queryFn` to conditionally disable the query (equivalent
* to `enabled: false`) while preserving full type inference for the query's data. Unlike `enabled: false`,
* a query disabled via `skipToken` cannot be triggered with `refetch`.
*
* @example
* ```ts
* new QueryObserver(queryClient, {
*   queryKey: ['post', postId],
*   queryFn: postId != null ? () => fetchPost(postId) : skipToken,
* })
* ```
*/
var skipToken = Symbol();
function ensureQueryFn(options, fetchOptions) {
	if (!options.queryFn && fetchOptions?.initialPromise) return () => fetchOptions.initialPromise;
	if (!options.queryFn || options.queryFn === skipToken) return () => Promise.reject(/* @__PURE__ */ new Error(`Missing queryFn: '${options.queryHash}'`));
	return options.queryFn;
}
/**
* Resolves a `throwOnError` option to a boolean.
* If `throwOnError` is a function, it is called with `params` (e.g. the error and, depending on the caller,
* additional context such as the query or mutation) and its result is returned, allowing the throwing
* behavior to be decided per error. Otherwise, `throwOnError` itself is coerced to a boolean (`undefined`
* resolves to `false`).
*
* @example
* ```ts
* const throwOnError =
*   query.state.error && typeof options.throwOnError === 'function'
*     ? shouldThrowError(options.throwOnError, [query.state.error, query])
*     : options.throwOnError
* ```
*/
function shouldThrowError(throwOnError, params) {
	if (typeof throwOnError === "function") return throwOnError(...params);
	return !!throwOnError;
}
function addConsumeAwareSignal(object, getSignal, onCancelled) {
	let consumed = false;
	let signal;
	Object.defineProperty(object, "signal", {
		enumerable: true,
		get: () => {
			signal ??= getSignal();
			if (consumed) return signal;
			consumed = true;
			if (signal.aborted) onCancelled();
			else signal.addEventListener("abort", onCancelled, { once: true });
			return signal;
		}
	});
	return object;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/environmentManager.js
var isServerFn = () => isServer$1;
/**
* Returns whether the current runtime should be treated as a server environment.
*/
var isServer = () => isServerFn();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/subscribable.js
/**
* The base class behind everything in Query that you can subscribe to: `QueryCache`, `MutationCache`,
* the observers, and the `FocusManager`/`OnlineManager` behind `focusManager` and `onlineManager`.
* Subclasses decide what a listener receives and when it is called.
*/
var Subscribable = class {
	constructor() {
		this.listeners = /* @__PURE__ */ new Set();
		this.subscribe = this.subscribe.bind(this);
	}
	/**
	* Registers a listener to be called on every update this object notifies about. Returns a function
	* that removes the listener again — call it to stop listening. The base class never drops a listener
	* on its own, though some subclasses clear all of theirs in `destroy()`.
	* @param listener - Called on each update, with whatever the subclass passes to its subscribers.
	* @example
	* ```ts
	* const unsubscribe = subscribable.subscribe(() => {
	*   // react to the update
	* })
	*
	* unsubscribe()
	* ```
	*/
	subscribe(listener) {
		this.listeners.add(listener);
		this.onSubscribe();
		return () => {
			this.listeners.delete(listener);
			this.onUnsubscribe();
		};
	}
	/**
	* Returns `true` while at least one listener is registered, `false` once they have all unsubscribed.
	*/
	hasListeners() {
		return this.listeners.size > 0;
	}
	onSubscribe() {}
	onUnsubscribe() {}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/focusManager.js
/**
* The `FocusManager` manages the focus state within TanStack Query.
*
* It can be used to change the default event listeners or to manually change the focus state.
*/
var FocusManager = class extends Subscribable {
	#focused;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onFocus) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const listener = () => onFocus();
				window.addEventListener("visibilitychange", listener, false);
				return () => {
					window.removeEventListener("visibilitychange", listener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the focus state. The provided `setup` function
	* receives a `setFocused` callback: call it with a `boolean` to manually
	* set the focus state, or with no arguments to re-evaluate the current
	* focus state and notify subscribers.
	*
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* focusManager.setEventListener((handleFocus) => {
	*   const listener = () => handleFocus()
	*   // Listen to visibilitychange
	*   if (typeof window !== 'undefined' && window.addEventListener) {
	*     window.addEventListener('visibilitychange', listener, false)
	*   }
	*
	*   return () => {
	*     // Be sure to unsubscribe if a new handler is set
	*     window.removeEventListener('visibilitychange', listener)
	*   }
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup((focused) => {
			if (typeof focused === "boolean") this.setFocused(focused);
			else this.onFocus();
		});
	}
	/**
	* `setFocused` can be used to manually set the focus state. Set `undefined`
	* to fall back to the default focus check.
	*
	* @example
	* ```ts
	* import { focusManager } from '@tanstack/query-core'
	*
	* // Set focused
	* focusManager.setFocused(true)
	*
	* // Set unfocused
	* focusManager.setFocused(false)
	*
	* // Fallback to the default focus check
	* focusManager.setFocused(undefined)
	* ```
	*/
	setFocused(focused) {
		if (this.#focused !== focused) {
			this.#focused = focused;
			this.onFocus();
		}
	}
	/**
	* `onFocus` notifies all subscribed listeners with the current focus state.
	*/
	onFocus() {
		const isFocused = this.isFocused();
		this.listeners.forEach((listener) => {
			listener(isFocused);
		});
	}
	/**
	* `isFocused` can be used to get the current focus state.
	*/
	isFocused() {
		if (typeof this.#focused === "boolean") return this.#focused;
		return globalThis.document?.visibilityState !== "hidden";
	}
};
/**
* Singleton instance of {@link FocusManager}, used to manage and observe the focus state within TanStack Query.
*/
var focusManager = new FocusManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/notifyManager.js
/**
* Default scheduling function used by the notify manager.
* Schedules the callback with the system's `setTimeout(callback, 0)`.
*/
var defaultScheduler = systemSetTimeoutZero;
function createNotifyManager() {
	let queue = [];
	let transactions = 0;
	let notifyFn = (callback) => {
		callback();
	};
	let batchNotifyFn = (callback) => {
		callback();
	};
	let scheduleFn = defaultScheduler;
	const schedule = (callback) => {
		if (transactions) queue.push(callback);
		else scheduleFn(() => {
			notifyFn(callback);
		});
	};
	const flush = () => {
		const originalQueue = queue;
		queue = [];
		if (originalQueue.length) scheduleFn(() => {
			batchNotifyFn(() => {
				originalQueue.forEach((callback) => {
					notifyFn(callback);
				});
			});
		});
	};
	return {
		/**
		* Batches all updates scheduled inside the passed callback.
		* This is mainly used internally to optimize query client updating.
		* Batches can be nested; the queue is only flushed once the outermost `batch` call finishes.
		* The return value of `callback` is passed through.
		*/
		batch: (callback) => {
			let result;
			transactions++;
			try {
				result = callback();
			} finally {
				transactions--;
				if (!transactions) flush();
			}
			return result;
		},
		/**
		* All calls to the wrapped function will be batched.
		*/
		batchCalls: (callback) => {
			return (...args) => {
				schedule(() => {
					callback(...args);
				});
			};
		},
		/**
		* Schedules a function to be run on the next batch.
		* By default, the batch is run with a `setTimeout`, but this can be configured via `setScheduler`.
		*/
		schedule,
		/**
		* Use this method to set a custom notify function.
		* This can be used to for example wrap notifications with `React.act` while running tests.
		*/
		setNotifyFunction: (fn) => {
			notifyFn = fn;
		},
		/**
		* Use this method to set a custom function to batch notifications together into a single tick.
		* Framework adapters use this to plug in their own batching primitive, so that a single query
		* update only triggers one re-render instead of one per subscriber.
		*
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		* import { batch } from 'solid-js'
		*
		* notifyManager.setBatchNotifyFunction(batch)
		* ```
		*/
		setBatchNotifyFunction: (fn) => {
			batchNotifyFn = fn;
		},
		/**
		* Configures a custom callback that schedules when the next batch runs.
		* The default behavior is `setTimeout(callback, 0)`.
		*
		* @example
		* ```ts
		* import { notifyManager } from '@tanstack/query-core'
		*
		* // Schedule batches in the next microtask
		* notifyManager.setScheduler(queueMicrotask)
		*
		* // Schedule batches before the next frame is rendered
		* notifyManager.setScheduler(requestAnimationFrame)
		*
		* // Schedule batches some time in the future
		* notifyManager.setScheduler((cb) => setTimeout(cb, 10))
		* ```
		*/
		setScheduler: (fn) => {
			scheduleFn = fn;
		}
	};
}
/**
* Handles scheduling and batching callbacks in TanStack Query.
*/
var notifyManager = createNotifyManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/onlineManager.js
/**
* The `OnlineManager` manages the online state within TanStack Query. It can
* be used to change the default event listeners or to manually change the
* online state.
*
* By default, the `onlineManager` assumes an active network connection, and
* listens to the `online` and `offline` events on the `window` object to
* detect changes.
*/
var OnlineManager = class extends Subscribable {
	#online = true;
	#cleanup;
	#setup;
	constructor() {
		super();
		this.#setup = (onOnline) => {
			if (typeof window !== "undefined" && window.addEventListener) {
				const onlineListener = () => onOnline(true);
				const offlineListener = () => onOnline(false);
				window.addEventListener("online", onlineListener, false);
				window.addEventListener("offline", offlineListener, false);
				return () => {
					window.removeEventListener("online", onlineListener);
					window.removeEventListener("offline", offlineListener);
				};
			}
		};
	}
	onSubscribe() {
		if (!this.#cleanup) this.setEventListener(this.#setup);
	}
	onUnsubscribe() {
		if (!this.hasListeners()) {
			this.#cleanup?.();
			this.#cleanup = void 0;
		}
	}
	/**
	* `setEventListener` can be used to set a custom event listener that will
	* be used to determine the online state. The provided `setup` function
	* receives a `setOnline` callback that should be called with a `boolean`
	* whenever the online state changes.
	*
	* @example
	* ```ts
	* import NetInfo from '@react-native-community/netinfo'
	* import { onlineManager } from '@tanstack/query-core'
	*
	* onlineManager.setEventListener((setOnline) => {
	*   return NetInfo.addEventListener((state) => {
	*     setOnline(!!state.isConnected)
	*   })
	* })
	* ```
	*/
	setEventListener(setup) {
		this.#setup = setup;
		this.#cleanup?.();
		this.#cleanup = setup(this.setOnline.bind(this));
	}
	/**
	* `setOnline` can be used to manually set the online state.
	*
	* @example
	* ```ts
	* import { onlineManager } from '@tanstack/query-core'
	*
	* // Set to online
	* onlineManager.setOnline(true)
	*
	* // Set to offline
	* onlineManager.setOnline(false)
	* ```
	*/
	setOnline(online) {
		if (this.#online !== online) {
			this.#online = online;
			this.listeners.forEach((listener) => {
				listener(online);
			});
		}
	}
	/**
	* `isOnline` can be used to get the current online state.
	*/
	isOnline() {
		return this.#online;
	}
};
/**
* Singleton instance of {@link OnlineManager}, used to manage and observe the online state within TanStack Query.
*/
var onlineManager = new OnlineManager();
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/retryer.js
function defaultRetryDelay(failureCount) {
	return Math.min(1e3 * 2 ** failureCount, 3e4);
}
function canFetch(networkMode) {
	return (networkMode ?? "online") === "online" ? onlineManager.isOnline() : true;
}
/**
* The error thrown by a `Retryer` (and surfaced to `query.promise`/`mutation`) when a fetch is cancelled, e.g. via
* `query.cancel()`. `revert`, if `true`, tells the caller to restore the state the query was in before the fetch
* started instead of surfacing the error. `silent`, if `true`, tells the caller to suppress this error and instead
* resolve with the promise of the fetch that triggered the cancellation.
* @example
* ```ts
* query.cancel()
*
* try {
*   await query.promise
* } catch (error) {
*   if (error instanceof CancelledError) {
*     // the fetch was cancelled, e.g. via `query.cancel()`
*   }
* }
* ```
*/
var CancelledError = class extends Error {
	constructor(options) {
		super("CancelledError");
		this.revert = options?.revert;
		this.silent = options?.silent;
	}
};
function createRetryer(config) {
	let isRetryCancelled = false;
	let failureCount = 0;
	let continueFn;
	let status = "pending";
	let promiseResolve;
	let promiseReject;
	const promise = new Promise((resolve, reject) => {
		promiseResolve = resolve;
		promiseReject = reject;
	});
	promise.catch(noop);
	const isResolved = () => status !== "pending";
	const cancel = (cancelOptions) => {
		if (!isResolved()) {
			const error = new CancelledError(cancelOptions);
			reject(error);
			config.onCancel?.(error);
		}
	};
	const cancelRetry = () => {
		isRetryCancelled = true;
	};
	const continueRetry = () => {
		isRetryCancelled = false;
	};
	const canContinue = () => focusManager.isFocused() && (config.networkMode === "always" || onlineManager.isOnline()) && config.canRun();
	const canStart = () => canFetch(config.networkMode) && config.canRun();
	const resolve = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "resolved";
			promiseResolve(value);
		}
	};
	const reject = (value) => {
		if (!isResolved()) {
			continueFn?.();
			status = "rejected";
			promiseReject(value);
		}
	};
	const pause = () => {
		return new Promise((continueResolve) => {
			continueFn = (value) => {
				if (isResolved() || canContinue()) continueResolve(value);
			};
			config.onPause?.();
		}).then(() => {
			continueFn = void 0;
			if (!isResolved()) config.onContinue?.();
		});
	};
	const run = () => {
		if (isResolved()) return;
		let promiseOrValue;
		const initialPromise = failureCount === 0 ? config.initialPromise : void 0;
		try {
			promiseOrValue = initialPromise ?? config.fn();
		} catch (error) {
			promiseOrValue = Promise.reject(error);
		}
		Promise.resolve(promiseOrValue).then(resolve).catch((error) => {
			if (isResolved()) return;
			const retry = config.retry ?? (isServer() ? 0 : 3);
			const retryDelay = config.retryDelay ?? defaultRetryDelay;
			const delay = typeof retryDelay === "function" ? retryDelay(failureCount, error) : retryDelay;
			const shouldRetry = retry === true || typeof retry === "number" && failureCount < retry || typeof retry === "function" && retry(failureCount, error);
			if (isRetryCancelled || !shouldRetry) {
				reject(error);
				return;
			}
			failureCount++;
			config.onFail?.(failureCount, error);
			sleep(delay).then(() => {
				return canContinue() ? void 0 : pause();
			}).then(() => {
				if (isRetryCancelled) reject(error);
				else run();
			});
		});
	};
	return {
		promise,
		status: () => status,
		cancel,
		continue: () => {
			continueFn?.();
			return promise;
		},
		cancelRetry,
		continueRetry,
		canStart,
		start: () => {
			if (canStart()) run();
			else pause().then(run);
			return promise;
		}
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/removable.js
/**
* The base class for cache entries that are garbage collected once nothing is using them —
* `Query` and `Mutation` both extend it. `gcTime` controls how long an unused entry is kept.
*/
var Removable = class {
	#gcTimeout;
	/**
	* Clears the pending garbage collection timeout, so the entry is no longer scheduled for removal.
	* A subclass may override this to release what it holds on to as well — `Query` also cancels any
	* in-flight fetch.
	*/
	destroy() {
		this.clearGcTimeout();
	}
	scheduleGc() {
		this.clearGcTimeout();
		if (isValidTimeout(this.gcTime)) this.#gcTimeout = timeoutManager.setTimeout(() => {
			this.optionalRemove();
		}, this.gcTime);
	}
	updateGcTime(newGcTime) {
		this.gcTime = Math.max(this.gcTime || 0, newGcTime ?? (isServer() ? Infinity : 3e5));
	}
	clearGcTimeout() {
		if (this.#gcTimeout !== void 0) {
			timeoutManager.clearTimeout(this.#gcTimeout);
			this.#gcTimeout = void 0;
		}
	}
};
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/infiniteQueryBehavior.js
function infiniteQueryBehavior(pages) {
	return { onFetch: (context, query) => {
		const options = context.options;
		const direction = context.fetchOptions?.meta?.fetchMore?.direction;
		const oldPages = context.state.data?.pages || [];
		const oldPageParams = context.state.data?.pageParams || [];
		let result = {
			pages: [],
			pageParams: []
		};
		let currentPage = 0;
		const fetchFn = async () => {
			let cancelled = false;
			const addSignalProperty = (object) => {
				addConsumeAwareSignal(object, () => context.signal, () => cancelled = true);
			};
			const queryFn = ensureQueryFn(context.options, context.fetchOptions);
			const fetchPage = async (data, param, previous) => {
				if (cancelled) return Promise.reject(context.signal.reason);
				if (param == null && data.pages.length) return Promise.resolve(data);
				const createQueryFnContext = () => {
					const queryFnContext = {
						client: context.client,
						queryKey: context.queryKey,
						pageParam: param,
						direction: previous ? "backward" : "forward",
						meta: context.options.meta
					};
					addSignalProperty(queryFnContext);
					return queryFnContext;
				};
				const queryFnContext = createQueryFnContext();
				const page = await queryFn(queryFnContext);
				const { maxPages } = context.options;
				const addTo = previous ? addToStart : addToEnd;
				return {
					pages: addTo(data.pages, page, maxPages),
					pageParams: addTo(data.pageParams, param, maxPages)
				};
			};
			if (direction && oldPages.length) {
				const previous = direction === "backward";
				const pageParamFn = previous ? getPreviousPageParam : getNextPageParam;
				const oldData = {
					pages: oldPages,
					pageParams: oldPageParams
				};
				result = await fetchPage(oldData, pageParamFn(options, oldData), previous);
			} else {
				const remainingPages = pages ?? oldPages.length;
				do {
					const param = currentPage === 0 ? oldPageParams[0] ?? options.initialPageParam : getNextPageParam(options, result);
					if (currentPage > 0 && param == null) break;
					result = await fetchPage(result, param);
					currentPage++;
				} while (currentPage < remainingPages);
			}
			return result;
		};
		if (context.options.persister) context.fetchFn = () => {
			return context.options.persister?.(fetchFn, {
				client: context.client,
				queryKey: context.queryKey,
				meta: context.options.meta,
				signal: context.signal
			}, query);
		};
		else context.fetchFn = fetchFn;
	} };
}
function getNextPageParam(options, { pages, pageParams }) {
	const lastIndex = pages.length - 1;
	return pages.length > 0 ? options.getNextPageParam(pages[lastIndex], pages, pageParams[lastIndex], pageParams) : void 0;
}
function getPreviousPageParam(options, { pages, pageParams }) {
	return pages.length > 0 ? options.getPreviousPageParam?.(pages[0], pages, pageParams[0], pageParams) : void 0;
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/query.js
/**
* Represents a single cached query. A `Query` holds the query's key, options,
* state (data/error/status), and the observers currently subscribed to it.
*
* Instances are created and managed internally by `QueryCache`; application
* code typically interacts with queries indirectly through `QueryClient` or
* a framework hook like `useQuery`. Direct access to a `Query` instance is
* possible via `queryCache.find()`/`findAll()` for inspecting cache state.
*
* @example
* ```ts
* const queryCache = queryClient.getQueryCache()
* const query = queryCache.find({ queryKey: ['posts'] })
*
* if (query) {
*   console.log(query.state.dataUpdatedAt)
* }
* ```
*/
var Query = class extends Removable {
	#queryType;
	#initialState;
	#revertState;
	#cache;
	#client;
	#retryer;
	#defaultOptions;
	#abortSignalConsumed;
	constructor(config) {
		super();
		this.#abortSignalConsumed = false;
		this.#defaultOptions = config.defaultOptions;
		this.setOptions(config.options);
		this.observers = [];
		this.#client = config.client;
		this.#cache = this.#client.getQueryCache();
		this.queryKey = config.queryKey;
		this.queryHash = config.queryHash;
		this.#initialState = getDefaultState$1(this.options);
		this.state = config.state ?? this.#initialState;
		this.scheduleGc();
	}
	/**
	* The `meta` object passed in the query's options, if any.
	*/
	get meta() {
		return this.options.meta;
	}
	/** @internal */
	get queryType() {
		return this.#queryType;
	}
	/**
	* The promise for the currently in-flight fetch, if the query is fetching.
	* `undefined` when the query is not fetching.
	*/
	get promise() {
		return this.#retryer?.promise;
	}
	/** @internal */
	setOptions(options) {
		this.options = {
			...this.#defaultOptions,
			...options
		};
		if (options?._type) this.#queryType = options._type;
		this.updateGcTime(this.options.gcTime);
		if (this.state && this.state.data === void 0) {
			const defaultState = getDefaultState$1(this.options);
			if (defaultState.data !== void 0) {
				this.setState(successState(defaultState.data, defaultState.dataUpdatedAt));
				this.#initialState = defaultState;
			}
		}
	}
	optionalRemove() {
		if (!this.observers.length && this.state.fetchStatus === "idle") this.#cache.remove(this);
	}
	/** @internal */
	setData(newData, options) {
		const data = replaceData(this.state.data, newData, this.options);
		this.#dispatch({
			data,
			type: "success",
			dataUpdatedAt: options?.updatedAt,
			manual: options?.manual
		});
		return data;
	}
	/**
	* Merges the given partial state directly into this query's state, notifying observers. Used
	* by persistence and broadcast plugins to restore a state snapshot, and by devtools to let a
	* user manually trigger a loading/error state or edit the cached data.
	*/
	setState(state) {
		this.#dispatch({
			type: "setState",
			state
		});
	}
	/**
	* Cancels the query's currently in-flight fetch, if any.
	* - Returns a promise that resolves once the cancellation has settled.
	* - If no fetch is in progress, resolves immediately.
	*
	* @example
	* ```ts
	* await query.cancel()
	* ```
	*/
	cancel(options) {
		const promise = this.#retryer?.promise;
		this.#retryer?.cancel(options);
		return promise ? promise.then(noop).catch(noop) : Promise.resolve();
	}
	/**
	* Clears the query's garbage collection timeout and silently cancels any
	* in-flight fetch. Called by `QueryCache` when the query is removed from
	* the cache.
	*
	* @see {@link Query#cancel}
	*/
	destroy() {
		super.destroy();
		this.cancel({ silent: true });
	}
	/** @internal */
	get resetState() {
		return this.#initialState;
	}
	/**
	* Resets the query back to its initial state (the state it had when it was
	* first created, e.g. any `initialData`), destroying it first to cancel any
	* in-flight fetch.
	*/
	reset() {
		this.destroy();
		this.setState(this.resetState);
	}
	/**
	* Returns `true` if the query has at least one observer for which `enabled`
	* does not resolve to `false`.
	*/
	isActive() {
		return this.observers.some((observer) => resolveQueryValue(observer.options.enabled, this) !== false);
	}
	/**
	* Returns `true` if the query is disabled, meaning it will not fetch
	* automatically.
	* - If the query has observers, it is disabled when none of them are active
	*   (see `isActive`).
	* - If the query has no observers, it is disabled when its `queryFn` is
	*   `skipToken` or it has never been fetched.
	*/
	isDisabled() {
		if (this.getObserversCount() > 0) return !this.isActive();
		return this.options.queryFn === skipToken || !this.isFetched();
	}
	/**
	* Returns `true` if the query has been fetched, i.e. it has resolved with
	* either data or an error at least once.
	*/
	isFetched() {
		return this.state.dataUpdateCount + this.state.errorUpdateCount > 0;
	}
	/**
	* Returns `true` if the query has at least one observer configured with
	* `staleTime: 'static'`, meaning it is treated as never stale.
	*/
	isStatic() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => resolveQueryValue(observer.options.staleTime, this) === "static");
		return false;
	}
	/**
	* Returns `true` if the query is stale.
	* - If the query has observers, defers to whether any observer's current
	*   result reports `isStale` (which accounts for each observer's own
	*   `staleTime` and `enabled` state).
	* - If the query has no observers, it is considered stale when it has no
	*   data or has been invalidated.
	*
	* @see {@link Query#isStaleByTime}
	* @example
	* ```ts
	* if (query.isStale()) {
	*   // refetch or otherwise treat the cached data as outdated
	* }
	* ```
	*/
	isStale() {
		if (this.getObserversCount() > 0) return this.observers.some((observer) => observer.getCurrentResult().isStale);
		return this.state.data === void 0 || this.state.isInvalidated;
	}
	/**
	* Returns `true` if the query's data is stale relative to the given
	* `staleTime` (defaults to `0`).
	* - A query with no data is always stale.
	* - `staleTime: 'static'` is never stale.
	* - An invalidated query is always stale.
	* - Otherwise, staleness is based on elapsed time since `dataUpdatedAt`.
	*
	* @see {@link Query#isStale}
	* @example
	* ```ts
	* const isStale = query.isStaleByTime(1000 * 60)
	* ```
	*/
	isStaleByTime(staleTime = 0) {
		if (this.state.data === void 0) return true;
		if (staleTime === "static") return false;
		if (this.state.isInvalidated) return true;
		return !timeUntilStale(this.state.dataUpdatedAt, staleTime);
	}
	/** @internal */
	onFocus() {
		this.observers.find((x) => x.shouldFetchOnWindowFocus())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/** @internal */
	onOnline() {
		this.observers.find((x) => x.shouldFetchOnReconnect())?.refetch({ cancelRefetch: false });
		this.#retryer?.continue();
	}
	/** @internal */
	addObserver(observer) {
		if (!this.observers.includes(observer)) {
			this.observers.push(observer);
			this.clearGcTimeout();
			this.#cache.notify({
				type: "observerAdded",
				query: this,
				observer
			});
		}
	}
	/** @internal */
	removeObserver(observer) {
		const index = this.observers.indexOf(observer);
		if (index !== -1) {
			this.observers.splice(index, 1);
			if (!this.observers.length) {
				if (this.#retryer) {
					if (this.#abortSignalConsumed || this.state.fetchStatus === "paused" && this.state.status === "pending") this.#retryer.cancel({ revert: true });
					else this.#retryer.cancelRetry();
				}
				this.scheduleGc();
			}
			this.#cache.notify({
				type: "observerRemoved",
				query: this,
				observer
			});
		}
	}
	/**
	* Returns the number of observers currently subscribed to this query.
	*
	* @example
	* ```ts
	* if (query.getObserversCount() === 0) {
	*   // no component is currently watching this query
	* }
	* ```
	*/
	getObserversCount() {
		return this.observers.length;
	}
	/**
	* Marks the query as invalidated, unless it is already invalidated. This
	* updates `state.isInvalidated` and notifies observers, but does not by
	* itself trigger a refetch.
	*
	* @example
	* ```ts
	* query.invalidate()
	* ```
	*/
	invalidate() {
		if (!this.state.isInvalidated) this.#dispatch({ type: "invalidate" });
	}
	/**
	* Fetches the query, i.e. runs its `queryFn` (through any configured
	* retryer/behavior) and updates the query's state with the result.
	* - If a fetch is already in flight, returns its promise instead of
	*   starting a new one, unless `fetchOptions.cancelRefetch` is set and the
	*   query already has data, in which case the current fetch is silently
	*   cancelled first.
	* - If `options` is passed, it replaces the query's current options
	*   before fetching.
	*/
	async fetch(options, fetchOptions) {
		if (this.state.fetchStatus !== "idle" && this.#retryer?.status() !== "rejected") {
			if (this.state.data !== void 0 && fetchOptions?.cancelRefetch) this.cancel({ silent: true });
			else if (this.#retryer) {
				this.#retryer.continueRetry();
				return this.#retryer.promise;
			}
		}
		if (options) this.setOptions(options);
		if (!this.options.queryFn) {
			const observer = this.observers.find((x) => x.options.queryFn);
			if (observer) this.setOptions(observer.options);
		}
		const abortController = new AbortController();
		const addSignalProperty = (object) => {
			Object.defineProperty(object, "signal", {
				enumerable: true,
				get: () => {
					this.#abortSignalConsumed = true;
					return abortController.signal;
				}
			});
		};
		const fetchFn = () => {
			const queryFn = ensureQueryFn(this.options, fetchOptions);
			const createQueryFnContext = () => {
				const queryFnContext = {
					client: this.#client,
					queryKey: this.queryKey,
					meta: this.meta
				};
				addSignalProperty(queryFnContext);
				return queryFnContext;
			};
			const queryFnContext = createQueryFnContext();
			this.#abortSignalConsumed = false;
			if (this.options.persister) return this.options.persister(queryFn, queryFnContext, this);
			return queryFn(queryFnContext);
		};
		const createFetchContext = () => {
			const context = {
				fetchOptions,
				options: this.options,
				queryKey: this.queryKey,
				client: this.#client,
				state: this.state,
				fetchFn
			};
			addSignalProperty(context);
			return context;
		};
		const context = createFetchContext();
		(this.#queryType === "infinite" ? infiniteQueryBehavior(this.options.pages) : this.options.behavior)?.onFetch(context, this);
		this.#revertState = this.state;
		if (this.state.fetchStatus === "idle" || this.state.fetchMeta !== context.fetchOptions?.meta) this.#dispatch({
			type: "fetch",
			meta: context.fetchOptions?.meta
		});
		const retryer = this.#retryer = createRetryer({
			initialPromise: fetchOptions?.initialPromise,
			fn: context.fetchFn,
			onCancel: (error) => {
				if (error instanceof CancelledError && error.revert) this.setState({
					...this.#revertState,
					fetchStatus: "idle"
				});
				abortController.abort();
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue: () => {
				this.#dispatch({ type: "continue" });
			},
			retry: context.options.retry,
			retryDelay: context.options.retryDelay,
			networkMode: context.options.networkMode,
			canRun: () => true
		});
		try {
			const data = await retryer.start();
			if (data === void 0) throw new Error(`${this.queryHash} data is undefined`);
			this.setData(data);
			this.#cache.config.onSuccess?.(data, this);
			this.#cache.config.onSettled?.(data, this.state.error, this);
			return data;
		} catch (error) {
			if (error instanceof CancelledError) {
				if (error.silent) return this.#retryer.promise;
				else if (error.revert) {
					if (this.state.data === void 0) throw error;
					return this.state.data;
				}
			}
			this.#dispatch({
				type: "error",
				error
			});
			this.#cache.config.onError?.(error, this);
			this.#cache.config.onSettled?.(this.state.data, error, this);
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.scheduleGc();
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					fetchFailureCount: action.failureCount,
					fetchFailureReason: action.error
				};
				case "pause": return {
					...state,
					fetchStatus: "paused"
				};
				case "continue": return {
					...state,
					fetchStatus: "fetching"
				};
				case "fetch": return {
					...state,
					...fetchState(state.data, this.options),
					fetchMeta: action.meta ?? null
				};
				case "success":
					const newState = {
						...state,
						...successState(action.data, action.dataUpdatedAt),
						dataUpdateCount: state.dataUpdateCount + 1,
						...!action.manual && {
							fetchStatus: "idle",
							fetchFailureCount: 0,
							fetchFailureReason: null
						}
					};
					this.#revertState = action.manual ? newState : void 0;
					return newState;
				case "error":
					const error = action.error;
					return {
						...state,
						error,
						errorUpdateCount: state.errorUpdateCount + 1,
						errorUpdatedAt: Date.now(),
						fetchFailureCount: state.fetchFailureCount + 1,
						fetchFailureReason: error,
						fetchStatus: "idle",
						status: "error",
						isInvalidated: true
					};
				case "invalidate": return {
					...state,
					isInvalidated: true
				};
				case "setState": return {
					...state,
					...action.state
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.observers.slice().forEach((observer) => {
				observer.onQueryUpdate();
			});
			this.#cache.notify({
				query: this,
				type: "updated",
				action
			});
		});
	}
};
function fetchState(data, options) {
	return {
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchStatus: canFetch(options.networkMode) ? "fetching" : "paused",
		...data === void 0 && {
			error: null,
			status: "pending"
		}
	};
}
function successState(data, dataUpdatedAt) {
	return {
		data,
		dataUpdatedAt: dataUpdatedAt ?? Date.now(),
		error: null,
		isInvalidated: false,
		status: "success"
	};
}
function getDefaultState$1(options) {
	const data = typeof options.initialData === "function" ? options.initialData() : options.initialData;
	const hasData = data !== void 0;
	const initialDataUpdatedAt = hasData ? typeof options.initialDataUpdatedAt === "function" ? options.initialDataUpdatedAt() : options.initialDataUpdatedAt : 0;
	return {
		data,
		dataUpdateCount: 0,
		dataUpdatedAt: hasData ? initialDataUpdatedAt ?? Date.now() : 0,
		error: null,
		errorUpdateCount: 0,
		errorUpdatedAt: 0,
		fetchFailureCount: 0,
		fetchFailureReason: null,
		fetchMeta: null,
		isInvalidated: false,
		status: hasData ? "success" : "pending",
		fetchStatus: "idle"
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/queryObserver.js
/**
* A `QueryObserver` watches a single query in the `QueryCache` and computes a
* `QueryObserverResult` from its state, recomputing and notifying subscribers
* whenever the underlying query (or the observer's options) changes. It is
* the primitive that framework adapters (e.g. `useQuery`) build their hooks
* on top of, but it can also be used directly to observe and switch between
* queries outside of any framework.
*
* @example
* ```ts
* const observer = new QueryObserver(queryClient, {
*   queryKey: ['posts'],
*   queryFn: fetchPosts,
* })
*
* const unsubscribe = observer.subscribe((result) => {
*   console.log(result.data)
* })
* ```
*/
var QueryObserver = class extends Subscribable {
	#client;
	#currentQuery = void 0;
	#currentQueryInitialState = void 0;
	#currentResult = void 0;
	#currentResultState;
	#currentResultOptions;
	#selectError;
	#selectFn;
	#selectResult;
	#lastQueryWithDefinedData;
	#staleTimeoutId;
	#refetchIntervalId;
	#currentRefetchInterval;
	#trackedProps = /* @__PURE__ */ new Set();
	constructor(client, options) {
		super();
		this.options = options;
		this.#client = client;
		this.#selectError = null;
		this.bindMethods();
		this.setOptions(options);
	}
	bindMethods() {
		this.refetch = this.refetch.bind(this);
	}
	onSubscribe() {
		if (this.listeners.size === 1) {
			this.#currentQuery.addObserver(this);
			if (shouldFetchOnMount(this.#currentQuery, this.options)) this.#executeFetch();
			else this.updateResult();
			this.#updateTimers();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.destroy();
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnReconnect` option) to refetch when the network
	* reconnects.
	*/
	shouldFetchOnReconnect() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnReconnect);
	}
	/**
	* Returns whether the observed query is currently stale and configured
	* (via the `refetchOnWindowFocus` option) to refetch when the window
	* regains focus.
	*/
	shouldFetchOnWindowFocus() {
		return shouldFetchOn(this.#currentQuery, this.options, this.options.refetchOnWindowFocus);
	}
	/**
	* Stops observing the current query: clears all listeners, cancels the
	* stale and refetch-interval timers, and removes this observer from the
	* query it was observing.
	*/
	destroy() {
		this.listeners = /* @__PURE__ */ new Set();
		this.#clearStaleTimeout();
		this.#clearRefetchInterval();
		this.#currentQuery.removeObserver(this);
	}
	/**
	* Updates the observer's options. This will re-resolve the query being
	* observed (switching to a different query if the `queryKey` changed),
	* trigger a fetch if the new options require one and the observer has
	* subscribers, recompute the current result, and reschedule the stale and
	* refetch-interval timers as needed.
	*
	* @example
	* ```ts
	* observer.setOptions({ queryKey: ['posts', 1], queryFn: () => fetchPost(1) })
	* // later: switch to a different query, reusing the same observer
	* observer.setOptions({ queryKey: ['posts', 2], queryFn: () => fetchPost(2) })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		const prevQuery = this.#currentQuery;
		this.options = this.#client.defaultQueryOptions(options);
		if (this.options.enabled !== void 0 && typeof this.options.enabled !== "boolean" && typeof this.options.enabled !== "function" && typeof resolveQueryValue(this.options.enabled, this.#currentQuery) !== "boolean") throw new Error("Expected enabled to be a boolean or a callback that returns a boolean");
		this.#updateQuery();
		this.#currentQuery.setOptions(this.options);
		if (prevOptions._defaulted && !shallowEqualObjects(this.options, prevOptions)) this.#client.getQueryCache().notify({
			type: "observerOptionsUpdated",
			query: this.#currentQuery,
			observer: this
		});
		const mounted = this.hasListeners();
		if (mounted && shouldFetchOptionally(this.#currentQuery, prevQuery, this.options, prevOptions)) this.#executeFetch();
		this.updateResult();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || resolveQueryValue(this.options.staleTime, this.#currentQuery) !== resolveQueryValue(prevOptions.staleTime, this.#currentQuery))) this.#updateStaleTimeout();
		const nextRefetchInterval = this.#computeRefetchInterval();
		if (mounted && (this.#currentQuery !== prevQuery || resolveQueryValue(this.options.enabled, this.#currentQuery) !== resolveQueryValue(prevOptions.enabled, this.#currentQuery) || nextRefetchInterval !== this.#currentRefetchInterval)) this.#updateRefetchInterval(nextRefetchInterval);
	}
	/**
	* Computes the result the observer would produce for the given (already-defaulted) options
	* right now, building the underlying `Query` if it doesn't exist yet, without waiting for a
	* subscription callback. Called by framework adapters on every render (e.g. `useQuery`) so the
	* returned value is available synchronously, ahead of `setOptions` triggering an actual fetch.
	*/
	getOptimisticResult(options) {
		const query = this.#client.getQueryCache().build(this.#client, options);
		const result = this.createResult(query, options);
		if (!shallowEqualObjects(this.getCurrentResult(), result)) {
			this.#currentResult = result;
			this.#currentResultOptions = this.options;
			this.#currentResultState = this.#currentQuery.state;
		}
		return result;
	}
	/**
	* Returns the most recently computed `QueryObserverResult` for the
	* observed query. This is a point-in-time read; to be notified of updates
	* as they happen, subscribe to the observer instead (its inherited
	* `subscribe` method).
	*
	* @example
	* ```ts
	* const result = observer.getCurrentResult()
	* console.log(result.status, result.data)
	* ```
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Wraps a `QueryObserverResult` in a `Proxy` that records which properties are read, via
	* {@link QueryObserver#trackProp} (and an optional `onPropTracked` callback). Used by framework
	* adapters when `notifyOnChangeProps` is not set, to implement its default "only re-render on
	* properties you actually read" behavior.
	*/
	trackResult(result, onPropTracked) {
		return new Proxy(result, { get: (target, key) => {
			this.trackProp(key);
			onPropTracked?.(key);
			return Reflect.get(target, key);
		} });
	}
	/**
	* Records that the given `QueryObserverResult` property was read, so a subsequent update only
	* notifies this observer if a tracked property actually changed. Normally called indirectly via
	* {@link QueryObserver#trackResult}'s proxy; exposed directly for adapters that track property
	* access themselves (e.g. through their own reactivity system) instead of via the proxy.
	*/
	trackProp(key) {
		this.#trackedProps.add(key);
	}
	/**
	* Returns the `Query` instance this observer is currently observing.
	*/
	getCurrentQuery() {
		return this.#currentQuery;
	}
	/**
	* Refetches the observed query and returns a promise that resolves with
	* the resulting `QueryObserverResult`.
	*
	* @example
	* ```ts
	* const result = await observer.refetch({ cancelRefetch: false })
	* console.log(result.data)
	* ```
	*/
	refetch({ ...options } = {}) {
		return this.fetch({ ...options });
	}
	/**
	* Fetches a query defined by the given options without affecting this
	* observer's own tracked query or result, and returns a promise that
	* resolves with the `QueryObserverResult` for that fetch. This is useful
	* for prefetching data that another observer (e.g. a query about to be
	* navigated to) will need, ahead of time.
	*
	* @example
	* ```ts
	* const result = await observer.fetchOptimistic({
	*   queryKey: ['posts', 2],
	*   queryFn: () => fetchPost(2),
	* })
	* console.log(result.data)
	* ```
	*/
	fetchOptimistic(options) {
		const defaultedOptions = this.#client.defaultQueryOptions(options);
		const query = this.#client.getQueryCache().build(this.#client, defaultedOptions);
		let unsubscribe = () => {};
		let resolveEarly;
		const cachePromise = new Promise((resolve) => {
			resolveEarly = resolve;
			unsubscribe = this.#client.getQueryCache().subscribe((event) => {
				if (event.type === "updated" && event.query.queryHash === query.queryHash && query.state.data !== void 0) {
					unsubscribe();
					resolve(this.createResult(query, defaultedOptions));
				}
			});
		});
		return Promise.race([query.fetch().then(() => {
			const result = this.createResult(query, defaultedOptions);
			resolveEarly?.(result);
			return result;
		}).finally(() => {
			unsubscribe();
		}), cachePromise]);
	}
	fetch(fetchOptions) {
		return this.#executeFetch({
			...fetchOptions,
			cancelRefetch: fetchOptions.cancelRefetch ?? true
		}).then(() => {
			this.updateResult();
			return this.#currentResult;
		});
	}
	#executeFetch(fetchOptions) {
		this.#updateQuery();
		let promise = this.#currentQuery.fetch(this.options, fetchOptions);
		if (!fetchOptions?.throwOnError) promise = promise.catch(noop);
		return promise;
	}
	#shouldScheduleTimer(timeout) {
		return !isServer() && resolveQueryValue(this.options.enabled, this.#currentQuery) !== false && isValidTimeout(timeout);
	}
	#updateStaleTimeout() {
		this.#clearStaleTimeout();
		const staleTime = resolveQueryValue(this.options.staleTime, this.#currentQuery);
		if (this.#currentResult.isStale || !this.#shouldScheduleTimer(staleTime)) return;
		const timeout = timeUntilStale(this.#currentResult.dataUpdatedAt, staleTime) + 1;
		this.#staleTimeoutId = timeoutManager.setTimeout(() => {
			if (!this.#currentResult.isStale) this.updateResult();
		}, timeout);
	}
	#computeRefetchInterval() {
		return resolveQueryValue(this.options.refetchInterval, this.#currentQuery) ?? false;
	}
	#updateRefetchInterval(nextInterval) {
		this.#clearRefetchInterval();
		this.#currentRefetchInterval = nextInterval;
		if (this.#currentRefetchInterval === 0 || !this.#shouldScheduleTimer(this.#currentRefetchInterval)) return;
		this.#refetchIntervalId = timeoutManager.setInterval(() => {
			if (this.options.refetchIntervalInBackground || focusManager.isFocused()) this.#executeFetch();
		}, this.#currentRefetchInterval);
	}
	#updateTimers() {
		this.#updateStaleTimeout();
		this.#updateRefetchInterval(this.#computeRefetchInterval());
	}
	#clearStaleTimeout() {
		if (this.#staleTimeoutId !== void 0) {
			timeoutManager.clearTimeout(this.#staleTimeoutId);
			this.#staleTimeoutId = void 0;
		}
	}
	#clearRefetchInterval() {
		if (this.#refetchIntervalId !== void 0) {
			timeoutManager.clearInterval(this.#refetchIntervalId);
			this.#refetchIntervalId = void 0;
		}
	}
	createResult(query, options) {
		const prevQuery = this.#currentQuery;
		const prevOptions = this.options;
		const prevResult = this.#currentResult;
		const prevResultState = this.#currentResultState;
		const prevResultOptions = this.#currentResultOptions;
		const queryInitialState = query !== prevQuery ? query.state : this.#currentQueryInitialState;
		const { state } = query;
		let newState = { ...state };
		let isPlaceholderData = false;
		let data;
		if (options._optimisticResults) {
			const mounted = this.hasListeners();
			const fetchOnMount = !mounted && shouldFetchOnMount(query, options);
			const fetchOptionally = mounted && shouldFetchOptionally(query, prevQuery, options, prevOptions);
			if (fetchOnMount || fetchOptionally) newState = {
				...newState,
				...fetchState(state.data, query.options)
			};
			if (options._optimisticResults === "isRestoring") newState.fetchStatus = "idle";
		}
		let { error, errorUpdatedAt, status } = newState;
		data = newState.data;
		let skipSelect = false;
		if (options.placeholderData !== void 0 && data === void 0 && status === "pending") {
			let placeholderData;
			if (prevResult?.isPlaceholderData && options.placeholderData === prevResultOptions?.placeholderData) {
				placeholderData = prevResult.data;
				skipSelect = true;
			} else placeholderData = typeof options.placeholderData === "function" ? options.placeholderData(this.#lastQueryWithDefinedData?.state.data, this.#lastQueryWithDefinedData) : options.placeholderData;
			if (placeholderData !== void 0) {
				status = "success";
				data = replaceData(prevResult?.data, placeholderData, options);
				isPlaceholderData = true;
			}
		}
		if (options.select && data !== void 0 && !skipSelect) {
			if (prevResult && data === prevResultState?.data && options.select === this.#selectFn) data = this.#selectResult;
			else try {
				this.#selectFn = options.select;
				data = options.select(data);
				data = replaceData(prevResult?.data, data, options);
				this.#selectResult = data;
				this.#selectError = null;
			} catch (selectError) {
				this.#selectError = selectError;
			}
		} else if (data === void 0) this.#selectError = null;
		if (this.#selectError) {
			error = this.#selectError;
			data = this.#selectResult;
			errorUpdatedAt = Date.now();
			status = "error";
			isPlaceholderData = false;
		}
		const isFetching = newState.fetchStatus === "fetching";
		const isPending = status === "pending";
		const isError = status === "error";
		const isLoading = isPending && isFetching;
		const hasData = data !== void 0;
		return {
			status,
			fetchStatus: newState.fetchStatus,
			isPending,
			isSuccess: status === "success",
			isError,
			isInitialLoading: isLoading,
			isLoading,
			data,
			dataUpdatedAt: newState.dataUpdatedAt,
			error,
			errorUpdatedAt,
			failureCount: newState.fetchFailureCount,
			failureReason: newState.fetchFailureReason,
			errorUpdateCount: newState.errorUpdateCount,
			isFetched: query.isFetched(),
			isFetchedAfterMount: newState.dataUpdateCount > queryInitialState.dataUpdateCount || newState.errorUpdateCount > queryInitialState.errorUpdateCount,
			isFetching,
			isRefetching: isFetching && !isPending,
			isLoadingError: isError && !hasData,
			isPaused: newState.fetchStatus === "paused",
			isPlaceholderData,
			isRefetchError: isError && hasData,
			isStale: isStale(query, options),
			refetch: this.refetch,
			isEnabled: resolveQueryValue(options.enabled, query) !== false
		};
	}
	/**
	* Recomputes and stores the current result from the current query/options, notifying listeners
	* if it changed. Framework adapters call this right after subscribing to make sure no query
	* update was missed in the gap between creating the observer and subscribing to it.
	*/
	updateResult() {
		const prevResult = this.#currentResult;
		const nextResult = this.createResult(this.#currentQuery, this.options);
		this.#currentResultState = this.#currentQuery.state;
		this.#currentResultOptions = this.options;
		if (this.#currentResultState.data !== void 0) this.#lastQueryWithDefinedData = this.#currentQuery;
		if (shallowEqualObjects(nextResult, prevResult)) return;
		this.#currentResult = nextResult;
		const shouldNotifyListeners = () => {
			if (!prevResult) return true;
			const { notifyOnChangeProps } = this.options;
			const notifyOnChangePropsValue = typeof notifyOnChangeProps === "function" ? notifyOnChangeProps() : notifyOnChangeProps;
			if (notifyOnChangePropsValue === "all" || !notifyOnChangePropsValue && !this.#trackedProps.size) return true;
			const includedProps = new Set(notifyOnChangePropsValue ?? this.#trackedProps);
			if (this.options.throwOnError) includedProps.add("error");
			return Object.keys(this.#currentResult).some((key) => {
				const typedKey = key;
				return this.#currentResult[typedKey] !== prevResult[typedKey] && includedProps.has(typedKey);
			});
		};
		const notifyListeners = shouldNotifyListeners();
		notifyManager.batch(() => {
			if (notifyListeners) this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
			this.#client.getQueryCache().notify({
				query: this.#currentQuery,
				type: "observerResultsUpdated"
			});
		});
	}
	#updateQuery() {
		const query = this.#client.getQueryCache().build(this.#client, this.options);
		if (query === this.#currentQuery) return;
		const prevQuery = this.#currentQuery;
		this.#currentQuery = query;
		this.#currentQueryInitialState = query.state;
		if (this.hasListeners()) {
			prevQuery?.removeObserver(this);
			query.addObserver(this);
		}
	}
	/** @internal */
	onQueryUpdate() {
		this.updateResult();
		if (this.hasListeners()) this.#updateTimers();
	}
};
function shouldLoadOnMount(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.state.data === void 0 && !(query.state.status === "error" && resolveQueryValue(options.retryOnMount, query) === false);
}
function shouldFetchOnMount(query, options) {
	return shouldLoadOnMount(query, options) || query.state.data !== void 0 && shouldFetchOn(query, options, options.refetchOnMount);
}
function shouldFetchOn(query, options, field) {
	if (resolveQueryValue(options.enabled, query) !== false && resolveQueryValue(options.staleTime, query) !== "static") {
		const value = resolveQueryValue(field, query);
		return value === "always" || value !== false && isStale(query, options);
	}
	return false;
}
function shouldFetchOptionally(query, prevQuery, options, prevOptions) {
	return (query !== prevQuery || resolveQueryValue(prevOptions.enabled, query) === false) && (!options.suspense || query.state.status !== "error") && isStale(query, options);
}
function isStale(query, options) {
	return resolveQueryValue(options.enabled, query) !== false && query.isStaleByTime(resolveQueryValue(options.staleTime, query));
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutation.js
/**
* Represents a single mutation attempt. A `Mutation` holds the mutation's
* options, state (data/error/status), and the `MutationObserver`s currently
* subscribed to it.
*
* Instances are created and managed internally by `MutationCache`; application
* code typically interacts with mutations indirectly through `QueryClient` or
* a framework hook like `useMutation`. Direct access to a `Mutation` instance
* is possible via `mutationCache.find()`/`getAll()` for inspecting cache state.
*
* @example
* ```ts
* const mutationCache = queryClient.getMutationCache()
*
* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
* ```
*/
var Mutation = class extends Removable {
	#client;
	#observers;
	#mutationCache;
	#retryer;
	constructor(config) {
		super();
		this.#client = config.client;
		this.mutationId = config.mutationId;
		this.#mutationCache = config.mutationCache;
		this.#observers = [];
		this.state = config.state || getDefaultState();
		this.setOptions(config.options);
		this.scheduleGc();
	}
	/** @internal */
	setOptions(options) {
		this.options = options;
		this.updateGcTime(this.options.gcTime);
	}
	/**
	* The `meta` object passed in the mutation's options, if any.
	*/
	get meta() {
		return this.options.meta;
	}
	/** @internal */
	addObserver(observer) {
		if (!this.#observers.includes(observer)) {
			this.#observers.push(observer);
			this.clearGcTimeout();
			this.#mutationCache.notify({
				type: "observerAdded",
				mutation: this,
				observer
			});
		}
	}
	/** @internal */
	removeObserver(observer) {
		this.#observers = this.#observers.filter((x) => x !== observer);
		this.scheduleGc();
		this.#mutationCache.notify({
			type: "observerRemoved",
			mutation: this,
			observer
		});
	}
	optionalRemove() {
		if (!this.#observers.length) {
			if (this.state.status === "pending") this.scheduleGc();
			else this.#mutationCache.remove(this);
		}
	}
	/**
	* Resumes a mutation that is currently paused or was restored from a
	* dehydrated, still-`pending` state.
	*
	* - If this mutation has an active retryer (it paused mid-attempt, e.g. due
	*   to the network mode or scope-based queuing), its retryer is resumed.
	* - Otherwise, if the mutation's status is still `pending` (e.g. it was
	*   dehydrated while an attempt was in flight and never got a retryer in
	*   this instance), `execute` is called again with the last known variables.
	* - Otherwise the mutation has already settled and this resolves immediately
	*   without running anything again.
	*
	* @example
	* ```ts
	* // typically driven by reconnect handling, e.g. queryClient.resumePausedMutations()
	* const mutation = mutationCache.find({ mutationKey: ['addPost'] })
	* await mutation?.continue()
	* ```
	*
	* @see {@link Mutation#execute}
	*/
	continue() {
		return this.#retryer?.continue() ?? (this.state.status === "pending" ? this.execute(this.state.variables) : Promise.resolve());
	}
	/**
	* Runs the mutation function for the given variables through a retryer, and
	* drives the mutation's state and lifecycle callbacks through to settlement.
	*
	* If this mutation's state is already `pending` when `execute` is called
	* (i.e. it was restored, still in-flight, from a dehydrated state), the
	* `onMutate` step is skipped and a `continue` action is dispatched to
	* unpause it; otherwise a `pending` action is dispatched first, then the
	* mutation cache's `onMutate` and the mutation's own `onMutate` option are
	* awaited in that order, and the resulting context is stored.
	*
	* The mutation function is then run (subject to `retry`/`retryDelay`/
	* `networkMode`, and to the mutation cache's scope-based serialization).
	* On success, the cache's `onSuccess`/`onSettled` callbacks run before the
	* mutation's own `onSuccess`/`onSettled` options, a `success` action is
	* dispatched, and the resolved data is returned. On failure, the same
	* cache-then-option ordering is used for `onError`/`onSettled`, but each of
	* those four callbacks is individually caught so that a throwing callback
	* cannot mask the original error; an `error` action is then dispatched and
	* the original error is re-thrown.
	*
	* @example
	* ```ts
	* // Called internally by `MutationObserver.mutate` and `Mutation.continue` —
	* // applications normally trigger mutations through those, not this method.
	* const data = await mutation.execute(variables)
	* ```
	*
	* @see {@link Mutation#continue}
	*/
	async execute(variables) {
		const onContinue = () => {
			this.#dispatch({ type: "continue" });
		};
		const mutationFnContext = {
			client: this.#client,
			meta: this.options.meta,
			mutationKey: this.options.mutationKey
		};
		const retryer = this.#retryer = createRetryer({
			fn: () => {
				if (!this.options.mutationFn) return Promise.reject(/* @__PURE__ */ new Error("No mutationFn found"));
				return this.options.mutationFn(variables, mutationFnContext);
			},
			onFail: (failureCount, error) => {
				this.#dispatch({
					type: "failed",
					failureCount,
					error
				});
			},
			onPause: () => {
				this.#dispatch({ type: "pause" });
			},
			onContinue,
			retry: this.options.retry ?? 0,
			retryDelay: this.options.retryDelay,
			networkMode: this.options.networkMode,
			canRun: () => this.#mutationCache.canRun(this)
		});
		const restored = this.state.status === "pending";
		const isPaused = !retryer.canStart();
		try {
			if (restored) onContinue();
			else {
				this.#dispatch({
					type: "pending",
					variables,
					isPaused
				});
				if (this.#mutationCache.config.onMutate) await this.#mutationCache.config.onMutate(variables, this, mutationFnContext);
				const context = await this.options.onMutate?.(variables, mutationFnContext);
				if (context !== this.state.context) this.#dispatch({
					type: "pending",
					context,
					variables,
					isPaused
				});
			}
			const data = await retryer.start();
			await this.#mutationCache.config.onSuccess?.(data, variables, this.state.context, this, mutationFnContext);
			await this.options.onSuccess?.(data, variables, this.state.context, mutationFnContext);
			await this.#mutationCache.config.onSettled?.(data, null, this.state.variables, this.state.context, this, mutationFnContext);
			await this.options.onSettled?.(data, null, variables, this.state.context, mutationFnContext);
			this.#dispatch({
				type: "success",
				data
			});
			return data;
		} catch (error) {
			try {
				await this.#mutationCache.config.onError?.(error, variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onError?.(error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.#mutationCache.config.onSettled?.(void 0, error, this.state.variables, this.state.context, this, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			try {
				await this.options.onSettled?.(void 0, error, variables, this.state.context, mutationFnContext);
			} catch (e) {
				Promise.reject(e);
			}
			this.#dispatch({
				type: "error",
				error
			});
			throw error;
		} finally {
			if (this.#retryer === retryer) this.#retryer = void 0;
			this.#mutationCache.runNext(this);
		}
	}
	#dispatch(action) {
		const reducer = (state) => {
			switch (action.type) {
				case "failed": return {
					...state,
					failureCount: action.failureCount,
					failureReason: action.error
				};
				case "pause": return {
					...state,
					isPaused: true
				};
				case "continue": return {
					...state,
					isPaused: false
				};
				case "pending": return {
					...state,
					context: action.context,
					data: void 0,
					failureCount: 0,
					failureReason: null,
					error: null,
					isPaused: action.isPaused,
					status: "pending",
					variables: action.variables,
					submittedAt: Date.now()
				};
				case "success": return {
					...state,
					data: action.data,
					failureCount: 0,
					failureReason: null,
					error: null,
					status: "success",
					isPaused: false
				};
				case "error": return {
					...state,
					data: void 0,
					error: action.error,
					failureCount: state.failureCount + 1,
					failureReason: action.error,
					isPaused: false,
					status: "error"
				};
			}
		};
		this.state = reducer(this.state);
		notifyManager.batch(() => {
			this.#observers.forEach((observer) => {
				observer.onMutationUpdate(action);
			});
			this.#mutationCache.notify({
				mutation: this,
				type: "updated",
				action
			});
		});
	}
};
function getDefaultState() {
	return {
		context: void 0,
		data: void 0,
		error: null,
		failureCount: 0,
		failureReason: null,
		isPaused: false,
		status: "idle",
		variables: void 0,
		submittedAt: 0
	};
}
//#endregion
//#region node_modules/@tanstack/query-core/build/modern/mutationObserver.js
/**
* Observes a single mutation and derives a `MutationObserverResult` from it.
* A framework hook like `useMutation` creates one `MutationObserver` per hook
* call, keeps it stable across re-renders, calls `setOptions` when the options
* passed to the hook change, subscribes to it to re-render on updates, and
* reads `getCurrentResult()` for the value to return. Calling `mutate()`
* builds a new underlying `Mutation` in the `MutationCache` and executes it.
*
* @example
* ```ts
* const observer = new MutationObserver(queryClient, {
*   mutationFn: (variables: { title: string }) => addPost(variables),
* })
* ```
*/
var MutationObserver$1 = class extends Subscribable {
	#client;
	#currentResult = void 0;
	#currentMutation;
	#mutateOptions;
	constructor(client, options) {
		super();
		this.#client = client;
		this.setOptions(options);
		this.bindMethods();
		this.#updateResult();
	}
	bindMethods() {
		this.mutate = this.mutate.bind(this);
		this.reset = this.reset.bind(this);
	}
	/**
	* Updates the observer's options.
	*
	* If the new `mutationKey` differs from the previous one (and both were
	* defined), the observer is reset, detaching it from the mutation it was
	* observing. Otherwise, if the currently observed mutation is still
	* `pending`, its options are updated in place as well.
	*
	* @example
	* ```ts
	* observer.setOptions({
	*   mutationFn: (variables: { title: string }) => addPost(variables),
	*   onSuccess: (data) => console.log(data),
	* })
	* ```
	*/
	setOptions(options) {
		const prevOptions = this.options;
		this.options = this.#client.defaultMutationOptions(options);
		if (!shallowEqualObjects(this.options, prevOptions)) this.#client.getMutationCache().notify({
			type: "observerOptionsUpdated",
			mutation: this.#currentMutation,
			observer: this
		});
		if (prevOptions?.mutationKey && this.options.mutationKey && hashKey(prevOptions.mutationKey) !== hashKey(this.options.mutationKey)) this.reset();
		else if (this.#currentMutation?.state.status === "pending") this.#currentMutation.setOptions(this.options);
	}
	onSubscribe() {
		if (this.listeners.size === 1 && this.#currentMutation) {
			this.#currentMutation.addObserver(this);
			this.#updateResult();
		}
	}
	onUnsubscribe() {
		if (!this.hasListeners()) this.#currentMutation?.removeObserver(this);
	}
	/** @internal */
	onMutationUpdate(action) {
		this.#updateResult();
		this.#notify(action);
	}
	/**
	* Returns the observer's current result, derived from the observed
	* mutation's state (or the default, `idle` state if no mutation has been
	* built yet, e.g. before the first `mutate()` call or after `reset()`).
	*/
	getCurrentResult() {
		return this.#currentResult;
	}
	/**
	* Detaches the observer from the mutation it is currently observing (if
	* any) and resets the observed result back to its default, `idle` state.
	*
	* This does not cancel an in-flight mutation; the mutation itself keeps
	* running to completion and its own callbacks still fire, but this
	* observer stops reflecting its state and a subsequent `mutate()` call
	* will build a brand new mutation.
	*
	* @example
	* ```ts
	* observer.reset()
	* ```
	*
	* @see {@link MutationObserver#mutate}
	*/
	reset() {
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = void 0;
		this.#updateResult();
		this.#notify();
	}
	/**
	* Builds a new `Mutation` in the `MutationCache` using the observer's
	* current options, detaches this observer from any previously observed
	* mutation, attaches it to the new one, and executes it with the given
	* variables.
	*
	* The optional per-call `options` (`onSuccess`/`onError`/`onSettled`) are
	* invoked once the mutation settles, in addition to any callbacks defined
	* on the observer's own options.
	*
	* @example
	* ```ts
	* await observer.mutate(
	*   { title: 'New post' },
	*   { onSuccess: (data) => console.log(data) },
	* )
	* ```
	*/
	mutate(variables, options) {
		this.#mutateOptions = options;
		this.#currentMutation?.removeObserver(this);
		this.#currentMutation = this.#client.getMutationCache().build(this.#client, this.options);
		this.#currentMutation.addObserver(this);
		return this.#currentMutation.execute(variables);
	}
	#updateResult() {
		const state = this.#currentMutation?.state ?? getDefaultState();
		this.#currentResult = {
			...state,
			isPending: state.status === "pending",
			isSuccess: state.status === "success",
			isError: state.status === "error",
			isIdle: state.status === "idle",
			mutate: this.mutate,
			reset: this.reset
		};
	}
	#notify(action) {
		notifyManager.batch(() => {
			if (this.#mutateOptions && this.hasListeners()) {
				const variables = this.#currentResult.variables;
				const onMutateResult = this.#currentResult.context;
				const context = {
					client: this.#client,
					meta: this.options.meta,
					mutationKey: this.options.mutationKey
				};
				if (action?.type === "success") {
					try {
						this.#mutateOptions.onSuccess?.(action.data, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(action.data, null, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				} else if (action?.type === "error") {
					try {
						this.#mutateOptions.onError?.(action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
					try {
						this.#mutateOptions.onSettled?.(void 0, action.error, variables, onMutateResult, context);
					} catch (e) {
						Promise.reject(e);
					}
				}
			}
			this.listeners.forEach((listener) => {
				listener(this.#currentResult);
			});
		});
	}
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/IsRestoringProvider.js
var IsRestoringContext = import_react.createContext(false);
/**
* If you are using `PersistQueryClientProvider`, you can also use the `useIsRestoring` hook alongside it to
* check if a restore is currently in progress. `useQuery` and friends also check this internally to avoid
* race conditions between the restore and mounting queries.
*
* @returns `true` while a persisted client is being restored, `false` otherwise.
*/
var useIsRestoring = () => import_react.useContext(IsRestoringContext);
IsRestoringContext.Provider;
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/QueryErrorResetBoundary.js
/**
* Resets any query errors within the boundary, so queries know they can try again.
*/
function createValue() {
	let isReset = false;
	return {
		/**
		* Clears the reset state, so queries know not to try again until the boundary is reset again.
		*/
		clearReset: () => {
			isReset = false;
		},
		/**
		* Resets any query errors within the boundary, so queries know they can try again.
		*/
		reset: () => {
			isReset = true;
		},
		/**
		* Returns whether the boundary has been reset and not yet cleared.
		*/
		isReset: () => {
			return isReset;
		}
	};
}
var QueryErrorResetBoundaryContext = import_react.createContext(createValue());
/**
* This hook will reset any query errors within the closest `QueryErrorResetBoundary`. If there is no boundary
* defined it will reset them globally.
*
* @returns The boundary's {@link QueryErrorResetBoundaryValue}.
*
* @example
* ```tsx
* import { ErrorBoundary } from 'react-error-boundary'
* import { useQueryErrorResetBoundary } from '@tanstack/react-query'
*
* function App({ children }: { children: React.ReactNode }) {
*   const { reset } = useQueryErrorResetBoundary()
*
*   return (
*     <ErrorBoundary
*       onReset={reset}
*       fallbackRender={({ resetErrorBoundary }) => (
*         <div>
*           There was an error!
*           <button onClick={() => resetErrorBoundary()}>Try again</button>
*         </div>
*       )}
*     >
*       {children}
*     </ErrorBoundary>
*   )
* }
* ```
*/
var useQueryErrorResetBoundary = () => import_react.useContext(QueryErrorResetBoundaryContext);
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/errorBoundaryUtils.js
var ensurePreventErrorBoundaryRetry = (options, errorResetBoundary, query) => {
	const throwOnError = query?.state.error && typeof options.throwOnError === "function" ? shouldThrowError(options.throwOnError, [query.state.error, query]) : options.throwOnError;
	if (options.suspense || throwOnError) {
		if (!errorResetBoundary.isReset()) options.retryOnMount = false;
	}
};
var useClearResetErrorBoundary = (errorResetBoundary) => {
	import_react.useEffect(() => {
		errorResetBoundary.clearReset();
	}, [errorResetBoundary]);
};
var getHasError = ({ result, errorResetBoundary, throwOnError, query, suspense }) => {
	return result.isError && !errorResetBoundary.isReset() && !result.isFetching && query && (suspense && result.data === void 0 || shouldThrowError(throwOnError, [result.error, query]));
};
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/suspense.js
var ensureSuspenseTimers = (defaultedOptions) => {
	if (defaultedOptions.suspense) {
		const MIN_SUSPENSE_TIME_MS = 1e3;
		const clamp = (value) => value === "static" ? value : Math.max(value ?? MIN_SUSPENSE_TIME_MS, MIN_SUSPENSE_TIME_MS);
		const originalStaleTime = defaultedOptions.staleTime;
		defaultedOptions.staleTime = typeof originalStaleTime === "function" ? (...args) => clamp(originalStaleTime(...args)) : clamp(originalStaleTime);
		if (typeof defaultedOptions.gcTime === "number") defaultedOptions.gcTime = Math.max(defaultedOptions.gcTime, MIN_SUSPENSE_TIME_MS);
	}
};
var shouldSuspend = (defaultedOptions, result) => defaultedOptions?.suspense && result.isPending;
var fetchOptimistic = (defaultedOptions, observer, errorResetBoundary) => observer.fetchOptimistic(defaultedOptions).catch(() => {
	errorResetBoundary.clearReset();
});
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useBaseQuery.js
function useBaseQuery(options, Observer, queryClient) {
	const isRestoring = useIsRestoring();
	const errorResetBoundary = useQueryErrorResetBoundary();
	const client = useQueryClient(queryClient);
	const defaultedOptions = client.defaultQueryOptions(options);
	const query = client.getQueryCache().get(defaultedOptions.queryHash);
	const subscribed = options.subscribed !== false;
	defaultedOptions._optimisticResults = isRestoring ? "isRestoring" : subscribed ? "optimistic" : void 0;
	ensureSuspenseTimers(defaultedOptions);
	ensurePreventErrorBoundaryRetry(defaultedOptions, errorResetBoundary, query);
	useClearResetErrorBoundary(errorResetBoundary);
	const [observer] = import_react.useState(() => new Observer(client, defaultedOptions));
	const result = observer.getOptimisticResult(defaultedOptions);
	const shouldSubscribe = !isRestoring && subscribed;
	import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => {
		const unsubscribe = shouldSubscribe ? observer.subscribe(notifyManager.batchCalls(onStoreChange)) : noop;
		observer.updateResult();
		return unsubscribe;
	}, [observer, shouldSubscribe]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	import_react.useEffect(() => {
		observer.setOptions(defaultedOptions);
	}, [defaultedOptions, observer]);
	if (shouldSuspend(defaultedOptions, result)) throw fetchOptimistic(defaultedOptions, observer, errorResetBoundary);
	if (getHasError({
		result,
		errorResetBoundary,
		throwOnError: defaultedOptions.throwOnError,
		query,
		suspense: defaultedOptions.suspense
	})) throw result.error;
	return !defaultedOptions.notifyOnChangeProps ? observer.trackResult(result) : result;
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useQuery.js
function useQuery(options, queryClient) {
	return useBaseQuery(options, QueryObserver, queryClient);
}
//#endregion
//#region node_modules/@tanstack/react-query/build/modern/useMutation.js
/**
* Unlike queries, mutations are typically used to create/update/delete data or perform server side-effects.
* `useMutation` is the hook for that.
*
* @see {@link mutationOptions} to share these options across multiple `useMutation` call sites, or to look
* the mutation up elsewhere via its `mutationKey` (e.g. with `useMutationState`).
* @param options - The {@link UseMutationOptions} to use — everything you can pass to `useMutation`.
* @param queryClient - Use this to use a custom `QueryClient`. Otherwise, the one from the nearest context will
* be used.
* @returns `mutate`/`mutateAsync` also accept per-call `onSuccess`/`onError`/`onSettled` callbacks as a second
* argument, useful for triggering call-site side effects (e.g. navigation) without coupling them to the shared
* mutation definition. Hook-level callbacks (passed to `options`) fire for every mutation; per-call callbacks
* fire only for the latest call you've made, and only while the component is still mounted — unmounting before
* the mutation settles removes the subscription and prevents them from firing.
*
* @example
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <button
*       onClick={() =>
*         addMutation.mutate('Item', {
*           onError: (error) => console.error('Failed to add item:', error),
*         })
*       }
*     >
*       Add
*     </button>
*   )
* }
* ```
*
* @example
* Rendering the mutation's own state, rather than just firing it off:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   return (
*     <div>
*       {addMutation.isPending ? (
*         'Adding todo...'
*       ) : (
*         <>
*           {addMutation.isError ? (
*             <div>An error occurred: {addMutation.error.message}</div>
*           ) : null}
*           <button onClick={() => addMutation.mutate('Item')}>Add</button>
*         </>
*       )}
*     </div>
*   )
* }
* ```
*
* @example
* Optimistic update via `onMutate`, rolling back on `onError`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodo() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onMutate: async (newTodo) => {
*       await queryClient.cancelQueries({ queryKey: ['todos'] })
*       const previousTodos = queryClient.getQueryData<Array<string>>(['todos'])
*
*       queryClient.setQueryData<Array<string>>(['todos'], (old) => [
*         ...(old ?? []),
*         newTodo,
*       ])
*
*       // Passed to `onError` as `onMutateResult` if the mutation fails.
*       return { previousTodos }
*     },
*     onError: (_err, _newTodo, onMutateResult) => {
*       queryClient.setQueryData(['todos'], onMutateResult?.previousTodos)
*     },
*     onSettled: () => {
*       queryClient.invalidateQueries({ queryKey: ['todos'] })
*     },
*   })
*
*   return (
*     <button onClick={() => addMutation.mutate('Item')}>Add</button>
*   )
* }
* ```
*
* @example
* Callbacks passed per call to `mutate` only fire for the last call — `mutateAsync` gives you a
* promise per call instead, so you can wait for all of them when they succeed:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     try {
*       await Promise.all(todos.map((todo) => addMutation.mutateAsync(todo)))
*     } catch (error) {
*       console.error('Failed to add todos:', error)
*     }
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*
* @example
* If some of the mutations above can fail independently of the others, and you want to know which ones
* did — rather than losing that information the moment the first one rejects — swap `Promise.all` for
* `Promise.allSettled`:
* ```tsx
* import { useMutation, useQueryClient } from '@tanstack/react-query'
*
* function AddTodos() {
*   const queryClient = useQueryClient()
*
*   const addMutation = useMutation({
*     mutationFn: addTodo,
*     onSuccess: () => queryClient.invalidateQueries({ queryKey: ['todos'] }),
*   })
*
*   async function handleAddAll(todos: Array<string>) {
*     const addResults = await Promise.allSettled(
*       todos.map((todo) => addMutation.mutateAsync(todo)),
*     )
*
*     addResults.forEach((addResult, index) => {
*       if (addResult.status === 'rejected') {
*         console.error(`Failed to add "${todos[index]}":`, addResult.reason)
*       }
*     })
*   }
*
*   return (
*     <button onClick={() => handleAddAll(['Todo 1', 'Todo 2', 'Todo 3'])}>
*       Add all
*     </button>
*   )
* }
* ```
*/
function useMutation(options, queryClient) {
	const client = useQueryClient(queryClient);
	const [observer] = import_react.useState(() => new MutationObserver$1(client, options));
	import_react.useEffect(() => {
		observer.setOptions(options);
	}, [observer, options]);
	const result = import_react.useSyncExternalStore(import_react.useCallback((onStoreChange) => observer.subscribe(notifyManager.batchCalls(onStoreChange)), [observer]), () => observer.getCurrentResult(), () => observer.getCurrentResult());
	const mutate = import_react.useCallback((...args) => {
		observer.mutate(args[0], args[1]).catch(noop);
	}, [observer]);
	if (result.error && shouldThrowError(observer.options.throwOnError, [result.error])) throw result.error;
	return {
		...result,
		mutate,
		mutateAsync: result.mutate
	};
}
//#endregion
//#region node_modules/@radix-ui/primitive/dist/index.mjs
var __defProp$14 = Object.defineProperty;
var __name$14 = (target, value) => __defProp$14(target, "name", {
	value,
	configurable: true
});
var canUseDOM = !!(typeof window !== "undefined" && window.document && window.document.createElement);
function composeEventHandlers(originalEventHandler, ourEventHandler, { checkForDefaultPrevented = true } = {}) {
	return /* @__PURE__ */ __name$14(function handleEvent(event) {
		originalEventHandler?.(event);
		if (checkForDefaultPrevented === false || !event || !event.defaultPrevented) return ourEventHandler?.(event);
	}, "handleEvent");
}
__name$14(composeEventHandlers, "composeEventHandlers");
function getOwnerWindow(element) {
	if (!canUseDOM) throw new Error("Cannot access window outside of the DOM");
	return element?.ownerDocument?.defaultView ?? window;
}
__name$14(getOwnerWindow, "getOwnerWindow");
function getOwnerDocument(element) {
	if (!canUseDOM) throw new Error("Cannot access document outside of the DOM");
	return element?.ownerDocument ?? document;
}
__name$14(getOwnerDocument, "getOwnerDocument");
function getActiveElement(node, activeDescendant = false) {
	const { activeElement } = getOwnerDocument(node);
	if (!activeElement?.nodeName) return null;
	if (isFrame(activeElement) && activeElement.contentDocument) return getActiveElement(activeElement.contentDocument.body, activeDescendant);
	if (activeDescendant) {
		const id = activeElement.getAttribute("aria-activedescendant");
		if (id) {
			const element = getOwnerDocument(activeElement).getElementById(id);
			if (element) return element;
		}
	}
	return activeElement;
}
__name$14(getActiveElement, "getActiveElement");
function isFrame(element) {
	return element.tagName === "IFRAME";
}
__name$14(isFrame, "isFrame");
//#endregion
//#region node_modules/@radix-ui/react-compose-refs/dist/index.mjs
var __defProp$13 = Object.defineProperty;
var __name$13 = (target, value) => __defProp$13(target, "name", {
	value,
	configurable: true
});
function setRef$1(ref, value) {
	if (typeof ref === "function") return ref(value);
	else if (ref !== null && ref !== void 0) ref.current = value;
}
__name$13(setRef$1, "setRef");
function composeRefs(...refs) {
	return (node) => {
		let hasCleanup = false;
		const cleanups = refs.map((ref) => {
			const cleanup = setRef$1(ref, node);
			if (!hasCleanup && typeof cleanup == "function") hasCleanup = true;
			return cleanup;
		});
		if (hasCleanup) return () => {
			for (let i = 0; i < cleanups.length; i++) {
				const cleanup = cleanups[i];
				if (typeof cleanup == "function") cleanup();
				else setRef$1(refs[i], null);
			}
		};
	};
}
__name$13(composeRefs, "composeRefs");
function useComposedRefs(...refs) {
	return import_react.useCallback(composeRefs(...refs), refs);
}
__name$13(useComposedRefs, "useComposedRefs");
//#endregion
//#region node_modules/@radix-ui/react-context/dist/index.mjs
var __defProp$12 = Object.defineProperty;
var __name$12 = (target, value) => __defProp$12(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createContext2$1(rootComponentName, defaultContext) {
	const Context = import_react.createContext(defaultContext);
	Context.displayName = rootComponentName + "Context";
	const Provider = /* @__PURE__ */ __name$12((props) => {
		const { children, ...context } = props;
		const value = import_react.useMemo(() => context, Object.values(context));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Context.Provider, {
			value,
			children
		});
	}, "Provider");
	Provider.displayName = rootComponentName + "Provider";
	function useContext2(consumerName, options = {}) {
		const { optional = false } = options;
		const context = import_react.useContext(Context);
		if (context) return context;
		if (defaultContext !== void 0) return defaultContext;
		if (optional) return void 0;
		throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
	}
	__name$12(useContext2, "useContext");
	return [Provider, useContext2];
}
__name$12(createContext2$1, "createContext");
// @__NO_SIDE_EFFECTS__
function createContextScope(scopeName, createContextScopeDeps = []) {
	let defaultContexts = [];
	function createContext3(rootComponentName, defaultContext) {
		const BaseContext = import_react.createContext(defaultContext);
		BaseContext.displayName = rootComponentName + "Context";
		const index = defaultContexts.length;
		defaultContexts = [...defaultContexts, defaultContext];
		const Provider = /* @__PURE__ */ __name$12((props) => {
			const { scope, children, ...context } = props;
			const Context = scope?.[scopeName]?.[index] || BaseContext;
			const value = import_react.useMemo(() => context, Object.values(context));
			return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Context.Provider, {
				value,
				children
			});
		}, "Provider");
		Provider.displayName = rootComponentName + "Provider";
		function useContext2(consumerName, scope, options = {}) {
			const { optional = false } = options;
			const Context = scope?.[scopeName]?.[index] || BaseContext;
			const context = import_react.useContext(Context);
			if (context) return context;
			if (defaultContext !== void 0) return defaultContext;
			if (optional) return void 0;
			throw new Error(`\`${consumerName}\` must be used within \`${rootComponentName}\``);
		}
		__name$12(useContext2, "useContext");
		return [Provider, useContext2];
	}
	__name$12(createContext3, "createContext");
	const createScope = /* @__PURE__ */ __name$12(() => {
		const scopeContexts = defaultContexts.map((defaultContext) => {
			return import_react.createContext(defaultContext);
		});
		return /* @__PURE__ */ __name$12(function useScope(scope) {
			const contexts = scope?.[scopeName] || scopeContexts;
			return import_react.useMemo(() => ({ [`__scope${scopeName}`]: {
				...scope,
				[scopeName]: contexts
			} }), [scope, contexts]);
		}, "useScope");
	}, "createScope");
	createScope.scopeName = scopeName;
	return [createContext3, composeContextScopes(createScope, ...createContextScopeDeps)];
}
__name$12(createContextScope, "createContextScope");
function composeContextScopes(...scopes) {
	const baseScope = scopes[0];
	if (scopes.length === 1) return baseScope;
	const createScope = /* @__PURE__ */ __name$12(() => {
		const scopeHooks = scopes.map((createScope2) => ({
			useScope: createScope2(),
			scopeName: createScope2.scopeName
		}));
		return /* @__PURE__ */ __name$12(function useComposedScopes(overrideScopes) {
			const nextScopes = scopeHooks.reduce((nextScopes2, { useScope, scopeName }) => {
				const currentScope = useScope(overrideScopes)[`__scope${scopeName}`];
				return {
					...nextScopes2,
					...currentScope
				};
			}, {});
			return import_react.useMemo(() => ({ [`__scope${baseScope.scopeName}`]: nextScopes }), [nextScopes]);
		}, "useComposedScopes");
	}, "createScope");
	createScope.scopeName = baseScope.scopeName;
	return createScope;
}
__name$12(composeContextScopes, "composeContextScopes");
//#endregion
//#region node_modules/@radix-ui/react-use-layout-effect/dist/index.mjs
var useLayoutEffect2$1 = globalThis?.document ? import_react.useLayoutEffect : () => {};
//#endregion
//#region node_modules/@radix-ui/react-id/dist/index.mjs
var __defProp$11 = Object.defineProperty;
var __name$11 = (target, value) => __defProp$11(target, "name", {
	value,
	configurable: true
});
var useReactId = import_react[" useId ".trim().toString()] || (() => void 0);
var count$1 = 0;
function useId(deterministicId) {
	const [id, setId] = import_react.useState(useReactId());
	useLayoutEffect2$1(() => {
		if (!deterministicId) setId((reactId) => reactId ?? String(count$1++));
	}, [deterministicId]);
	return deterministicId || (id ? `radix-${id}` : "");
}
__name$11(useId, "useId");
//#endregion
//#region node_modules/@radix-ui/react-use-effect-event/dist/index.mjs
var __defProp$10 = Object.defineProperty;
var __name$10 = (target, value) => __defProp$10(target, "name", {
	value,
	configurable: true
});
var useReactEffectEvent = import_react[" useEffectEvent ".trim().toString()];
var useReactInsertionEffect = import_react[" useInsertionEffect ".trim().toString()];
function useEffectEvent(callback) {
	if (typeof useReactEffectEvent === "function") return useReactEffectEvent(callback);
	const ref = import_react.useRef(() => {
		throw new Error("Cannot call an event handler while rendering.");
	});
	if (typeof useReactInsertionEffect === "function") useReactInsertionEffect(() => {
		ref.current = callback;
	});
	else useLayoutEffect2$1(() => {
		ref.current = callback;
	});
	return import_react.useMemo(() => ((...args) => ref.current?.(...args)), []);
}
__name$10(useEffectEvent, "useEffectEvent");
//#endregion
//#region node_modules/@radix-ui/react-use-controllable-state/dist/index.mjs
var __defProp$9 = Object.defineProperty;
var __name$9 = (target, value) => __defProp$9(target, "name", {
	value,
	configurable: true
});
var useInsertionEffect = import_react[" useInsertionEffect ".trim().toString()] || useLayoutEffect2$1;
function useControllableState({ prop, defaultProp, onChange = /* @__PURE__ */ __name$9(() => {}, "onChange"), caller }) {
	const [uncontrolledProp, setUncontrolledProp, onChangeRef] = useUncontrolledState({
		defaultProp,
		onChange
	});
	const isControlled = prop !== void 0;
	return [isControlled ? prop : uncontrolledProp, import_react.useCallback((nextValue) => {
		if (isControlled) {
			const value2 = isFunction(nextValue) ? nextValue(prop) : nextValue;
			if (value2 !== prop) onChangeRef.current?.(value2);
		} else setUncontrolledProp(nextValue);
	}, [
		isControlled,
		prop,
		setUncontrolledProp,
		onChangeRef
	])];
}
__name$9(useControllableState, "useControllableState");
function useUncontrolledState({ defaultProp, onChange }) {
	const [value, setValue] = import_react.useState(defaultProp);
	const prevValueRef = import_react.useRef(value);
	const onChangeRef = import_react.useRef(onChange);
	useInsertionEffect(() => {
		onChangeRef.current = onChange;
	}, [onChange]);
	import_react.useEffect(() => {
		if (prevValueRef.current !== value) {
			onChangeRef.current?.(value);
			prevValueRef.current = value;
		}
	}, [value, prevValueRef]);
	return [
		value,
		setValue,
		onChangeRef
	];
}
__name$9(useUncontrolledState, "useUncontrolledState");
function isFunction(value) {
	return typeof value === "function";
}
__name$9(isFunction, "isFunction");
var SYNC_STATE = Symbol("RADIX:SYNC_STATE");
function useControllableStateReducer(reducer, userArgs, initialArg, init) {
	const { prop: controlledState, defaultProp, onChange: onChangeProp, caller } = userArgs;
	const isControlled = controlledState !== void 0;
	const onChange = useEffectEvent(onChangeProp);
	const args = [{
		...initialArg,
		state: defaultProp
	}];
	if (init) args.push(init);
	const [internalState, dispatch] = import_react.useReducer((state2, action) => {
		if (action.type === SYNC_STATE) return {
			...state2,
			state: action.state
		};
		const next = reducer(state2, action);
		if (isControlled && !Object.is(next.state, state2.state)) onChange(next.state);
		return next;
	}, ...args);
	const uncontrolledState = internalState.state;
	const prevValueRef = import_react.useRef(uncontrolledState);
	import_react.useEffect(() => {
		if (prevValueRef.current !== uncontrolledState) {
			prevValueRef.current = uncontrolledState;
			if (!isControlled) onChange(uncontrolledState);
		}
	}, [
		uncontrolledState,
		prevValueRef,
		isControlled
	]);
	const state = import_react.useMemo(() => {
		if (controlledState !== void 0) return {
			...internalState,
			state: controlledState
		};
		return internalState;
	}, [internalState, controlledState]);
	import_react.useEffect(() => {
		if (isControlled && !Object.is(controlledState, internalState.state)) dispatch({
			type: SYNC_STATE,
			state: controlledState
		});
	}, [
		controlledState,
		internalState.state,
		isControlled
	]);
	return [state, dispatch];
}
__name$9(useControllableStateReducer, "useControllableStateReducer");
//#endregion
//#region node_modules/@radix-ui/react-slot/dist/index.mjs
var import_react_dom = /* @__PURE__ */ __toESM(require_react_dom(), 1);
var __defProp$8 = Object.defineProperty;
var __name$8 = (target, value) => __defProp$8(target, "name", {
	value,
	configurable: true
});
// @__NO_SIDE_EFFECTS__
function createSlot(ownerName) {
	const Slot2 = import_react.forwardRef((props, forwardedRef) => {
		let { children, ...slotProps } = props;
		let slottableElement = null;
		let hasSlottable = false;
		const newChildren = [];
		if (isLazyComponent(children) && typeof use === "function") children = use(children._payload);
		import_react.Children.forEach(children, (maybeSlottable) => {
			if (isSlottable(maybeSlottable)) {
				hasSlottable = true;
				const slottable = maybeSlottable;
				let child = "child" in slottable.props ? slottable.props.child : slottable.props.children;
				if (isLazyComponent(child) && typeof use === "function") child = use(child._payload);
				slottableElement = getSlottableElementFromSlottable(slottable, child);
				newChildren.push(slottableElement?.props?.children);
			} else newChildren.push(maybeSlottable);
		});
		if (slottableElement) slottableElement = import_react.cloneElement(slottableElement, void 0, newChildren);
		else if (!hasSlottable && import_react.Children.count(children) === 1 && import_react.isValidElement(children)) slottableElement = children;
		const slottableElementRef = slottableElement ? getElementRef$1(slottableElement) : void 0;
		const composedRef = useComposedRefs(forwardedRef, slottableElementRef);
		if (!slottableElement) {
			if (children || children === 0) throw new Error(hasSlottable ? createSlottableError(ownerName) : createSlotError(ownerName));
			return children;
		}
		const mergedProps = mergeProps(slotProps, slottableElement.props ?? {});
		if (slottableElement.type !== import_react.Fragment) mergedProps.ref = forwardedRef ? composedRef : slottableElementRef;
		return import_react.cloneElement(slottableElement, mergedProps);
	});
	Slot2.displayName = `${ownerName}.Slot`;
	return Slot2;
}
__name$8(createSlot, "createSlot");
var Slot$1 = /* @__PURE__ */ createSlot("Slot");
var SLOTTABLE_IDENTIFIER = Symbol.for("radix.slottable");
// @__NO_SIDE_EFFECTS__
function createSlottable(ownerName) {
	const Slottable2 = /* @__PURE__ */ __name$8((props) => "child" in props ? props.children(props.child) : props.children, "Slottable");
	Slottable2.displayName = `${ownerName}.Slottable`;
	Slottable2.__radixId = SLOTTABLE_IDENTIFIER;
	return Slottable2;
}
__name$8(createSlottable, "createSlottable");
var getSlottableElementFromSlottable = /* @__PURE__ */ __name$8((slottable, child) => {
	if ("child" in slottable.props) {
		const child2 = slottable.props.child;
		if (!import_react.isValidElement(child2)) return null;
		return import_react.cloneElement(child2, void 0, slottable.props.children(child2.props.children));
	}
	return import_react.isValidElement(child) ? child : null;
}, "getSlottableElementFromSlottable");
function mergeProps(slotProps, childProps) {
	const overrideProps = { ...childProps };
	for (const propName in childProps) {
		const slotPropValue = slotProps[propName];
		const childPropValue = childProps[propName];
		if (/^on[A-Z]/.test(propName)) {
			if (slotPropValue && childPropValue) overrideProps[propName] = (...args) => {
				const result = childPropValue(...args);
				slotPropValue(...args);
				return result;
			};
			else if (slotPropValue) overrideProps[propName] = slotPropValue;
		} else if (propName === "style") overrideProps[propName] = {
			...slotPropValue,
			...childPropValue
		};
		else if (propName === "className") overrideProps[propName] = [slotPropValue, childPropValue].filter(Boolean).join(" ");
	}
	return {
		...slotProps,
		...overrideProps
	};
}
__name$8(mergeProps, "mergeProps");
function getElementRef$1(element) {
	let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
	let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
	if (mayWarn) return element.ref;
	getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
	mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
	if (mayWarn) return element.props.ref;
	return element.props.ref || element.ref;
}
__name$8(getElementRef$1, "getElementRef");
function isSlottable(child) {
	return import_react.isValidElement(child) && typeof child.type === "function" && "__radixId" in child.type && child.type.__radixId === SLOTTABLE_IDENTIFIER;
}
__name$8(isSlottable, "isSlottable");
var REACT_LAZY_TYPE = Symbol.for("react.lazy");
function isLazyComponent(element) {
	return element != null && typeof element === "object" && "$$typeof" in element && element.$$typeof === REACT_LAZY_TYPE && "_payload" in element && isPromiseLike(element._payload);
}
__name$8(isLazyComponent, "isLazyComponent");
function isPromiseLike(value) {
	return typeof value === "object" && value !== null && "then" in value;
}
__name$8(isPromiseLike, "isPromiseLike");
var createSlotError = /* @__PURE__ */ __name$8((ownerName) => {
	return `${ownerName} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`;
}, "createSlotError");
var createSlottableError = /* @__PURE__ */ __name$8((ownerName) => {
	return `${ownerName} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`;
}, "createSlottableError");
var use = import_react[" use ".trim().toString()];
//#endregion
//#region node_modules/@radix-ui/react-primitive/dist/index.mjs
var __defProp$7 = Object.defineProperty;
var __name$7 = (target, value) => __defProp$7(target, "name", {
	value,
	configurable: true
});
var Primitive = [
	"a",
	"button",
	"div",
	"form",
	"h2",
	"h3",
	"img",
	"input",
	"label",
	"li",
	"nav",
	"ol",
	"p",
	"select",
	"span",
	"svg",
	"ul"
].reduce((primitive, node) => {
	const Slot = /* @__PURE__ */ createSlot(`Primitive.${node}`);
	const Node = import_react.forwardRef((props, forwardedRef) => {
		const { asChild, ...primitiveProps } = props;
		const Comp = asChild ? Slot : node;
		if (typeof window !== "undefined") window[Symbol.for("radix-ui")] = true;
		return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Comp, {
			...primitiveProps,
			ref: forwardedRef
		});
	});
	Node.displayName = `Primitive.${node}`;
	return {
		...primitive,
		[node]: Node
	};
}, {});
function dispatchDiscreteCustomEvent(target, event) {
	if (target) import_react_dom.flushSync(() => target.dispatchEvent(event));
}
__name$7(dispatchDiscreteCustomEvent, "dispatchDiscreteCustomEvent");
//#endregion
//#region node_modules/@radix-ui/react-use-callback-ref/dist/index.mjs
var __defProp$6 = Object.defineProperty;
var __name$6 = (target, value) => __defProp$6(target, "name", {
	value,
	configurable: true
});
function useCallbackRef$1(callback) {
	const callbackRef = import_react.useRef(callback);
	import_react.useEffect(() => {
		callbackRef.current = callback;
	});
	return import_react.useMemo(() => ((...args) => callbackRef.current?.(...args)), []);
}
__name$6(useCallbackRef$1, "useCallbackRef");
//#endregion
//#region node_modules/@radix-ui/react-dismissable-layer/dist/index.mjs
var __defProp$5 = Object.defineProperty;
var __name$5 = (target, value) => __defProp$5(target, "name", {
	value,
	configurable: true
});
var CONTEXT_UPDATE = "dismissableLayer.update";
var POINTER_DOWN_OUTSIDE = "dismissableLayer.pointerDownOutside";
var FOCUS_OUTSIDE = "dismissableLayer.focusOutside";
var originalBodyPointerEvents;
var DismissableLayerContext = import_react.createContext({
	layers: /* @__PURE__ */ new Set(),
	layersWithOutsidePointerEventsDisabled: /* @__PURE__ */ new Set(),
	branches: /* @__PURE__ */ new Set(),
	dismissableSurfaces: /* @__PURE__ */ new Set()
});
var DismissableLayer = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$5(function DismissableLayer2(props, forwardedRef) {
	const { disableOutsidePointerEvents = false, deferPointerDownOutside = false, onEscapeKeyDown, onPointerDownOutside, onFocusOutside, onInteractOutside, onDismiss, ...layerProps } = props;
	const context = import_react.useContext(DismissableLayerContext);
	const [node, setNode] = import_react.useState(null);
	const ownerDocument = node?.ownerDocument ?? globalThis?.document;
	const [, force] = import_react.useState({});
	const composedRefs = useComposedRefs(forwardedRef, setNode);
	const layers = Array.from(context.layers);
	const [highestLayerWithOutsidePointerEventsDisabled] = [...context.layersWithOutsidePointerEventsDisabled].slice(-1);
	const highestLayerWithOutsidePointerEventsDisabledIndex = highestLayerWithOutsidePointerEventsDisabled ? layers.indexOf(highestLayerWithOutsidePointerEventsDisabled) : -1;
	const index = node ? layers.indexOf(node) : -1;
	const isBodyPointerEventsDisabled = context.layersWithOutsidePointerEventsDisabled.size > 0;
	const isPointerEventsEnabled = index >= highestLayerWithOutsidePointerEventsDisabledIndex;
	const isDeferredPointerDownOutsideRef = import_react.useRef(false);
	const pointerDownOutside = usePointerDownOutside((event) => {
		onPointerDownOutside?.(event);
		onInteractOutside?.(event);
		if (!event.defaultPrevented) onDismiss?.();
	}, {
		ownerDocument,
		deferPointerDownOutside,
		isDeferredPointerDownOutsideRef,
		dismissableSurfaces: context.dismissableSurfaces,
		shouldHandlePointerDownOutside: import_react.useCallback((target) => {
			if (!(target instanceof Node)) return false;
			const isPointerDownOnBranch = [...context.branches].some((branch) => branch.contains(target));
			return isPointerEventsEnabled && !isPointerDownOnBranch;
		}, [context.branches, isPointerEventsEnabled])
	});
	const focusOutside = useFocusOutside((event) => {
		if (deferPointerDownOutside && isDeferredPointerDownOutsideRef.current) return;
		const target = event.target;
		if ([...context.branches].some((branch) => branch.contains(target))) return;
		onFocusOutside?.(event);
		onInteractOutside?.(event);
		if (!event.defaultPrevented) onDismiss?.();
	}, ownerDocument);
	const isHighestLayer = node ? index === layers.length - 1 : false;
	const handleKeyDown = useCallbackRef$1((event) => {
		if (event.key !== "Escape") return;
		onEscapeKeyDown?.(event);
		if (!event.defaultPrevented && onDismiss) {
			event.preventDefault();
			onDismiss();
		}
	});
	import_react.useEffect(() => {
		if (!isHighestLayer) return;
		ownerDocument.addEventListener("keydown", handleKeyDown, { capture: true });
		return () => ownerDocument.removeEventListener("keydown", handleKeyDown, { capture: true });
	}, [
		ownerDocument,
		isHighestLayer,
		handleKeyDown
	]);
	import_react.useEffect(() => {
		if (!node) return;
		if (disableOutsidePointerEvents) {
			if (context.layersWithOutsidePointerEventsDisabled.size === 0) {
				originalBodyPointerEvents = ownerDocument.body.style.pointerEvents;
				ownerDocument.body.style.pointerEvents = "none";
			}
			context.layersWithOutsidePointerEventsDisabled.add(node);
		}
		context.layers.add(node);
		dispatchUpdate();
		return () => {
			if (disableOutsidePointerEvents) {
				context.layersWithOutsidePointerEventsDisabled.delete(node);
				if (context.layersWithOutsidePointerEventsDisabled.size === 0) ownerDocument.body.style.pointerEvents = originalBodyPointerEvents;
			}
		};
	}, [
		node,
		ownerDocument,
		disableOutsidePointerEvents,
		context
	]);
	import_react.useEffect(() => {
		return () => {
			if (!node) return;
			context.layers.delete(node);
			context.layersWithOutsidePointerEventsDisabled.delete(node);
			dispatchUpdate();
		};
	}, [node, context]);
	import_react.useEffect(() => {
		const handleUpdate = /* @__PURE__ */ __name$5(() => force({}), "handleUpdate");
		document.addEventListener(CONTEXT_UPDATE, handleUpdate);
		return () => document.removeEventListener(CONTEXT_UPDATE, handleUpdate);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...layerProps,
		ref: composedRefs,
		style: {
			pointerEvents: isBodyPointerEventsDisabled ? isPointerEventsEnabled ? "auto" : "none" : void 0,
			...props.style
		},
		onFocusCapture: composeEventHandlers(props.onFocusCapture, focusOutside.onFocusCapture),
		onBlurCapture: composeEventHandlers(props.onBlurCapture, focusOutside.onBlurCapture),
		onPointerDownCapture: composeEventHandlers(props.onPointerDownCapture, pointerDownOutside.onPointerDownCapture)
	});
}, "DismissableLayer"));
function useDismissableLayerSurface() {
	const context = import_react.useContext(DismissableLayerContext);
	const [node, setNode] = import_react.useState(null);
	import_react.useEffect(() => {
		if (!node) return;
		context.dismissableSurfaces.add(node);
		return () => {
			context.dismissableSurfaces.delete(node);
		};
	}, [node, context.dismissableSurfaces]);
	return setNode;
}
__name$5(useDismissableLayerSurface, "useDismissableLayerSurface");
var IS_TRUE = /* @__PURE__ */ __name$5(() => true, "IS_TRUE");
function usePointerDownOutside(onPointerDownOutside, args) {
	const { ownerDocument = globalThis?.document, deferPointerDownOutside = false, isDeferredPointerDownOutsideRef, dismissableSurfaces, shouldHandlePointerDownOutside = IS_TRUE } = args;
	const handlePointerDownOutside = useCallbackRef$1(onPointerDownOutside);
	const isPointerInsideReactTreeRef = import_react.useRef(false);
	const isPointerDownOutsideRef = import_react.useRef(false);
	const interceptedOutsideInteractionEventsRef = import_react.useRef(/* @__PURE__ */ new Map());
	const handleClickRef = import_react.useRef(() => {});
	import_react.useEffect(() => {
		function resetOutsideInteraction() {
			isPointerDownOutsideRef.current = false;
			isDeferredPointerDownOutsideRef.current = false;
			interceptedOutsideInteractionEventsRef.current.clear();
		}
		__name$5(resetOutsideInteraction, "resetOutsideInteraction");
		function isOutsideInteractionIntercepted() {
			return Array.from(interceptedOutsideInteractionEventsRef.current.values()).some(Boolean);
		}
		__name$5(isOutsideInteractionIntercepted, "isOutsideInteractionIntercepted");
		function handleInteractionCapture(event) {
			if (!isPointerDownOutsideRef.current) return;
			const target = event.target;
			if (!(target instanceof Node && [...dismissableSurfaces].some((surface) => surface.contains(target)))) interceptedOutsideInteractionEventsRef.current.set(event.type, true);
			if (event.type === "click") window.setTimeout(() => {
				if (isPointerDownOutsideRef.current) handleClickRef.current();
			}, 0);
		}
		__name$5(handleInteractionCapture, "handleInteractionCapture");
		function handleInteractionBubble(event) {
			if (isPointerDownOutsideRef.current) interceptedOutsideInteractionEventsRef.current.set(event.type, false);
		}
		__name$5(handleInteractionBubble, "handleInteractionBubble");
		const handlePointerDown = /* @__PURE__ */ __name$5((event) => {
			if (event.target && !isPointerInsideReactTreeRef.current) {
				let handleAndDispatchPointerDownOutsideEvent2 = function() {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					const wasOutsideInteractionIntercepted = isOutsideInteractionIntercepted();
					resetOutsideInteraction();
					if (!wasOutsideInteractionIntercepted) handleAndDispatchCustomEvent(POINTER_DOWN_OUTSIDE, handlePointerDownOutside, eventDetail, { discrete: true });
				};
				__name$5(handleAndDispatchPointerDownOutsideEvent2, "handleAndDispatchPointerDownOutsideEvent");
				if (!shouldHandlePointerDownOutside(event.target)) {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					resetOutsideInteraction();
					isPointerInsideReactTreeRef.current = false;
					return;
				}
				const eventDetail = { originalEvent: event };
				isPointerDownOutsideRef.current = true;
				isDeferredPointerDownOutsideRef.current = deferPointerDownOutside && event.button === 0;
				interceptedOutsideInteractionEventsRef.current.clear();
				if (!deferPointerDownOutside || event.button !== 0) handleAndDispatchPointerDownOutsideEvent2();
				else {
					ownerDocument.removeEventListener("click", handleClickRef.current);
					handleClickRef.current = handleAndDispatchPointerDownOutsideEvent2;
					ownerDocument.addEventListener("click", handleClickRef.current, { once: true });
				}
			} else {
				ownerDocument.removeEventListener("click", handleClickRef.current);
				resetOutsideInteraction();
			}
			isPointerInsideReactTreeRef.current = false;
		}, "handlePointerDown");
		const outsideInteractionEvents = [
			"pointerup",
			"mousedown",
			"mouseup",
			"touchstart",
			"touchend",
			"click"
		];
		for (const eventName of outsideInteractionEvents) {
			ownerDocument.addEventListener(eventName, handleInteractionCapture, true);
			ownerDocument.addEventListener(eventName, handleInteractionBubble);
		}
		const timerId = window.setTimeout(() => {
			ownerDocument.addEventListener("pointerdown", handlePointerDown);
		}, 0);
		return () => {
			window.clearTimeout(timerId);
			ownerDocument.removeEventListener("pointerdown", handlePointerDown);
			ownerDocument.removeEventListener("click", handleClickRef.current);
			for (const eventName of outsideInteractionEvents) {
				ownerDocument.removeEventListener(eventName, handleInteractionCapture, true);
				ownerDocument.removeEventListener(eventName, handleInteractionBubble);
			}
		};
	}, [
		ownerDocument,
		handlePointerDownOutside,
		deferPointerDownOutside,
		isDeferredPointerDownOutsideRef,
		dismissableSurfaces,
		shouldHandlePointerDownOutside
	]);
	return { onPointerDownCapture: /* @__PURE__ */ __name$5(() => isPointerInsideReactTreeRef.current = true, "onPointerDownCapture") };
}
__name$5(usePointerDownOutside, "usePointerDownOutside");
function useFocusOutside(onFocusOutside, ownerDocument = globalThis?.document) {
	const handleFocusOutside = useCallbackRef$1(onFocusOutside);
	const isFocusInsideReactTreeRef = import_react.useRef(false);
	import_react.useEffect(() => {
		const handleFocus = /* @__PURE__ */ __name$5((event) => {
			if (event.target && !isFocusInsideReactTreeRef.current) handleAndDispatchCustomEvent(FOCUS_OUTSIDE, handleFocusOutside, { originalEvent: event }, { discrete: false });
		}, "handleFocus");
		ownerDocument.addEventListener("focusin", handleFocus);
		return () => ownerDocument.removeEventListener("focusin", handleFocus);
	}, [ownerDocument, handleFocusOutside]);
	return {
		onFocusCapture: /* @__PURE__ */ __name$5(() => isFocusInsideReactTreeRef.current = true, "onFocusCapture"),
		onBlurCapture: /* @__PURE__ */ __name$5(() => isFocusInsideReactTreeRef.current = false, "onBlurCapture")
	};
}
__name$5(useFocusOutside, "useFocusOutside");
function dispatchUpdate() {
	const event = new CustomEvent(CONTEXT_UPDATE);
	document.dispatchEvent(event);
}
__name$5(dispatchUpdate, "dispatchUpdate");
function handleAndDispatchCustomEvent(name, handler, detail, { discrete }) {
	const target = detail.originalEvent.target;
	const event = new CustomEvent(name, {
		bubbles: false,
		cancelable: true,
		detail
	});
	if (handler) target.addEventListener(name, handler, { once: true });
	if (discrete) dispatchDiscreteCustomEvent(target, event);
	else target.dispatchEvent(event);
}
__name$5(handleAndDispatchCustomEvent, "handleAndDispatchCustomEvent");
//#endregion
//#region node_modules/@radix-ui/react-focus-scope/dist/index.mjs
var __defProp$4 = Object.defineProperty;
var __name$4 = (target, value) => __defProp$4(target, "name", {
	value,
	configurable: true
});
var AUTOFOCUS_ON_MOUNT = "focusScope.autoFocusOnMount";
var AUTOFOCUS_ON_UNMOUNT = "focusScope.autoFocusOnUnmount";
var EVENT_OPTIONS = {
	bubbles: false,
	cancelable: true
};
var FocusScope = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$4(function FocusScope2(props, forwardedRef) {
	const { loop = false, trapped = false, onMountAutoFocus: onMountAutoFocusProp, onUnmountAutoFocus: onUnmountAutoFocusProp, ...scopeProps } = props;
	const [container, setContainer] = import_react.useState(null);
	const onMountAutoFocus = useCallbackRef$1(onMountAutoFocusProp);
	const onUnmountAutoFocus = useCallbackRef$1(onUnmountAutoFocusProp);
	const lastFocusedElementRef = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, setContainer);
	const focusScope = import_react.useRef({
		paused: false,
		pause() {
			this.paused = true;
		},
		resume() {
			this.paused = false;
		}
	}).current;
	import_react.useEffect(() => {
		if (trapped) {
			let handleFocusIn2 = function(event) {
				if (focusScope.paused || !container) return;
				const target = event.target;
				if (container.contains(target)) lastFocusedElementRef.current = target;
				else focus(lastFocusedElementRef.current, { select: true });
			}, handleFocusOut2 = function(event) {
				if (focusScope.paused || !container) return;
				const relatedTarget = event.relatedTarget;
				if (relatedTarget === null) return;
				if (!container.contains(relatedTarget)) focus(lastFocusedElementRef.current, { select: true });
			}, handleMutations2 = function(mutations) {
				if (document.activeElement !== document.body) return;
				for (const mutation of mutations) if (mutation.removedNodes.length > 0) focus(container);
			};
			__name$4(handleFocusIn2, "handleFocusIn");
			__name$4(handleFocusOut2, "handleFocusOut");
			__name$4(handleMutations2, "handleMutations");
			document.addEventListener("focusin", handleFocusIn2);
			document.addEventListener("focusout", handleFocusOut2);
			const mutationObserver = new MutationObserver(handleMutations2);
			if (container) mutationObserver.observe(container, {
				childList: true,
				subtree: true
			});
			return () => {
				document.removeEventListener("focusin", handleFocusIn2);
				document.removeEventListener("focusout", handleFocusOut2);
				mutationObserver.disconnect();
			};
		}
	}, [
		trapped,
		container,
		focusScope.paused
	]);
	import_react.useEffect(() => {
		if (container) {
			focusScopesStack.add(focusScope);
			const previouslyFocusedElement = document.activeElement;
			if (!container.contains(previouslyFocusedElement)) {
				const mountEvent = new CustomEvent(AUTOFOCUS_ON_MOUNT, EVENT_OPTIONS);
				container.addEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
				container.dispatchEvent(mountEvent);
				if (!mountEvent.defaultPrevented) {
					focusFirst(removeLinks(getTabbableCandidates(container)), { select: true });
					if (document.activeElement === previouslyFocusedElement) focus(container);
				}
			}
			return () => {
				container.removeEventListener(AUTOFOCUS_ON_MOUNT, onMountAutoFocus);
				setTimeout(() => {
					const unmountEvent = new CustomEvent(AUTOFOCUS_ON_UNMOUNT, EVENT_OPTIONS);
					container.addEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
					container.dispatchEvent(unmountEvent);
					if (!unmountEvent.defaultPrevented) focus(previouslyFocusedElement ?? document.body, { select: true });
					container.removeEventListener(AUTOFOCUS_ON_UNMOUNT, onUnmountAutoFocus);
					focusScopesStack.remove(focusScope);
				}, 0);
			};
		}
	}, [
		container,
		onMountAutoFocus,
		onUnmountAutoFocus,
		focusScope
	]);
	const handleKeyDown = import_react.useCallback((event) => {
		if (!loop && !trapped) return;
		if (focusScope.paused) return;
		const isTabKey = event.key === "Tab" && !event.altKey && !event.ctrlKey && !event.metaKey;
		const focusedElement = document.activeElement;
		if (isTabKey && focusedElement) {
			const container2 = event.currentTarget;
			const [first, last] = getTabbableEdges(container2);
			if (!(first && last)) {
				if (focusedElement === container2) event.preventDefault();
			} else if (!event.shiftKey && focusedElement === last) {
				event.preventDefault();
				if (loop) focus(first, { select: true });
			} else if (event.shiftKey && focusedElement === first) {
				event.preventDefault();
				if (loop) focus(last, { select: true });
			}
		}
	}, [
		loop,
		trapped,
		focusScope.paused
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		tabIndex: -1,
		...scopeProps,
		ref: composedRefs,
		onKeyDown: handleKeyDown
	});
}, "FocusScope"));
function focusFirst(candidates, { select = false } = {}) {
	const previouslyFocusedElement = document.activeElement;
	for (const candidate of candidates) {
		focus(candidate, { select });
		if (document.activeElement !== previouslyFocusedElement) return;
	}
}
__name$4(focusFirst, "focusFirst");
function getTabbableEdges(container) {
	const candidates = getTabbableCandidates(container);
	return [findVisible(candidates, container), findVisible(candidates.reverse(), container)];
}
__name$4(getTabbableEdges, "getTabbableEdges");
function getTabbableCandidates(container) {
	const nodes = [];
	const walker = document.createTreeWalker(container, NodeFilter.SHOW_ELEMENT, { acceptNode: /* @__PURE__ */ __name$4((node) => {
		const isHiddenInput = node.tagName === "INPUT" && node.type === "hidden";
		if (node.disabled || node.hidden || isHiddenInput) return NodeFilter.FILTER_SKIP;
		return node.tabIndex >= 0 ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_SKIP;
	}, "acceptNode") });
	while (walker.nextNode()) nodes.push(walker.currentNode);
	return nodes;
}
__name$4(getTabbableCandidates, "getTabbableCandidates");
function findVisible(elements, container) {
	const canUseCheckVisibility = typeof container.checkVisibility === "function" && container.checkVisibility({ checkVisibilityCSS: true });
	for (const element of elements) if (!(canUseCheckVisibility ? !element.checkVisibility({ checkVisibilityCSS: true }) : isHidden(element, { upTo: container }))) return element;
}
__name$4(findVisible, "findVisible");
function isHidden(node, { upTo }) {
	if (getComputedStyle(node).visibility === "hidden") return true;
	while (node) {
		if (upTo !== void 0 && node === upTo) return false;
		if (getComputedStyle(node).display === "none") return true;
		node = node.parentElement;
	}
	return false;
}
__name$4(isHidden, "isHidden");
function isSelectableInput(element) {
	return element instanceof HTMLInputElement && "select" in element;
}
__name$4(isSelectableInput, "isSelectableInput");
function focus(element, { select = false } = {}) {
	if (element && element.focus) {
		const previouslyFocusedElement = document.activeElement;
		element.focus({ preventScroll: true });
		if (element !== previouslyFocusedElement && isSelectableInput(element) && select) element.select();
	}
}
__name$4(focus, "focus");
var focusScopesStack = createFocusScopesStack();
function createFocusScopesStack() {
	let stack = [];
	return {
		add(focusScope) {
			const activeFocusScope = stack[0];
			if (focusScope !== activeFocusScope) activeFocusScope?.pause();
			stack = arrayRemove(stack, focusScope);
			stack.unshift(focusScope);
		},
		remove(focusScope) {
			stack = arrayRemove(stack, focusScope);
			stack[0]?.resume();
		}
	};
}
__name$4(createFocusScopesStack, "createFocusScopesStack");
function arrayRemove(array, item) {
	const updatedArray = [...array];
	const index = updatedArray.indexOf(item);
	if (index !== -1) updatedArray.splice(index, 1);
	return updatedArray;
}
__name$4(arrayRemove, "arrayRemove");
function removeLinks(items) {
	return items.filter((item) => item.tagName !== "A");
}
__name$4(removeLinks, "removeLinks");
//#endregion
//#region node_modules/@radix-ui/react-portal/dist/index.mjs
var __defProp$3 = Object.defineProperty;
var __name$3 = (target, value) => __defProp$3(target, "name", {
	value,
	configurable: true
});
var Portal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name$3(function Portal2(props, forwardedRef) {
	const { container: containerProp, ...portalProps } = props;
	const [mounted, setMounted] = import_react.useState(false);
	useLayoutEffect2$1(() => setMounted(true), []);
	const container = containerProp || mounted && globalThis?.document?.body;
	return container ? import_react_dom.createPortal(/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
		...portalProps,
		ref: forwardedRef
	}), container) : null;
}, "Portal"));
//#endregion
//#region node_modules/@radix-ui/react-presence/dist/index.mjs
var __defProp$2 = Object.defineProperty;
var __name$2 = (target, value) => __defProp$2(target, "name", {
	value,
	configurable: true
});
function useStateMachine(initialState, machine) {
	return import_react.useReducer((state, event) => {
		return machine[state][event] ?? state;
	}, initialState);
}
__name$2(useStateMachine, "useStateMachine");
var Presence = /* @__PURE__ */ __name$2((props) => {
	const { present, children } = props;
	const presence = usePresence(present);
	const child = typeof children === "function" ? children({ present: presence.isPresent }) : import_react.Children.only(children);
	const ref = useStableComposedRefs(presence.ref, getElementRef(child));
	return typeof children === "function" || presence.isPresent ? import_react.cloneElement(child, { ref }) : null;
}, "Presence");
function usePresence(present) {
	const [node, setNode] = import_react.useState();
	const stylesRef = import_react.useRef(null);
	const prevPresentRef = import_react.useRef(present);
	const prevAnimationNameRef = import_react.useRef("none");
	const mountAnimationNameRef = import_react.useRef(void 0);
	const [state, send] = useStateMachine(present ? "mounted" : "unmounted", {
		mounted: {
			UNMOUNT: "unmounted",
			ANIMATION_OUT: "unmountSuspended"
		},
		unmountSuspended: {
			MOUNT: "mounted",
			ANIMATION_END: "unmounted"
		},
		unmounted: { MOUNT: "mounted" }
	});
	import_react.useEffect(() => {
		if (state === "mounted") {
			prevAnimationNameRef.current = mountAnimationNameRef.current ?? getAnimationName(stylesRef.current);
			mountAnimationNameRef.current = void 0;
		} else prevAnimationNameRef.current = "none";
	}, [state]);
	useLayoutEffect2$1(() => {
		const styles = stylesRef.current;
		const wasPresent = prevPresentRef.current;
		if (wasPresent !== present) {
			const prevAnimationName = prevAnimationNameRef.current;
			const currentAnimationName = getAnimationName(styles);
			if (present) {
				mountAnimationNameRef.current = currentAnimationName;
				send("MOUNT");
			} else if (currentAnimationName === "none" || styles?.display === "none") send("UNMOUNT");
			else if (wasPresent && prevAnimationName !== currentAnimationName) send("ANIMATION_OUT");
			else send("UNMOUNT");
			prevPresentRef.current = present;
		}
	}, [present, send]);
	useLayoutEffect2$1(() => {
		if (node) {
			let timeoutId;
			const ownerWindow = node.ownerDocument.defaultView ?? window;
			const handleAnimationEnd = /* @__PURE__ */ __name$2((event) => {
				const isCurrentAnimation = getAnimationName(stylesRef.current).includes(CSS.escape(event.animationName));
				if (event.target === node && isCurrentAnimation) {
					send("ANIMATION_END");
					if (!prevPresentRef.current) {
						const currentFillMode = node.style.animationFillMode;
						node.style.animationFillMode = "forwards";
						timeoutId = ownerWindow.setTimeout(() => {
							if (node.style.animationFillMode === "forwards") node.style.animationFillMode = currentFillMode;
						});
					}
				}
			}, "handleAnimationEnd");
			const handleAnimationStart = /* @__PURE__ */ __name$2((event) => {
				if (event.target === node) prevAnimationNameRef.current = getAnimationName(stylesRef.current);
			}, "handleAnimationStart");
			node.addEventListener("animationstart", handleAnimationStart);
			node.addEventListener("animationcancel", handleAnimationEnd);
			node.addEventListener("animationend", handleAnimationEnd);
			return () => {
				ownerWindow.clearTimeout(timeoutId);
				node.removeEventListener("animationstart", handleAnimationStart);
				node.removeEventListener("animationcancel", handleAnimationEnd);
				node.removeEventListener("animationend", handleAnimationEnd);
			};
		} else send("ANIMATION_END");
	}, [node, send]);
	return {
		isPresent: ["mounted", "unmountSuspended"].includes(state),
		ref: import_react.useCallback((node2) => {
			if (node2) {
				const styles = getComputedStyle(node2);
				stylesRef.current = styles;
				mountAnimationNameRef.current = getAnimationName(styles);
			} else stylesRef.current = null;
			setNode(node2);
		}, [])
	};
}
__name$2(usePresence, "usePresence");
function setRef(ref, value) {
	if (typeof ref === "function") return ref(value);
	else if (ref !== null && ref !== void 0) ref.current = value;
}
__name$2(setRef, "setRef");
function useStableComposedRefs(...refs) {
	const refsRef = import_react.useRef(refs);
	refsRef.current = refs;
	return import_react.useCallback((node) => {
		const currentRefs = refsRef.current;
		let hasCleanup = false;
		const cleanups = currentRefs.map((ref) => {
			const cleanup = setRef(ref, node);
			if (!hasCleanup && typeof cleanup === "function") hasCleanup = true;
			return cleanup;
		});
		if (hasCleanup) return () => {
			for (let i = 0; i < cleanups.length; i++) {
				const cleanup = cleanups[i];
				if (typeof cleanup === "function") cleanup();
				else setRef(currentRefs[i], null);
			}
		};
	}, []);
}
__name$2(useStableComposedRefs, "useStableComposedRefs");
function getAnimationName(styles) {
	return styles?.animationName || "none";
}
__name$2(getAnimationName, "getAnimationName");
function getElementRef(element) {
	let getter = Object.getOwnPropertyDescriptor(element.props, "ref")?.get;
	let mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
	if (mayWarn) return element.ref;
	getter = Object.getOwnPropertyDescriptor(element, "ref")?.get;
	mayWarn = getter && "isReactWarning" in getter && getter.isReactWarning;
	if (mayWarn) return element.props.ref;
	return element.props.ref || element.ref;
}
__name$2(getElementRef, "getElementRef");
//#endregion
//#region node_modules/@radix-ui/react-focus-guards/dist/index.mjs
var __defProp$1 = Object.defineProperty;
var __name$1 = (target, value) => __defProp$1(target, "name", {
	value,
	configurable: true
});
var count = 0;
var guards = null;
function FocusGuards(props) {
	useFocusGuards();
	return props.children;
}
__name$1(FocusGuards, "FocusGuards");
function useFocusGuards() {
	import_react.useEffect(() => {
		if (!guards) guards = {
			start: createFocusGuard(),
			end: createFocusGuard()
		};
		const { start, end } = guards;
		if (document.body.firstElementChild !== start) document.body.insertAdjacentElement("afterbegin", start);
		if (document.body.lastElementChild !== end) document.body.insertAdjacentElement("beforeend", end);
		count++;
		return () => {
			if (count === 1) {
				guards?.start.remove();
				guards?.end.remove();
				guards = null;
			}
			count = Math.max(0, count - 1);
		};
	}, []);
}
__name$1(useFocusGuards, "useFocusGuards");
function createFocusGuard() {
	const element = document.createElement("span");
	element.setAttribute("data-radix-focus-guard", "");
	element.tabIndex = 0;
	element.style.outline = "none";
	element.style.opacity = "0";
	element.style.position = "fixed";
	element.style.pointerEvents = "none";
	return element;
}
__name$1(createFocusGuard, "createFocusGuard");
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/constants.js
var zeroRightClassName = "right-scroll-bar-position";
var fullWidthClassName = "width-before-scroll-bar";
var noScrollbarsClassName = "with-scroll-bars-hidden";
/**
* Name of a CSS variable containing the amount of "hidden" scrollbar
* ! might be undefined ! use will fallback!
*/
var removedBarSizeVariable = "--removed-body-scroll-bar-size";
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/assignRef.js
/**
* Assigns a value for a given ref, no matter of the ref format
* @param {RefObject} ref - a callback function or ref object
* @param value - a new value
*
* @see https://github.com/theKashey/use-callback-ref#assignref
* @example
* const refObject = useRef();
* const refFn = (ref) => {....}
*
* assignRef(refObject, "refValue");
* assignRef(refFn, "refValue");
*/
function assignRef(ref, value) {
	if (typeof ref === "function") ref(value);
	else if (ref) ref.current = value;
	return ref;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useRef.js
/**
* creates a MutableRef with ref change callback
* @param initialValue - initial ref value
* @param {Function} callback - a callback to run when value changes
*
* @example
* const ref = useCallbackRef(0, (newValue, oldValue) => console.log(oldValue, '->', newValue);
* ref.current = 1;
* // prints 0 -> 1
*
* @see https://reactjs.org/docs/hooks-reference.html#useref
* @see https://github.com/theKashey/use-callback-ref#usecallbackref---to-replace-reactuseref
* @returns {MutableRefObject}
*/
function useCallbackRef(initialValue, callback) {
	var ref = (0, import_react.useState)(function() {
		return {
			value: initialValue,
			callback,
			facade: {
				get current() {
					return ref.value;
				},
				set current(value) {
					var last = ref.value;
					if (last !== value) {
						ref.value = value;
						ref.callback(value, last);
					}
				}
			}
		};
	})[0];
	ref.callback = callback;
	return ref.facade;
}
//#endregion
//#region node_modules/use-callback-ref/dist/es2015/useMergeRef.js
var useIsomorphicLayoutEffect = typeof window !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect;
var currentValues = /* @__PURE__ */ new WeakMap();
/**
* Merges two or more refs together providing a single interface to set their value
* @param {RefObject|Ref} refs
* @returns {MutableRefObject} - a new ref, which translates all changes to {refs}
*
* @see {@link mergeRefs} a version without buit-in memoization
* @see https://github.com/theKashey/use-callback-ref#usemergerefs
* @example
* const Component = React.forwardRef((props, ref) => {
*   const ownRef = useRef();
*   const domRef = useMergeRefs([ref, ownRef]); // 👈 merge together
*   return <div ref={domRef}>...</div>
* }
*/
function useMergeRefs(refs, defaultValue) {
	var callbackRef = useCallbackRef(defaultValue || null, function(newValue) {
		return refs.forEach(function(ref) {
			return assignRef(ref, newValue);
		});
	});
	useIsomorphicLayoutEffect(function() {
		var oldValue = currentValues.get(callbackRef);
		if (oldValue) {
			var prevRefs_1 = new Set(oldValue);
			var nextRefs_1 = new Set(refs);
			var current_1 = callbackRef.current;
			prevRefs_1.forEach(function(ref) {
				if (!nextRefs_1.has(ref)) assignRef(ref, null);
			});
			nextRefs_1.forEach(function(ref) {
				if (!prevRefs_1.has(ref)) assignRef(ref, current_1);
			});
		}
		currentValues.set(callbackRef, refs);
	}, [refs]);
	return callbackRef;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/medium.js
function ItoI(a) {
	return a;
}
function innerCreateMedium(defaults, middleware) {
	if (middleware === void 0) middleware = ItoI;
	var buffer = [];
	var assigned = false;
	return {
		read: function() {
			if (assigned) throw new Error("Sidecar: could not `read` from an `assigned` medium. `read` could be used only with `useMedium`.");
			if (buffer.length) return buffer[buffer.length - 1];
			return defaults;
		},
		useMedium: function(data) {
			var item = middleware(data, assigned);
			buffer.push(item);
			return function() {
				buffer = buffer.filter(function(x) {
					return x !== item;
				});
			};
		},
		assignSyncMedium: function(cb) {
			assigned = true;
			while (buffer.length) {
				var cbs = buffer;
				buffer = [];
				cbs.forEach(cb);
			}
			buffer = {
				push: function(x) {
					return cb(x);
				},
				filter: function() {
					return buffer;
				}
			};
		},
		assignMedium: function(cb) {
			assigned = true;
			var pendingQueue = [];
			if (buffer.length) {
				var cbs = buffer;
				buffer = [];
				cbs.forEach(cb);
				pendingQueue = buffer;
			}
			var executeQueue = function() {
				var cbs = pendingQueue;
				pendingQueue = [];
				cbs.forEach(cb);
			};
			var cycle = function() {
				return Promise.resolve().then(executeQueue);
			};
			cycle();
			buffer = {
				push: function(x) {
					pendingQueue.push(x);
					cycle();
				},
				filter: function(filter) {
					pendingQueue = pendingQueue.filter(filter);
					return buffer;
				}
			};
		}
	};
}
function createSidecarMedium(options) {
	if (options === void 0) options = {};
	var medium = innerCreateMedium(null);
	medium.options = __assign({
		async: true,
		ssr: false
	}, options);
	return medium;
}
//#endregion
//#region node_modules/use-sidecar/dist/es2015/exports.js
var SideCar = function(_a) {
	var sideCar = _a.sideCar, rest = __rest(_a, ["sideCar"]);
	if (!sideCar) throw new Error("Sidecar: please provide `sideCar` property to import the right car");
	var Target = sideCar.read();
	if (!Target) throw new Error("Sidecar medium not found");
	return import_react.createElement(Target, __assign({}, rest));
};
SideCar.isSideCarExport = true;
function exportSidecar(medium, exported) {
	medium.useMedium(exported);
	return SideCar;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/medium.js
var effectCar = createSidecarMedium();
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/UI.js
var nothing = function() {};
/**
* Removes scrollbar from the page and contain the scroll within the Lock
*/
var RemoveScroll = import_react.forwardRef(function(props, parentRef) {
	var ref = import_react.useRef(null);
	var _a = import_react.useState({
		onScrollCapture: nothing,
		onWheelCapture: nothing,
		onTouchMoveCapture: nothing
	}), callbacks = _a[0], setCallbacks = _a[1];
	var forwardProps = props.forwardProps, children = props.children, className = props.className, removeScrollBar = props.removeScrollBar, enabled = props.enabled, shards = props.shards, sideCar = props.sideCar, noRelative = props.noRelative, noIsolation = props.noIsolation, inert = props.inert, allowPinchZoom = props.allowPinchZoom, _b = props.as, Container = _b === void 0 ? "div" : _b, gapMode = props.gapMode, rest = __rest(props, [
		"forwardProps",
		"children",
		"className",
		"removeScrollBar",
		"enabled",
		"shards",
		"sideCar",
		"noRelative",
		"noIsolation",
		"inert",
		"allowPinchZoom",
		"as",
		"gapMode"
	]);
	var SideCar = sideCar;
	var containerRef = useMergeRefs([ref, parentRef]);
	var containerProps = __assign(__assign({}, rest), callbacks);
	return import_react.createElement(import_react.Fragment, null, enabled && import_react.createElement(SideCar, {
		sideCar: effectCar,
		removeScrollBar,
		shards,
		noRelative,
		noIsolation,
		inert,
		setCallbacks,
		allowPinchZoom: !!allowPinchZoom,
		lockRef: ref,
		gapMode
	}), forwardProps ? import_react.cloneElement(import_react.Children.only(children), __assign(__assign({}, containerProps), { ref: containerRef })) : import_react.createElement(Container, __assign({}, containerProps, {
		className,
		ref: containerRef
	}), children));
});
RemoveScroll.defaultProps = {
	enabled: true,
	removeScrollBar: true,
	inert: false
};
RemoveScroll.classNames = {
	fullWidth: fullWidthClassName,
	zeroRight: zeroRightClassName
};
var getNonce = function() {
	if (typeof __webpack_nonce__ !== "undefined") return __webpack_nonce__;
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/singleton.js
function makeStyleTag() {
	if (!document) return null;
	var tag = document.createElement("style");
	tag.type = "text/css";
	var nonce = getNonce();
	if (nonce) tag.setAttribute("nonce", nonce);
	return tag;
}
function injectStyles(tag, css) {
	if (tag.styleSheet) tag.styleSheet.cssText = css;
	else tag.appendChild(document.createTextNode(css));
}
function insertStyleTag(tag) {
	(document.head || document.getElementsByTagName("head")[0]).appendChild(tag);
}
var stylesheetSingleton = function() {
	var counter = 0;
	var stylesheet = null;
	return {
		add: function(style) {
			if (counter == 0) {
				if (stylesheet = makeStyleTag()) {
					injectStyles(stylesheet, style);
					insertStyleTag(stylesheet);
				}
			}
			counter++;
		},
		remove: function() {
			counter--;
			if (!counter && stylesheet) {
				stylesheet.parentNode && stylesheet.parentNode.removeChild(stylesheet);
				stylesheet = null;
			}
		}
	};
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/hook.js
/**
* creates a hook to control style singleton
* @see {@link styleSingleton} for a safer component version
* @example
* ```tsx
* const useStyle = styleHookSingleton();
* ///
* useStyle('body { overflow: hidden}');
*/
var styleHookSingleton = function() {
	var sheet = stylesheetSingleton();
	return function(styles, isDynamic) {
		import_react.useEffect(function() {
			sheet.add(styles);
			return function() {
				sheet.remove();
			};
		}, [styles && isDynamic]);
	};
};
//#endregion
//#region node_modules/react-style-singleton/dist/es2015/component.js
/**
* create a Component to add styles on demand
* - styles are added when first instance is mounted
* - styles are removed when the last instance is unmounted
* - changing styles in runtime does nothing unless dynamic is set. But with multiple components that can lead to the undefined behavior
*/
var styleSingleton = function() {
	var useStyle = styleHookSingleton();
	var Sheet = function(_a) {
		var styles = _a.styles, dynamic = _a.dynamic;
		useStyle(styles, dynamic);
		return null;
	};
	return Sheet;
};
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/utils.js
var zeroGap = {
	left: 0,
	top: 0,
	right: 0,
	gap: 0
};
var parse$1 = function(x) {
	return parseInt(x || "", 10) || 0;
};
var getOffset = function(gapMode) {
	var cs = window.getComputedStyle(document.body);
	var left = cs[gapMode === "padding" ? "paddingLeft" : "marginLeft"];
	var top = cs[gapMode === "padding" ? "paddingTop" : "marginTop"];
	var right = cs[gapMode === "padding" ? "paddingRight" : "marginRight"];
	return [
		parse$1(left),
		parse$1(top),
		parse$1(right)
	];
};
var getGapWidth = function(gapMode) {
	if (gapMode === void 0) gapMode = "margin";
	if (typeof window === "undefined") return zeroGap;
	var offsets = getOffset(gapMode);
	var documentWidth = document.documentElement.clientWidth;
	var windowWidth = window.innerWidth;
	return {
		left: offsets[0],
		top: offsets[1],
		right: offsets[2],
		gap: Math.max(0, windowWidth - documentWidth + offsets[2] - offsets[0])
	};
};
//#endregion
//#region node_modules/react-remove-scroll-bar/dist/es2015/component.js
var Style = styleSingleton();
var lockAttribute = "data-scroll-locked";
var getStyles = function(_a, allowRelative, gapMode, important) {
	var left = _a.left, top = _a.top, right = _a.right, gap = _a.gap;
	if (gapMode === void 0) gapMode = "margin";
	return "\n  .".concat(noScrollbarsClassName, " {\n   overflow: hidden ").concat(important, ";\n   padding-right: ").concat(gap, "px ").concat(important, ";\n  }\n  body[").concat(lockAttribute, "] {\n    overflow: hidden ").concat(important, ";\n    overscroll-behavior: contain;\n    ").concat([
		allowRelative && "position: relative ".concat(important, ";"),
		gapMode === "margin" && "\n    padding-left: ".concat(left, "px;\n    padding-top: ").concat(top, "px;\n    padding-right: ").concat(right, "px;\n    margin-left:0;\n    margin-top:0;\n    margin-right: ").concat(gap, "px ").concat(important, ";\n    "),
		gapMode === "padding" && "padding-right: ".concat(gap, "px ").concat(important, ";")
	].filter(Boolean).join(""), "\n  }\n  \n  .").concat(zeroRightClassName, " {\n    right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " {\n    margin-right: ").concat(gap, "px ").concat(important, ";\n  }\n  \n  .").concat(zeroRightClassName, " .").concat(zeroRightClassName, " {\n    right: 0 ").concat(important, ";\n  }\n  \n  .").concat(fullWidthClassName, " .").concat(fullWidthClassName, " {\n    margin-right: 0 ").concat(important, ";\n  }\n  \n  body[").concat(lockAttribute, "] {\n    ").concat(removedBarSizeVariable, ": ").concat(gap, "px;\n  }\n");
};
var getCurrentUseCounter = function() {
	var counter = parseInt(document.body.getAttribute("data-scroll-locked") || "0", 10);
	return isFinite(counter) ? counter : 0;
};
var useLockAttribute = function() {
	import_react.useEffect(function() {
		document.body.setAttribute(lockAttribute, (getCurrentUseCounter() + 1).toString());
		return function() {
			var newCounter = getCurrentUseCounter() - 1;
			if (newCounter <= 0) document.body.removeAttribute(lockAttribute);
			else document.body.setAttribute(lockAttribute, newCounter.toString());
		};
	}, []);
};
/**
* Removes page scrollbar and blocks page scroll when mounted
*/
var RemoveScrollBar = function(_a) {
	var noRelative = _a.noRelative, noImportant = _a.noImportant, _b = _a.gapMode, gapMode = _b === void 0 ? "margin" : _b;
	useLockAttribute();
	var gap = import_react.useMemo(function() {
		return getGapWidth(gapMode);
	}, [gapMode]);
	return import_react.createElement(Style, { styles: getStyles(gap, !noRelative, gapMode, !noImportant ? "!important" : "") });
};
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/aggresiveCapture.js
var passiveSupported = false;
if (typeof window !== "undefined") try {
	var options = Object.defineProperty({}, "passive", { get: function() {
		passiveSupported = true;
		return true;
	} });
	window.addEventListener("test", options, options);
	window.removeEventListener("test", options, options);
} catch (err) {
	passiveSupported = false;
}
var nonPassive = passiveSupported ? { passive: false } : false;
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/handleScroll.js
var alwaysContainsScroll = function(node) {
	return node.tagName === "TEXTAREA";
};
var elementCanBeScrolled = function(node, overflow) {
	if (!(node instanceof Element)) return false;
	var styles = window.getComputedStyle(node);
	return styles[overflow] !== "hidden" && !(styles.overflowY === styles.overflowX && !alwaysContainsScroll(node) && styles[overflow] === "visible");
};
var elementCouldBeVScrolled = function(node) {
	return elementCanBeScrolled(node, "overflowY");
};
var elementCouldBeHScrolled = function(node) {
	return elementCanBeScrolled(node, "overflowX");
};
var locationCouldBeScrolled = function(axis, node) {
	var ownerDocument = node.ownerDocument;
	var current = node;
	do {
		if (typeof ShadowRoot !== "undefined" && current instanceof ShadowRoot) current = current.host;
		if (elementCouldBeScrolled(axis, current)) {
			var _a = getScrollVariables(axis, current);
			if (_a[1] > _a[2]) return true;
		}
		current = current.parentNode;
	} while (current && current !== ownerDocument.body);
	return false;
};
var getVScrollVariables = function(_a) {
	return [
		_a.scrollTop,
		_a.scrollHeight,
		_a.clientHeight
	];
};
var getHScrollVariables = function(_a) {
	return [
		_a.scrollLeft,
		_a.scrollWidth,
		_a.clientWidth
	];
};
var elementCouldBeScrolled = function(axis, node) {
	return axis === "v" ? elementCouldBeVScrolled(node) : elementCouldBeHScrolled(node);
};
var getScrollVariables = function(axis, node) {
	return axis === "v" ? getVScrollVariables(node) : getHScrollVariables(node);
};
var getDirectionFactor = function(axis, direction) {
	/**
	* If the element's direction is rtl (right-to-left), then scrollLeft is 0 when the scrollbar is at its rightmost position,
	* and then increasingly negative as you scroll towards the end of the content.
	* @see https://developer.mozilla.org/en-US/docs/Web/API/Element/scrollLeft
	*/
	return axis === "h" && direction === "rtl" ? -1 : 1;
};
var handleScroll = function(axis, endTarget, event, sourceDelta, noOverscroll) {
	var directionFactor = getDirectionFactor(axis, window.getComputedStyle(endTarget).direction);
	var delta = directionFactor * sourceDelta;
	var target = event.target;
	var targetInLock = endTarget.contains(target);
	var shouldCancelScroll = false;
	var isDeltaPositive = delta > 0;
	var availableScroll = 0;
	var availableScrollTop = 0;
	do {
		if (!target) break;
		var _a = getScrollVariables(axis, target), position = _a[0];
		var elementScroll = _a[1] - _a[2] - directionFactor * position;
		if (position || elementScroll) {
			if (elementCouldBeScrolled(axis, target)) {
				availableScroll += elementScroll;
				availableScrollTop += position;
			}
		}
		var parent_1 = target.parentNode;
		target = parent_1 && parent_1.nodeType === Node.DOCUMENT_FRAGMENT_NODE ? parent_1.host : parent_1;
	} while (!targetInLock && target !== document.body || targetInLock && (endTarget.contains(target) || endTarget === target));
	if (isDeltaPositive && (noOverscroll && Math.abs(availableScroll) < 1 || !noOverscroll && delta > availableScroll)) shouldCancelScroll = true;
	else if (!isDeltaPositive && (noOverscroll && Math.abs(availableScrollTop) < 1 || !noOverscroll && -delta > availableScrollTop)) shouldCancelScroll = true;
	return shouldCancelScroll;
};
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/SideEffect.js
var getTouchXY = function(event) {
	return "changedTouches" in event ? [event.changedTouches[0].clientX, event.changedTouches[0].clientY] : [0, 0];
};
var getDeltaXY = function(event) {
	return [event.deltaX, event.deltaY];
};
var extractRef = function(ref) {
	return ref && "current" in ref ? ref.current : ref;
};
var deltaCompare = function(x, y) {
	return x[0] === y[0] && x[1] === y[1];
};
var generateStyle = function(id) {
	return "\n  .block-interactivity-".concat(id, " {pointer-events: none;}\n  .allow-interactivity-").concat(id, " {pointer-events: all;}\n");
};
var idCounter = 0;
var lockStack = [];
function RemoveScrollSideCar(props) {
	var shouldPreventQueue = import_react.useRef([]);
	var touchStartRef = import_react.useRef([0, 0]);
	var activeAxis = import_react.useRef();
	var id = import_react.useState(idCounter++)[0];
	var Style = import_react.useState(styleSingleton)[0];
	var lastProps = import_react.useRef(props);
	import_react.useEffect(function() {
		lastProps.current = props;
	}, [props]);
	import_react.useEffect(function() {
		if (props.inert) {
			document.body.classList.add("block-interactivity-".concat(id));
			var allow_1 = __spreadArray([props.lockRef.current], (props.shards || []).map(extractRef), true).filter(Boolean);
			allow_1.forEach(function(el) {
				return el.classList.add("allow-interactivity-".concat(id));
			});
			return function() {
				document.body.classList.remove("block-interactivity-".concat(id));
				allow_1.forEach(function(el) {
					return el.classList.remove("allow-interactivity-".concat(id));
				});
			};
		}
	}, [
		props.inert,
		props.lockRef.current,
		props.shards
	]);
	var shouldCancelEvent = import_react.useCallback(function(event, parent) {
		if ("touches" in event && event.touches.length === 2 || event.type === "wheel" && event.ctrlKey) return !lastProps.current.allowPinchZoom;
		var touch = getTouchXY(event);
		var touchStart = touchStartRef.current;
		var deltaX = "deltaX" in event ? event.deltaX : touchStart[0] - touch[0];
		var deltaY = "deltaY" in event ? event.deltaY : touchStart[1] - touch[1];
		var currentAxis;
		var target = event.target;
		var moveDirection = Math.abs(deltaX) > Math.abs(deltaY) ? "h" : "v";
		if ("touches" in event && moveDirection === "h" && target.type === "range") return false;
		var selection = window.getSelection();
		var anchorNode = selection && selection.anchorNode;
		if (anchorNode ? anchorNode === target || anchorNode.contains(target) : false) return false;
		var canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
		if (!canBeScrolledInMainDirection) return true;
		if (canBeScrolledInMainDirection) currentAxis = moveDirection;
		else {
			currentAxis = moveDirection === "v" ? "h" : "v";
			canBeScrolledInMainDirection = locationCouldBeScrolled(moveDirection, target);
		}
		if (!canBeScrolledInMainDirection) return false;
		if (!activeAxis.current && "changedTouches" in event && (deltaX || deltaY)) activeAxis.current = currentAxis;
		if (!currentAxis) return true;
		var cancelingAxis = activeAxis.current || currentAxis;
		return handleScroll(cancelingAxis, parent, event, cancelingAxis === "h" ? deltaX : deltaY, true);
	}, []);
	var shouldPrevent = import_react.useCallback(function(_event) {
		var event = _event;
		if (!lockStack.length || lockStack[lockStack.length - 1] !== Style) return;
		var delta = "deltaY" in event ? getDeltaXY(event) : getTouchXY(event);
		var sourceEvent = shouldPreventQueue.current.filter(function(e) {
			return e.name === event.type && (e.target === event.target || event.target === e.shadowParent) && deltaCompare(e.delta, delta);
		})[0];
		if (sourceEvent && sourceEvent.should) {
			if (event.cancelable) event.preventDefault();
			return;
		}
		if (!sourceEvent) {
			var shardNodes = (lastProps.current.shards || []).map(extractRef).filter(Boolean).filter(function(node) {
				return node.contains(event.target);
			});
			if (shardNodes.length > 0 ? shouldCancelEvent(event, shardNodes[0]) : !lastProps.current.noIsolation) {
				if (event.cancelable) event.preventDefault();
			}
		}
	}, []);
	var shouldCancel = import_react.useCallback(function(name, delta, target, should) {
		var event = {
			name,
			delta,
			target,
			should,
			shadowParent: getOutermostShadowParent(target)
		};
		shouldPreventQueue.current.push(event);
		setTimeout(function() {
			shouldPreventQueue.current = shouldPreventQueue.current.filter(function(e) {
				return e !== event;
			});
		}, 1);
	}, []);
	var scrollTouchStart = import_react.useCallback(function(event) {
		touchStartRef.current = getTouchXY(event);
		activeAxis.current = void 0;
	}, []);
	var scrollWheel = import_react.useCallback(function(event) {
		shouldCancel(event.type, getDeltaXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
	}, []);
	var scrollTouchMove = import_react.useCallback(function(event) {
		shouldCancel(event.type, getTouchXY(event), event.target, shouldCancelEvent(event, props.lockRef.current));
	}, []);
	import_react.useEffect(function() {
		lockStack.push(Style);
		props.setCallbacks({
			onScrollCapture: scrollWheel,
			onWheelCapture: scrollWheel,
			onTouchMoveCapture: scrollTouchMove
		});
		document.addEventListener("wheel", shouldPrevent, nonPassive);
		document.addEventListener("touchmove", shouldPrevent, nonPassive);
		document.addEventListener("touchstart", scrollTouchStart, nonPassive);
		return function() {
			lockStack = lockStack.filter(function(inst) {
				return inst !== Style;
			});
			document.removeEventListener("wheel", shouldPrevent, nonPassive);
			document.removeEventListener("touchmove", shouldPrevent, nonPassive);
			document.removeEventListener("touchstart", scrollTouchStart, nonPassive);
		};
	}, []);
	var removeScrollBar = props.removeScrollBar, inert = props.inert;
	return import_react.createElement(import_react.Fragment, null, inert ? import_react.createElement(Style, { styles: generateStyle(id) }) : null, removeScrollBar ? import_react.createElement(RemoveScrollBar, {
		noRelative: props.noRelative,
		gapMode: props.gapMode
	}) : null);
}
function getOutermostShadowParent(node) {
	var shadowParent = null;
	while (node !== null) {
		if (node instanceof ShadowRoot) {
			shadowParent = node.host;
			node = node.host;
		}
		node = node.parentNode;
	}
	return shadowParent;
}
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/sidecar.js
var sidecar_default = exportSidecar(effectCar, RemoveScrollSideCar);
//#endregion
//#region node_modules/react-remove-scroll/dist/es2015/Combination.js
var ReactRemoveScroll = import_react.forwardRef(function(props, ref) {
	return import_react.createElement(RemoveScroll, __assign({}, props, {
		ref,
		sideCar: sidecar_default
	}));
});
ReactRemoveScroll.classNames = RemoveScroll.classNames;
//#endregion
//#region node_modules/aria-hidden/dist/es2015/index.js
var getDefaultParent = function(originalTarget) {
	if (typeof document === "undefined") return null;
	return (Array.isArray(originalTarget) ? originalTarget[0] : originalTarget).ownerDocument.body;
};
var counterMap = /* @__PURE__ */ new WeakMap();
var uncontrolledNodes = /* @__PURE__ */ new WeakMap();
var markerMap = {};
var lockCount = 0;
var unwrapHost = function(node) {
	return node && (node.host || unwrapHost(node.parentNode));
};
var correctTargets = function(parent, targets) {
	return targets.map(function(target) {
		if (parent.contains(target)) return target;
		var correctedTarget = unwrapHost(target);
		if (correctedTarget && parent.contains(correctedTarget)) return correctedTarget;
		console.error("aria-hidden", target, "in not contained inside", parent, ". Doing nothing");
		return null;
	}).filter(function(x) {
		return Boolean(x);
	});
};
/**
* Marks everything except given node(or nodes) as aria-hidden
* @param {Element | Element[]} originalTarget - elements to keep on the page
* @param [parentNode] - top element, defaults to document.body
* @param {String} [markerName] - a special attribute to mark every node
* @param {String} [controlAttribute] - html Attribute to control
* @return {Undo} undo command
*/
var applyAttributeToOthers = function(originalTarget, parentNode, markerName, controlAttribute) {
	var targets = correctTargets(parentNode, Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
	if (!markerMap[markerName]) markerMap[markerName] = /* @__PURE__ */ new WeakMap();
	var markerCounter = markerMap[markerName];
	var hiddenNodes = [];
	var elementsToKeep = /* @__PURE__ */ new Set();
	var elementsToStop = new Set(targets);
	var keep = function(el) {
		if (!el || elementsToKeep.has(el)) return;
		elementsToKeep.add(el);
		keep(el.parentNode);
	};
	targets.forEach(keep);
	var deep = function(parent) {
		if (!parent || elementsToStop.has(parent)) return;
		Array.prototype.forEach.call(parent.children, function(node) {
			if (elementsToKeep.has(node)) deep(node);
			else try {
				var attr = node.getAttribute(controlAttribute);
				var alreadyHidden = attr !== null && attr !== "false";
				var counterValue = (counterMap.get(node) || 0) + 1;
				var markerValue = (markerCounter.get(node) || 0) + 1;
				counterMap.set(node, counterValue);
				markerCounter.set(node, markerValue);
				hiddenNodes.push(node);
				if (counterValue === 1 && alreadyHidden) uncontrolledNodes.set(node, true);
				if (markerValue === 1) node.setAttribute(markerName, "true");
				if (!alreadyHidden) node.setAttribute(controlAttribute, "true");
			} catch (e) {
				console.error("aria-hidden: cannot operate on ", node, e);
			}
		});
	};
	deep(parentNode);
	elementsToKeep.clear();
	lockCount++;
	return function() {
		hiddenNodes.forEach(function(node) {
			var counterValue = counterMap.get(node) - 1;
			var markerValue = markerCounter.get(node) - 1;
			counterMap.set(node, counterValue);
			markerCounter.set(node, markerValue);
			if (!counterValue) {
				if (!uncontrolledNodes.has(node)) node.removeAttribute(controlAttribute);
				uncontrolledNodes.delete(node);
			}
			if (!markerValue) node.removeAttribute(markerName);
		});
		lockCount--;
		if (!lockCount) {
			counterMap = /* @__PURE__ */ new WeakMap();
			counterMap = /* @__PURE__ */ new WeakMap();
			uncontrolledNodes = /* @__PURE__ */ new WeakMap();
			markerMap = {};
		}
	};
};
/**
* Marks everything except given node(or nodes) as aria-hidden
* @param {Element | Element[]} originalTarget - elements to keep on the page
* @param [parentNode] - top element, defaults to document.body
* @param {String} [markerName] - a special attribute to mark every node
* @return {Undo} undo command
*/
var hideOthers = function(originalTarget, parentNode, markerName) {
	if (markerName === void 0) markerName = "data-aria-hidden";
	var targets = Array.from(Array.isArray(originalTarget) ? originalTarget : [originalTarget]);
	var activeParentNode = parentNode || getDefaultParent(originalTarget);
	if (!activeParentNode) return function() {
		return null;
	};
	targets.push.apply(targets, Array.from(activeParentNode.querySelectorAll("[aria-live], script")));
	return applyAttributeToOthers(targets, activeParentNode, markerName, "aria-hidden");
};
//#endregion
//#region node_modules/@radix-ui/react-dialog/dist/index.mjs
var __defProp = Object.defineProperty;
var __name = (target, value) => __defProp(target, "name", {
	value,
	configurable: true
});
var DIALOG_NAME = "Dialog";
var [createDialogContext, createDialogScope] = /* @__PURE__ */ createContextScope(DIALOG_NAME);
var [DialogProvider, useDialogContext] = createDialogContext(DIALOG_NAME);
var Dialog = /* @__PURE__ */ __name((props) => {
	const { __scopeDialog, children, open: openProp, defaultOpen, onOpenChange, modal = true } = props;
	const triggerRef = import_react.useRef(null);
	const contentRef = import_react.useRef(null);
	const [open, setOpen] = useControllableState({
		prop: openProp,
		defaultProp: defaultOpen ?? false,
		onChange: onOpenChange,
		caller: DIALOG_NAME
	});
	const [titleCount, setTitleCount] = import_react.useState(0);
	const [descriptionCount, setDescriptionCount] = import_react.useState(0);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogProvider, {
		scope: __scopeDialog,
		triggerRef,
		contentRef,
		contentId: useId(),
		titleId: useId(),
		descriptionId: useId(),
		titlePresent: titleCount > 0,
		descriptionPresent: descriptionCount > 0,
		setTitleCount,
		setDescriptionCount,
		open,
		onOpenChange: setOpen,
		onOpenToggle: import_react.useCallback(() => setOpen((prevOpen) => !prevOpen), [setOpen]),
		modal,
		children
	});
}, "Dialog");
var TRIGGER_NAME = "DialogTrigger";
var DialogTrigger = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogTrigger2(props, forwardedRef) {
	const { __scopeDialog, ...triggerProps } = props;
	const context = useDialogContext(TRIGGER_NAME, __scopeDialog);
	const composedTriggerRef = useComposedRefs(forwardedRef, context.triggerRef);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
		type: "button",
		"aria-haspopup": "dialog",
		"aria-expanded": context.open,
		"aria-controls": context.open ? context.contentId : void 0,
		"data-state": getState(context.open),
		...triggerProps,
		ref: composedTriggerRef,
		onClick: composeEventHandlers(props.onClick, context.onOpenToggle)
	});
}, "DialogTrigger"));
var PORTAL_NAME = "DialogPortal";
var [PortalProvider, usePortalContext] = createDialogContext(PORTAL_NAME, { forceMount: void 0 });
var DialogPortal = /* @__PURE__ */ __name((props) => {
	const { __scopeDialog, forceMount, children, container } = props;
	const context = useDialogContext(PORTAL_NAME, __scopeDialog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PortalProvider, {
		scope: __scopeDialog,
		forceMount,
		children: import_react.Children.map(children, (child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
			present: forceMount || context.open,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal, {
				asChild: true,
				container,
				children: child
			})
		}))
	});
}, "DialogPortal");
var OVERLAY_NAME = "DialogOverlay";
var DialogOverlay = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogOverlay2(props, forwardedRef) {
	const portalContext = usePortalContext(OVERLAY_NAME, props.__scopeDialog);
	const { forceMount = portalContext.forceMount, ...overlayProps } = props;
	const context = useDialogContext(OVERLAY_NAME, props.__scopeDialog);
	return context.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || context.open,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlayImpl, {
			...overlayProps,
			ref: forwardedRef
		})
	}) : null;
}, "DialogOverlay"));
var Slot = /* @__PURE__ */ createSlot("DialogOverlay.RemoveScroll");
var DialogOverlayImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogOverlayImpl2(props, forwardedRef) {
	const { __scopeDialog, ...overlayProps } = props;
	const context = useDialogContext(OVERLAY_NAME, __scopeDialog);
	const composedRefs = useComposedRefs(forwardedRef, useDismissableLayerSurface());
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ReactRemoveScroll, {
		as: Slot,
		allowPinchZoom: true,
		shards: [context.contentRef],
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.div, {
			"data-state": getState(context.open),
			...overlayProps,
			ref: composedRefs,
			style: {
				pointerEvents: "auto",
				...overlayProps.style
			}
		})
	});
}, "DialogOverlayImpl"));
var CONTENT_NAME = "DialogContent";
var DialogContent = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContent2(props, forwardedRef) {
	const portalContext = usePortalContext(CONTENT_NAME, props.__scopeDialog);
	const { forceMount = portalContext.forceMount, ...contentProps } = props;
	const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Presence, {
		present: forceMount || context.open,
		children: context.modal ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentModal, {
			...contentProps,
			ref: forwardedRef
		}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentNonModal, {
			...contentProps,
			ref: forwardedRef
		})
	});
}, "DialogContent"));
var DialogContentModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContentModal2(props, forwardedRef) {
	const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
	const contentRef = import_react.useRef(null);
	const composedRefs = useComposedRefs(forwardedRef, context.contentRef, contentRef);
	import_react.useEffect(() => {
		const content = contentRef.current;
		if (content) return hideOthers(content);
	}, []);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentImpl, {
		...props,
		ref: composedRefs,
		trapFocus: context.open,
		disableOutsidePointerEvents: context.open,
		onCloseAutoFocus: composeEventHandlers(props.onCloseAutoFocus, (event) => {
			event.preventDefault();
			context.triggerRef.current?.focus();
		}),
		onPointerDownOutside: composeEventHandlers(props.onPointerDownOutside, (event) => {
			const originalEvent = event.detail.originalEvent;
			const ctrlLeftClick = originalEvent.button === 0 && originalEvent.ctrlKey === true;
			if (originalEvent.button === 2 || ctrlLeftClick) event.preventDefault();
		}),
		onFocusOutside: composeEventHandlers(props.onFocusOutside, (event) => event.preventDefault())
	});
}, "DialogContentModal"));
var DialogContentNonModal = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContentNonModal2(props, forwardedRef) {
	const context = useDialogContext(CONTENT_NAME, props.__scopeDialog);
	const hasInteractedOutsideRef = import_react.useRef(false);
	const hasPointerDownOutsideRef = import_react.useRef(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogContentImpl, {
		...props,
		ref: forwardedRef,
		trapFocus: false,
		disableOutsidePointerEvents: false,
		onCloseAutoFocus: (event) => {
			props.onCloseAutoFocus?.(event);
			if (!event.defaultPrevented) {
				if (!hasInteractedOutsideRef.current) context.triggerRef.current?.focus();
				event.preventDefault();
			}
			hasInteractedOutsideRef.current = false;
			hasPointerDownOutsideRef.current = false;
		},
		onInteractOutside: (event) => {
			props.onInteractOutside?.(event);
			if (!event.defaultPrevented) {
				hasInteractedOutsideRef.current = true;
				if (event.detail.originalEvent.type === "pointerdown") hasPointerDownOutsideRef.current = true;
			}
			const target = event.target;
			if (context.triggerRef.current?.contains(target)) event.preventDefault();
			if (event.detail.originalEvent.type === "focusin" && hasPointerDownOutsideRef.current) event.preventDefault();
		}
	});
}, "DialogContentNonModal"));
var DialogContentImpl = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogContentImpl2(props, forwardedRef) {
	const { __scopeDialog, trapFocus, onOpenAutoFocus, onCloseAutoFocus, ...contentProps } = props;
	const context = useDialogContext(CONTENT_NAME, __scopeDialog);
	useFocusGuards();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(import_jsx_runtime.Fragment, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FocusScope, {
		asChild: true,
		loop: true,
		trapped: trapFocus,
		onMountAutoFocus: onOpenAutoFocus,
		onUnmountAutoFocus: onCloseAutoFocus,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DismissableLayer, {
			role: "dialog",
			id: context.contentId,
			"aria-describedby": context.descriptionPresent ? context.descriptionId : void 0,
			"aria-labelledby": context.titlePresent ? context.titleId : void 0,
			"data-state": getState(context.open),
			...contentProps,
			ref: forwardedRef,
			deferPointerDownOutside: true,
			onDismiss: () => context.onOpenChange(false)
		})
	}) });
}, "DialogContentImpl"));
var TITLE_NAME = "DialogTitle";
var DialogTitle = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogTitle2(props, forwardedRef) {
	const { __scopeDialog, ...titleProps } = props;
	const context = useDialogContext(TITLE_NAME, __scopeDialog);
	const { setTitleCount } = context;
	useLayoutEffect2$1(() => {
		setTitleCount((count) => count + 1);
		return () => setTitleCount((count) => count - 1);
	}, [setTitleCount]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.h2, {
		id: context.titleId,
		...titleProps,
		ref: forwardedRef
	});
}, "DialogTitle"));
var CLOSE_NAME = "DialogClose";
var DialogClose = /* @__PURE__ */ import_react.forwardRef(/* @__PURE__ */ __name(function DialogClose2(props, forwardedRef) {
	const { __scopeDialog, ...closeProps } = props;
	const context = useDialogContext(CLOSE_NAME, __scopeDialog);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Primitive.button, {
		type: "button",
		...closeProps,
		ref: forwardedRef,
		onClick: composeEventHandlers(props.onClick, () => context.onOpenChange(false))
	});
}, "DialogClose"));
function getState(open) {
	return open ? "open" : "closed";
}
__name(getState, "getState");
//#endregion
//#region node_modules/clsx/dist/clsx.mjs
function r(e) {
	var t, f, n = "";
	if ("string" == typeof e || "number" == typeof e) n += e;
	else if ("object" == typeof e) if (Array.isArray(e)) {
		var o = e.length;
		for (t = 0; t < o; t++) e[t] && (f = r(e[t])) && (n && (n += " "), n += f);
	} else for (f in e) e[f] && (n && (n += " "), n += f);
	return n;
}
function clsx() {
	for (var e, t, f = 0, n = "", o = arguments.length; f < o; f++) (e = arguments[f]) && (t = r(e)) && (n && (n += " "), n += t);
	return n;
}
//#endregion
//#region node_modules/@mysten/wallet-standard/dist/wallet.mjs
async function signTransaction(wallet, input) {
	if (wallet.features["sui:signTransaction"]) return wallet.features["sui:signTransaction"].signTransaction(input);
	if (!wallet.features["sui:signTransactionBlock"]) throw new Error(`Provided wallet (${wallet.name}) does not support the signTransaction feature.`);
	const { signTransactionBlock } = wallet.features["sui:signTransactionBlock"];
	const { transactionBlockBytes, signature } = await signTransactionBlock({
		transactionBlock: Transaction.from(await input.transaction.toJSON()),
		account: input.account,
		chain: input.chain
	});
	return {
		bytes: transactionBlockBytes,
		signature
	};
}
//#endregion
//#region node_modules/@wallet-standard/app/lib/esm/wallets.js
var __classPrivateFieldGet$1 = function(receiver, state, kind, f) {
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
	return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet$1 = function(receiver, state, value, kind, f) {
	if (kind === "m") throw new TypeError("Private method is not writable");
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
	return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var _AppReadyEvent_detail;
var wallets = void 0;
var registeredWalletsSet = /* @__PURE__ */ new Set();
function addRegisteredWallet(wallet) {
	cachedWalletsArray = void 0;
	registeredWalletsSet.add(wallet);
}
function removeRegisteredWallet(wallet) {
	cachedWalletsArray = void 0;
	registeredWalletsSet.delete(wallet);
}
var listeners = {};
/**
* Get an API for {@link Wallets.get | getting}, {@link Wallets.on | listening for}, and
* {@link Wallets.register | registering} {@link "@wallet-standard/base".Wallet | Wallets}.
*
* When called for the first time --
*
* This dispatches a {@link "@wallet-standard/base".WindowAppReadyEvent} to notify each Wallet that the app is ready
* to register it.
*
* This also adds a listener for {@link "@wallet-standard/base".WindowRegisterWalletEvent} to listen for a notification
* from each Wallet that the Wallet is ready to be registered by the app.
*
* This combination of event dispatch and listener guarantees that each Wallet will be registered synchronously as soon
* as the app is ready whether the app loads before or after each Wallet.
*
* @return API for getting, listening for, and registering Wallets.
*
* @group App
*/
function getWallets() {
	if (wallets) return wallets;
	wallets = Object.freeze({
		register,
		get: get$1,
		on
	});
	if (typeof window === "undefined") return wallets;
	const api = Object.freeze({ register });
	try {
		window.addEventListener("wallet-standard:register-wallet", ({ detail: callback }) => callback(api));
	} catch (error) {
		console.error("wallet-standard:register-wallet event listener could not be added\n", error);
	}
	try {
		window.dispatchEvent(new AppReadyEvent(api));
	} catch (error) {
		console.error("wallet-standard:app-ready event could not be dispatched\n", error);
	}
	return wallets;
}
function register(...wallets) {
	wallets = wallets.filter((wallet) => !registeredWalletsSet.has(wallet));
	if (!wallets.length) return () => {};
	wallets.forEach((wallet) => addRegisteredWallet(wallet));
	listeners["register"]?.forEach((listener) => guard(() => listener(...wallets)));
	return function unregister() {
		wallets.forEach((wallet) => removeRegisteredWallet(wallet));
		listeners["unregister"]?.forEach((listener) => guard(() => listener(...wallets)));
	};
}
var cachedWalletsArray;
function get$1() {
	if (!cachedWalletsArray) cachedWalletsArray = [...registeredWalletsSet];
	return cachedWalletsArray;
}
function on(event, listener) {
	listeners[event]?.push(listener) || (listeners[event] = [listener]);
	return function off() {
		listeners[event] = listeners[event]?.filter((existingListener) => listener !== existingListener);
	};
}
function guard(callback) {
	try {
		callback();
	} catch (error) {
		console.error(error);
	}
}
var AppReadyEvent = class extends Event {
	get detail() {
		return __classPrivateFieldGet$1(this, _AppReadyEvent_detail, "f");
	}
	get type() {
		return "wallet-standard:app-ready";
	}
	constructor(api) {
		super("wallet-standard:app-ready", {
			bubbles: false,
			cancelable: false,
			composed: false
		});
		_AppReadyEvent_detail.set(this, void 0);
		__classPrivateFieldSet$1(this, _AppReadyEvent_detail, api, "f");
	}
	/** @deprecated */
	preventDefault() {
		throw new Error("preventDefault cannot be called");
	}
	/** @deprecated */
	stopImmediatePropagation() {
		throw new Error("stopImmediatePropagation cannot be called");
	}
	/** @deprecated */
	stopPropagation() {
		throw new Error("stopPropagation cannot be called");
	}
};
_AppReadyEvent_detail = /* @__PURE__ */ new WeakMap();
//#endregion
//#region node_modules/@wallet-standard/features/lib/esm/connect.js
/** Name of the feature. */
var StandardConnect = "standard:connect";
//#endregion
//#region node_modules/@wallet-standard/features/lib/esm/events.js
/** Name of the feature. */
var StandardEvents = "standard:events";
//#endregion
//#region node_modules/@wallet-standard/wallet/lib/esm/util.js
var __classPrivateFieldGet = function(receiver, state, kind, f) {
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a getter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot read private member from an object whose class did not declare it");
	return kind === "m" ? f : kind === "a" ? f.call(receiver) : f ? f.value : state.get(receiver);
};
var __classPrivateFieldSet = function(receiver, state, value, kind, f) {
	if (kind === "m") throw new TypeError("Private method is not writable");
	if (kind === "a" && !f) throw new TypeError("Private accessor was defined without a setter");
	if (typeof state === "function" ? receiver !== state || !f : !state.has(receiver)) throw new TypeError("Cannot write private member to an object whose class did not declare it");
	return kind === "a" ? f.call(receiver, value) : f ? f.value = value : state.set(receiver, value), value;
};
var _ReadonlyWalletAccount_address;
var _ReadonlyWalletAccount_publicKey;
var _ReadonlyWalletAccount_chains;
var _ReadonlyWalletAccount_features;
var _ReadonlyWalletAccount_label;
var _ReadonlyWalletAccount_icon;
/**
* Base implementation of a {@link "@wallet-standard/base".WalletAccount} to be used or extended by a
* {@link "@wallet-standard/base".Wallet}.
*
* `WalletAccount` properties must be read-only. This class enforces this by making all properties
* [truly private](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Classes/Private_class_fields) and
* read-only, using getters for access, returning copies instead of references, and calling
* [Object.freeze](https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Object/freeze)
* on the instance.
*
* @group Account
*/
var ReadonlyWalletAccount = class ReadonlyWalletAccount {
	/** Implementation of {@link "@wallet-standard/base".WalletAccount.address | WalletAccount::address} */
	get address() {
		return __classPrivateFieldGet(this, _ReadonlyWalletAccount_address, "f");
	}
	/** Implementation of {@link "@wallet-standard/base".WalletAccount.publicKey | WalletAccount::publicKey} */
	get publicKey() {
		return __classPrivateFieldGet(this, _ReadonlyWalletAccount_publicKey, "f").slice();
	}
	/** Implementation of {@link "@wallet-standard/base".WalletAccount.chains | WalletAccount::chains} */
	get chains() {
		return __classPrivateFieldGet(this, _ReadonlyWalletAccount_chains, "f").slice();
	}
	/** Implementation of {@link "@wallet-standard/base".WalletAccount.features | WalletAccount::features} */
	get features() {
		return __classPrivateFieldGet(this, _ReadonlyWalletAccount_features, "f").slice();
	}
	/** Implementation of {@link "@wallet-standard/base".WalletAccount.label | WalletAccount::label} */
	get label() {
		return __classPrivateFieldGet(this, _ReadonlyWalletAccount_label, "f");
	}
	/** Implementation of {@link "@wallet-standard/base".WalletAccount.icon | WalletAccount::icon} */
	get icon() {
		return __classPrivateFieldGet(this, _ReadonlyWalletAccount_icon, "f");
	}
	/**
	* Create and freeze a read-only account.
	*
	* @param account Account to copy properties from.
	*/
	constructor(account) {
		_ReadonlyWalletAccount_address.set(this, void 0);
		_ReadonlyWalletAccount_publicKey.set(this, void 0);
		_ReadonlyWalletAccount_chains.set(this, void 0);
		_ReadonlyWalletAccount_features.set(this, void 0);
		_ReadonlyWalletAccount_label.set(this, void 0);
		_ReadonlyWalletAccount_icon.set(this, void 0);
		if (new.target === ReadonlyWalletAccount) Object.freeze(this);
		__classPrivateFieldSet(this, _ReadonlyWalletAccount_address, account.address, "f");
		__classPrivateFieldSet(this, _ReadonlyWalletAccount_publicKey, account.publicKey.slice(), "f");
		__classPrivateFieldSet(this, _ReadonlyWalletAccount_chains, account.chains.slice(), "f");
		__classPrivateFieldSet(this, _ReadonlyWalletAccount_features, account.features.slice(), "f");
		__classPrivateFieldSet(this, _ReadonlyWalletAccount_label, account.label, "f");
		__classPrivateFieldSet(this, _ReadonlyWalletAccount_icon, account.icon, "f");
	}
};
_ReadonlyWalletAccount_address = /* @__PURE__ */ new WeakMap(), _ReadonlyWalletAccount_publicKey = /* @__PURE__ */ new WeakMap(), _ReadonlyWalletAccount_chains = /* @__PURE__ */ new WeakMap(), _ReadonlyWalletAccount_features = /* @__PURE__ */ new WeakMap(), _ReadonlyWalletAccount_label = /* @__PURE__ */ new WeakMap(), _ReadonlyWalletAccount_icon = /* @__PURE__ */ new WeakMap();
//#endregion
//#region node_modules/@mysten/wallet-standard/dist/detect.mjs
var REQUIRED_FEATURES = [StandardConnect, StandardEvents];
function isWalletWithRequiredFeatureSet(wallet, additionalFeatures = []) {
	return [...REQUIRED_FEATURES, ...additionalFeatures].every((feature) => feature in wallet.features);
}
var SUI_CHAINS = [
	"sui:devnet",
	"sui:testnet",
	"sui:localnet",
	"sui:mainnet"
];
//#endregion
//#region node_modules/@mysten/window-wallet-core/dist/jwt-session/index.mjs
var AccountSchema = object({
	address: string(),
	publicKey: string(),
	label: optional(string()),
	features: optional(array(string())),
	chains: optional(array(string()))
});
var JwtSessionSchema = object({
	exp: number(),
	iat: number(),
	iss: string(),
	aud: string(),
	payload: object({ accounts: array(AccountSchema) })
});
function decodeJwtSession(jwt) {
	const decodedJwt = decodeJwt(jwt);
	return parse$2(JwtSessionSchema, decodedJwt);
}
//#endregion
//#region node_modules/@mysten/window-wallet-core/dist/web-wallet-channel/responses.mjs
var ResponseData = variant("type", [
	object({
		type: literal("connect"),
		session: string("`session` is required")
	}),
	object({
		type: literal("sign-transaction"),
		bytes: string(),
		signature: string()
	}),
	object({
		type: literal("sign-and-execute-transaction"),
		bytes: string(),
		signature: string(),
		digest: string(),
		effects: string()
	}),
	object({
		type: literal("sign-personal-message"),
		bytes: string(),
		signature: string()
	})
]);
var ResponsePayload = variant("type", [object({
	type: literal("reject"),
	reason: optional(string("`reason` must be a string"))
}), object({
	type: literal("resolve"),
	data: ResponseData
})]);
var Response = object({
	id: pipe(string(), uuid()),
	source: literal("web-wallet-channel"),
	payload: ResponsePayload,
	version: literal("1")
});
//#endregion
//#region node_modules/@mysten/window-wallet-core/dist/web-wallet-channel/utils.mjs
function getClientMetadata() {
	return {
		version: "1",
		originUrl: window.location.href,
		userAgent: navigator.userAgent,
		screenResolution: `${window.screen.width}x${window.screen.height}`,
		language: navigator.language,
		platform: navigator.platform,
		timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
		timestamp: Date.now()
	};
}
//#endregion
//#region node_modules/@mysten/window-wallet-core/dist/web-wallet-channel/dapp-post-message-channel.mjs
var DappPostMessageChannel = class {
	#popup;
	#version = "1";
	#id;
	#hostOrigin;
	#hostPathname;
	#appName;
	#extraRequestOptions;
	#promise;
	#resolve;
	#reject;
	#interval = null;
	#isSendCalled = false;
	constructor({ appName, hostOrigin, hostPathname = "dapp-request", extraRequestOptions, popupWindow }) {
		const popup = popupWindow ?? window.open("about:blank", "_blank");
		if (!popup) throw new Error("Failed to open new window");
		this.#id = crypto.randomUUID();
		this.#popup = popup;
		this.#hostOrigin = hostOrigin;
		this.#hostPathname = hostPathname;
		this.#appName = appName;
		const { promise, resolve, reject } = promiseWithResolvers();
		this.#promise = promise;
		this.#resolve = resolve;
		this.#reject = reject;
		this.#extraRequestOptions = extraRequestOptions;
		this.#interval = setInterval(() => {
			try {
				if (this.#popup.closed) {
					this.#cleanup();
					reject(/* @__PURE__ */ new Error("User closed the wallet window"));
				}
			} catch {}
		}, 1e3);
	}
	send({ type, ...data }) {
		if (this.#popup.closed) throw new Error("User closed the wallet window");
		if (this.#isSendCalled) throw new Error("send() can only be called once");
		this.#isSendCalled = true;
		window.addEventListener("message", this.#listener);
		const requestData = {
			version: this.#version,
			requestId: this.#id,
			appUrl: window.location.href.split("#")[0],
			appName: this.#appName,
			payload: {
				type,
				...data
			},
			metadata: getClientMetadata(),
			extraRequestOptions: this.#extraRequestOptions
		};
		const encodedRequestData = encodeURIComponent(btoa(JSON.stringify(requestData)));
		this.#popup.location.assign(`${this.#hostOrigin}/${this.#hostPathname}#${encodedRequestData}`);
		return this.#promise;
	}
	close() {
		this.#cleanup();
		this.#popup.close();
	}
	#listener = (event) => {
		if (event.origin !== this.#hostOrigin) return;
		const { success, output } = safeParse(Response, event.data);
		if (!success || output.id !== this.#id) return;
		this.#cleanup();
		if (output.payload.type === "reject") this.#reject(new Error(output.payload.reason || "User rejected the request"));
		else if (output.payload.type === "resolve") this.#resolve(output.payload.data);
	};
	#cleanup() {
		if (this.#interval) {
			clearInterval(this.#interval);
			this.#interval = null;
		}
		window.removeEventListener("message", this.#listener);
	}
};
//#endregion
//#region node_modules/@mysten/slush-wallet/dist/wallet/index.mjs
var DEFAULT_SLUSH_ORIGIN = "https://my.slush.app";
var SLUSH_SESSION_KEY = "slush:session";
var SLUSH_WALLET_NAME = "Slush";
var SLUSH_WALLET_ICON = "data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNDgiIGhlaWdodD0iNDgiIHZpZXdCb3g9IjAgMCA0OCA0OCIgZmlsbD0ibm9uZSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj4KPHBhdGggZD0iTTAgMjRDMCAxMC43NDUyIDEwLjc0NTIgMCAyNCAwQzM3LjI1NDggMCA0OCAxMC43NDUyIDQ4IDI0QzQ4IDM3LjI1NDggMzcuMjU0OCA0OCAyNCA0OEMxMC43NDUyIDQ4IDAgMzcuMjU0OCAwIDI0WiIgZmlsbD0iIzBDMEExRiIvPgo8cGF0aCBkPSJNMTMuMTM1OCAzMi4xMDg1QzE0LjE3MDEgMzUuOTY4MyAxOC4wMzMxIDM5LjQ2MjQgMjYuMDI1NSAzNy4zMjA4QzMzLjY1MTUgMzUuMjc3NCAzOC40MzA5IDI5LjAwNCAzNy4xOTE2IDI0LjM3ODlDMzYuNzYzNiAyMi43ODE3IDM1LjQ3NDYgMjEuNzAwNiAzMy40ODcyIDIxLjg3NjVMMTUuNzE2NSAyMy4zNTcyQzE0LjU5NzMgMjMuNDQzIDE0LjA4NDIgMjMuMjU5NiAxMy43ODgxIDIyLjU1NDNDMTMuNTAxIDIxLjg4MjMgMTMuNjY0NiAyMS4xNjA5IDE1LjAxNjMgMjAuNDc3N0wyOC41NDAxIDEzLjUzNzRDMjkuNTc2NyAxMy4wMSAzMC4yNjcxIDEyLjc4OTMgMzAuODk4IDEzLjAxMjZDMzEuMjkzNCAxMy4xNTYzIDMxLjU1MzggMTMuNzI4NCAzMS4zMTQ3IDE0LjQzNDRMMzAuNDM3OCAxNy4wMjMyQzI5LjM2MTcgMjAuMjAwMiAzMS42NjUzIDIwLjkzODIgMzIuOTY0MSAyMC41OTAyQzM0LjkyODkgMjAuMDYzNyAzNS4zOTExIDE4LjE5MjMgMzQuNzU4MSAxNS44Mjk5QzMzLjE1MzMgOS44NDA1NCAyNi43OTkgOC45MDQxMSAyMS4wMzc4IDEwLjQ0NzhDMTUuMTc2NyAxMi4wMTgzIDEwLjA5NiAxNi43Njc2IDExLjY0NzQgMjIuNTU3M0MxMi4wMTI5IDIzLjkyMTYgMTMuMjY4NyAyNS4wMTE2IDE0LjcyMzIgMjQuOTc4NUwxNi45NDM4IDI0Ljk3MzFDMTcuNDAwNCAyNC45NjI1IDE3LjIzNiAyNSAxOC4xMTcgMjQuOTI3MUMxOC45OTggMjQuODU0MSAyMS4zNTA5IDI0LjU2NDYgMjEuMzUwOSAyNC41NjQ2TDMyLjg5NjIgMjMuMjU4TDMzLjE5MzcgMjMuMjE0OEMzMy44Njg5IDIzLjA5OTcgMzQuMzc5MiAyMy4yNzUgMzQuODEwNiAyNC4wMTgzQzM1LjQ1NjMgMjUuMTMwNCAzNC40NzEyIDI1Ljk2OTEgMzMuMjkyIDI2Ljk3MzFDMzMuMjYwNSAyNyAzMy4yMjg4IDI3LjAyNyAzMy4xOTcgMjcuMDU0MUwyMy4wNDgyIDM1LjgwMDVDMjEuMzA4NyAzNy4zMDA4IDIwLjA4NjcgMzYuNzM2NyAxOS42NTg4IDM1LjEzOTVMMTguMTQzMSAyOS40ODI5QzE3Ljc2ODcgMjguMDg1NCAxNi40MDQxIDI2Ljk4ODkgMTQuODA1NiAyNy40MTcyQzEyLjgwNzUgMjcuOTUyNiAxMi42NDU1IDMwLjI3ODQgMTMuMTM1OCAzMi4xMDg1WiIgZmlsbD0iI0ZCRkFGRiIvPgo8L3N2Zz4K";
var SUI_WALLET_EXTENSION_ID = "com.mystenlabs.suiwallet";
var METADATA_API_URL = "https://api.slush.app/api/wallet/metadata";
var FALLBACK_METADATA = {
	id: "com.mystenlabs.suiwallet.web",
	walletName: "Slush",
	description: "Trade and earn on Sui.",
	icon: SLUSH_WALLET_ICON,
	enabled: true
};
var WalletMetadataSchema = object({
	id: string("Wallet ID is required"),
	walletName: string("Wallet name is required"),
	icon: string("Icon must be a valid wallet icon format"),
	enabled: boolean("Enabled is required")
});
function setSessionToStorage(session) {
	localStorage.setItem(SLUSH_SESSION_KEY, session);
}
function getSessionFromStorage() {
	const session = localStorage.getItem(SLUSH_SESSION_KEY);
	if (!session) throw new Error("No session found");
	return session;
}
var walletAccountFeatures = [
	"sui:signTransaction",
	"sui:signAndExecuteTransaction",
	"sui:signPersonalMessage",
	"sui:signTransactionBlock"
];
function getAccountsFromSession(session) {
	const { payload } = decodeJwtSession(session);
	return payload.accounts.map((account) => {
		return new ReadonlyWalletAccount({
			address: account.address,
			chains: account.chains ? SUI_CHAINS.filter((chain) => account.chains?.includes(chain)) : SUI_CHAINS,
			features: account.features ? walletAccountFeatures.filter((feature) => account.features?.includes(feature)) : walletAccountFeatures,
			publicKey: fromBase64(account.publicKey)
		});
	});
}
var SlushWallet = class {
	#id;
	#events;
	#accounts;
	#origin;
	#walletName;
	#icon;
	#name;
	#removeStorageListener = null;
	get name() {
		return this.#walletName;
	}
	get id() {
		return this.#id;
	}
	get icon() {
		return this.#icon;
	}
	get version() {
		return "1.0.0";
	}
	get chains() {
		return SUI_CHAINS;
	}
	get accounts() {
		return this.#accounts;
	}
	get features() {
		return {
			"standard:connect": {
				version: "1.0.0",
				connect: this.#connect
			},
			"standard:disconnect": {
				version: "1.0.0",
				disconnect: this.#disconnect
			},
			"standard:events": {
				version: "1.0.0",
				on: this.#on
			},
			"sui:signTransactionBlock": {
				version: "1.0.0",
				signTransactionBlock: this.#signTransactionBlock
			},
			"sui:signTransaction": {
				version: "2.0.0",
				signTransaction: this.#signTransaction
			},
			"sui:signPersonalMessage": {
				version: "1.1.0",
				signPersonalMessage: this.#signPersonalMessage
			},
			"sui:signAndExecuteTransaction": {
				version: "2.0.0",
				signAndExecuteTransaction: this.#signAndExecuteTransaction
			}
		};
	}
	constructor({ name, origin, metadata }) {
		this.#id = metadata.id;
		this.#accounts = this.#getPreviouslyAuthorizedAccounts();
		this.#events = mitt();
		this.#origin = origin || DEFAULT_SLUSH_ORIGIN;
		this.#name = name;
		this.#walletName = metadata.walletName;
		this.#icon = metadata.icon;
		if (typeof window !== "undefined") {
			const target = window;
			const onStorage = (event) => {
				if (event.storageArea !== localStorage || event.key !== SLUSH_SESSION_KEY && event.key !== null) return;
				this.#setAccounts(this.#getPreviouslyAuthorizedAccounts());
			};
			target.addEventListener("storage", onStorage);
			this.#removeStorageListener = () => target.removeEventListener("storage", onStorage);
		}
	}
	/** Stop observing cross-tab session changes. Registered wallets dispose on unregister. */
	dispose() {
		this.#removeStorageListener?.();
		this.#removeStorageListener = null;
	}
	#signTransactionBlock = async ({ transactionBlock, account, chain }) => {
		const data = await transactionBlock.toJSON();
		const response = await this.#getNewPopupChannel().send({
			type: "sign-transaction",
			transaction: data,
			address: account.address,
			chain,
			session: getSessionFromStorage()
		});
		return {
			transactionBlockBytes: response.bytes,
			signature: response.signature
		};
	};
	#signTransaction = async ({ transaction, account, chain }) => {
		const popup = this.#getNewPopupChannel();
		const tx = await transaction.toJSON();
		const response = await popup.send({
			type: "sign-transaction",
			transaction: tx,
			address: account.address,
			chain,
			session: getSessionFromStorage()
		});
		return {
			bytes: response.bytes,
			signature: response.signature
		};
	};
	#signAndExecuteTransaction = async ({ transaction, account, chain }) => {
		const popup = this.#getNewPopupChannel();
		const data = await transaction.toJSON();
		const response = await popup.send({
			type: "sign-and-execute-transaction",
			transaction: data,
			address: account.address,
			chain,
			session: getSessionFromStorage()
		});
		return {
			bytes: response.bytes,
			signature: response.signature,
			digest: response.digest,
			effects: response.effects
		};
	};
	#signPersonalMessage = async ({ message, account, chain }) => {
		const selectedChain = chain ?? (account.chains.includes("sui:mainnet") ? "sui:mainnet" : SUI_CHAINS.find((supported) => account.chains.includes(supported)));
		if (!selectedChain) throw new Error("Account has no supported chain");
		const response = await this.#getNewPopupChannel().send({
			type: "sign-personal-message",
			message: toBase64(message),
			address: account.address,
			chain: selectedChain,
			session: getSessionFromStorage()
		});
		return {
			bytes: response.bytes,
			signature: response.signature
		};
	};
	#on = (event, listener) => {
		this.#events.on(event, listener);
		return () => this.#events.off(event, listener);
	};
	#setAccounts(accounts) {
		this.#accounts = accounts;
		this.#events.emit("change", { accounts: this.accounts });
	}
	#connect = async (input) => {
		if (input?.silent) return { accounts: this.accounts };
		const response = await this.#getNewPopupChannel().send({ type: "connect" });
		setSessionToStorage(response.session);
		this.#setAccounts(getAccountsFromSession(response.session));
		return { accounts: this.accounts };
	};
	#getPreviouslyAuthorizedAccounts() {
		try {
			return getAccountsFromSession(getSessionFromStorage());
		} catch {
			return [];
		}
	}
	#disconnect = async () => {
		localStorage.removeItem(SLUSH_SESSION_KEY);
		this.#setAccounts([]);
	};
	#getNewPopupChannel() {
		return new DappPostMessageChannel({
			appName: this.#name,
			hostOrigin: this.#origin
		});
	}
	updateMetadata(metadata) {
		this.#id = metadata.id;
		this.#walletName = metadata.walletName;
		this.#icon = metadata.icon;
	}
};
async function fetchMetadata(metadataApiUrl) {
	const response = await fetch(metadataApiUrl);
	if (!response.ok) throw new Error("Failed to fetch wallet metadata");
	return parse$2(WalletMetadataSchema, await response.json());
}
function registerSlushWallet(name, { origin, metadataApiUrl = METADATA_API_URL } = {}) {
	const wallets = getWallets();
	if (wallets.get().some((wallet) => wallet.id === SUI_WALLET_EXTENSION_ID)) return;
	const slushWalletInstance = new SlushWallet({
		name,
		origin,
		metadata: FALLBACK_METADATA
	});
	const unregisterWallet = wallets.register(slushWalletInstance);
	let unregistered = false;
	const unregister = () => {
		if (unregistered) return;
		unregistered = true;
		slushWalletInstance.dispose();
		stopRegistrationListener();
		unregisterWallet();
	};
	const stopRegistrationListener = wallets.on("register", (wallet) => {
		if (wallet.id === SUI_WALLET_EXTENSION_ID) unregister();
	});
	if (wallets.get().some((wallet) => wallet.id === SUI_WALLET_EXTENSION_ID)) unregister();
	fetchMetadata(metadataApiUrl).then((metadata) => {
		if (unregistered) return;
		if (!metadata.enabled) {
			console.log("Slush wallet is not currently enabled.");
			unregister();
			return;
		}
		slushWalletInstance.updateMetadata(metadata);
	}).catch((error) => {
		console.error("Error fetching metadata", error);
	});
	return {
		wallet: slushWalletInstance,
		unregister
	};
}
//#endregion
//#region node_modules/zustand/esm/vanilla.mjs
var createStoreImpl = (createState) => {
	let state;
	const listeners = /* @__PURE__ */ new Set();
	const setState = (partial, replace) => {
		const nextState = typeof partial === "function" ? partial(state) : partial;
		if (!Object.is(nextState, state)) {
			const previousState = state;
			state = (replace != null ? replace : typeof nextState !== "object" || nextState === null) ? nextState : Object.assign({}, state, nextState);
			listeners.forEach((listener) => listener(state, previousState));
		}
	};
	const getState = () => state;
	const getInitialState = () => initialState;
	const subscribe = (listener) => {
		listeners.add(listener);
		return () => listeners.delete(listener);
	};
	const api = {
		setState,
		getState,
		getInitialState,
		subscribe
	};
	const initialState = state = createState(setState, getState, api);
	return api;
};
var createStore = ((createState) => createState ? createStoreImpl(createState) : createStoreImpl);
//#endregion
//#region node_modules/zustand/esm/react.mjs
var identity = (arg) => arg;
function useStore(api, selector = identity) {
	const slice = import_react.useSyncExternalStore(api.subscribe, import_react.useCallback(() => selector(api.getState()), [api, selector]), import_react.useCallback(() => selector(api.getInitialState()), [api, selector]));
	import_react.useDebugValue(slice);
	return slice;
}
//#endregion
//#region node_modules/@vanilla-extract/recipes/dist/createRuntimeFn-166334d7.cjs.prod.js
var require_createRuntimeFn_166334d7_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	function toPrimitive(t, r) {
		if ("object" != typeof t || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != typeof i) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == typeof i ? i : String(i);
	}
	function _defineProperty(obj, key, value) {
		key = toPropertyKey(key);
		if (key in obj) Object.defineProperty(obj, key, {
			value,
			enumerable: true,
			configurable: true,
			writable: true
		});
		else obj[key] = value;
		return obj;
	}
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				_defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	function mapValues(input, fn) {
		var result = {};
		for (var _key in input) result[_key] = fn(input[_key], _key);
		return result;
	}
	var shouldApplyCompound = (compoundCheck, selections, defaultVariants) => {
		for (var key of Object.keys(compoundCheck)) {
			var _selections$key;
			if (compoundCheck[key] !== ((_selections$key = selections[key]) !== null && _selections$key !== void 0 ? _selections$key : defaultVariants[key])) return false;
		}
		return true;
	};
	var createRuntimeFn = (config) => {
		var runtimeFn = (options) => {
			var className = config.defaultClassName;
			var selections = _objectSpread2(_objectSpread2({}, config.defaultVariants), options);
			for (var variantName in selections) {
				var _selections$variantNa;
				var variantSelection = (_selections$variantNa = selections[variantName]) !== null && _selections$variantNa !== void 0 ? _selections$variantNa : config.defaultVariants[variantName];
				if (variantSelection != null) {
					var selection = variantSelection;
					if (typeof selection === "boolean") selection = selection === true ? "true" : "false";
					var selectionClassName = config.variantClassNames[variantName][selection];
					if (selectionClassName) className += " " + selectionClassName;
				}
			}
			for (var [compoundCheck, compoundClassName] of config.compoundVariants) if (shouldApplyCompound(compoundCheck, selections, config.defaultVariants)) className += " " + compoundClassName;
			return className;
		};
		runtimeFn.variants = () => Object.keys(config.variantClassNames);
		runtimeFn.classNames = {
			get base() {
				return config.defaultClassName.split(" ")[0];
			},
			get variants() {
				return mapValues(config.variantClassNames, (classNames) => mapValues(classNames, (className) => className.split(" ")[0]));
			}
		};
		return runtimeFn;
	};
	exports.createRuntimeFn = createRuntimeFn;
	exports.mapValues = mapValues;
}));
//#endregion
//#region node_modules/@vanilla-extract/recipes/createRuntimeFn/dist/vanilla-extract-recipes-createRuntimeFn.cjs.prod.js
var require_vanilla_extract_recipes_createRuntimeFn_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.createRuntimeFn = require_createRuntimeFn_166334d7_cjs_prod().createRuntimeFn;
}));
//#endregion
//#region node_modules/@vanilla-extract/recipes/createRuntimeFn/dist/vanilla-extract-recipes-createRuntimeFn.cjs.js
var require_vanilla_extract_recipes_createRuntimeFn_cjs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_vanilla_extract_recipes_createRuntimeFn_cjs_prod();
}));
//#endregion
//#region node_modules/@mysten/sui/dist/jsonRpc/errors.mjs
var CODE_TO_ERROR_TYPE = {
	"-32700": "ParseError",
	"-32701": "OversizedRequest",
	"-32702": "OversizedResponse",
	"-32600": "InvalidRequest",
	"-32601": "MethodNotFound",
	"-32602": "InvalidParams",
	"-32603": "InternalError",
	"-32604": "ServerBusy",
	"-32000": "CallExecutionFailed",
	"-32001": "UnknownError",
	"-32003": "SubscriptionClosed",
	"-32004": "SubscriptionClosedWithError",
	"-32005": "BatchesNotSupported",
	"-32006": "TooManySubscriptions",
	"-32050": "TransientError",
	"-32002": "TransactionExecutionClientError"
};
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
var SuiHTTPTransportError = class extends Error {};
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
var JsonRpcError = class extends SuiHTTPTransportError {
	constructor(message, code) {
		super(message);
		this.code = code;
		this.type = CODE_TO_ERROR_TYPE[code] ?? "ServerError";
	}
};
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
var SuiHTTPStatusError = class extends SuiHTTPTransportError {
	constructor(message, status, statusText) {
		super(message);
		this.status = status;
		this.statusText = statusText;
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/jsonRpc/http-transport.mjs
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
var JsonRpcHTTPTransport = class {
	#requestId = 0;
	#options;
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	constructor(options) {
		this.#options = options;
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	fetch(input, init) {
		const fetchFn = this.#options.fetch ?? fetch;
		if (!fetchFn) throw new Error("The current environment does not support fetch, you can provide a fetch implementation in the options for SuiHTTPTransport.");
		return fetchFn(input, init);
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async request(input) {
		this.#requestId += 1;
		const res = await this.fetch(this.#options.rpc?.url ?? this.#options.url, {
			method: "POST",
			signal: input.signal,
			headers: {
				"Content-Type": "application/json",
				"Client-Sdk-Type": "typescript",
				"Client-Sdk-Version": PACKAGE_VERSION,
				"Client-Request-Method": input.method,
				...this.#options.rpc?.headers
			},
			body: JSON.stringify({
				jsonrpc: "2.0",
				id: this.#requestId,
				method: input.method,
				params: input.params
			})
		});
		if (!res.ok) throw new SuiHTTPStatusError(`Unexpected status code: ${res.status}`, res.status, res.statusText);
		const data = await res.json();
		if ("error" in data && data.error != null) throw new JsonRpcError(data.error.message, data.error.code);
		return data.result;
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/client/cache.mjs
var ClientCache = class ClientCache {
	#prefix;
	#cache;
	constructor({ prefix, cache } = {}) {
		this.#prefix = prefix ?? [];
		this.#cache = cache ?? /* @__PURE__ */ new Map();
	}
	read(key, load) {
		const cacheKey = [this.#prefix, ...key].join(":");
		if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
		const result = load();
		this.#cache.set(cacheKey, result);
		if (typeof result === "object" && result !== null && "then" in result) return Promise.resolve(result).then((v) => {
			this.#cache.set(cacheKey, v);
			return v;
		}).catch((err) => {
			this.#cache.delete(cacheKey);
			throw err;
		});
		return result;
	}
	readSync(key, load) {
		const cacheKey = [this.#prefix, ...key].join(":");
		if (this.#cache.has(cacheKey)) return this.#cache.get(cacheKey);
		const result = load();
		this.#cache.set(cacheKey, result);
		return result;
	}
	clear(prefix) {
		const prefixKey = [...this.#prefix, ...prefix ?? []].join(":");
		if (!prefixKey) {
			this.#cache.clear();
			return;
		}
		for (const key of this.#cache.keys()) if (key.startsWith(prefixKey)) this.#cache.delete(key);
	}
	scope(prefix) {
		return new ClientCache({
			prefix: [...this.#prefix, ...Array.isArray(prefix) ? prefix : [prefix]],
			cache: this.#cache
		});
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/client/client.mjs
var BaseClient = class {
	constructor({ network, base, cache = base?.cache ?? new ClientCache() }) {
		this.network = network;
		this.base = base ?? this;
		this.cache = cache;
	}
	$extend(...registrations) {
		const extensions = Object.fromEntries(registrations.map((registration) => {
			return [registration.name, registration.register(this)];
		}));
		const methodCache = /* @__PURE__ */ new Map();
		return new Proxy(this, { get(target, prop, receiver) {
			if (typeof prop === "string" && prop in extensions) return extensions[prop];
			const value = Reflect.get(target, prop, receiver);
			if (typeof value === "function") {
				if (prop === "$extend") return value.bind(receiver);
				if (!methodCache.has(prop)) methodCache.set(prop, value.bind(target));
				return methodCache.get(prop);
			}
			return value;
		} });
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/client/core.mjs
var DEFAULT_MVR_URLS = {
	mainnet: "https://mainnet.mvr.mystenlabs.com",
	testnet: "https://testnet.mvr.mystenlabs.com"
};
var CoreClient = class extends BaseClient {
	constructor(options) {
		super(options);
		this.core = this;
		this.mvr = new MvrClient({
			cache: this.cache.scope("core.mvr"),
			url: options.mvr?.url ?? DEFAULT_MVR_URLS[this.network],
			pageSize: options.mvr?.pageSize,
			overrides: options.mvr?.overrides
		});
	}
	async getObject(options) {
		const { objectId } = options;
		const { objects: [result] } = await this.getObjects({
			objectIds: [objectId],
			signal: options.signal,
			include: options.include
		});
		if (result instanceof Error) throw result;
		return { object: result };
	}
	async getDynamicField(options) {
		const normalizedNameType = TypeTagSerializer.parseFromStr((await this.core.mvr.resolveType({
			type: options.name.type,
			signal: options.signal
		})).type);
		const fieldId = deriveDynamicFieldID(options.parentId, normalizedNameType, options.name.bcs);
		const { objects: [fieldObject] } = await this.getObjects({
			objectIds: [fieldId],
			signal: options.signal,
			include: {
				previousTransaction: true,
				content: true
			}
		});
		if (fieldObject instanceof Error) throw fieldObject;
		const fieldType = parseStructTag(fieldObject.type);
		const content = await fieldObject.content;
		const nameTypeParam = fieldType.typeParams[0];
		const isDynamicObject = typeof nameTypeParam !== "string" && nameTypeParam.module === "dynamic_object_field" && nameTypeParam.name === "Wrapper";
		const valueBcs = content.slice(32 + options.name.bcs.length);
		const valueType = typeof fieldType.typeParams[1] === "string" ? fieldType.typeParams[1] : normalizeStructTag(fieldType.typeParams[1]);
		return { dynamicField: {
			$kind: isDynamicObject ? "DynamicObject" : "DynamicField",
			fieldId: fieldObject.objectId,
			digest: fieldObject.digest,
			version: fieldObject.version,
			type: fieldObject.type,
			previousTransaction: fieldObject.previousTransaction,
			name: {
				type: typeof nameTypeParam === "string" ? nameTypeParam : normalizeStructTag(nameTypeParam),
				bcs: options.name.bcs
			},
			value: {
				type: valueType,
				bcs: valueBcs
			},
			childId: isDynamicObject ? suiBcs.Address.parse(valueBcs) : void 0
		} };
	}
	async getDynamicObjectField(options) {
		const wrappedType = `0x2::dynamic_object_field::Wrapper<${(await this.core.mvr.resolveType({
			type: options.name.type,
			signal: options.signal
		})).type}>`;
		const { dynamicField } = await this.getDynamicField({
			parentId: options.parentId,
			name: {
				type: wrappedType,
				bcs: options.name.bcs
			},
			signal: options.signal
		});
		const { object } = await this.getObject({
			objectId: dynamicField.childId,
			signal: options.signal,
			include: options.include
		});
		return { object };
	}
	async waitForTransaction(options) {
		const { signal, timeout = 6e4, pollSchedule, include } = options;
		const digest = "result" in options && options.result ? (options.result.Transaction ?? options.result.FailedTransaction).digest : options.digest;
		const abortSignal = signal ? AbortSignal.any([AbortSignal.timeout(timeout), signal]) : AbortSignal.timeout(timeout);
		const abortPromise = new Promise((_, reject) => {
			abortSignal.addEventListener("abort", () => reject(abortSignal.reason));
		});
		abortPromise.catch(() => {});
		const schedule = pollSchedule ?? [
			0,
			300,
			600,
			1500,
			3500
		];
		const t0 = Date.now();
		let scheduleIndex = 0;
		const lastInterval = schedule.length > 0 ? schedule[schedule.length - 1] - (schedule[schedule.length - 2] ?? 0) : 2e3;
		while (true) {
			if (scheduleIndex < schedule.length) {
				const remaining = t0 + schedule[scheduleIndex] - Date.now();
				scheduleIndex++;
				if (remaining > 0) await Promise.race([new Promise((resolve) => setTimeout(resolve, remaining)), abortPromise]);
			} else await Promise.race([new Promise((resolve) => setTimeout(resolve, lastInterval)), abortPromise]);
			abortSignal.throwIfAborted();
			try {
				return await this.getTransaction({
					digest,
					include,
					signal: abortSignal
				});
			} catch {}
		}
	}
	async signAndExecuteTransaction({ transaction, signer, additionalSignatures = [], ...input }) {
		let transactionBytes;
		if (transaction instanceof Uint8Array) transactionBytes = transaction;
		else {
			transaction.setSenderIfNotSet(signer.toSuiAddress());
			transactionBytes = await transaction.build({ client: this });
		}
		const { signature } = await signer.signTransaction(transactionBytes);
		return this.executeTransaction({
			transaction: transactionBytes,
			signatures: [signature, ...additionalSignatures],
			...input
		});
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/client/utils.mjs
var ordinalRules = new Intl.PluralRules("en-US", { type: "ordinal" });
var ordinalSuffixes = /* @__PURE__ */ new Map([
	["one", "st"],
	["two", "nd"],
	["few", "rd"],
	["other", "th"]
]);
function formatOrdinal(n) {
	return `${n}${ordinalSuffixes.get(ordinalRules.select(n))}`;
}
function formatMoveAbortMessage(options) {
	const { command, location, abortCode, cleverError } = options;
	const parts = [];
	if (command != null) parts.push(`MoveAbort in ${formatOrdinal(command + 1)} command`);
	else parts.push("MoveAbort");
	if (cleverError?.constantName) {
		const errorStr = cleverError.value ? `'${cleverError.constantName}': ${cleverError.value}` : `'${cleverError.constantName}'`;
		parts.push(errorStr);
	} else parts.push(`abort code: ${abortCode}`);
	if (location?.package && location?.module) {
		const locationStr = [`in '${[
			location.package.startsWith("0x") ? location.package : `0x${location.package}`,
			location.module,
			location.functionName
		].filter(Boolean).join("::")}'`];
		if (cleverError?.lineNumber != null) locationStr.push(`(line ${cleverError.lineNumber})`);
		else if (location.instruction != null) locationStr.push(`(instruction ${location.instruction})`);
		parts.push(locationStr.join(" "));
	}
	return parts.join(", ");
}
var MinimalEffectsWithError = suiBcs.struct("MinimalEffectsWithError", { status: ExecutionStatus });
suiBcs.enum("MinimalTransactionEffectsWithError", {
	V1: MinimalEffectsWithError,
	V2: MinimalEffectsWithError
});
var MinimalExecutionStatusNoError = suiBcs.enum("MinimalExecutionStatusNoError", {
	Success: null,
	Failed: null
});
var MinimalEffectsNoError = suiBcs.struct("MinimalEffectsNoError", { status: MinimalExecutionStatusNoError });
suiBcs.enum("MinimalTransactionEffectsNoError", {
	V1: MinimalEffectsNoError,
	V2: MinimalEffectsNoError
});
function formatErrorMessage($kind, data) {
	if (data !== null && data !== void 0 && typeof data !== "boolean") return `${$kind}(${JSON.stringify(data, (_key, value) => typeof value === "bigint" ? value.toString() : value)})`;
	return $kind;
}
function parseBcsExecutionError(failure) {
	const error = failure.error;
	const command = failure.command != null ? Number(failure.command) : void 0;
	switch (error.$kind) {
		case "MoveAbort": {
			const [location, abortCode] = error.MoveAbort;
			const moveLocation = {
				package: location.module.address,
				module: location.module.name,
				function: location.function,
				functionName: location.functionName ?? void 0,
				instruction: location.instruction
			};
			return {
				$kind: "MoveAbort",
				message: formatMoveAbortMessage({
					command,
					location: moveLocation,
					abortCode: String(abortCode)
				}),
				command,
				MoveAbort: {
					abortCode: String(abortCode),
					location: moveLocation
				}
			};
		}
		case "MoveObjectTooBig": return {
			$kind: "SizeError",
			message: formatErrorMessage("MoveObjectTooBig", error.MoveObjectTooBig),
			command,
			SizeError: {
				name: "ObjectTooBig",
				size: Number(error.MoveObjectTooBig.objectSize),
				maxSize: Number(error.MoveObjectTooBig.maxObjectSize)
			}
		};
		case "MovePackageTooBig": return {
			$kind: "SizeError",
			message: formatErrorMessage("MovePackageTooBig", error.MovePackageTooBig),
			command,
			SizeError: {
				name: "PackageTooBig",
				size: Number(error.MovePackageTooBig.objectSize),
				maxSize: Number(error.MovePackageTooBig.maxObjectSize)
			}
		};
		case "EffectsTooLarge": return {
			$kind: "SizeError",
			message: formatErrorMessage("EffectsTooLarge", error.EffectsTooLarge),
			command,
			SizeError: {
				name: "EffectsTooLarge",
				size: Number(error.EffectsTooLarge.currentSize),
				maxSize: Number(error.EffectsTooLarge.maxSize)
			}
		};
		case "WrittenObjectsTooLarge": return {
			$kind: "SizeError",
			message: formatErrorMessage("WrittenObjectsTooLarge", error.WrittenObjectsTooLarge),
			command,
			SizeError: {
				name: "WrittenObjectsTooLarge",
				size: Number(error.WrittenObjectsTooLarge.currentSize),
				maxSize: Number(error.WrittenObjectsTooLarge.maxSize)
			}
		};
		case "MoveVectorElemTooBig": return {
			$kind: "SizeError",
			message: formatErrorMessage("MoveVectorElemTooBig", error.MoveVectorElemTooBig),
			command,
			SizeError: {
				name: "MoveVectorElemTooBig",
				size: Number(error.MoveVectorElemTooBig.valueSize),
				maxSize: Number(error.MoveVectorElemTooBig.maxScaledSize)
			}
		};
		case "MoveRawValueTooBig": return {
			$kind: "SizeError",
			message: formatErrorMessage("MoveRawValueTooBig", error.MoveRawValueTooBig),
			command,
			SizeError: {
				name: "MoveRawValueTooBig",
				size: Number(error.MoveRawValueTooBig.valueSize),
				maxSize: Number(error.MoveRawValueTooBig.maxScaledSize)
			}
		};
		case "CommandArgumentError": return {
			$kind: "CommandArgumentError",
			message: formatErrorMessage("CommandArgumentError", error.CommandArgumentError),
			command,
			CommandArgumentError: {
				argument: error.CommandArgumentError.argIdx,
				name: error.CommandArgumentError.kind.$kind
			}
		};
		case "TypeArgumentError": return {
			$kind: "TypeArgumentError",
			message: formatErrorMessage("TypeArgumentError", error.TypeArgumentError),
			command,
			TypeArgumentError: {
				typeArgument: error.TypeArgumentError.argumentIdx,
				name: error.TypeArgumentError.kind.$kind
			}
		};
		case "PackageUpgradeError": {
			const upgradeError = error.PackageUpgradeError.upgradeError;
			return {
				$kind: "PackageUpgradeError",
				message: formatErrorMessage("PackageUpgradeError", error.PackageUpgradeError),
				command,
				PackageUpgradeError: {
					name: upgradeError.$kind,
					packageId: upgradeError.$kind === "UnableToFetchPackage" ? upgradeError.UnableToFetchPackage.packageId : void 0,
					digest: upgradeError.$kind === "DigestDoesNotMatch" ? toBase64(upgradeError.DigestDoesNotMatch.digest) : void 0
				}
			};
		}
		case "ExecutionCancelledDueToSharedObjectCongestion": return {
			$kind: "CongestedObjects",
			message: formatErrorMessage("ExecutionCancelledDueToSharedObjectCongestion", error.ExecutionCancelledDueToSharedObjectCongestion),
			command,
			CongestedObjects: {
				name: "ExecutionCanceledDueToConsensusObjectCongestion",
				objects: error.ExecutionCancelledDueToSharedObjectCongestion.congested_objects
			}
		};
		case "AddressDeniedForCoin": return {
			$kind: "CoinDenyListError",
			message: formatErrorMessage("AddressDeniedForCoin", error.AddressDeniedForCoin),
			command,
			CoinDenyListError: {
				name: "AddressDeniedForCoin",
				address: error.AddressDeniedForCoin.address,
				coinType: error.AddressDeniedForCoin.coinType
			}
		};
		case "CoinTypeGlobalPause": return {
			$kind: "CoinDenyListError",
			message: formatErrorMessage("CoinTypeGlobalPause", error.CoinTypeGlobalPause),
			command,
			CoinDenyListError: {
				name: "CoinTypeGlobalPause",
				coinType: error.CoinTypeGlobalPause.coinType
			}
		};
		case "CircularObjectOwnership": return {
			$kind: "ObjectIdError",
			message: formatErrorMessage("CircularObjectOwnership", error.CircularObjectOwnership),
			command,
			ObjectIdError: {
				name: "CircularObjectOwnership",
				objectId: error.CircularObjectOwnership.object
			}
		};
		case "InvalidGasObject": return {
			$kind: "ObjectIdError",
			message: "InvalidGasObject",
			command,
			ObjectIdError: {
				name: "InvalidGasObject",
				objectId: ""
			}
		};
		case "InputObjectDeleted": return {
			$kind: "ObjectIdError",
			message: "InputObjectDeleted",
			command,
			ObjectIdError: {
				name: "InputObjectDeleted",
				objectId: ""
			}
		};
		case "InvalidTransferObject": return {
			$kind: "ObjectIdError",
			message: "InvalidTransferObject",
			command,
			ObjectIdError: {
				name: "InvalidTransferObject",
				objectId: ""
			}
		};
		case "NonExclusiveWriteInputObjectModified": return {
			$kind: "Unknown",
			message: formatErrorMessage("NonExclusiveWriteInputObjectModified", error.NonExclusiveWriteInputObjectModified),
			command,
			Unknown: null
		};
		case "InsufficientGas":
		case "InvariantViolation":
		case "FeatureNotYetSupported":
		case "InsufficientCoinBalance":
		case "CoinBalanceOverflow":
		case "PublishErrorNonZeroAddress":
		case "SuiMoveVerificationError":
		case "MovePrimitiveRuntimeError":
		case "VMVerificationOrDeserializationError":
		case "VMInvariantViolation":
		case "FunctionNotFound":
		case "ArityMismatch":
		case "TypeArityMismatch":
		case "NonEntryFunctionInvoked":
		case "UnusedValueWithoutDrop":
		case "InvalidPublicFunctionReturnType":
		case "PublishUpgradeMissingDependency":
		case "PublishUpgradeDependencyDowngrade":
		case "CertificateDenied":
		case "SuiMoveVerificationTimedout":
		case "SharedObjectOperationNotAllowed":
		case "ExecutionCancelledDueToRandomnessUnavailable":
		case "InvalidLinkage":
		case "InsufficientBalanceForWithdraw": return {
			$kind: "Unknown",
			message: error.$kind,
			command,
			Unknown: null
		};
		default: return {
			$kind: "Unknown",
			message: "Unknown error",
			command,
			Unknown: null
		};
	}
}
function parseTransactionBcs(bytes, onlyTransactionKind = false) {
	return (onlyTransactionKind ? TransactionDataBuilder.fromKindBytes(bytes) : TransactionDataBuilder.fromBytes(bytes)).snapshot();
}
/**
* Checks whether a gas object ID is the mocked gas coin the node substitutes when a transaction
* is simulated without a gas payment.
*/
function isMockedGasObjectId(objectId) {
	return objectId != null && normalizeSuiAddress(objectId) === "0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff";
}
function parseTransactionEffectsBcs(effects) {
	const parsed = suiBcs.TransactionEffects.parse(effects);
	switch (parsed.$kind) {
		case "V1": return parseTransactionEffectsV1({
			bytes: effects,
			effects: parsed.V1
		});
		case "V2": return parseTransactionEffectsV2({
			bytes: effects,
			effects: parsed.V2
		});
		default: throw new Error(`Unknown transaction effects version: ${parsed.$kind}`);
	}
}
function parseTransactionEffectsV1({ bytes, effects }) {
	const modifiedAtVersions = new Map(effects.modifiedAtVersions);
	const sharedObjects = new Map(effects.sharedObjects.map((object) => [object.objectId, object]));
	const mapChangedObject = (reference, change) => {
		const sharedInput = sharedObjects.get(reference.objectId);
		return {
			objectId: reference.objectId,
			inputState: change.inputState,
			inputVersion: change.inputState === "Exists" ? sharedInput?.version ?? modifiedAtVersions.get(reference.objectId) ?? null : null,
			inputDigest: change.inputState === "Exists" ? sharedInput?.digest ?? null : null,
			inputOwner: null,
			outputState: change.outputState,
			outputVersion: change.outputState === "DoesNotExist" ? null : reference.version,
			outputDigest: change.outputState === "DoesNotExist" ? null : reference.digest,
			outputOwner: change.outputOwner,
			idOperation: change.idOperation
		};
	};
	const written = (changes, inputState, idOperation) => changes.map(([reference, owner]) => mapChangedObject(reference, {
		inputState,
		outputState: "ObjectWrite",
		outputOwner: owner,
		idOperation
	}));
	const removed = (changes, inputState, idOperation) => changes.map((reference) => mapChangedObject(reference, {
		inputState,
		outputState: "DoesNotExist",
		outputOwner: null,
		idOperation
	}));
	const changedObjects = [
		...written(effects.created, "DoesNotExist", "Created"),
		...written(effects.mutated, "Exists", "None"),
		...written(effects.unwrapped, "DoesNotExist", "None"),
		...removed(effects.deleted, "Exists", "Deleted"),
		...removed(effects.unwrappedThenDeleted, "DoesNotExist", "Deleted"),
		...removed(effects.wrapped, "Exists", "None")
	];
	const gasObjectId = effects.gasObject[0].objectId;
	const gasObject = changedObjects.find((object) => object.objectId === gasObjectId) ?? null;
	const changedObjectIds = new Set(changedObjects.map((object) => object.objectId));
	const lamportVersion = effects.modifiedAtVersions.reduce((max, [, version]) => BigInt(version) > max ? BigInt(version) : max, 0n);
	return {
		bcs: bytes,
		version: 1,
		status: effects.status.$kind === "Success" ? {
			success: true,
			error: null
		} : {
			success: false,
			error: parseBcsExecutionError(effects.status.Failure)
		},
		gasUsed: effects.gasUsed,
		transactionDigest: effects.transactionDigest,
		gasObject,
		eventsDigest: effects.eventsDigest,
		dependencies: effects.dependencies,
		lamportVersion: (lamportVersion + 1n).toString(),
		changedObjects,
		unchangedConsensusObjects: effects.sharedObjects.filter((object) => !changedObjectIds.has(object.objectId)).map((object) => ({
			kind: "ReadOnlyRoot",
			objectId: object.objectId,
			version: object.version,
			digest: object.digest
		})),
		auxiliaryDataDigest: null
	};
}
function parseTransactionEffectsV2({ bytes, effects }) {
	const changedObjects = effects.changedObjects.map(([id, change]) => {
		return {
			objectId: id,
			inputState: change.inputState.$kind === "Exist" ? "Exists" : "DoesNotExist",
			inputVersion: change.inputState.Exist?.[0][0] ?? null,
			inputDigest: change.inputState.Exist?.[0][1] ?? null,
			inputOwner: change.inputState.Exist?.[1] ?? null,
			outputState: change.outputState.$kind === "NotExist" ? "DoesNotExist" : change.outputState.$kind,
			outputVersion: change.outputState.$kind === "PackageWrite" ? change.outputState.PackageWrite?.[0] : change.outputState.$kind === "ObjectWrite" ? effects.lamportVersion : null,
			outputDigest: change.outputState.$kind === "PackageWrite" ? change.outputState.PackageWrite?.[1] : change.outputState.$kind === "ObjectWrite" ? change.outputState.ObjectWrite?.[0] ?? null : null,
			outputOwner: change.outputState.$kind === "ObjectWrite" ? change.outputState.ObjectWrite[1] : null,
			idOperation: change.idOperation.$kind
		};
	});
	return {
		bcs: bytes,
		version: 2,
		status: effects.status.$kind === "Success" ? {
			success: true,
			error: null
		} : {
			success: false,
			error: parseBcsExecutionError(effects.status.Failure)
		},
		gasUsed: effects.gasUsed,
		transactionDigest: effects.transactionDigest,
		gasObject: effects.gasObjectIndex === null ? null : changedObjects[effects.gasObjectIndex] ?? null,
		eventsDigest: effects.eventsDigest,
		dependencies: effects.dependencies,
		lamportVersion: effects.lamportVersion,
		changedObjects,
		unchangedConsensusObjects: effects.unchangedConsensusObjects.map(([objectId, object]) => {
			return {
				kind: object.$kind,
				objectId,
				version: object.$kind === "ReadOnlyRoot" ? object.ReadOnlyRoot[0] : object[object.$kind],
				digest: object.$kind === "ReadOnlyRoot" ? object.ReadOnlyRoot[1] : null
			};
		}),
		auxiliaryDataDigest: effects.auxDataDigest
	};
}
//#endregion
//#region node_modules/@mysten/sui/dist/client/query-filters.mjs
/**
* Default page size applied when `limit` is omitted, so every transport
* requests the same page size instead of falling back to differing server
* defaults.
*/
var DEFAULT_PAGE_SIZE = 50;
/**
* Validates pagination bounds and resolves the traversal direction.
*
* `after` and `before` are exclusive ledger-position bounds. Until every
* transport can combine bounds freely, a query accepts at most one bound, and
* the bound must match the traversal direction (`after` implies ascending,
* `before` implies descending).
*/
function resolvePagination(options) {
	if (options.after != null && options.before != null) throw new Error("Only one of `after` or `before` may be provided");
	const descending = options.order ? options.order === "descending" : options.before != null;
	if (options.after != null && descending) throw new Error("`after` can not be combined with descending queries");
	if (options.before != null && !descending) throw new Error("`before` can not be combined with ascending queries");
	return {
		descending,
		after: options.after ?? void 0,
		before: options.before ?? void 0,
		limit: options.limit ?? DEFAULT_PAGE_SIZE
	};
}
/**
* Validates that a transaction query's filter supports pagination bounds.
*
* Function filters can only be paginated when fully qualified, since JSON-RPC
* rejects cursors on package- or module-level `MoveFunction` filters.
*/
function validateTransactionQuery(filter, pagination) {
	if (filter?.$kind === "function" && (pagination.after != null || pagination.before != null) && (!filter.module || !filter.function)) throw new Error("Paginating transactions filtered by function requires a fully qualified `package::module::function`");
}
/**
* Validates a transaction filter and resolves any MVR names it contains.
*
* Every transport resolves filters through this function so that validation
* errors and MVR handling are identical across clients.
*/
async function resolveTransactionFilter(mvr, filter, signal) {
	assertSinglePredicate(filter, ["sender", "function"], "transaction");
	if (filter.sender != null) return {
		$kind: "sender",
		sender: normalizeSuiAddress(filter.sender)
	};
	const [pkg, module, fn, ...rest] = filter.function.split("::");
	if (!pkg || rest.length > 0 || module === "" || fn === "") throw new Error(`Invalid function filter "${filter.function}": expected "package", "package::module", or "package::module::function"`);
	return {
		$kind: "function",
		package: normalizeSuiAddress((await mvr.resolvePackage({
			package: pkg,
			signal
		})).package),
		module,
		function: fn
	};
}
/**
* Validates an event filter and resolves any MVR names it contains.
*
* `emitModule` must name a module (`package::module`), and `eventType` must be
* at least module-qualified (`package::module` or a full type). Every transport
* resolves filters through this function so that validation errors and MVR
* handling are identical across clients.
*/
async function resolveEventFilter(mvr, filter, signal) {
	assertSinglePredicate(filter, [
		"sender",
		"emitModule",
		"eventType"
	], "event");
	if (filter.sender != null) return {
		$kind: "sender",
		sender: normalizeSuiAddress(filter.sender)
	};
	if (filter.emitModule != null) {
		const [pkg, module, ...rest] = filter.emitModule.split("::");
		if (!pkg || !module || rest.length > 0) throw new Error(`Invalid emitModule filter "${filter.emitModule}": expected "package::module"`);
		return {
			$kind: "emitModule",
			package: normalizeSuiAddress((await mvr.resolvePackage({
				package: pkg,
				signal
			})).package),
			module
		};
	}
	const eventType = filter.eventType;
	const segments = eventType.split("::");
	if (segments.length === 2 && segments.every((segment) => segment !== "")) return {
		$kind: "eventTypeModule",
		package: normalizeSuiAddress((await mvr.resolvePackage({
			package: segments[0],
			signal
		})).package),
		module: segments[1]
	};
	if (segments.length < 3 || segments.some((segment) => segment === "")) throw new Error(`Invalid eventType filter "${eventType}": expected "package::module" or a fully qualified type name`);
	return {
		$kind: "eventType",
		eventType: (await mvr.resolveType({
			type: eventType,
			signal
		})).type
	};
}
function assertSinglePredicate(filter, predicates, kind) {
	const present = predicates.filter((predicate) => filter[predicate] != null);
	if (present.length !== 1) throw new Error(`A ${kind} filter must specify exactly one of ${predicates.join(", ")}${present.length ? ` (got ${present.join(", ")})` : ""}`);
}
//#endregion
//#region node_modules/@mysten/sui/dist/jsonRpc/core.mjs
var MAX_GAS = 5e10;
function mapJsonRpcObjectError(response, requestedObjectId) {
	switch (response.code) {
		case "notExists": return new ObjectError(response.code, `Object ${response.object_id} does not exist`, {
			cause: response,
			reason: "notFound",
			objectId: requestedObjectId ?? response.object_id
		});
		case "dynamicFieldNotFound": return new ObjectError(response.code, `Dynamic field not found for object ${response.parent_object_id}`, {
			cause: response,
			reason: "notFound",
			objectId: requestedObjectId ?? response.parent_object_id
		});
		case "deleted": return new ObjectError(response.code, `Object ${response.object_id} has been deleted`, {
			cause: response,
			reason: "deleted",
			objectId: requestedObjectId ?? response.object_id
		});
		case "displayError": return new ObjectError(response.code, `Display error: ${response.error}`, {
			cause: response,
			reason: "unknown",
			objectId: requestedObjectId
		});
		default: return new ObjectError(response.code, `Unknown error while loading object${requestedObjectId ? ` ${requestedObjectId}` : ""}`, {
			cause: response,
			reason: "unknown",
			objectId: requestedObjectId
		});
	}
}
function isJsonRpcTransactionNotFound(error, digest) {
	if (!(error instanceof JsonRpcError) || error.code !== -32602) return false;
	return error.message === `Invalid Params: Transaction ${digest} not found` || error.message === `Could not find the referenced transaction [TransactionDigest(${digest})].`;
}
function parseJsonRpcExecutionStatus(status, abortError) {
	if (status.status === "success") return {
		success: true,
		error: null
	};
	const rawMessage = status.error ?? "Unknown";
	if (abortError) {
		const commandMatch = rawMessage.match(/in command (\d+)/);
		const command = commandMatch ? parseInt(commandMatch[1], 10) : void 0;
		const instructionMatch = rawMessage.match(/instruction:\s*(\d+)/);
		const instruction = instructionMatch ? parseInt(instructionMatch[1], 10) : void 0;
		const moduleParts = abortError.module_id?.split("::") ?? [];
		const pkg = moduleParts[0] ? normalizeSuiAddress(moduleParts[0]) : void 0;
		const module = moduleParts[1];
		return {
			success: false,
			error: {
				$kind: "MoveAbort",
				message: formatMoveAbortMessage({
					command,
					location: pkg && module ? {
						package: pkg,
						module,
						functionName: abortError.function ?? void 0,
						instruction
					} : void 0,
					abortCode: String(abortError.error_code ?? 0),
					cleverError: abortError.line != null ? { lineNumber: abortError.line } : void 0
				}),
				command,
				MoveAbort: {
					abortCode: String(abortError.error_code ?? 0),
					location: abortError.module_id ? {
						package: normalizeSuiAddress(abortError.module_id.split("::")[0] ?? ""),
						module: abortError.module_id.split("::")[1] ?? "",
						functionName: abortError.function ?? void 0,
						instruction
					} : void 0
				}
			}
		};
	}
	return {
		success: false,
		error: {
			$kind: "Unknown",
			message: rawMessage,
			Unknown: null
		}
	};
}
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
var JSONRpcCoreClient = class extends CoreClient {
	#jsonRpcClient;
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	constructor({ jsonRpcClient, mvr }) {
		super({
			network: jsonRpcClient.network,
			base: jsonRpcClient,
			mvr
		});
		this.#jsonRpcClient = jsonRpcClient;
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getObjects(options) {
		const batches = chunk(options.objectIds, 50);
		const results = [];
		for (const batch of batches) {
			const objects = await this.#jsonRpcClient.multiGetObjects({
				ids: batch,
				options: {
					showOwner: true,
					showType: true,
					showBcs: options.include?.content || options.include?.objectBcs ? true : false,
					showPreviousTransaction: options.include?.previousTransaction || options.include?.objectBcs ? true : false,
					showStorageRebate: options.include?.objectBcs ?? false,
					showContent: options.include?.json ?? false,
					showDisplay: options.include?.display ?? false
				},
				signal: options.signal
			});
			for (const [idx, object] of objects.entries()) if (object.error) results.push(mapJsonRpcObjectError(object.error, batch[idx]));
			else results.push(parseObject(object.data, options.include));
		}
		return { objects: results };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async listOwnedObjects(options) {
		let filter = null;
		if (options.type) {
			const parts = options.type.split("::");
			if (parts.length === 1) filter = { Package: options.type };
			else if (parts.length === 2) filter = { MoveModule: {
				package: parts[0],
				module: parts[1]
			} };
			else filter = { StructType: options.type };
		}
		const objects = await this.#jsonRpcClient.getOwnedObjects({
			owner: options.owner,
			limit: options.limit,
			cursor: options.cursor,
			options: {
				showOwner: true,
				showType: true,
				showBcs: options.include?.content || options.include?.objectBcs ? true : false,
				showPreviousTransaction: options.include?.previousTransaction || options.include?.objectBcs ? true : false,
				showStorageRebate: options.include?.objectBcs ?? false,
				showContent: options.include?.json ?? false,
				showDisplay: options.include?.display ?? false
			},
			filter,
			signal: options.signal
		});
		return {
			objects: objects.data.map((result) => {
				if (result.error) throw mapJsonRpcObjectError(result.error);
				return parseObject(result.data, options.include);
			}),
			hasNextPage: objects.hasNextPage,
			cursor: objects.nextCursor ?? null
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async listCoins(options) {
		const coins = await this.#jsonRpcClient.getCoins({
			owner: options.owner,
			coinType: options.coinType,
			limit: options.limit,
			cursor: options.cursor,
			signal: options.signal
		});
		return {
			objects: coins.data.map((coin) => ({
				objectId: coin.coinObjectId,
				version: coin.version,
				digest: coin.digest,
				balance: coin.balance,
				type: normalizeStructTag(`0x2::coin::Coin<${coin.coinType}>`),
				owner: {
					$kind: "AddressOwner",
					AddressOwner: options.owner
				}
			})),
			hasNextPage: coins.hasNextPage,
			cursor: coins.nextCursor ?? null
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getBalance(options) {
		const balance = await this.#jsonRpcClient.getBalance({
			owner: options.owner,
			coinType: options.coinType,
			signal: options.signal
		});
		const addressBalance = balance.fundsInAddressBalance ?? "0";
		const coinBalance = String(BigInt(balance.totalBalance) - BigInt(addressBalance));
		return { balance: {
			coinType: normalizeStructTag(balance.coinType),
			balance: balance.totalBalance,
			coinBalance,
			addressBalance
		} };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCoinMetadata(options) {
		const coinType = (await this.mvr.resolveType({
			type: options.coinType,
			signal: options.signal
		})).type;
		const result = await this.#jsonRpcClient.getCoinMetadata({
			coinType,
			signal: options.signal
		});
		if (!result) return { coinMetadata: null };
		return { coinMetadata: {
			id: result.id ?? null,
			decimals: result.decimals,
			name: result.name,
			symbol: result.symbol,
			description: result.description,
			iconUrl: result.iconUrl ?? null
		} };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async listBalances(options) {
		return {
			balances: (await this.#jsonRpcClient.getAllBalances({
				owner: options.owner,
				signal: options.signal
			})).map((balance) => {
				const addressBalance = balance.fundsInAddressBalance ?? "0";
				const coinBalance = String(BigInt(balance.totalBalance) - BigInt(addressBalance));
				return {
					coinType: normalizeStructTag(balance.coinType),
					balance: balance.totalBalance,
					coinBalance,
					addressBalance
				};
			}),
			hasNextPage: false,
			cursor: null
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getTransaction(options) {
		try {
			return parseTransaction(await this.#jsonRpcClient.getTransactionBlock({
				digest: options.digest,
				options: {
					showRawInput: true,
					showEffects: true,
					showObjectChanges: options.include?.objectTypes ?? false,
					showRawEffects: options.include?.effects ?? false,
					showEvents: options.include?.events ?? false,
					showBalanceChanges: options.include?.balanceChanges ?? false
				},
				signal: options.signal
			}), options.include);
		} catch (error) {
			if (isJsonRpcTransactionNotFound(error, options.digest)) throw new TransactionError("notFound", options.digest, { cause: error });
			throw error;
		}
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async executeTransaction(options) {
		return parseTransaction(await this.#jsonRpcClient.executeTransactionBlock({
			transactionBlock: options.transaction,
			signature: options.signatures,
			options: {
				showRawInput: true,
				showEffects: true,
				showRawEffects: options.include?.effects ?? false,
				showEvents: options.include?.events ?? false,
				showObjectChanges: options.include?.objectTypes ?? false,
				showBalanceChanges: options.include?.balanceChanges ?? false
			},
			signal: options.signal
		}), options.include);
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async simulateTransaction(options) {
		if (!(options.transaction instanceof Uint8Array)) await options.transaction.build({
			client: this,
			onlyTransactionKind: true
		});
		const tx = Transaction.from(options.transaction);
		const data = options.transaction instanceof Uint8Array ? null : TransactionDataBuilder.restore(options.transaction.getData());
		const transactionBytes = data ? data.build({ overrides: { gasData: {
			budget: data.gasData.budget ?? String(MAX_GAS),
			price: data.gasData.price ?? String(await this.#jsonRpcClient.getReferenceGasPrice({ signal: options.signal })),
			payment: data.gasData.payment ?? []
		} } }) : options.transaction;
		const sender = tx.getData().sender ?? normalizeSuiAddress("0x0");
		const checksDisabled = options.checksEnabled === false;
		let dryRunResult = null;
		try {
			dryRunResult = await this.#jsonRpcClient.dryRunTransactionBlock({
				transactionBlock: transactionBytes,
				signal: options.signal
			});
		} catch (e) {
			if (!checksDisabled) throw e;
		}
		let devInspectResult = null;
		if (options.include?.commandResults || checksDisabled) try {
			devInspectResult = await this.#jsonRpcClient.devInspectTransactionBlock({
				sender,
				transactionBlock: tx,
				signal: options.signal
			});
		} catch {}
		const dryRunFailed = !dryRunResult || dryRunResult.effects.status.status !== "success";
		const effectsSource = checksDisabled && dryRunFailed && devInspectResult ? devInspectResult : dryRunResult ?? devInspectResult;
		if (!effectsSource) throw new Error("simulateTransaction failed: no results from dryRun or devInspect");
		const { effects, objectTypes } = parseTransactionEffectsJson({
			effects: effectsSource.effects,
			objectChanges: (!dryRunFailed ? dryRunResult?.objectChanges : null) ?? []
		});
		let parsedTransaction;
		if (options.include?.transaction) {
			parsedTransaction = parseTransactionBcs(transactionBytes);
			if (data && !dryRunFailed && effects.gasUsed) {
				if (!data.gasData.budget) parsedTransaction.gasData.budget = computeGasBudget(effects.gasUsed);
			}
		}
		const transactionData = {
			digest: TransactionDataBuilder.getDigestFromBytes(transactionBytes),
			epoch: null,
			timestampMs: null,
			checkpoint: null,
			status: effects.status,
			effects: options.include?.effects ? effects : void 0,
			objectTypes: options.include?.objectTypes ? objectTypes : void 0,
			signatures: [],
			transaction: parsedTransaction ?? void 0,
			bcs: options.include?.bcs ? transactionBytes : void 0,
			balanceChanges: options.include?.balanceChanges && dryRunResult && !dryRunFailed ? dryRunResult.balanceChanges.map((change) => ({
				coinType: normalizeStructTag(change.coinType),
				address: parseOwnerAddress(change.owner),
				amount: change.amount
			})) : void 0,
			events: options.include?.events ? effectsSource.events?.map((event) => ({
				packageId: event.packageId,
				module: event.transactionModule,
				sender: event.sender,
				eventType: event.type,
				bcs: "bcs" in event ? fromBase64(event.bcs) : /* @__PURE__ */ new Uint8Array(),
				json: event.parsedJson ?? null
			})) ?? [] : void 0
		};
		let commandResults;
		if (options.include?.commandResults && devInspectResult?.results) commandResults = devInspectResult.results.map((result) => ({
			returnValues: (result.returnValues ?? []).map(([bytes]) => ({ bcs: new Uint8Array(bytes) })),
			mutatedReferences: (result.mutableReferenceOutputs ?? []).map(([, bytes]) => ({ bcs: new Uint8Array(bytes) }))
		}));
		const gasPaymentMocked = isMockedGasObjectId(effects.gasObject?.objectId);
		return effects.status.success ? {
			$kind: "Transaction",
			Transaction: transactionData,
			commandResults,
			gasPaymentMocked
		} : {
			$kind: "FailedTransaction",
			FailedTransaction: transactionData,
			commandResults,
			gasPaymentMocked
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getReferenceGasPrice(options) {
		const referenceGasPrice = await this.#jsonRpcClient.getReferenceGasPrice({ signal: options?.signal });
		return { referenceGasPrice: String(referenceGasPrice) };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getProtocolConfig(options) {
		const result = await this.#jsonRpcClient.getProtocolConfig({ signal: options?.signal });
		const attributes = {};
		for (const [key, value] of Object.entries(result.attributes)) if (value === null) attributes[key] = null;
		else if ("u16" in value) attributes[key] = value.u16;
		else if ("u32" in value) attributes[key] = value.u32;
		else if ("u64" in value) attributes[key] = value.u64;
		else if ("f64" in value) attributes[key] = value.f64;
		else if ("bool" in value) attributes[key] = value.bool;
		else {
			const entries = Object.entries(value);
			attributes[key] = entries.length === 1 ? String(entries[0][1]) : JSON.stringify(value);
		}
		return { protocolConfig: {
			protocolVersion: result.protocolVersion,
			featureFlags: { ...result.featureFlags },
			attributes
		} };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCurrentSystemState(options) {
		const systemState = await this.#jsonRpcClient.getLatestSuiSystemState({ signal: options?.signal });
		return { systemState: {
			systemStateVersion: systemState.systemStateVersion,
			epoch: systemState.epoch,
			protocolVersion: systemState.protocolVersion,
			referenceGasPrice: systemState.referenceGasPrice?.toString() ?? null,
			epochStartTimestampMs: systemState.epochStartTimestampMs,
			safeMode: systemState.safeMode,
			safeModeStorageRewards: systemState.safeModeStorageRewards,
			safeModeComputationRewards: systemState.safeModeComputationRewards,
			safeModeStorageRebates: systemState.safeModeStorageRebates,
			safeModeNonRefundableStorageFee: systemState.safeModeNonRefundableStorageFee,
			parameters: {
				epochDurationMs: systemState.epochDurationMs,
				stakeSubsidyStartEpoch: systemState.stakeSubsidyStartEpoch,
				maxValidatorCount: systemState.maxValidatorCount,
				minValidatorJoiningStake: systemState.minValidatorJoiningStake,
				validatorLowStakeThreshold: systemState.validatorLowStakeThreshold,
				validatorLowStakeGracePeriod: systemState.validatorLowStakeGracePeriod
			},
			storageFund: {
				totalObjectStorageRebates: systemState.storageFundTotalObjectStorageRebates,
				nonRefundableBalance: systemState.storageFundNonRefundableBalance
			},
			stakeSubsidy: {
				balance: systemState.stakeSubsidyBalance,
				distributionCounter: systemState.stakeSubsidyDistributionCounter,
				currentDistributionAmount: systemState.stakeSubsidyCurrentDistributionAmount,
				stakeSubsidyPeriodLength: systemState.stakeSubsidyPeriodLength,
				stakeSubsidyDecreaseRate: systemState.stakeSubsidyDecreaseRate
			}
		} };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async listDynamicFields(options) {
		const dynamicFields = await this.#jsonRpcClient.getDynamicFields({
			parentId: options.parentId,
			limit: options.limit,
			cursor: options.cursor,
			signal: options.signal
		});
		return {
			dynamicFields: dynamicFields.data.map((dynamicField) => {
				const isDynamicObject = dynamicField.type === "DynamicObject";
				const fullType = isDynamicObject ? `0x2::dynamic_field::Field<0x2::dynamic_object_field::Wrapper<${dynamicField.name.type}>, 0x2::object::ID>` : `0x2::dynamic_field::Field<${dynamicField.name.type}, ${dynamicField.objectType}>`;
				const bcsBytes = fromBase64(dynamicField.bcsName);
				const derivedNameType = isDynamicObject ? `0x2::dynamic_object_field::Wrapper<${dynamicField.name.type}>` : dynamicField.name.type;
				return {
					$kind: isDynamicObject ? "DynamicObject" : "DynamicField",
					fieldId: deriveDynamicFieldID(options.parentId, derivedNameType, bcsBytes),
					type: normalizeStructTag(fullType),
					name: {
						type: dynamicField.name.type,
						bcs: bcsBytes
					},
					valueType: dynamicField.objectType,
					childId: isDynamicObject ? dynamicField.objectId : void 0
				};
			}),
			hasNextPage: dynamicFields.hasNextPage,
			cursor: dynamicFields.nextCursor
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async listTransactions(options) {
		const filter = options.filter ? await resolveTransactionFilter(this.mvr, options.filter, options.signal) : void 0;
		const pagination = resolvePagination(options);
		const { descending, after, before } = pagination;
		validateTransactionQuery(filter, pagination);
		const page = await this.#jsonRpcClient.queryTransactionBlocks({
			filter: filter && (filter.$kind === "sender" ? { FromAddress: filter.sender } : { MoveFunction: {
				package: filter.package,
				module: filter.module ?? null,
				function: filter.function ?? null
			} }),
			cursor: after ?? before,
			limit: pagination.limit,
			order: descending ? "descending" : "ascending",
			options: {
				showRawInput: true,
				showEffects: true,
				showObjectChanges: options.include?.objectTypes ?? false,
				showRawEffects: options.include?.effects ?? false,
				showEvents: options.include?.events ?? false,
				showBalanceChanges: options.include?.balanceChanges ?? false
			},
			signal: options.signal
		});
		return {
			transactions: page.data.map((transaction) => parseTransaction(transaction, options.include)),
			hasNextPage: page.hasNextPage,
			startCursor: page.data[0]?.digest ?? null,
			endCursor: page.data.length ? page.nextCursor ?? page.data[page.data.length - 1].digest : null
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async listEvents(options) {
		const filter = options.filter ? await resolveEventFilter(this.mvr, options.filter, options.signal) : void 0;
		const { descending, after, before, limit } = resolvePagination(options);
		const cursor = after ?? before;
		const page = await this.#jsonRpcClient.queryEvents({
			query: !filter ? { All: [] } : filter.$kind === "sender" ? { Sender: filter.sender } : filter.$kind === "emitModule" ? { MoveModule: {
				package: filter.package,
				module: filter.module
			} } : filter.$kind === "eventTypeModule" ? { MoveEventModule: {
				package: filter.package,
				module: filter.module
			} } : { MoveEventType: filter.eventType },
			cursor: cursor ? parseEventCursor(cursor) : void 0,
			limit,
			order: descending ? "descending" : "ascending",
			signal: options.signal
		});
		return {
			events: page.data.map((event) => ({
				packageId: normalizeSuiAddress(event.packageId),
				module: event.transactionModule,
				sender: normalizeSuiAddress(event.sender),
				eventType: normalizeStructTag(event.type),
				bcs: event.bcsEncoding === "base58" ? fromBase58(event.bcs) : fromBase64(event.bcs),
				json: event.parsedJson ?? null,
				checkpoint: null,
				transactionDigest: event.id.txDigest,
				eventIndex: Number(event.id.eventSeq)
			})),
			hasNextPage: page.hasNextPage,
			startCursor: page.data.length ? JSON.stringify(page.data[0].id) : null,
			endCursor: page.data.length && page.nextCursor ? JSON.stringify(page.nextCursor) : page.data.length ? JSON.stringify(page.data[page.data.length - 1].id) : null
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async verifyZkLoginSignature(options) {
		const result = await this.#jsonRpcClient.verifyZkLoginSignature({
			signal: options.signal,
			bytes: options.bytes,
			signature: options.signature,
			intentScope: options.intentScope,
			author: options.address
		});
		return {
			success: result.success,
			errors: result.errors
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async defaultNameServiceName(options) {
		return { data: { name: (await this.#jsonRpcClient.resolveNameServiceNames(options)).data[0] ?? null } };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async resolveNameServiceAddress(options) {
		return { address: await this.#jsonRpcClient.resolveNameServiceAddress(options) };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	resolveTransactionPlugin() {
		return coreClientResolveTransactionPlugin;
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getMoveFunction(options) {
		const resolvedPackageId = (await this.mvr.resolvePackage({
			package: options.packageId,
			signal: options.signal
		})).package;
		const result = await this.#jsonRpcClient.getNormalizedMoveFunction({
			package: resolvedPackageId,
			module: options.moduleName,
			function: options.name,
			signal: options.signal
		});
		return { function: {
			packageId: normalizeSuiAddress(resolvedPackageId),
			moduleName: options.moduleName,
			name: options.name,
			visibility: parseVisibility(result.visibility),
			isEntry: result.isEntry,
			typeParameters: result.typeParameters.map((abilities) => ({
				isPhantom: false,
				constraints: parseAbilities(abilities)
			})),
			parameters: result.parameters.map((param) => parseNormalizedSuiMoveType(param)),
			returns: result.return.map((ret) => parseNormalizedSuiMoveType(ret))
		} };
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getChainIdentifier(options) {
		const cached = this.cache.read(["chainIdentifier"], async () => {
			return { chainIdentifier: (await this.#jsonRpcClient.getCheckpoint({ id: "0" })).digest };
		});
		return raceSignal(Promise.resolve(cached), options?.signal);
	}
};
function serializeObjectToBcs(object) {
	if (object.bcs?.dataType !== "moveObject") return;
	try {
		const typeStr = normalizeStructTag(object.bcs.type);
		let moveObjectType;
		const normalizedSuiFramework = normalizeSuiAddress(SUI_FRAMEWORK_ADDRESS);
		const gasCoinType = normalizeStructTag(`${SUI_FRAMEWORK_ADDRESS}::coin::Coin<${SUI_FRAMEWORK_ADDRESS}::sui::SUI>`);
		const stakedSuiType = normalizeStructTag(`${SUI_SYSTEM_ADDRESS}::staking_pool::StakedSui`);
		const coinPrefix = `${normalizedSuiFramework}::coin::Coin<`;
		if (typeStr === gasCoinType) moveObjectType = { GasCoin: null };
		else if (typeStr === stakedSuiType) moveObjectType = { StakedSui: null };
		else if (typeStr.startsWith(coinPrefix)) {
			const innerTypeMatch = typeStr.match(/* @__PURE__ */ new RegExp(`${normalizedSuiFramework.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}::coin::Coin<(.+)>$`));
			if (innerTypeMatch) moveObjectType = { Coin: TypeTagSerializer.parseFromStr(innerTypeMatch[1], true) };
			else throw new Error("Failed to parse Coin type");
		} else {
			const typeTag = TypeTagSerializer.parseFromStr(typeStr, true);
			if (typeof typeTag !== "object" || !("struct" in typeTag)) throw new Error("Expected struct type tag");
			moveObjectType = { Other: typeTag.struct };
		}
		const contents = fromBase64(object.bcs.bcsBytes);
		const owner = convertOwnerToBcs(object.owner);
		return suiBcs.Object.serialize({
			data: { Move: {
				type: moveObjectType,
				hasPublicTransfer: object.bcs.hasPublicTransfer,
				version: object.bcs.version,
				contents
			} },
			owner,
			previousTransaction: object.previousTransaction,
			storageRebate: object.storageRebate
		}).toBytes();
	} catch {
		return;
	}
}
function parseObject(object, include) {
	const bcsContent = object.bcs?.dataType === "moveObject" ? fromBase64(object.bcs.bcsBytes) : void 0;
	const objectBcs = include?.objectBcs ? serializeObjectToBcs(object) : void 0;
	const type = object.type && object.type.includes("::") ? normalizeStructTag(object.type) : object.type ?? "";
	const jsonContent = include?.json && object.content?.dataType === "moveObject" ? object.content.fields : include?.json ? null : void 0;
	const displayData = include?.display ? object.display?.data != null ? {
		output: object.display.data,
		errors: null
	} : null : void 0;
	return {
		objectId: object.objectId,
		version: object.version,
		digest: object.digest,
		type,
		content: include?.content ? bcsContent : void 0,
		owner: parseOwner(object.owner),
		previousTransaction: include?.previousTransaction ? object.previousTransaction ?? void 0 : void 0,
		objectBcs,
		json: jsonContent,
		display: displayData
	};
}
function parseOwner(owner) {
	if (owner === "Immutable") return {
		$kind: "Immutable",
		Immutable: true
	};
	if ("ConsensusAddressOwner" in owner) return {
		$kind: "ConsensusAddressOwner",
		ConsensusAddressOwner: {
			owner: owner.ConsensusAddressOwner.owner,
			startVersion: owner.ConsensusAddressOwner.start_version
		}
	};
	if ("AddressOwner" in owner) return {
		$kind: "AddressOwner",
		AddressOwner: owner.AddressOwner
	};
	if ("ObjectOwner" in owner) return {
		$kind: "ObjectOwner",
		ObjectOwner: owner.ObjectOwner
	};
	if ("Shared" in owner) return {
		$kind: "Shared",
		Shared: { initialSharedVersion: owner.Shared.initial_shared_version }
	};
	throw new Error(`Unknown owner type: ${JSON.stringify(owner)}`);
}
function convertOwnerToBcs(owner) {
	if (owner === "Immutable") return { Immutable: null };
	if ("AddressOwner" in owner) return { AddressOwner: owner.AddressOwner };
	if ("ObjectOwner" in owner) return { ObjectOwner: owner.ObjectOwner };
	if ("Shared" in owner) return { Shared: { initialSharedVersion: owner.Shared.initial_shared_version } };
	if (typeof owner === "object" && owner !== null && "ConsensusAddressOwner" in owner) return { ConsensusAddressOwner: {
		startVersion: owner.ConsensusAddressOwner.start_version,
		owner: owner.ConsensusAddressOwner.owner
	} };
	throw new Error(`Unknown owner type: ${JSON.stringify(owner)}`);
}
function parseOwnerAddress(owner) {
	if (owner === "Immutable") return null;
	if ("ConsensusAddressOwner" in owner) return owner.ConsensusAddressOwner.owner;
	if ("AddressOwner" in owner) return owner.AddressOwner;
	if ("ObjectOwner" in owner) return owner.ObjectOwner;
	if ("Shared" in owner) return null;
	throw new Error(`Unknown owner type: ${JSON.stringify(owner)}`);
}
function parseEventCursor(cursor) {
	try {
		const parsed = JSON.parse(cursor);
		if (typeof parsed?.txDigest !== "string" || typeof parsed?.eventSeq !== "string") throw new Error("malformed event cursor");
		return parsed;
	} catch {
		throw new Error(`Invalid event cursor: ${cursor}`);
	}
}
function parseTransaction(transaction, include) {
	const objectTypes = {};
	if (include?.objectTypes) transaction.objectChanges?.forEach((change) => {
		if (change.type !== "published") objectTypes[change.objectId] = normalizeStructTag(change.objectType);
	});
	let transactionData;
	let signatures = [];
	let bcsBytes;
	if (transaction.rawTransaction) {
		const parsedTx = suiBcs.SenderSignedData.parse(fromBase64(transaction.rawTransaction))[0];
		signatures = parsedTx.txSignatures;
		if (include?.transaction || include?.bcs) {
			const bytes = suiBcs.TransactionData.serialize(parsedTx.intentMessage.value).toBytes();
			if (include?.bcs) bcsBytes = bytes;
			if (include?.transaction) transactionData = { ...TransactionDataBuilder.restore({
				version: 2,
				sender: parsedTx.intentMessage.value.V1.sender,
				expiration: parsedTx.intentMessage.value.V1.expiration,
				gasData: parsedTx.intentMessage.value.V1.gasData,
				inputs: parsedTx.intentMessage.value.V1.kind.ProgrammableTransaction.inputs,
				commands: parsedTx.intentMessage.value.V1.kind.ProgrammableTransaction.commands
			}) };
		}
	}
	const status = transaction.effects?.status ? parseJsonRpcExecutionStatus(transaction.effects.status, transaction.effects.abortError) : {
		success: false,
		error: {
			$kind: "Unknown",
			message: "Unknown",
			Unknown: null
		}
	};
	const effectsBytes = transaction.rawEffects ? new Uint8Array(transaction.rawEffects) : null;
	const result = {
		digest: transaction.digest,
		epoch: transaction.effects?.executedEpoch ?? null,
		timestampMs: transaction.timestampMs == null ? null : Number(transaction.timestampMs),
		checkpoint: transaction.checkpoint ?? null,
		status,
		effects: include?.effects && effectsBytes ? parseTransactionEffectsBcs(effectsBytes) : void 0,
		objectTypes: include?.objectTypes ? objectTypes : void 0,
		transaction: transactionData,
		bcs: bcsBytes,
		signatures,
		balanceChanges: include?.balanceChanges ? transaction.balanceChanges?.map((change) => ({
			coinType: normalizeStructTag(change.coinType),
			address: parseOwnerAddress(change.owner),
			amount: change.amount
		})) ?? [] : void 0,
		events: include?.events ? transaction.events?.map((event) => ({
			packageId: event.packageId,
			module: event.transactionModule,
			sender: event.sender,
			eventType: event.type,
			bcs: "bcs" in event ? fromBase64(event.bcs) : /* @__PURE__ */ new Uint8Array(),
			json: event.parsedJson ?? null
		})) ?? [] : void 0
	};
	return status.success ? {
		$kind: "Transaction",
		Transaction: result
	} : {
		$kind: "FailedTransaction",
		FailedTransaction: result
	};
}
function parseTransactionEffectsJson({ bytes, effects, objectChanges }) {
	const changedObjects = [];
	const unchangedConsensusObjects = [];
	const objectTypes = {};
	objectChanges?.forEach((change) => {
		switch (change.type) {
			case "published":
				changedObjects.push({
					objectId: change.packageId,
					inputState: "DoesNotExist",
					inputVersion: null,
					inputDigest: null,
					inputOwner: null,
					outputState: "PackageWrite",
					outputVersion: change.version,
					outputDigest: change.digest,
					outputOwner: null,
					idOperation: "Created"
				});
				break;
			case "transferred":
				changedObjects.push({
					objectId: change.objectId,
					inputState: "Exists",
					inputVersion: change.version,
					inputDigest: change.digest,
					inputOwner: {
						$kind: "AddressOwner",
						AddressOwner: change.sender
					},
					outputState: "ObjectWrite",
					outputVersion: change.version,
					outputDigest: change.digest,
					outputOwner: parseOwner(change.recipient),
					idOperation: "None"
				});
				objectTypes[change.objectId] = normalizeStructTag(change.objectType);
				break;
			case "mutated":
				changedObjects.push({
					objectId: change.objectId,
					inputState: "Exists",
					inputVersion: change.previousVersion,
					inputDigest: null,
					inputOwner: parseOwner(change.owner),
					outputState: "ObjectWrite",
					outputVersion: change.version,
					outputDigest: change.digest,
					outputOwner: parseOwner(change.owner),
					idOperation: "None"
				});
				objectTypes[change.objectId] = normalizeStructTag(change.objectType);
				break;
			case "deleted":
				changedObjects.push({
					objectId: change.objectId,
					inputState: "Exists",
					inputVersion: change.version,
					inputDigest: effects.deleted?.find((d) => d.objectId === change.objectId)?.digest ?? null,
					inputOwner: null,
					outputState: "DoesNotExist",
					outputVersion: null,
					outputDigest: null,
					outputOwner: null,
					idOperation: "Deleted"
				});
				objectTypes[change.objectId] = normalizeStructTag(change.objectType);
				break;
			case "wrapped":
				changedObjects.push({
					objectId: change.objectId,
					inputState: "Exists",
					inputVersion: change.version,
					inputDigest: null,
					inputOwner: {
						$kind: "AddressOwner",
						AddressOwner: change.sender
					},
					outputState: "ObjectWrite",
					outputVersion: change.version,
					outputDigest: effects.wrapped?.find((w) => w.objectId === change.objectId)?.digest ?? null,
					outputOwner: {
						$kind: "ObjectOwner",
						ObjectOwner: change.sender
					},
					idOperation: "None"
				});
				objectTypes[change.objectId] = normalizeStructTag(change.objectType);
				break;
			case "created":
				changedObjects.push({
					objectId: change.objectId,
					inputState: "DoesNotExist",
					inputVersion: null,
					inputDigest: null,
					inputOwner: null,
					outputState: "ObjectWrite",
					outputVersion: change.version,
					outputDigest: change.digest,
					outputOwner: parseOwner(change.owner),
					idOperation: "Created"
				});
				objectTypes[change.objectId] = normalizeStructTag(change.objectType);
		}
	});
	const hasGasObject = normalizeSuiAddress(effects.gasObject.reference.objectId) !== normalizeSuiAddress("0x0");
	let lamportVersion = null;
	if (hasGasObject) lamportVersion = effects.gasObject.reference.version;
	else for (const change of changedObjects) if (change.outputVersion && (lamportVersion === null || BigInt(change.outputVersion) > BigInt(lamportVersion))) lamportVersion = change.outputVersion;
	return {
		objectTypes,
		effects: {
			bcs: bytes ?? null,
			version: 2,
			status: parseJsonRpcExecutionStatus(effects.status, effects.abortError),
			gasUsed: effects.gasUsed,
			transactionDigest: effects.transactionDigest,
			gasObject: hasGasObject ? {
				objectId: effects.gasObject.reference.objectId,
				inputState: "Exists",
				inputVersion: null,
				inputDigest: null,
				inputOwner: null,
				outputState: "ObjectWrite",
				outputVersion: effects.gasObject.reference.version,
				outputDigest: effects.gasObject.reference.digest,
				outputOwner: parseOwner(effects.gasObject.owner),
				idOperation: "None"
			} : null,
			eventsDigest: effects.eventsDigest ?? null,
			dependencies: effects.dependencies ?? [],
			lamportVersion,
			changedObjects,
			unchangedConsensusObjects,
			auxiliaryDataDigest: null
		}
	};
}
function parseNormalizedSuiMoveType(type) {
	if (typeof type !== "string") {
		if ("Reference" in type) return {
			reference: "immutable",
			body: parseNormalizedSuiMoveTypeBody(type.Reference)
		};
		if ("MutableReference" in type) return {
			reference: "mutable",
			body: parseNormalizedSuiMoveTypeBody(type.MutableReference)
		};
	}
	return {
		reference: null,
		body: parseNormalizedSuiMoveTypeBody(type)
	};
}
function parseNormalizedSuiMoveTypeBody(type) {
	switch (type) {
		case "Address": return { $kind: "address" };
		case "Bool": return { $kind: "bool" };
		case "U8": return { $kind: "u8" };
		case "U16": return { $kind: "u16" };
		case "U32": return { $kind: "u32" };
		case "U64": return { $kind: "u64" };
		case "U128": return { $kind: "u128" };
		case "U256": return { $kind: "u256" };
	}
	if (typeof type === "string") throw new Error(`Unknown type: ${type}`);
	if ("Vector" in type) return {
		$kind: "vector",
		vector: parseNormalizedSuiMoveTypeBody(type.Vector)
	};
	if ("Struct" in type) return {
		$kind: "datatype",
		datatype: {
			typeName: `${normalizeSuiAddress(type.Struct.address)}::${type.Struct.module}::${type.Struct.name}`,
			typeParameters: type.Struct.typeArguments.map((t) => parseNormalizedSuiMoveTypeBody(t))
		}
	};
	if ("TypeParameter" in type) return {
		$kind: "typeParameter",
		index: type.TypeParameter
	};
	throw new Error(`Unknown type: ${JSON.stringify(type)}`);
}
function parseAbilities(abilitySet) {
	return abilitySet.abilities.map((ability) => {
		switch (ability) {
			case "Copy": return "copy";
			case "Drop": return "drop";
			case "Store": return "store";
			case "Key": return "key";
			default: return "unknown";
		}
	});
}
function parseVisibility(visibility) {
	switch (visibility) {
		case "Public": return "public";
		case "Private": return "private";
		case "Friend": return "friend";
		default: return "unknown";
	}
}
//#endregion
//#region node_modules/@mysten/sui/dist/jsonRpc/client.mjs
var SUI_CLIENT_BRAND = Symbol.for("@mysten/SuiJsonRpcClient");
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
function isSuiJsonRpcClient(client) {
	return typeof client === "object" && client !== null && client[SUI_CLIENT_BRAND] === true;
}
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
var SuiJsonRpcClient = class extends BaseClient {
	get [SUI_CLIENT_BRAND]() {
		return true;
	}
	/**
	* Establish a connection to a Sui RPC endpoint
	*
	* @param options configuration options for the API Client
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	constructor(options) {
		super({ network: options.network });
		this.jsonRpc = this;
		this.transport = options.transport ?? new JsonRpcHTTPTransport({ url: options.url });
		this.core = new JSONRpcCoreClient({
			jsonRpcClient: this,
			mvr: options.mvr
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getRpcApiVersion({ signal } = {}) {
		return (await this.transport.request({
			method: "rpc.discover",
			params: [],
			signal
		})).info.version;
	}
	/**
	* Get all Coin<`coin_type`> objects owned by an address.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCoins({ coinType, owner, cursor, limit, signal }) {
		if (!owner || !isValidSuiAddress(normalizeSuiAddress(owner))) throw new Error("Invalid Sui address");
		if (coinType && hasMvrName(coinType)) coinType = (await this.core.mvr.resolveType({
			type: coinType,
			signal
		})).type;
		const result = await this.transport.request({
			method: "suix_getCoins",
			params: [
				owner,
				coinType,
				cursor,
				limit
			],
			signal
		});
		return {
			...result,
			data: result.data.filter((coin) => !isCoinReservationDigest(coin.digest))
		};
	}
	/**
	* Get all Coin objects owned by an address.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getAllCoins(input) {
		if (!input.owner || !isValidSuiAddress(normalizeSuiAddress(input.owner))) throw new Error("Invalid Sui address");
		const result = await this.transport.request({
			method: "suix_getAllCoins",
			params: [
				input.owner,
				input.cursor,
				input.limit
			],
			signal: input.signal
		});
		return {
			...result,
			data: result.data.filter((coin) => !isCoinReservationDigest(coin.digest))
		};
	}
	/**
	* Get the total coin balance for one coin type, owned by the address owner.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getBalance({ owner, coinType, signal }) {
		if (!owner || !isValidSuiAddress(normalizeSuiAddress(owner))) throw new Error("Invalid Sui address");
		if (coinType && hasMvrName(coinType)) coinType = (await this.core.mvr.resolveType({
			type: coinType,
			signal
		})).type;
		return await this.transport.request({
			method: "suix_getBalance",
			params: [owner, coinType],
			signal
		});
	}
	/**
	* Get the total coin balance for all coin types, owned by the address owner.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getAllBalances(input) {
		if (!input.owner || !isValidSuiAddress(normalizeSuiAddress(input.owner))) throw new Error("Invalid Sui address");
		return await this.transport.request({
			method: "suix_getAllBalances",
			params: [input.owner],
			signal: input.signal
		});
	}
	/**
	* Fetch CoinMetadata for a given coin type
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCoinMetadata({ coinType, signal }) {
		if (coinType && hasMvrName(coinType)) coinType = (await this.core.mvr.resolveType({
			type: coinType,
			signal
		})).type;
		return await this.transport.request({
			method: "suix_getCoinMetadata",
			params: [coinType],
			signal
		});
	}
	/**
	*  Fetch total supply for a coin
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getTotalSupply({ coinType, signal }) {
		if (coinType && hasMvrName(coinType)) coinType = (await this.core.mvr.resolveType({
			type: coinType,
			signal
		})).type;
		return await this.transport.request({
			method: "suix_getTotalSupply",
			params: [coinType],
			signal
		});
	}
	/**
	* Invoke any RPC method
	* @param method the method to be invoked
	* @param args the arguments to be passed to the RPC request
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async call(method, params, { signal } = {}) {
		return await this.transport.request({
			method,
			params,
			signal
		});
	}
	/**
	* Get Move function argument types like read, write and full access
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getMoveFunctionArgTypes({ package: pkg, module, function: fn, signal }) {
		if (pkg && isValidNamedPackage(pkg)) pkg = (await this.core.mvr.resolvePackage({
			package: pkg,
			signal
		})).package;
		return await this.transport.request({
			method: "sui_getMoveFunctionArgTypes",
			params: [
				pkg,
				module,
				fn
			],
			signal
		});
	}
	/**
	* Get a map from module name to
	* structured representations of Move modules
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getNormalizedMoveModulesByPackage({ package: pkg, signal }) {
		if (pkg && isValidNamedPackage(pkg)) pkg = (await this.core.mvr.resolvePackage({
			package: pkg,
			signal
		})).package;
		return await this.transport.request({
			method: "sui_getNormalizedMoveModulesByPackage",
			params: [pkg],
			signal
		});
	}
	/**
	* Get a structured representation of Move module
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getNormalizedMoveModule({ package: pkg, module, signal }) {
		if (pkg && isValidNamedPackage(pkg)) pkg = (await this.core.mvr.resolvePackage({
			package: pkg,
			signal
		})).package;
		return await this.transport.request({
			method: "sui_getNormalizedMoveModule",
			params: [pkg, module],
			signal
		});
	}
	/**
	* Get a structured representation of Move function
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getNormalizedMoveFunction({ package: pkg, module, function: fn, signal }) {
		if (pkg && isValidNamedPackage(pkg)) pkg = (await this.core.mvr.resolvePackage({
			package: pkg,
			signal
		})).package;
		return await this.transport.request({
			method: "sui_getNormalizedMoveFunction",
			params: [
				pkg,
				module,
				fn
			],
			signal
		});
	}
	/**
	* Get a structured representation of Move struct
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getNormalizedMoveStruct({ package: pkg, module, struct, signal }) {
		if (pkg && isValidNamedPackage(pkg)) pkg = (await this.core.mvr.resolvePackage({
			package: pkg,
			signal
		})).package;
		return await this.transport.request({
			method: "sui_getNormalizedMoveStruct",
			params: [
				pkg,
				module,
				struct
			],
			signal
		});
	}
	/**
	* Get all objects owned by an address
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getOwnedObjects(input) {
		if (!input.owner || !isValidSuiAddress(normalizeSuiAddress(input.owner))) throw new Error("Invalid Sui address");
		const filter = input.filter ? { ...input.filter } : void 0;
		if (filter && "MoveModule" in filter && isValidNamedPackage(filter.MoveModule.package)) filter.MoveModule = {
			module: filter.MoveModule.module,
			package: (await this.core.mvr.resolvePackage({
				package: filter.MoveModule.package,
				signal: input.signal
			})).package
		};
		else if (filter && "StructType" in filter && hasMvrName(filter.StructType)) filter.StructType = (await this.core.mvr.resolveType({
			type: filter.StructType,
			signal: input.signal
		})).type;
		return await this.transport.request({
			method: "suix_getOwnedObjects",
			params: [
				input.owner,
				{
					filter,
					options: input.options
				},
				input.cursor,
				input.limit
			],
			signal: input.signal
		});
	}
	/**
	* Get details about an object
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getObject(input) {
		if (!input.id || !isValidSuiObjectId(normalizeSuiObjectId(input.id))) throw new Error("Invalid Sui Object id");
		return await this.transport.request({
			method: "sui_getObject",
			params: [input.id, input.options],
			signal: input.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async tryGetPastObject(input) {
		return await this.transport.request({
			method: "sui_tryGetPastObject",
			params: [
				input.id,
				input.version,
				input.options
			],
			signal: input.signal
		});
	}
	/**
	* Batch get details about a list of objects. If any of the object ids are duplicates the call will fail
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async multiGetObjects(input) {
		input.ids.forEach((id) => {
			if (!id || !isValidSuiObjectId(normalizeSuiObjectId(id))) throw new Error(`Invalid Sui Object id ${id}`);
		});
		if (input.ids.length !== new Set(input.ids).size) throw new Error(`Duplicate object ids in batch call ${input.ids}`);
		return await this.transport.request({
			method: "sui_multiGetObjects",
			params: [input.ids, input.options],
			signal: input.signal
		});
	}
	/**
	* Get transaction blocks for a given query criteria
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async queryTransactionBlocks({ filter, options, cursor, limit, order, signal }) {
		if (filter && "MoveFunction" in filter && isValidNamedPackage(filter.MoveFunction.package)) filter = {
			...filter,
			MoveFunction: { package: (await this.core.mvr.resolvePackage({
				package: filter.MoveFunction.package,
				signal
			})).package }
		};
		return await this.transport.request({
			method: "suix_queryTransactionBlocks",
			params: [
				{
					filter,
					options
				},
				cursor,
				limit,
				(order || "descending") === "descending"
			],
			signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getTransactionBlock(input) {
		if (!isValidTransactionDigest(input.digest)) throw new Error("Invalid Transaction digest");
		return await this.transport.request({
			method: "sui_getTransactionBlock",
			params: [input.digest, input.options],
			signal: input.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async multiGetTransactionBlocks(input) {
		input.digests.forEach((d) => {
			if (!isValidTransactionDigest(d)) throw new Error(`Invalid Transaction digest ${d}`);
		});
		if (input.digests.length !== new Set(input.digests).size) throw new Error(`Duplicate digests in batch call ${input.digests}`);
		return await this.transport.request({
			method: "sui_multiGetTransactionBlocks",
			params: [input.digests, input.options],
			signal: input.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async executeTransactionBlock({ transactionBlock, signature, options, signal }) {
		return await this.transport.request({
			method: "sui_executeTransactionBlock",
			params: [
				typeof transactionBlock === "string" ? transactionBlock : toBase64(transactionBlock),
				Array.isArray(signature) ? signature : [signature],
				options
			],
			signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async signAndExecuteTransaction({ transaction, signer, ...input }) {
		let transactionBytes;
		if (transaction instanceof Uint8Array) transactionBytes = transaction;
		else {
			transaction.setSenderIfNotSet(signer.toSuiAddress());
			transactionBytes = await transaction.build({ client: this });
		}
		const { signature, bytes } = await signer.signTransaction(transactionBytes);
		return this.executeTransactionBlock({
			transactionBlock: bytes,
			signature,
			...input
		});
	}
	/**
	* Get total number of transactions
	*/
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getTotalTransactionBlocks({ signal } = {}) {
		const resp = await this.transport.request({
			method: "sui_getTotalTransactionBlocks",
			params: [],
			signal
		});
		return BigInt(resp);
	}
	/**
	* Getting the reference gas price for the network
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getReferenceGasPrice({ signal } = {}) {
		const resp = await this.transport.request({
			method: "suix_getReferenceGasPrice",
			params: [],
			signal
		});
		return BigInt(resp);
	}
	/**
	* Return the delegated stakes for an address
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getStakes(input) {
		if (!input.owner || !isValidSuiAddress(normalizeSuiAddress(input.owner))) throw new Error("Invalid Sui address");
		return await this.transport.request({
			method: "suix_getStakes",
			params: [input.owner],
			signal: input.signal
		});
	}
	/**
	* Return the delegated stakes queried by id.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getStakesByIds(input) {
		input.stakedSuiIds.forEach((id) => {
			if (!id || !isValidSuiObjectId(normalizeSuiObjectId(id))) throw new Error(`Invalid Sui Stake id ${id}`);
		});
		return await this.transport.request({
			method: "suix_getStakesByIds",
			params: [input.stakedSuiIds],
			signal: input.signal
		});
	}
	/**
	* Return the latest system state content.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getLatestSuiSystemState({ signal } = {}) {
		return await this.transport.request({
			method: "suix_getLatestSuiSystemState",
			params: [],
			signal
		});
	}
	/**
	* Get events for a given query criteria
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async queryEvents({ query, cursor, limit, order, signal }) {
		if (query && "MoveEventType" in query && hasMvrName(query.MoveEventType)) query = {
			...query,
			MoveEventType: (await this.core.mvr.resolveType({
				type: query.MoveEventType,
				signal
			})).type
		};
		if (query && "MoveEventModule" in query && isValidNamedPackage(query.MoveEventModule.package)) query = {
			...query,
			MoveEventModule: {
				module: query.MoveEventModule.module,
				package: (await this.core.mvr.resolvePackage({
					package: query.MoveEventModule.package,
					signal
				})).package
			}
		};
		if ("MoveModule" in query && isValidNamedPackage(query.MoveModule.package)) query = {
			...query,
			MoveModule: {
				module: query.MoveModule.module,
				package: (await this.core.mvr.resolvePackage({
					package: query.MoveModule.package,
					signal
				})).package
			}
		};
		return await this.transport.request({
			method: "suix_queryEvents",
			params: [
				query,
				cursor,
				limit,
				(order || "descending") === "descending"
			],
			signal
		});
	}
	/**
	* Runs the transaction block in dev-inspect mode. Which allows for nearly any
	* transaction (or Move call) with any arguments. Detailed results are
	* provided, including both the transaction effects and any return values.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async devInspectTransactionBlock(input) {
		let devInspectTxBytes;
		if (isTransaction(input.transactionBlock)) {
			input.transactionBlock.setSenderIfNotSet(input.sender);
			devInspectTxBytes = toBase64(await input.transactionBlock.build({
				client: this,
				onlyTransactionKind: true
			}));
		} else if (typeof input.transactionBlock === "string") devInspectTxBytes = input.transactionBlock;
		else if (input.transactionBlock instanceof Uint8Array) devInspectTxBytes = toBase64(input.transactionBlock);
		else throw new Error("Unknown transaction block format.");
		input.signal?.throwIfAborted();
		return await this.transport.request({
			method: "sui_devInspectTransactionBlock",
			params: [
				input.sender,
				devInspectTxBytes,
				input.gasPrice?.toString(),
				input.epoch
			],
			signal: input.signal
		});
	}
	/**
	* Dry run a transaction block and return the result.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async dryRunTransactionBlock(input) {
		return await this.transport.request({
			method: "sui_dryRunTransactionBlock",
			params: [typeof input.transactionBlock === "string" ? input.transactionBlock : toBase64(input.transactionBlock)]
		});
	}
	/**
	* Return the list of dynamic field objects owned by an object
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getDynamicFields(input) {
		if (!input.parentId || !isValidSuiObjectId(normalizeSuiObjectId(input.parentId))) throw new Error("Invalid Sui Object id");
		return await this.transport.request({
			method: "suix_getDynamicFields",
			params: [
				input.parentId,
				input.cursor,
				input.limit
			],
			signal: input.signal
		});
	}
	/**
	* Return the dynamic field object information for a specified object
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getDynamicFieldObject(input) {
		return await this.transport.request({
			method: "suix_getDynamicFieldObject",
			params: [input.parentId, input.name],
			signal: input.signal
		});
	}
	/**
	* Get the sequence number of the latest checkpoint that has been executed
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getLatestCheckpointSequenceNumber({ signal } = {}) {
		const resp = await this.transport.request({
			method: "sui_getLatestCheckpointSequenceNumber",
			params: [],
			signal
		});
		return String(resp);
	}
	/**
	* Returns information about a given checkpoint
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCheckpoint(input) {
		return await this.transport.request({
			method: "sui_getCheckpoint",
			params: [input.id],
			signal: input.signal
		});
	}
	/**
	* Returns historical checkpoints paginated
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCheckpoints(input) {
		return await this.transport.request({
			method: "sui_getCheckpoints",
			params: [
				input.cursor,
				input?.limit,
				input.descendingOrder
			],
			signal: input.signal
		});
	}
	/**
	* Return the committee information for the asked epoch
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCommitteeInfo(input) {
		return await this.transport.request({
			method: "suix_getCommitteeInfo",
			params: [input?.epoch],
			signal: input?.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getNetworkMetrics({ signal } = {}) {
		return await this.transport.request({
			method: "suix_getNetworkMetrics",
			params: [],
			signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getAddressMetrics({ signal } = {}) {
		return await this.transport.request({
			method: "suix_getLatestAddressMetrics",
			params: [],
			signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getEpochMetrics(input) {
		return await this.transport.request({
			method: "suix_getEpochMetrics",
			params: [
				input?.cursor,
				input?.limit,
				input?.descendingOrder
			],
			signal: input?.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getAllEpochAddressMetrics(input) {
		return await this.transport.request({
			method: "suix_getAllEpochAddressMetrics",
			params: [input?.descendingOrder],
			signal: input?.signal
		});
	}
	/**
	* Return the committee information for the asked epoch
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getEpochs(input) {
		return await this.transport.request({
			method: "suix_getEpochs",
			params: [
				input?.cursor,
				input?.limit,
				input?.descendingOrder
			],
			signal: input?.signal
		});
	}
	/**
	* Returns list of top move calls by usage
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getMoveCallMetrics({ signal } = {}) {
		return await this.transport.request({
			method: "suix_getMoveCallMetrics",
			params: [],
			signal
		});
	}
	/**
	* Return the committee information for the asked epoch
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getCurrentEpoch({ signal } = {}) {
		return await this.transport.request({
			method: "suix_getCurrentEpoch",
			params: [],
			signal
		});
	}
	/**
	* Return the Validators APYs
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getValidatorsApy({ signal } = {}) {
		return await this.transport.request({
			method: "suix_getValidatorsApy",
			params: [],
			signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getChainIdentifier({ signal } = {}) {
		return toHex(fromBase58((await this.getCheckpoint({
			id: "0",
			signal
		})).digest).slice(0, 4));
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async resolveNameServiceAddress(input) {
		return await this.transport.request({
			method: "suix_resolveNameServiceAddress",
			params: [input.name],
			signal: input.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async resolveNameServiceNames({ format = "dot", ...input }) {
		const { nextCursor, hasNextPage, data } = await this.transport.request({
			method: "suix_resolveNameServiceNames",
			params: [
				input.address,
				input.cursor,
				input.limit
			],
			signal: input.signal
		});
		return {
			hasNextPage,
			nextCursor,
			data: data.map((name) => normalizeSuiNSName(name, format))
		};
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async getProtocolConfig(input) {
		return await this.transport.request({
			method: "sui_getProtocolConfig",
			params: [input?.version],
			signal: input?.signal
		});
	}
	/**
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async verifyZkLoginSignature(input) {
		return await this.transport.request({
			method: "sui_verifyZkLoginSignature",
			params: [
				input.bytes,
				input.signature,
				input.intentScope,
				input.author
			],
			signal: input.signal
		});
	}
	/**
	* Wait for a transaction block result to be available over the API.
	* This can be used in conjunction with `executeTransactionBlock` to wait for the transaction to
	* be available via the API.
	* This currently polls the `getTransactionBlock` API to check for the transaction.
	* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
	* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
	*/
	async waitForTransaction({ signal, timeout = 6e4, pollInterval = 2e3, ...input }) {
		const timeoutSignal = AbortSignal.timeout(timeout);
		const timeoutPromise = new Promise((_, reject) => {
			timeoutSignal.addEventListener("abort", () => reject(timeoutSignal.reason));
		});
		timeoutPromise.catch(() => {});
		while (!timeoutSignal.aborted) {
			signal?.throwIfAborted();
			try {
				return await this.getTransactionBlock(input);
			} catch {
				await Promise.race([new Promise((resolve) => setTimeout(resolve, pollInterval)), timeoutPromise]);
			}
		}
		timeoutSignal.throwIfAborted();
		throw new Error("Unexpected error while waiting for transaction block.");
	}
};
//#endregion
//#region node_modules/@mysten/sui/dist/jsonRpc/network.mjs
/**
* @deprecated JSON-RPC APIs are deprecated in the Sui TypeScript SDK. Use `SuiGrpcClient`
* from `@mysten/sui/grpc` or `SuiGraphQLClient` from `@mysten/sui/graphql` instead.
*/
function getJsonRpcFullnodeUrl(network) {
	switch (network) {
		case "mainnet": return "https://fullnode.mainnet.sui.io:443";
		case "testnet": return "https://fullnode.testnet.sui.io:443";
		case "devnet": return "https://fullnode.devnet.sui.io:443";
		case "localnet": return "http://127.0.0.1:9000";
		default: throw new Error(`Unknown network: ${network}`);
	}
}
//#endregion
//#region node_modules/@mysten/sui/dist/cryptography/signature-scheme.mjs
var SIGNATURE_SCHEME_TO_FLAG = {
	ED25519: 0,
	Secp256k1: 1,
	Secp256r1: 2,
	MultiSig: 3,
	ZkLogin: 5,
	Passkey: 6
};
var SIGNATURE_SCHEME_TO_SIZE = {
	ED25519: 32,
	Secp256k1: 33,
	Secp256r1: 33,
	Passkey: 33
};
var SIGNATURE_FLAG_TO_SCHEME = {
	0: "ED25519",
	1: "Secp256k1",
	2: "Secp256r1",
	3: "MultiSig",
	5: "ZkLogin",
	6: "Passkey"
};
//#endregion
//#region node_modules/@mysten/sui/dist/cryptography/intent.mjs
/**
* Inserts a domain separator for a message that is being signed
*/
function messageWithIntent(scope, message) {
	return suiBcs.IntentMessage(suiBcs.bytes(message.length)).serialize({
		intent: {
			scope: { [scope]: true },
			version: { V0: true },
			appId: { Sui: true }
		},
		value: message
	}).toBytes();
}
//#endregion
//#region node_modules/@mysten/sui/dist/cryptography/publickey.mjs
function bytesEqual(a, b) {
	if (a === b) return true;
	if (a.length !== b.length) return false;
	for (let i = 0; i < a.length; i++) if (a[i] !== b[i]) return false;
	return true;
}
/**
* A public key
*/
var PublicKey = class {
	/**
	* Checks if two public keys are equal
	*/
	equals(publicKey) {
		return bytesEqual(this.toRawBytes(), publicKey.toRawBytes());
	}
	/**
	* Return the base-64 representation of the public key
	*/
	toBase64() {
		return toBase64(this.toRawBytes());
	}
	toString() {
		throw new Error("`toString` is not implemented on public keys. Use `toBase64()` or `toRawBytes()` instead.");
	}
	/**
	* Return the Sui representation of the public key encoded in
	* base-64. A Sui public key is formed by the concatenation
	* of the scheme flag with the raw bytes of the public key
	*/
	toSuiPublicKey() {
		return toBase64(this.toSuiBytes());
	}
	verifyWithIntent(bytes, signature, intent) {
		const digest = blake2b(messageWithIntent(intent, bytes), { dkLen: 32 });
		return this.verify(digest, signature);
	}
	/**
	* Verifies that the signature is valid for for the provided PersonalMessage
	*/
	verifyPersonalMessage(message, signature) {
		return this.verifyWithIntent(suiBcs.byteVector().serialize(message).toBytes(), signature, "PersonalMessage");
	}
	/**
	* Verifies that the signature is valid for for the provided Transaction
	*/
	verifyTransaction(transaction, signature) {
		return this.verifyWithIntent(transaction, signature, "TransactionData");
	}
	/**
	* Verifies that the public key is associated with the provided address
	*/
	verifyAddress(address) {
		return this.toSuiAddress() === address;
	}
	/**
	* Returns the bytes representation of the public key
	* prefixed with the signature scheme flag
	*/
	toSuiBytes() {
		const rawBytes = this.toRawBytes();
		const suiBytes = new Uint8Array(rawBytes.length + 1);
		suiBytes.set([this.flag()]);
		suiBytes.set(rawBytes, 1);
		return suiBytes;
	}
	/**
	* Return the Sui address associated with this Ed25519 public key
	*/
	toSuiAddress() {
		return normalizeSuiAddress(bytesToHex$1(blake2b(this.toSuiBytes(), { dkLen: 32 })).slice(0, 64));
	}
};
function parseSerializedKeypairSignature(serializedSignature) {
	const bytes = fromBase64(serializedSignature);
	const signatureScheme = SIGNATURE_FLAG_TO_SCHEME[bytes[0]];
	switch (signatureScheme) {
		case "ED25519":
		case "Secp256k1":
		case "Secp256r1":
			const size = SIGNATURE_SCHEME_TO_SIZE[signatureScheme];
			const signature = bytes.slice(1, bytes.length - size);
			return {
				serializedSignature,
				signatureScheme,
				signature,
				publicKey: bytes.slice(1 + signature.length),
				bytes
			};
		default: throw new Error("Unsupported signature scheme");
	}
}
//#endregion
//#region node_modules/@noble/curves/utils.js
/**
* Hex, bytes and number utilities.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
/**
* Validates that a value is an array, optionally validating each element.
* @param item - Value to validate.
* @param title - Label included in thrown errors.
* @param inner - Optional per-element validator, called with the element and its label.
* @returns The validated array.
* @example
* Validate an array of points before batch processing.
*
* ```ts
* aarray([1n, 2n], 'scalars');
* ```
*/
function aarray(item, title, inner = () => {}) {
	if (!Array.isArray(item)) throw new TypeError(`"${title}" expected array, got type=${typeof item}`);
	for (let i = 0; i < item.length; i++) inner(item[i], `${title}[${i}]`);
	return item;
}
/**
* Validates that a value is a byte array.
* @param value - Value to validate.
* @param length - Optional exact byte length.
* @param title - Optional field name.
* @returns Original byte array.
* @example
* Reject non-byte input before passing data into curve code.
*
* ```ts
* abytes(new Uint8Array(1));
* ```
*/
var abytes = (value, length, title) => abytes$1(value, length, title);
/**
* Validates that a value is a non-negative safe integer.
* @param n - Value to validate.
* @param title - Optional field name.
* @returns The validated number.
* @example
* Validate a numeric length before allocating buffers.
*
* ```ts
* anumber(1);
* ```
*/
var anumber = anumber$1;
/**
* Asserts something is a plain object-ish value, not null or array.
* @param value - Value to validate.
* @param title - Label included in thrown errors.
* @returns The validated object.
* @throws On wrong argument types. {@link TypeError}
* @example
* Validate an options object before checking fields.
*
* ```ts
* aobject({ flag: true });
* ```
*/
function aobject(value, title = "object") {
	if (value === null || typeof value !== "object" || Array.isArray(value)) throw new TypeError(title === "object" ? "expected valid options object" : `"${title}" expected object, got type=${typeof value}`);
	return value;
}
/**
* Asserts something is a function.
* @param value - Value to validate.
* @param title - Label included in thrown errors.
* @returns The validated function.
* @throws On wrong argument types. {@link TypeError}
* @example
* Validate a required method before calling it.
*
* ```ts
* afunction(() => true, 'predicate');
* ```
*/
function afunction(value, title) {
	if (typeof value !== "function") throw new TypeError(`"${title}" is invalid: expected function, got ${typeof value}`);
	return value;
}
/**
* Encodes bytes as lowercase hex.
* @param bytes - Bytes to encode.
* @returns Lowercase hex string.
* @example
* Serialize bytes as hex for logging or fixtures.
*
* ```ts
* bytesToHex(Uint8Array.of(1, 2, 3));
* ```
*/
var bytesToHex = bytesToHex$1;
/**
* Concatenates byte arrays.
* @param arrays - Byte arrays to join.
* @returns Concatenated bytes.
* @example
* Join domain-separated chunks into one buffer.
*
* ```ts
* concatBytes(Uint8Array.of(1), Uint8Array.of(2));
* ```
*/
var concatBytes = (...arrays) => concatBytes$1(...arrays);
/**
* Decodes lowercase or uppercase hex into bytes.
* @param hex - Hex string to decode.
* @returns Decoded bytes.
* @example
* Parse fixture hex into bytes before hashing.
*
* ```ts
* hexToBytes('0102');
* ```
*/
var hexToBytes = (hex) => hexToBytes$1(hex);
/**
* Checks whether a value is a Uint8Array.
* @param a - Value to inspect.
* @returns `true` when `a` is a Uint8Array.
* @example
* Branch on byte input before decoding it.
*
* ```ts
* isBytes(new Uint8Array(1));
* ```
*/
var isBytes = isBytes$1;
/**
* Reads random bytes from the platform CSPRNG.
* @param bytesLength - Number of random bytes to read.
* @returns Fresh random bytes.
* @example
* Generate a random seed for a keypair.
*
* ```ts
* randomBytes(2);
* ```
*/
var randomBytes = (bytesLength) => randomBytes$1(bytesLength);
var _0n$3 = /* @__PURE__ */ BigInt(0);
var _1n$4 = /* @__PURE__ */ BigInt(1);
var atitle = (title) => title ? `"${title}" ` : "";
/**
* Validates that a flag is boolean.
* @param value - Value to validate.
* @param title - Optional field name.
* @returns Original value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Reject non-boolean option flags early.
*
* ```ts
* abool(true);
* ```
*/
function abool(value, title = "") {
	if (typeof value !== "boolean") throw new TypeError(atitle(title) + "expected boolean, got type=" + typeof value);
	return value;
}
/**
* Validates that a value is a non-negative bigint or safe integer.
* @param n - Value to validate.
* @returns The same validated value.
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate one integer-like value before serializing it.
*
* ```ts
* abignumber(1n);
* ```
*/
function abignumber(n) {
	if (typeof n === "bigint") {
		if (!isPosBig(n)) throw new RangeError("positive bigint expected, got " + n);
	} else anumber(n);
	return n;
}
/**
* Validates that a value is a safe integer.
* @param value - Integer to validate.
* @param title - Optional field name.
* @throws On wrong argument types. {@link TypeError}
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Validate a window size before scalar arithmetic uses it.
*
* ```ts
* asafenumber(1);
* ```
*/
function asafenumber(value, title = "") {
	if (typeof value !== "number") {
		const prefix = title && `"${title}" `;
		throw new TypeError(prefix + "expected number, got type=" + typeof value);
	}
	if (!Number.isSafeInteger(value)) {
		const prefix = title && `"${title}" `;
		throw new RangeError(prefix + "expected safe integer, got " + value);
	}
}
/**
* Parses a big-endian hex string into bigint.
* Accepts odd-length hex through the native `BigInt('0x' + hex)` parser and currently surfaces the
* same native `SyntaxError` for malformed hex instead of wrapping it in a library-specific error.
* @param hex - Hex string without `0x`.
* @returns Parsed bigint value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Parse a scalar from fixture hex.
*
* ```ts
* hexToNumber('ff');
* ```
*/
function hexToNumber(hex) {
	if (typeof hex !== "string") throw new TypeError("hex string expected, got " + typeof hex);
	return hex === "" ? _0n$3 : BigInt("0x" + hex);
}
/**
* Parses big-endian bytes into bigint.
* @param bytes - Bytes in big-endian order.
* @returns Parsed bigint value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Read a scalar encoded in network byte order.
*
* ```ts
* bytesToNumberBE(Uint8Array.of(1, 0));
* ```
*/
function bytesToNumberBE(bytes) {
	return hexToNumber(bytesToHex$1(bytes));
}
/**
* Parses little-endian bytes into bigint.
* @param bytes - Bytes in little-endian order.
* @returns Parsed bigint value.
* @throws On wrong argument types. {@link TypeError}
* @example
* Read a scalar encoded in little-endian form.
*
* ```ts
* bytesToNumberLE(Uint8Array.of(1, 0));
* ```
*/
function bytesToNumberLE(bytes) {
	return hexToNumber(bytesToHex$1(copyBytes(abytes$1(bytes)).reverse()));
}
/**
* Encodes a bigint into fixed-length big-endian bytes.
* @param n - Number to encode.
* @param len - Output length in bytes. Must be greater than zero.
* @returns Big-endian byte array.
* @throws On wrong argument ranges or values. {@link RangeError}
* @throws If a documented runtime validation or state check fails. {@link Error}
* @example
* Serialize a scalar into a 32-byte field element.
*
* ```ts
* numberToBytesBE(255n, 2);
* ```
*/
function numberToBytesBE(n, len) {
	anumber$1(len);
	if (len === 0) throw new Error("zero output length is invalid");
	n = abignumber(n);
	const expectedLen = len * 2;
	const hex = n.toString(16);
	if (hex.length > expectedLen) throw new RangeError("number is too large");
	return hexToBytes$1(hex.padStart(expectedLen, "0"));
}
/**
* Encodes a bigint into fixed-length little-endian bytes.
* @param n - Number to encode.
* @param len - Output length in bytes.
* @returns Little-endian byte array.
* @throws On wrong argument ranges or values. {@link RangeError}
* @throws If a documented runtime validation or state check fails. {@link Error}
* @example
* Serialize a scalar for little-endian protocols.
*
* ```ts
* numberToBytesLE(255n, 2);
* ```
*/
function numberToBytesLE(n, len) {
	return numberToBytesBE(n, len).reverse();
}
/**
* Copies Uint8Array. We can't use u8a.slice(), because u8a can be Buffer,
* and Buffer#slice creates mutable copy. Never use Buffers!
* @param bytes - Bytes to copy.
* @returns Detached copy.
* @example
* Make an isolated copy before mutating serialized bytes.
*
* ```ts
* copyBytes(Uint8Array.of(1, 2, 3));
* ```
*/
function copyBytes(bytes) {
	return Uint8Array.from(abytes(bytes));
}
/**
* Checks whether n is non-negative bigint. Historical name.
* @param n - candidate value
* @returns `true` when the value is bigint and 0 or larger
* @example
* Check a candidate scalar before range validation.
*
* ```ts
* isPosBig(2n);
* ```
*/
function isPosBig(n) {
	return typeof n === "bigint" && _0n$3 <= n;
}
/**
* Checks whether a bigint lies inside a half-open range.
* @param n - Candidate value.
* @param min - Inclusive lower bound.
* @param max - Exclusive upper bound.
* @returns `true` when the value is inside the range.
* @example
* Check whether a candidate scalar fits the field order.
*
* ```ts
* inRange(2n, 1n, 3n);
* ```
*/
function inRange(n, min, max) {
	return isPosBig(n) && isPosBig(min) && isPosBig(max) && min <= n && n < max;
}
/**
* Asserts `min <= n < max`. NOTE: upper bound is exclusive.
* @param title - Value label for error messages.
* @param n - Candidate value.
* @param min - Inclusive lower bound.
* @param max - Exclusive upper bound.
* Wrong-type inputs are not separated from out-of-range values here: they still flow through the
* shared `RangeError` path because this is only a throwing wrapper around `inRange(...)`.
* @throws On wrong argument ranges or values. {@link RangeError}
* @example
* Assert that a bigint stays within one half-open range.
*
* ```ts
* aInRange('x', 2n, 1n, 256n);
* ```
*/
function aInRange(title, n, min, max) {
	if (!inRange(n, min, max)) throw new RangeError("expected valid " + title + ": " + min + " <= n < " + max + ", got " + n);
}
/**
* Calculates amount of bits in a bigint.
* Same as `n.toString(2).length`
* TODO: merge with nLength in modular
* @param n - Value to inspect.
* @returns Bit length.
* @throws If the value is negative. {@link Error}
* @example
* Measure the bit length of a scalar before serialization.
*
* ```ts
* bitLen(8n);
* ```
*/
function bitLen(n) {
	if (n < _0n$3) throw new Error("expected non-negative bigint, got " + n);
	return n === _0n$3 ? 0 : n.toString(2).length;
}
/**
* Calculate mask for N bits. Not using ** operator with bigints because of old engines.
* Same as BigInt(`0b${Array(i).fill('1').join('')}`)
* @param n - Number of bits. Negative widths are currently passed through to raw bigint shift
*   semantics and therefore produce `-1n`.
* @returns Bitmask value.
* @example
* Calculate mask for N bits.
*
* ```ts
* bitMask(4);
* ```
*/
var bitMask = (n) => {
	asafenumber(n, "n");
	return (_1n$4 << BigInt(n)) - _1n$4;
};
/**
* Validates declared required and optional field types on a plain object.
* Extra keys are intentionally ignored because many callers validate only the subset they use from
* richer option bags or runtime objects.
* This walks field schemas and formats detailed errors, so avoid it on hot paths; use direct
* one-line guards such as `aobject()`, `afunction()`, `abool()`, or `asafenumber()` instead.
* @param object - Object to validate.
* @param fields - Required field types.
* @param optFields - Optional field types.
* @param title - Object label included in thrown errors.
* @throws On wrong argument types. {@link TypeError}
* @example
* Check user options before building a curve helper.
*
* ```ts
* validateObject({ flag: true }, { flag: 'boolean' });
* ```
*/
function validateObject(object, fields = {}, optFields = {}, title = "object") {
	aobject(object, title);
	aobject(fields, "fields");
	aobject(optFields, "optFields");
	function checkField(fieldName, expectedType, isOpt) {
		const label = title === "object" ? `param "${String(fieldName)}"` : `"${title}.${String(fieldName)}"`;
		const val = object[fieldName];
		if (!Object.hasOwn(object, fieldName) && (isOpt ? val !== void 0 : expectedType !== "function")) throw new TypeError(`${label} is invalid: expected own property`);
		if (isOpt && val === void 0) return;
		const current = typeof val;
		if (current !== expectedType || val === null) throw new TypeError(`${label} is invalid: expected ${expectedType}, got ${current}`);
	}
	const iter = (f, isOpt) => Object.entries(f).forEach(([k, v]) => checkField(k, v, isOpt));
	iter(fields, false);
	iter(optFields, true);
}
//#endregion
//#region node_modules/@noble/curves/abstract/modular.js
/**
* Utils for modular division and fields.
* Field over 11 is a finite (Galois) field is integer number operations `mod 11`.
* There is no division: it is replaced by modular multiplicative inverse.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$2 = /* @__PURE__ */ BigInt(0);
var _1n$3 = /* @__PURE__ */ BigInt(1);
var _2n$2 = /* @__PURE__ */ BigInt(2);
var _3n = /* @__PURE__ */ BigInt(3);
var _4n$2 = /* @__PURE__ */ BigInt(4);
var _5n$1 = /* @__PURE__ */ BigInt(5);
var _7n = /* @__PURE__ */ BigInt(7);
var _8n$2 = /* @__PURE__ */ BigInt(8);
var _9n = /* @__PURE__ */ BigInt(9);
var _15n = /* @__PURE__ */ BigInt(15);
var _16n = /* @__PURE__ */ BigInt(16);
var POW_WINDOWED_MIN = /* @__PURE__ */ BigInt("0x10000000000000000");
/**
* @param a - Dividend value.
* @param b - Positive modulus.
* @returns Reduced value in `[0, b)` only when `b` is positive.
* @throws If the modulus is not positive. {@link Error}
* @example
* Normalize a bigint into one field residue.
*
* ```ts
* mod(-1n, 5n);
* ```
*/
function mod(a, b) {
	if (b <= _0n$2) throw new Error("mod: expected positive modulus, got " + b);
	const result = a % b;
	return result >= _0n$2 ? result : b + result;
}
/**
* Efficiently raise num to a power with modular reduction.
* Unsafe in some contexts: uses ladder, so can expose bigint bits.
* Low-level helper: callers that need canonical residues must pass a valid `num` for the chosen
* modulus instead of relying on the `power===0/1` fast paths to normalize it.
* @param num - Base value.
* @param power - Exponent value.
* @param modulo - Reduction modulus.
* @returns Modular exponentiation result.
* @throws If the modulus or exponent is invalid. {@link Error}
* @example
* Raise one bigint to a modular power.
*
* ```ts
* pow(2n, 6n, 11n) // 64n % 11n == 9n
* ```
*/
function pow(num, power, modulo) {
	if (modulo <= _1n$3) throw new Error("pow: expected modulus > 1, got " + modulo);
	if (typeof power !== "bigint") throw new TypeError("invalid exponent: expected bigint, got " + typeof power);
	if (power < _0n$2) throw new Error("invalid exponent, negatives unsupported");
	if (power === _0n$2) return _1n$3;
	if (power === _1n$3) return num;
	let d = num % modulo;
	if (d < _0n$2) d += modulo;
	if (power < POW_WINDOWED_MIN) {
		let p = _1n$3;
		while (power > _0n$2) {
			if (power & _1n$3) p = p * d % modulo;
			d = d * d % modulo;
			power >>= _1n$3;
		}
		return p;
	}
	const digits = [];
	while (power > _0n$2) {
		digits.push(Number(power & _15n));
		power >>= _4n$2;
	}
	const table = new Array(16);
	table[0] = _1n$3;
	table[1] = d;
	for (let i = 2; i < 16; i++) table[i] = table[i - 1] * d % modulo;
	let p = table[digits[digits.length - 1]];
	for (let w = digits.length - 2; w >= 0; w--) {
		p = p * p % modulo;
		p = p * p % modulo;
		p = p * p % modulo;
		p = p * p % modulo;
		const digit = digits[w];
		if (digit !== 0) p = p * table[digit] % modulo;
	}
	return p;
}
/**
* Does `x^(2^power)` mod p. `pow2(30, 4)` == `30^(2^4)`.
* Low-level helper: callers that need canonical residues must pass a valid `x` for the chosen
* modulus; the `power===0` fast path intentionally returns the input unchanged.
* @param x - Base value.
* @param power - Number of squarings.
* @param modulo - Reduction modulus.
* @returns Repeated-squaring result.
* @throws If the exponent is negative. {@link Error}
* @example
* Apply repeated squaring inside one field.
*
* ```ts
* pow2(3n, 2n, 11n);
* ```
*/
function pow2(x, power, modulo) {
	if (modulo <= _1n$3) throw new Error("pow2: expected modulus > 1, got " + modulo);
	if (power < _0n$2) throw new Error("pow2: expected non-negative exponent, got " + power);
	let res = x;
	while (power-- > _0n$2) {
		res *= res;
		res %= modulo;
	}
	return res;
}
/**
* Inverses number over modulo.
* Implemented using the {@link https://brilliant.org/wiki/extended-euclidean-algorithm/ | extended Euclidean algorithm}.
* @param number - Value to invert.
* @param modulo - Modulus greater than 1.
* @returns Multiplicative inverse.
* @throws If the modulus is invalid or the inverse does not exist. {@link Error}
* @example
* Compute one modular inverse with the extended Euclidean algorithm.
*
* ```ts
* invert(3n, 11n);
* ```
*/
function invert(number, modulo) {
	if (number === _0n$2) throw new Error("invert: expected non-zero number");
	if (modulo <= _1n$3) throw new Error("invert: expected modulus > 1, got " + modulo);
	let a = mod(number, modulo);
	let b = modulo;
	let x = _0n$2, u = _1n$3;
	while (a !== _0n$2) {
		const q = b / a;
		const r = b - a * q;
		const m = x - u * q;
		b = a, a = r, x = u, u = m;
	}
	if (b !== _1n$3) throw new Error("invert: does not exist");
	return mod(x, modulo);
}
function assertIsSquare(Fp, root, n) {
	const F = Fp;
	if (!F.eql(F.sqr(root), n)) throw new Error("Cannot find square root");
}
function aoddModulus(order, fnName) {
	if ((order & _1n$3) === _0n$2) throw new Error(fnName + ": expected odd modulus, got " + order);
}
function sqrt3mod4(Fp, n) {
	const F = Fp;
	const p1div4 = (F.ORDER + _1n$3) / _4n$2;
	const root = F.pow(n, p1div4);
	assertIsSquare(F, root, n);
	return root;
}
function sqrt5mod8(Fp, n) {
	const F = Fp;
	const p5div8 = (F.ORDER - _5n$1) / _8n$2;
	const n2 = F.mul(n, _2n$2);
	const v = F.pow(n2, p5div8);
	const nv = F.mul(n, v);
	const i = F.mul(F.mul(nv, _2n$2), v);
	const root = F.mul(nv, F.sub(i, F.ONE));
	assertIsSquare(F, root, n);
	return root;
}
function sqrt9mod16(P) {
	const Fp_ = Field(P);
	const tn = tonelliShanks(P);
	const c1 = tn(Fp_, Fp_.neg(Fp_.ONE));
	const c2 = tn(Fp_, c1);
	const c3 = tn(Fp_, Fp_.neg(c1));
	const c4 = (P + _7n) / _16n;
	return ((Fp, n) => {
		const F = Fp;
		let tv1 = F.pow(n, c4);
		let tv2 = F.mul(tv1, c1);
		const tv3 = F.mul(tv1, c2);
		const tv4 = F.mul(tv1, c3);
		const e1 = F.eql(F.sqr(tv2), n);
		const e2 = F.eql(F.sqr(tv3), n);
		tv1 = F.cmov(tv1, tv2, e1);
		tv2 = F.cmov(tv4, tv3, e2);
		const e3 = F.eql(F.sqr(tv2), n);
		const root = F.cmov(tv1, tv2, e3);
		assertIsSquare(F, root, n);
		return root;
	});
}
/**
* Tonelli-Shanks square root search algorithm.
* This implementation is variable-time: it searches data-dependently for the first non-residue `Z`
* and for the smallest `i` in the main loop, unlike RFC 9380 Appendix I.4's constant-time shape.
* 1. {@link https://eprint.iacr.org/2012/685.pdf | eprint 2012/685}, page 12
* 2. Square Roots from 1; 24, 51, 10 to Dan Shanks
* @param P - field order
* @returns function that takes field Fp (created from P) and number n
* @throws If the field is too small, non-prime, or the square root does not exist. {@link Error}
* @example
* Construct a square-root helper for primes that need Tonelli-Shanks.
*
* ```ts
* import { Field, tonelliShanks } from '@noble/curves/abstract/modular.js';
* const Fp = Field(17n);
* const sqrt = tonelliShanks(17n)(Fp, 4n);
* ```
*/
function tonelliShanks(P) {
	if (P < _3n) throw new Error("sqrt is not defined for small field");
	aoddModulus(P, "tonelliShanks");
	let Q = P - _1n$3;
	let S = 0;
	while (Q % _2n$2 === _0n$2) {
		Q /= _2n$2;
		S++;
	}
	let Z = _2n$2;
	const _Fp = Field(P);
	while (FpLegendre(_Fp, Z) === 1) if (Z++ > 1e3) throw new Error("Cannot find square root: probably non-prime P");
	if (S === 1) return sqrt3mod4;
	let cc = _Fp.pow(Z, Q);
	const Q1div2 = (Q + _1n$3) / _2n$2;
	return function tonelliSlow(Fp, n) {
		const F = Fp;
		if (F.is0(n)) return n;
		if (FpLegendre(F, n) !== 1) throw new Error("Cannot find square root");
		let M = S;
		let c = F.mul(F.ONE, cc);
		let t = F.pow(n, Q);
		let R = F.pow(n, Q1div2);
		while (!F.eql(t, F.ONE)) {
			if (F.is0(t)) throw new Error("Cannot find square root: probably non-prime P");
			let i = 1;
			let t_tmp = F.sqr(t);
			while (!F.eql(t_tmp, F.ONE)) {
				i++;
				t_tmp = F.sqr(t_tmp);
				if (i === M) throw new Error("Cannot find square root");
			}
			const exponent = _1n$3 << BigInt(M - i - 1);
			const b = F.pow(c, exponent);
			M = i;
			c = F.sqr(b);
			t = F.mul(t, c);
			R = F.mul(R, b);
		}
		return R;
	};
}
/**
* Square root for a finite field. Will try optimized versions first:
*
* 1. P ≡ 3 (mod 4)
* 2. P ≡ 5 (mod 8)
* 3. P ≡ 9 (mod 16)
* 4. Tonelli-Shanks algorithm
*
* Different algorithms can give different roots, it is up to user to decide which one they want.
* For example there is FpSqrtOdd/FpSqrtEven to choose a root by oddness
* (used for hash-to-curve).
* @param P - Field order.
* @returns Square-root helper. The generic fallback inherits Tonelli-Shanks' variable-time
*   behavior and this selector assumes prime-field-style integer moduli.
* @throws If the field is unsupported or the square root does not exist. {@link Error}
* @example
* Choose the square-root helper appropriate for one field modulus.
*
* ```ts
* import { Field, FpSqrt } from '@noble/curves/abstract/modular.js';
* const Fp = Field(17n);
* const sqrt = FpSqrt(17n)(Fp, 4n);
* ```
*/
function FpSqrt(P) {
	aoddModulus(P, "Fp.sqrt");
	if (P % _4n$2 === _3n) return sqrt3mod4;
	if (P % _8n$2 === _5n$1) return sqrt5mod8;
	if (P % _16n === _9n) return sqrt9mod16(P);
	return tonelliShanks(P);
}
/**
* @param num - Value to inspect.
* @param modulo - Field modulus.
* @returns `true` when the least-significant little-endian bit is set.
* @throws If the modulus is invalid for `mod(...)`. {@link Error}
* @example
* Inspect the low bit used by little-endian sign conventions.
*
* ```ts
* isNegativeLE(3n, 11n);
* ```
*/
var isNegativeLE = (num, modulo) => (mod(num, modulo) & _1n$3) === _1n$3;
var FIELD_FIELDS = [
	"create",
	"isValid",
	"is0",
	"neg",
	"inv",
	"sqrt",
	"sqr",
	"eql",
	"add",
	"sub",
	"mul",
	"pow",
	"div",
	"addN",
	"subN",
	"mulN",
	"sqrN"
];
/**
* @param field - Field implementation.
* @returns Validated field. This only checks the arithmetic subset needed by generic helpers; it
*   does not guarantee full runtime-method coverage for serialization, batching, `cmov`, or
*   field-specific extras beyond positive `BYTES` / `BITS`.
* @throws If the field shape or numeric metadata are invalid. {@link Error}
* @example
* Check that a field implementation exposes the operations curve code expects.
*
* ```ts
* import { Field, validateField } from '@noble/curves/abstract/modular.js';
* const Fp = validateField(Field(17n));
* ```
*/
function validateField(field) {
	aobject(field, "field");
	if (typeof field.ORDER !== "bigint") throw new TypeError("param \"ORDER\" is invalid: expected bigint, got " + typeof field.ORDER);
	asafenumber(field.BYTES, "BYTES");
	asafenumber(field.BITS, "BITS");
	for (const name of FIELD_FIELDS) afunction(field[name], "field." + name);
	if (field.BYTES < 1 || field.BITS < 1) throw new Error("invalid field: expected BYTES/BITS > 0");
	if (field.ORDER <= _1n$3) throw new Error("invalid field: expected ORDER > 1, got " + field.ORDER);
	return field;
}
function FpInvertBatch(Fp, nums, passZero = false) {
	validateField(Fp);
	aarray(nums, "nums");
	abool(passZero, "passZero");
	const F = Fp;
	const inverted = new Array(nums.length).fill(passZero ? F.ZERO : void 0);
	const multipliedAcc = nums.reduce((acc, num, i) => {
		if (F.is0(num)) return acc;
		inverted[i] = acc;
		return F.mul(acc, num);
	}, F.ONE);
	const invertedAcc = F.inv(multipliedAcc);
	nums.reduceRight((acc, num, i) => {
		if (F.is0(num)) return acc;
		inverted[i] = F.mul(acc, inverted[i]);
		return F.mul(acc, num);
	}, invertedAcc);
	return inverted;
}
/**
* Legendre symbol.
* Legendre constant is used to calculate Legendre symbol (a | p)
* which denotes the value of a^((p-1)/2) (mod p).
*
* * (a | p) ≡ 1    if a is a square (mod p), quadratic residue
* * (a | p) ≡ -1   if a is not a square (mod p), quadratic non residue
* * (a | p) ≡ 0    if a ≡ 0 (mod p)
* @param Fp - Field implementation.
* @param n - Value to inspect.
* @returns Legendre symbol.
* @throws If the powered value does not match a valid Legendre symbol. {@link Error}
* @example
* Compute the Legendre symbol of one field element.
*
* ```ts
* import { Field, FpLegendre } from '@noble/curves/abstract/modular.js';
* const Fp = Field(17n);
* const symbol = FpLegendre(Fp, 4n);
* ```
*/
function FpLegendre(Fp, n) {
	validateField(Fp);
	const F = Fp;
	aoddModulus(F.ORDER, "FpLegendre");
	const p1mod2 = (F.ORDER - _1n$3) / _2n$2;
	const powered = F.pow(n, p1mod2);
	const yes = F.eql(powered, F.ONE);
	const zero = F.eql(powered, F.ZERO);
	const no = F.eql(powered, F.neg(F.ONE));
	if (!yes && !zero && !no) throw new Error("invalid Legendre symbol result");
	return yes ? 1 : zero ? 0 : -1;
}
/**
* @param n - Curve order. Callers are expected to pass a positive order.
* @param nBitLength - Optional cached bit length. Callers are expected to pass a positive cached
*   value when overriding the derived bit length.
* @returns Byte and bit lengths.
* @throws If the order or cached bit length is invalid. {@link Error}
* @example
* Measure the encoding sizes needed for one modulus.
*
* ```ts
* nLength(255n);
* ```
*/
function nLength(n, nBitLength) {
	if (nBitLength !== void 0) anumber(nBitLength);
	if (n <= _0n$2) throw new Error("invalid n length: expected positive n, got " + n);
	if (nBitLength !== void 0 && nBitLength < 1) throw new Error("invalid n length: expected positive bit length, got " + nBitLength);
	const bits = bitLen(n);
	if (nBitLength !== void 0 && nBitLength < bits) throw new Error(`invalid n length: expected nBitLength (${nBitLength}) >= bitLen(n) (${bits})`);
	const _nBitLength = nBitLength !== void 0 ? nBitLength : bits;
	return {
		nBitLength: _nBitLength,
		nByteLength: Math.ceil(_nBitLength / 8)
	};
}
var FIELD_SQRT = /* @__PURE__ */ new WeakMap();
var _Field = class {
	ORDER;
	BITS;
	BYTES;
	isLE;
	ZERO = _0n$2;
	ONE = _1n$3;
	_lengths;
	_mod;
	constructor(ORDER, opts = {}) {
		if (ORDER <= _1n$3) throw new Error("invalid field: expected ORDER > 1, got " + ORDER);
		let _nbitLength = void 0;
		this.isLE = false;
		if (opts != null && typeof opts === "object") {
			if (typeof opts.BITS === "number") _nbitLength = opts.BITS;
			if (typeof opts.sqrt === "function") Object.defineProperty(this, "sqrt", {
				value: opts.sqrt,
				enumerable: true
			});
			if (typeof opts.isLE === "boolean") this.isLE = opts.isLE;
			if (opts.allowedLengths) this._lengths = Object.freeze(opts.allowedLengths.slice());
			if (typeof opts.modFromBytes === "boolean") this._mod = opts.modFromBytes;
		}
		const { nBitLength, nByteLength } = nLength(ORDER, _nbitLength);
		if (nByteLength > 2048) throw new Error("invalid field: expected ORDER of <= 2048 bytes");
		this.ORDER = ORDER;
		this.BITS = nBitLength;
		this.BYTES = nByteLength;
		Object.freeze(this);
	}
	create(num) {
		return mod(num, this.ORDER);
	}
	isValid(num) {
		if (typeof num !== "bigint") throw new TypeError("invalid field element: expected bigint, got " + typeof num);
		return _0n$2 <= num && num < this.ORDER;
	}
	is0(num) {
		return num === _0n$2;
	}
	isValidNot0(num) {
		return !this.is0(num) && this.isValid(num);
	}
	isOdd(num) {
		return (num & _1n$3) === _1n$3;
	}
	neg(num) {
		return mod(-num, this.ORDER);
	}
	eql(lhs, rhs) {
		return lhs === rhs;
	}
	sqr(num) {
		return mod(num * num, this.ORDER);
	}
	add(lhs, rhs) {
		return mod(lhs + rhs, this.ORDER);
	}
	sub(lhs, rhs) {
		return mod(lhs - rhs, this.ORDER);
	}
	mul(lhs, rhs) {
		return mod(lhs * rhs, this.ORDER);
	}
	pow(num, power) {
		return pow(num, power, this.ORDER);
	}
	div(lhs, rhs) {
		return mod(lhs * invert(rhs, this.ORDER), this.ORDER);
	}
	sqrN(num) {
		return num * num;
	}
	addN(lhs, rhs) {
		return lhs + rhs;
	}
	subN(lhs, rhs) {
		return lhs - rhs;
	}
	mulN(lhs, rhs) {
		return lhs * rhs;
	}
	inv(num) {
		return invert(num, this.ORDER);
	}
	sqrt(num) {
		let sqrt = FIELD_SQRT.get(this);
		if (!sqrt) FIELD_SQRT.set(this, sqrt = FpSqrt(this.ORDER));
		return sqrt(this, num);
	}
	toBytes(num) {
		return this.isLE ? numberToBytesLE(num, this.BYTES) : numberToBytesBE(num, this.BYTES);
	}
	fromBytes(bytes, skipValidation = false) {
		abytes(bytes);
		const { _lengths: allowedLengths, BYTES, isLE, ORDER, _mod: modFromBytes } = this;
		if (allowedLengths) {
			if (bytes.length < 1 || !allowedLengths.includes(bytes.length) || bytes.length > BYTES) throw new Error("Field.fromBytes: expected " + allowedLengths + " bytes, got " + bytes.length);
			const padded = new Uint8Array(BYTES);
			padded.set(bytes, isLE ? 0 : padded.length - bytes.length);
			bytes = padded;
		}
		if (bytes.length !== BYTES) throw new Error("Field.fromBytes: expected " + BYTES + " bytes, got " + bytes.length);
		let scalar = isLE ? bytesToNumberLE(bytes) : bytesToNumberBE(bytes);
		if (modFromBytes) scalar = mod(scalar, ORDER);
		if (!skipValidation) {
			if (!this.isValid(scalar)) throw new Error("invalid field element: outside of range 0..ORDER");
		}
		return scalar;
	}
	invertBatch(lst) {
		return FpInvertBatch(this, lst, true);
	}
	cmov(a, b, condition) {
		abool(condition, "condition");
		return condition ? b : a;
	}
};
/**
* Creates a finite field. Major performance optimizations:
* * 1. Denormalized operations like mulN instead of mul.
* * 2. Identical object shape: never add or remove keys.
* * 3. Frozen stable object shape; the lazy sqrt cache lives in a module-level `WeakMap`.
* Fragile: always run a benchmark on a change.
* Security note: operations and low-level serializers like `toBytes` don't check `isValid` for
* all elements for performance and protocol-flexibility reasons; callers are responsible for
* supplying valid elements when they need canonical field behavior.
* This is low-level code, please make sure you know what you're doing.
*
* Note about field properties:
* * CHARACTERISTIC p = prime number, number of elements in main subgroup.
* * ORDER q = similar to cofactor in curves, may be composite `q = p^m`.
*
* @param ORDER - field order, probably prime, or could be composite
* @param opts - Field options such as bit length or endianness. See {@link FieldOpts}.
* @returns Frozen field instance with a stable object shape. This wrapper forwards `opts` straight
*   into `_Field`, so it inherits `_Field`'s assumptions about cached sizes and `allowedLengths`.
* @example
* Construct one prime field with optional overrides.
*
* ```ts
* Field(11n);
* ```
*/
function Field(ORDER, opts = {}) {
	Object.freeze(_Field.prototype);
	return new _Field(ORDER, opts);
}
//#endregion
//#region node_modules/@noble/curves/abstract/curve.js
/**
* Methods for elliptic curve multiplication by scalars.
* Contains wNAF-based ScalarMultiplier, pippenger.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n$1 = /* @__PURE__ */ BigInt(0);
var _1n$2 = /* @__PURE__ */ BigInt(1);
var _4n$1 = /* @__PURE__ */ BigInt(4);
var BLIND_BYTES = 16;
var BLIND_BITS = 128;
var FW_WINDOW = 5;
var TABLE_BYTES_MAX = /* @__PURE__ */ (() => 2 ** 31)();
/**
* Validates the static surface of a point constructor.
* This is only a cheap sanity check for the constructor hooks and fields consumed by generic
* factories; it does not certify `BASE`/`ZERO` semantics or prove the curve implementation itself.
* @param Point - Runtime point constructor.
* @throws On missing constructor hooks or malformed field metadata. {@link TypeError}
* @example
* Check that one point constructor exposes the static hooks generic helpers need.
*
* ```ts
* import { ed25519 } from '@noble/curves/ed25519.js';
* import { validatePointCons } from '@noble/curves/abstract/curve.js';
* validatePointCons(ed25519.Point);
* ```
*/
function validatePointCons(Point) {
	const pc = Point;
	if (typeof pc !== "function") throw new TypeError("\"Point\" expected constructor, got type=" + typeof Point);
	afunction(pc.fromAffine, "Point.fromAffine");
	afunction(pc.fromBytes, "Point.fromBytes");
	afunction(pc.fromHex, "Point.fromHex");
	aobject(pc.BASE, "Point.BASE");
	aobject(pc.ZERO, "Point.ZERO");
	validateField(pc.Fp);
	validateField(pc.Fn);
}
/**
* Takes a bunch of Projective Points but executes only one
* inversion on all of them. Inversion is very slow operation,
* so this improves performance massively.
* Optimization: converts a list of projective points to a list of identical points with Z=1.
* Input points are left unchanged; the normalized points are returned as fresh instances.
* @param c - Point constructor.
* @param points - Projective points.
* @returns Fresh projective points reconstructed from normalized affine coordinates.
* @example
* Batch-normalize projective points with a single shared inversion.
*
* ```ts
* import { normalizeZ } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const points = normalizeZ(p256.Point, [p256.Point.BASE, p256.Point.BASE.double()]);
* ```
*/
function normalizeZ(c, points) {
	validatePointCons(c);
	validateMSMPoints(points, c);
	const invertedZs = FpInvertBatch(c.Fp, points.map((p) => p.Z));
	return points.map((p, i) => c.fromAffine(p.toAffine(invertedZs[i])));
}
function validateW(W, bits, min = 1) {
	if (!Number.isSafeInteger(W) || W < min || W > bits) throw new Error("invalid window size, expected [" + min + ".." + bits + "], got W=" + W);
}
function validateTableBytes(numPoints, fpBytes) {
	const bytes = numPoints * (4 * fpBytes + 128);
	if (bytes > TABLE_BYTES_MAX) throw new Error("invalid window size: table would need ~" + Math.ceil(bytes / 2 ** 20) + " MiB, max " + TABLE_BYTES_MAX / 2 ** 20 + " MiB");
}
/**
* Probes an RNG once, at construction time: returns `undefined` when it is unavailable —
* throws or returns malformed bytes — so callers can downgrade to their unblinded /
* deterministic constant-time fallback. Blinding is defense-in-depth (DPA/template
* hardening), not a correctness or key-secrecy requirement, so availability-based
* downgrade is acceptable.
*
* The downgrade decision is deliberately static. After a successful probe the RNG becomes
* part of the trusted contract: later misbehavior must fail closed in per-call validation
* (throw), never downgrade — a dynamic fallback would let a tampered RNG silently strip
* blinding on demand. A probe can only ever classify broken environments, not adversarial
* RNGs: a stateful RNG can always behave while probed and misbehave later.
* @param randomBytes - RNG to probe, or `undefined` when the environment provides none.
* @param length - Byte length requested from the probe call.
* @returns The RNG when the probe produced `length` valid bytes; `undefined` otherwise.
* @example
* Probe an RNG once before enabling scalar blinding.
*
* ```ts
* import { probeRandomBytes } from '@noble/curves/abstract/curve.js';
* import { randomBytes } from '@noble/hashes/utils.js';
* const rng = probeRandomBytes(randomBytes, 16);
* ```
*/
function probeRandomBytes(randomBytes, length) {
	if (randomBytes === void 0) return void 0;
	afunction(randomBytes, "randomBytes");
	try {
		const probe = randomBytes(length);
		if (!isBytes(probe) || probe.length !== length) return void 0;
	} catch {
		return;
	}
	return randomBytes;
}
function validateMSMPoints(points, c) {
	aarray(points, "points");
	points.forEach((p, i) => {
		if (!(p instanceof c)) throw new Error("invalid point at index " + i);
	});
}
function validateMSMScalars(scalars, field, maxScalar) {
	if (!Array.isArray(scalars)) throw new Error("array of scalars expected");
	scalars.forEach((s, i) => {
		if (!(maxScalar === void 0 ? field.isValid(s) : isPosBig(s) && s < maxScalar)) throw new Error("invalid scalar at index " + i);
	});
}
var pointWindowSizes = /* @__PURE__ */ new WeakMap();
function getWindowSize(P) {
	return pointWindowSizes.get(P) || 1;
}
/** Table of odd multiples [1P, 3P, ..., (2⋅size−1)P]; width-W wNAF uses size = 2^(W−2). */
function oddMultiples(p, size) {
	const dbl = p.double();
	const t = [p];
	for (let j = 1; j < size; j++) t.push(t[j - 1].add(dbl));
	return t;
}
/**
* Width-W wNAF signed-digit recoding (W >= 2), LSB-first: digits are 0 or odd with
* |digit| < 2^(W−1); nonzero density ~1/(W+1) (a nonzero digit is followed by W−1 zeros).
*/
function wnafDigits(n, W) {
	const size = 2 ** W;
	const half = size / 2;
	const mask = BigInt(size - 1);
	const d = [];
	while (n > _0n$1) {
		let w = 0;
		if (n & _1n$2) {
			w = Number(n & mask);
			if (w >= half) w -= size;
			n -= BigInt(w);
		}
		d.push(w);
		n >>= _1n$2;
	}
	return d;
}
/**
* Fixed-position signed-window recoding for precomputed wNAF: `n = Σ digits[w]⋅2^(w⋅W)` with
* digits in `[−2^(W−1)+1, 2^(W−1)]`. Digit count is fixed by `windows` (callers reserve one
* extra window for the final carry), so recoding length does not depend on the scalar.
*/
function signedWindowDigits(n, W, windows) {
	const size = 2 ** W;
	const half = size / 2;
	const mask = BigInt(size - 1);
	const shiftBy = BigInt(W);
	const d = [];
	for (let w = 0; w < windows; w++) {
		let v = Number(n & mask);
		n >>= shiftBy;
		if (v > half) {
			v -= size;
			n += _1n$2;
		}
		d.push(v);
	}
	if (n !== _0n$1) throw new Error("invalid wnaf");
	return d;
}
/**
* Shared vartime walk over per-scalar wNAF digit streams: one doubling of a single shared
* accumulator per bit position of the longest recoding, one signed table addition per
* nonzero digit. `tables[i]` must hold the odd multiples of the i-th point.
*/
function wnafWalk(zero, tables, digits) {
	let max = 0;
	for (const d of digits) max = Math.max(max, d.length);
	let acc = zero;
	for (let bit = max - 1; bit >= 0; bit--) {
		if (bit !== max - 1) acc = acc.double();
		for (let i = 0; i < digits.length; i++) {
			const w = digits[i][bit];
			if (w) {
				const item = tables[i][Math.abs(w) - 1 >> 1];
				acc = acc.add(w < 0 ? item.negate() : item);
			}
		}
	}
	return acc;
}
/**
* Elliptic curve multiplication of Point by scalar.
* Routes between cached-table, fixed-window, and one-shot wNAF paths; entry points validate
* their own scalars (`mulCT`/`mulCTBlinded`: `1 <= s < Fn.ORDER`; `mulUnsafe`: up to the
* `Fn.ORDER^4` DoS cap via {@link mulAddUnsafe}).
* Table generation is expensive and happens on first call of `multiply()`
* (or eagerly via `precompute(W, false)`). By default, `BASE` point is precomputed.
*
* Cached algorithm is signed fixed-window wNAF:
* - table stores, for every window w, the multiples `[1..2^(W−1)]⋅2^(w⋅W)⋅P` — all doublings
*   are baked in, so a multiplication is exactly one table addition per window
* - window count is fixed (`ceil(bits/W) + 1`), so the point-operation count is scalar-independent
*   (basis of the constant-time path)
* - for a 256-bit curve and W=6: 44⋅32 = 1408 table points, 44 additions per multiply
* - secret scalars are additionally blinded (see {@link ScalarMultiplier.mulCTBlinded}), which
*   widens tables by 128 bits
* @param Point - Point constructor.
* @param randomBytes - RNG used for scalar blinding; required by the blinded secret path.
* @example
* Elliptic curve multiplication of Point by scalar.
*
* ```ts
* import { ScalarMultiplier } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const mul = new ScalarMultiplier(p256.Point);
* ```
*/
var ScalarMultiplier = class {
	Point;
	BASE;
	ZERO;
	randomBytes;
	wnafPrecomputes = /* @__PURE__ */ new WeakMap();
	baseCanBeBlinded;
	bits;
	constructor(Point, randomBytes) {
		validatePointCons(Point);
		this.randomBytes = probeRandomBytes(randomBytes, BLIND_BYTES);
		this.Point = Point;
		this.BASE = Point.BASE;
		this.ZERO = Point.ZERO;
		this.bits = Point.Fn.BITS;
	}
	/**
	* Creates a signed fixed-window wNAF precomputation table: for every window w, the
	* multiples `[1..2^(W−1)]⋅2^(w⋅W)⋅P`, flattened. All doublings are baked into the table,
	* so cached multiplication is additions-only. `windows = ceil(bits/W) + 1`: the extra
	* window absorbs the final carry of signed-digit recoding.
	* For a 256-bit curve and W=6, the table is 44⋅32 = 1408 points.
	* @param point - Point instance
	* @param W - window size
	* @param bits - scalar bitlength the table must cover
	*/
	buildWnafTable(point, W, bits) {
		const windows = Math.ceil(bits / W) + 1;
		const half = 2 ** (W - 1);
		const comp = [];
		let base = point;
		for (let w = 0; w < windows; w++) {
			let acc = base;
			for (let i = 0; i < half; i++) {
				comp.push(acc);
				acc = acc.add(base);
			}
			base = comp[comp.length - 1].double();
		}
		return {
			W,
			bits,
			windows,
			comp
		};
	}
	/**
	* Implements ec multiplication using precomputed signed fixed-window wNAF tables.
	* Constant-time: fixed window count with one table addition per window — zero digits feed
	* the fake accumulator — and no doublings; the lookup scans the whole window slice.
	* Scalar bounds are validated by the public entry points ({@link ScalarMultiplier.mulCT},
	* {@link ScalarMultiplier.mulCTBlinded}, {@link ScalarMultiplier.mulUnsafe});
	* signedWindowDigits throws if `n` exceeds the table.
	* @returns real and fake (for const-time) points
	*/
	wnafCachedCT(precomputes, n) {
		const { W, windows, comp } = precomputes;
		const half = 2 ** (W - 1);
		const digits = signedWindowDigits(n, W, windows);
		let p = this.ZERO;
		let f = this.BASE;
		for (let w = 0; w < windows; w++) {
			const digit = digits[w];
			const start = w * half;
			const idx = Math.abs(digit) - 1;
			let sel = comp[start];
			for (let i = 1; i < half; i++) sel = i === idx ? comp[start + i] : sel;
			const neg = sel.negate();
			if (digit === 0) f = f.add(comp[start]);
			else p = p.add(digit < 0 ? neg : sel);
		}
		return {
			p,
			f
		};
	}
	getWnafPrecomputes(W, point, bits, transform) {
		let entries = this.wnafPrecomputes.get(point);
		let comp = entries?.find((entry) => entry.W === W && entry.bits === bits);
		if (!comp) {
			comp = this.buildWnafTable(point, W, bits);
			if (typeof transform === "function") comp = {
				...comp,
				comp: transform(comp.comp)
			};
			if (!entries) {
				entries = [];
				this.wnafPrecomputes.set(point, entries);
			}
			entries.push(comp);
		}
		return comp;
	}
	assertPoint(point) {
		if (!(point instanceof this.Point)) throw new TypeError("\"point\" expected Point instance, got type=" + typeof point);
	}
	validateMulInput(point, scalar) {
		this.assertPoint(point);
		if (!inRange(scalar, _1n$2, this.Point.Fn.ORDER)) throw new Error("invalid scalar");
	}
	runCT(point, n, bits, transform) {
		const W = getWindowSize(point);
		if (W === 1) return this.fixedWindowCT(point, n, bits);
		return this.wnafCachedCT(this.getWnafPrecomputes(W, point, bits, transform), n);
	}
	mulCT(point, scalar, transform) {
		this.validateMulInput(point, scalar);
		return this.runCT(point, scalar, this.bits, transform);
	}
	mulCTBlinded(point, scalar, transform) {
		this.validateMulInput(point, scalar);
		if (this.randomBytes === void 0) throw new Error("randomBytes is required for scalar blinding");
		const bits = this.Point.Fn.BITS + BLIND_BITS;
		const blind = this.randomBytes(BLIND_BYTES);
		if (!isBytes(blind) || blind.length !== BLIND_BYTES) throw new Error("randomBytes returned invalid byte array");
		blind[0] = blind[0] & 63 | 128;
		const n = scalar + bytesToNumberBE(blind) * this.Point.Fn.ORDER;
		return this.runCT(point, n, bits, transform);
	}
	/**
	* Constant-time multiplication `n*point` for an un-precomputed point, via a small fixed window.
	* A cached wNAF table only pays off when reused; a flat 2^FW_WINDOW table (`size-1` adds) is
	* far cheaper to build for a single use. The point-operation sequence is independent of `n`:
	* build the table, then per window exactly FW_WINDOW doublings, a data-oblivious scan over
	* every table entry, and one addition (adds the identity when the window digit is 0 — never
	* skipped).
	*
	* `n` must be `< 2^bits`. Assumes complete addition (adding the identity costs the same as any
	* add), which holds for the Weierstrass/Edwards point types used here. The table is left in
	* projective form (no normalizeZ): normalizing this small a table costs more than the
	* mixed-add savings it would buy for a single multiply.
	* @returns real point `p`; `f` duplicates it only to match {@link wnafCachedCT}'s return shape
	* (this path needs no fake accumulator — its op-count is already scalar-independent).
	*/
	fixedWindowCT(point, n, bits) {
		const W = FW_WINDOW;
		const size = 32;
		const mask = bitMask(W);
		const table = new Array(size);
		table[0] = this.ZERO;
		for (let i = 1; i < size; i++) table[i] = table[i - 1].add(point);
		const windows = Math.ceil(bits / W);
		let acc = this.ZERO;
		for (let window = windows - 1; window >= 0; window--) {
			if (window !== windows - 1) for (let d = 0; d < W; d++) acc = acc.double();
			const digit = Number(n >> BigInt(window * W) & mask);
			let sel = table[0];
			for (let i = 1; i < size; i++) sel = i === digit ? table[i] : sel;
			acc = acc.add(sel);
		}
		return {
			p: acc,
			f: acc
		};
	}
	shouldBlind(point, cofactor) {
		if (this.randomBytes === void 0) return false;
		if (cofactor === _1n$2) return true;
		if (point !== this.BASE) return false;
		if (this.baseCanBeBlinded === void 0) this.baseCanBeBlinded = this.mulUnsafe(this.BASE, this.Point.Fn.ORDER).is0();
		return this.baseCanBeBlinded;
	}
	mulSecret(point, scalar, cofactor, transform) {
		return this.shouldBlind(point, cofactor) ? this.mulCTBlinded(point, scalar, transform) : this.mulCT(point, scalar, transform);
	}
	mulUnsafe(point, scalar, transform) {
		this.assertPoint(point);
		if (!isPosBig(scalar)) throw new Error("invalid scalar");
		const W = getWindowSize(point);
		if (W === 1 || scalar >= this.Point.Fn.ORDER) return mulAddUnsafe(this.Point, [point], [scalar], true);
		const precomputes = this.getWnafPrecomputes(W, point, this.bits, transform);
		return this.wnafCachedCT(precomputes, scalar).p;
	}
	setWindowSize(point, W) {
		this.assertPoint(point);
		validateW(W, this.bits);
		validateTableBytes((Math.ceil((this.bits + BLIND_BITS) / W) + 1) * 2 ** (W - 1), this.Point.Fp.BYTES);
		pointWindowSizes.set(point, W);
		this.wnafPrecomputes.delete(point);
	}
	hasWindowSize(point) {
		return getWindowSize(point) !== 1;
	}
};
/**
* Combined multi-scalar multiplication `Σ scalars[i]⋅points[i]` via interleaved width-4 wNAF
* (Strauss–Shamir). Every input gets its own table of odd multiples `[1P, 3P, 5P, 7P]` and
* signed-digit recoding, but all walks share one doubling chain, so total cost is
* `~bits` doublings + `L⋅bits/5` additions instead of `L⋅bits` doublings for separate
* multiplications. Intended for the 2-4 point shapes of signature verification
* (`R = u1⋅G + u2⋅P`); use {@link pippenger} for larger batches.
*
* Not constant-time: only for public inputs. Scalars must satisfy `0 <= s < Fn.ORDER`;
* fold negative signs into the points before calling.
* @param c - Point constructor.
* @param points - Array of curve points.
* @param scalars - Array of non-negative scalars, same length as points.
* @param allowOversized - Replace the `s < Fn.ORDER` scalar check with a `Fn.ORDER^4` DoS cap.
*   Off by default. For scalars that must NOT be reduced mod ORDER: torsion checks
*   (`Fn.ORDER⋅P ≟ O`) and cofactor-clearing multiples. Walk length grows with `bitLen(s)`.
* @returns Combined multiplication result; identity for empty input.
* @throws If the point set or scalar set is invalid. {@link Error}
* @example
* Combined multi-scalar multiplication via Strauss–Shamir.
*
* ```ts
* import { mulAddUnsafe } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const G = p256.Point.BASE;
* const R = mulAddUnsafe(p256.Point, [G, G.double()], [2n, 3n]); // 2⋅G + 3⋅(2⋅G)
* ```
*/
function mulAddUnsafe(c, points, scalars, allowOversized = false) {
	validatePointCons(c);
	validateMSMPoints(points, c);
	abool(allowOversized, "allowOversized");
	validateMSMScalars(scalars, c.Fn, allowOversized ? c.Fn.ORDER ** _4n$1 : void 0);
	if (points.length !== scalars.length) throw new Error("arrays of points and scalars must have equal length");
	const tables = points.map((p) => oddMultiples(p, 4));
	const digits = scalars.map((n) => wnafDigits(n, 4));
	return wnafWalk(c.ZERO, tables, digits);
}
function createField(order, field, isLE) {
	if (field) {
		if (field.ORDER !== order) throw new Error("Field.ORDER must match order: Fp == p, Fn == n");
		validateField(field);
		return field;
	} else return Field(order, { isLE });
}
/**
* Validates basic CURVE shape and field membership, then creates fields.
* This does not prove that the generator is on-curve, that subgroup/order data are consistent, or
* that the curve equation itself is otherwise sane.
* @param type - Curve family.
* @param CURVE - Curve parameters.
* @param curveOpts - Optional field overrides. See {@link FpFn}:
*   - `Fp` (optional): Optional base-field override.
*   - `Fn` (optional): Optional scalar-field override.
* @param FpFnLE - Whether field encoding is little-endian.
* @returns Frozen curve parameters and fields.
* @throws If the curve parameters or field overrides are invalid. {@link Error}
* @example
* Build curve fields from raw constants before constructing a curve instance.
*
* ```ts
* const curve = createCurveFields('weierstrass', {
*   p: 17n,
*   n: 19n,
*   h: 1n,
*   a: 2n,
*   b: 2n,
*   Gx: 5n,
*   Gy: 1n,
* });
* ```
*/
function createCurveFields(type, CURVE, curveOpts = {}, FpFnLE) {
	if (type !== "weierstrass" && type !== "edwards") throw new Error("expected curve type \"weierstrass\" or \"edwards\"");
	if (FpFnLE === void 0) FpFnLE = type === "edwards";
	if (!CURVE || typeof CURVE !== "object") throw new Error(`expected valid ${type} CURVE object`);
	validateObject(curveOpts);
	for (const p of [
		"p",
		"n",
		"h"
	]) {
		const val = CURVE[p];
		if (!(isPosBig(val) && val !== _0n$1)) throw new Error(`CURVE.${p} must be positive bigint`);
	}
	const Fp = createField(CURVE.p, curveOpts.Fp, FpFnLE);
	const Fn = createField(CURVE.n, curveOpts.Fn, FpFnLE);
	const params = [
		"Gx",
		"Gy",
		"a",
		type === "weierstrass" ? "b" : "d"
	];
	for (const p of params) if (!Fp.isValid(CURVE[p])) throw new Error(`CURVE.${p} must be valid field element of CURVE.Fp`);
	CURVE = Object.freeze(Object.assign({}, CURVE));
	return {
		CURVE,
		Fp,
		Fn
	};
}
/**
* @param randomSecretKey - Secret-key generator.
* @param getPublicKey - Public-key derivation helper.
* @returns Keypair generator.
* @example
* Build a `keygen()` helper from existing secret-key and public-key primitives.
*
* ```ts
* import { createKeygen } from '@noble/curves/abstract/curve.js';
* import { p256 } from '@noble/curves/nist.js';
* const keygen = createKeygen(p256.utils.randomSecretKey, p256.getPublicKey);
* const pair = keygen();
* ```
*/
function createKeygen(randomSecretKey, getPublicKey) {
	return function keygen(seed) {
		const secretKey = randomSecretKey(seed);
		return {
			secretKey,
			publicKey: getPublicKey(secretKey)
		};
	};
}
//#endregion
//#region node_modules/@noble/curves/abstract/edwards.js
/**
* Twisted Edwards curve. The formula is: ax² + y² = 1 + dx²y².
* For design rationale of types / exports, see weierstrass module documentation.
* Untwisted Edwards curves exist, but they aren't used in real-world protocols.
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _0n = /* @__PURE__ */ BigInt(0);
var _1n$1 = /* @__PURE__ */ BigInt(1);
var _2n$1 = /* @__PURE__ */ BigInt(2);
var _4n = /* @__PURE__ */ BigInt(4);
var _8n$1 = /* @__PURE__ */ BigInt(8);
function isEdValidXY(Fp, CURVE, x, y) {
	const x2 = Fp.sqr(x);
	const y2 = Fp.sqr(y);
	const left = Fp.add(Fp.mul(CURVE.a, x2), y2);
	const right = Fp.add(Fp.ONE, Fp.mul(CURVE.d, Fp.mul(x2, y2)));
	return Fp.eql(left, right);
}
/**
* @param params - Curve parameters. See {@link EdwardsOpts}.
* @param extraOpts - Optional helpers and overrides. See {@link EdwardsExtraOpts}.
* @returns Edwards point constructor. Generator validation here only checks
*   that `(Gx, Gy)` satisfies the affine Edwards equation.
*   RFC 8032 base-point constraints like `B != (0,1)` and `[L]B = 0`
*   are left to the caller's chosen parameters, since eager subgroup
*   validation here adds about 10-15ms to heavyweight imports like ed448.
*   The returned constructor also eagerly marks `Point.BASE` for W=6
*   precompute caching. Some code paths still assume
*   `Fp.BYTES === Fn.BYTES`, so mismatched byte lengths are not fully audited here.
* @throws If the curve parameters or Edwards overrides are invalid. {@link Error}
* @example
* ```ts
* import { edwards } from '@noble/curves/abstract/edwards.js';
* import { jubjub } from '@noble/curves/misc.js';
* // Build a point constructor from explicit curve parameters, then use its base point.
* const Point = edwards(jubjub.Point.CURVE());
* Point.BASE.toHex();
* ```
*/
function edwards(params, extraOpts = {}) {
	validateObject(extraOpts, {}, {}, "extraOpts");
	const opts = extraOpts;
	const validated = createCurveFields("edwards", params, opts, opts.FpFnLE);
	const { Fp, Fn } = validated;
	let CURVE = validated.CURVE;
	const { h: cofactor } = CURVE;
	if (FpLegendre(Fp, CURVE.a) !== 1) throw new Error("edwards: CURVE.a must be a square in Fp for complete addition formulas");
	if (FpLegendre(Fp, CURVE.d) !== -1) throw new Error("edwards: CURVE.d must be a non-square in Fp for complete addition formulas");
	validateObject(opts, {}, {
		uvRatio: "function",
		randomBytes: "function"
	});
	const randomBytes$2 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
	const MASK = _2n$1 << BigInt(Fp.BYTES * 8) - _1n$1;
	function isOdd(n) {
		if (!Fp.isOdd) throw new Error("Field does not have .isOdd()");
		return Fp.isOdd(n);
	}
	const uvRatio = opts.uvRatio === void 0 ? (u, v) => {
		try {
			return {
				isValid: true,
				value: Fp.sqrt(Fp.div(u, v))
			};
		} catch (e) {
			return {
				isValid: false,
				value: _0n
			};
		}
	} : opts.uvRatio;
	if (!isEdValidXY(Fp, CURVE, CURVE.Gx, CURVE.Gy)) throw new Error("bad curve params: generator point");
	const mulA = Fp.eql(CURVE.a, Fp.neg(Fp.ONE)) ? (x) => Fp.neg(x) : Fp.eql(CURVE.a, Fp.ONE) ? (x) => x : (x) => Fp.mul(CURVE.a, x);
	/**
	* Asserts coordinate is valid: 0 <= n < MASK.
	* Coordinates >= Fp.ORDER are allowed for zip215.
	*/
	function acoord(title, n, banZero = false) {
		const min = banZero ? _1n$1 : _0n;
		aInRange("coordinate " + title, n, min, MASK);
		return n;
	}
	function aedpoint(other) {
		if (!(other instanceof Point)) throw new Error("EdwardsPoint expected");
	}
	class Point {
		static BASE = new Point(CURVE.Gx, CURVE.Gy, Fp.ONE, Fp.mul(CURVE.Gx, CURVE.Gy));
		static ZERO = new Point(Fp.ZERO, Fp.ONE, Fp.ONE, Fp.ZERO);
		static Fp = Fp;
		static Fn = Fn;
		X;
		Y;
		Z;
		T;
		constructor(X, Y, Z, T) {
			this.X = acoord("x", X);
			this.Y = acoord("y", Y);
			this.Z = acoord("z", Z, true);
			this.T = acoord("t", T);
			Object.freeze(this);
		}
		static CURVE() {
			return CURVE;
		}
		/**
		* Create one extended Edwards point from affine coordinates.
		* Does NOT validate that the point is on-curve or torsion-free.
		* Use `.assertValidity()` on adversarial inputs.
		*/
		static fromAffine(p) {
			if (p instanceof Point) throw new Error("extended point not allowed");
			const { x, y } = p || {};
			acoord("x", x);
			acoord("y", y);
			return new Point(x, y, Fp.ONE, Fp.mul(x, y));
		}
		static fromBytes(bytes, zip215 = false) {
			const len = Fp.BYTES;
			const { a, d } = CURVE;
			bytes = copyBytes(abytes(bytes, len, "point"));
			abool(zip215, "zip215");
			const normed = copyBytes(bytes);
			const lastByte = bytes[len - 1];
			normed[len - 1] = lastByte & -129;
			const y = bytesToNumberLE(normed);
			aInRange("point.y", y, _0n, zip215 ? MASK : Fp.ORDER);
			const y2 = Fp.sqr(y);
			const u = Fp.sub(y2, Fp.ONE);
			const v = Fp.sub(Fp.mulN(d, y2), a);
			let { isValid, value: x } = uvRatio(u, v);
			if (!isValid) throw new Error("bad point: invalid y coordinate");
			const isXOdd = isOdd(x);
			const isLastByteOdd = (lastByte & 128) !== 0;
			if (!zip215 && Fp.is0(x) && isLastByteOdd) throw new Error("bad point: x=0 and x_0=1");
			if (isLastByteOdd !== isXOdd) x = Fp.neg(x);
			return Point.fromAffine({
				x,
				y
			});
		}
		static fromHex(hex, zip215 = false) {
			return Point.fromBytes(hexToBytes(hex), zip215);
		}
		get x() {
			return this.toAffine().x;
		}
		get y() {
			return this.toAffine().y;
		}
		precompute(windowSize = 6, isLazy = true) {
			wnaf.setWindowSize(this, windowSize);
			if (!isLazy) this.multiply(_2n$1);
			return this;
		}
		assertValidity() {
			const p = this;
			const { a, d } = CURVE;
			if (p.is0()) throw new Error("bad point: ZERO");
			const { X, Y, Z, T } = p;
			const X2 = Fp.sqr(X);
			const Y2 = Fp.sqr(Y);
			const Z2 = Fp.sqr(Z);
			const Z4 = Fp.sqr(Z2);
			const aX2 = Fp.mul(X2, a);
			const left = Fp.mul(Fp.add(aX2, Y2), Z2);
			const right = Fp.add(Z4, Fp.mul(d, Fp.mul(X2, Y2)));
			if (!Fp.eql(left, right)) throw new Error("bad point: equation left != right (1)");
			const XY = Fp.mul(X, Y);
			const ZT = Fp.mul(Z, T);
			if (!Fp.eql(XY, ZT)) throw new Error("bad point: equation left != right (2)");
		}
		equals(other) {
			aedpoint(other);
			const { X: X1, Y: Y1, Z: Z1 } = this;
			const { X: X2, Y: Y2, Z: Z2 } = other;
			const X1Z2 = Fp.mul(X1, Z2);
			const X2Z1 = Fp.mul(X2, Z1);
			const Y1Z2 = Fp.mul(Y1, Z2);
			const Y2Z1 = Fp.mul(Y2, Z1);
			return Fp.eql(X1Z2, X2Z1) && Fp.eql(Y1Z2, Y2Z1);
		}
		is0() {
			return this.equals(Point.ZERO);
		}
		negate() {
			return new Point(Fp.neg(this.X), this.Y, this.Z, Fp.neg(this.T));
		}
		double() {
			const { X: X1, Y: Y1, Z: Z1 } = this;
			const A = Fp.sqr(X1);
			const B = Fp.sqr(Y1);
			const C = Fp.mul(Fp.sqr(Z1), _2n$1);
			const D = mulA(A);
			const x1y1 = Fp.addN(X1, Y1);
			const E = Fp.sub(Fp.subN(Fp.sqr(x1y1), A), B);
			const G = Fp.addN(D, B);
			const F = Fp.subN(G, C);
			const H = Fp.subN(D, B);
			const X3 = Fp.mul(E, F);
			const Y3 = Fp.mul(G, H);
			const T3 = Fp.mul(E, H);
			const Z3 = Fp.mul(F, G);
			return new Point(X3, Y3, Z3, T3);
		}
		add(other) {
			aedpoint(other);
			const { d } = CURVE;
			const { X: X1, Y: Y1, Z: Z1, T: T1 } = this;
			const { X: X2, Y: Y2, Z: Z2, T: T2 } = other;
			const A = Fp.mul(X1, X2);
			const B = Fp.mul(Y1, Y2);
			const C = Fp.mul(Fp.mulN(T1, d), T2);
			const D = Fp.mul(Z1, Z2);
			const E = Fp.sub(Fp.subN(Fp.mulN(Fp.addN(X1, Y1), Fp.addN(X2, Y2)), A), B);
			const F = Fp.subN(D, C);
			const G = Fp.addN(D, C);
			const H = Fp.sub(B, mulA(A));
			const X3 = Fp.mul(E, F);
			const Y3 = Fp.mul(G, H);
			const T3 = Fp.mul(E, H);
			const Z3 = Fp.mul(F, G);
			return new Point(X3, Y3, Z3, T3);
		}
		subtract(other) {
			aedpoint(other);
			return this.add(other.negate());
		}
		multiply(scalar) {
			if (!Fn.isValidNot0(scalar)) throw new RangeError("invalid scalar: expected 1 <= sc < curve.n");
			const { p, f } = wnaf.mulSecret(this, scalar, cofactor, normalize);
			return normalize([p, f])[0];
		}
		multiplyUnsafe(scalar) {
			if (!Fn.isValid(scalar)) throw new RangeError("invalid scalar: expected 0 <= sc < curve.n");
			if (scalar === _0n) return Point.ZERO;
			if (this.is0() || scalar === _1n$1) return this;
			return wnaf.mulUnsafe(this, scalar, normalize);
		}
		isSmallOrder() {
			return this.clearCofactor().is0();
		}
		isTorsionFree() {
			return wnaf.mulUnsafe(this, CURVE.n).is0();
		}
		toAffine(invertedZ) {
			const p = this;
			let iz = invertedZ;
			if (iz != null && typeof iz !== "bigint") throw new TypeError("\"invertedZ\" expected bigint, got type=" + typeof iz);
			const { X, Y, Z } = p;
			const is0 = p.is0();
			if (iz == null) iz = is0 ? Fp.create(_8n$1) : Fp.inv(Z);
			const x = Fp.mul(X, iz);
			const y = Fp.mul(Y, iz);
			const zz = Fp.mul(Z, iz);
			if (is0) return {
				x: Fp.ZERO,
				y: Fp.ONE
			};
			if (!Fp.eql(zz, Fp.ONE)) throw new Error("invZ was invalid");
			return {
				x,
				y
			};
		}
		clearCofactor() {
			if (cofactor === _1n$1) return this;
			if (cofactor === _2n$1) return this.double();
			if (cofactor === _4n) return this.double().double();
			if (cofactor === _8n$1) return this.double().double().double();
			return this.multiplyUnsafe(cofactor);
		}
		toBytes() {
			const { x, y } = this.toAffine();
			const bytes = Fp.toBytes(y);
			bytes[bytes.length - 1] |= isOdd(x) ? 128 : 0;
			return bytes;
		}
		toHex() {
			return bytesToHex(this.toBytes());
		}
		toString() {
			return `<Point ${this.is0() ? "ZERO" : this.toHex()}>`;
		}
	}
	const normalize = (points) => normalizeZ(Point, points);
	const wnaf = new ScalarMultiplier(Point, randomBytes$2);
	if (wnaf.bits >= 6) Point.BASE.precompute(6);
	Object.freeze(Point.prototype);
	Object.freeze(Point);
	return Point;
}
/**
* Initializes EdDSA signatures over given Edwards curve.
* @param Point - Edwards point constructor.
* @param cHash - Hash function.
* @param eddsaOpts - Optional signature helpers. See {@link EdDSAOpts}.
* @returns EdDSA helper namespace.
* @throws If the hash function, options, or derived point operations are invalid. {@link Error}
* @example
* Initializes EdDSA signatures over given Edwards curve.
*
* ```ts
* import { eddsa } from '@noble/curves/abstract/edwards.js';
* import { jubjub } from '@noble/curves/misc.js';
* import { sha512 } from '@noble/hashes/sha2.js';
* const sigs = eddsa(jubjub.Point, sha512);
* const { secretKey, publicKey } = sigs.keygen();
* const msg = new TextEncoder().encode('hello noble');
* const sig = sigs.sign(msg, secretKey);
* const isValid = sigs.verify(sig, msg, publicKey);
* ```
*/
function eddsa(Point, cHash, eddsaOpts = {}) {
	validatePointCons(Point);
	if (typeof cHash !== "function") throw new Error("\"hash\" function param is required");
	const hash = cHash;
	const opts = eddsaOpts;
	validateObject(opts, {}, {
		adjustScalarBytes: "function",
		randomBytes: "function",
		domain: "function",
		prehash: "function",
		zip215: "boolean",
		mapToCurve: "function",
		toMontgomery: "function",
		toMontgomerySecret: "function"
	});
	const { prehash } = opts;
	const { BASE, Fp, Fn } = Point;
	const outputLen = hash.outputLen;
	const expectedLen = 2 * Fp.BYTES;
	if (outputLen !== void 0) {
		asafenumber(outputLen, "hash.outputLen");
		if (outputLen !== expectedLen) throw new Error(`hash.outputLen must be ${expectedLen}, got ${outputLen}`);
	}
	const randomBytes$3 = opts.randomBytes === void 0 ? randomBytes : opts.randomBytes;
	const toMontgomery = opts.toMontgomery;
	const toMontgomerySecret = opts.toMontgomerySecret;
	const adjustScalarBytes = opts.adjustScalarBytes === void 0 ? (bytes) => bytes : opts.adjustScalarBytes;
	const domain = opts.domain === void 0 ? (data, ctx, phflag) => {
		abool(phflag, "phflag");
		if (ctx.length || phflag) throw new Error("Contexts/pre-hash are not supported");
		return data;
	} : opts.domain;
	function modN_LE(hash) {
		return Fn.create(bytesToNumberLE(hash));
	}
	function getPrivateScalar(key) {
		const len = lengths.secretKey;
		abytes(key, lengths.secretKey, "secretKey");
		const hashed = abytes(hash(key), 2 * len, "hashedSecretKey");
		const head = adjustScalarBytes(hashed.slice(0, len));
		return {
			head,
			prefix: hashed.slice(len, 2 * len),
			scalar: modN_LE(head)
		};
	}
	/** Convenience method that creates public key from scalar. RFC8032 5.1.5
	* Also exposes the derived scalar/prefix tuple and point form reused by sign().
	*/
	function getExtendedPublicKey(secretKey) {
		const { head, prefix, scalar } = getPrivateScalar(secretKey);
		const point = BASE.multiply(scalar);
		return {
			head,
			prefix,
			scalar,
			point,
			pointBytes: point.toBytes()
		};
	}
	/** Calculates EdDSA pub key. RFC8032 5.1.5. */
	function getPublicKey(secretKey) {
		return getExtendedPublicKey(secretKey).pointBytes;
	}
	function hashDomainToScalar(context = Uint8Array.of(), ...msgs) {
		const msg = concatBytes(...msgs);
		return modN_LE(hash(domain(msg, abytes(context, void 0, "context"), !!prehash)));
	}
	/** Signs message with secret key. RFC8032 5.1.6 */
	function sign(msg, secretKey, options = {}) {
		validateObject(options, {}, {}, "options");
		msg = copyBytes(abytes(msg, void 0, "message"));
		if (prehash) msg = prehash(msg);
		const { prefix, scalar, pointBytes } = getExtendedPublicKey(secretKey);
		const r = hashDomainToScalar(options.context, prefix, msg);
		const R = BASE.multiply(r).toBytes();
		const k = hashDomainToScalar(options.context, R, pointBytes, msg);
		const s = Fn.create(r + k * scalar);
		if (!Fn.isValid(s)) throw new Error("sign failed: invalid s");
		return abytes(concatBytes(R, Fn.toBytes(s)), lengths.signature, "result");
	}
	const verifyOpts = { zip215: opts.zip215 };
	/**
	* Verifies EdDSA signature against message and public key. RFC 8032 §§5.1.7 and 5.2.7.
	* A cofactored verification equation is checked.
	*/
	function verify(sig, msg, publicKey, options = verifyOpts) {
		validateObject(options);
		const { context } = options;
		const zip215 = options.zip215 === void 0 ? !!verifyOpts.zip215 : options.zip215;
		const len = lengths.signature;
		sig = abytes(sig, len, "signature");
		msg = abytes(msg, void 0, "message");
		publicKey = abytes(publicKey, lengths.publicKey, "publicKey");
		if (zip215 !== void 0) abool(zip215, "zip215");
		if (prehash) msg = prehash(msg);
		const mid = len / 2;
		const r = sig.subarray(0, mid);
		const s = bytesToNumberLE(sig.subarray(mid, len));
		let A, R, SB;
		try {
			A = Point.fromBytes(publicKey, zip215);
			R = Point.fromBytes(r, zip215);
			SB = BASE.multiplyUnsafe(s);
		} catch (error) {
			return false;
		}
		if (!zip215 && A.isSmallOrder()) return false;
		const k = hashDomainToScalar(context, r, publicKey, msg);
		return R.add(A.multiplyUnsafe(k)).subtract(SB).clearCofactor().is0();
	}
	const _size = Fp.BYTES;
	const lengths = {
		secretKey: _size,
		publicKey: _size,
		signature: 2 * _size,
		seed: _size
	};
	function randomSecretKey(seed) {
		seed = seed === void 0 ? randomBytes$3(lengths.seed) : seed;
		return abytes(seed, lengths.seed, "seed");
	}
	function isValidSecretKey(key) {
		return isBytes(key) && key.length === lengths.secretKey;
	}
	function isValidPublicKey(key, zip215) {
		try {
			return !!Point.fromBytes(key, zip215 === void 0 ? verifyOpts.zip215 : zip215);
		} catch (error) {
			return false;
		}
	}
	const utils = {
		getExtendedPublicKey,
		randomSecretKey,
		isValidSecretKey,
		isValidPublicKey,
		/** Converts an Edwards public key to a companion Montgomery public key. */
		toMontgomery(publicKey) {
			if (toMontgomery === void 0) throw new Error("Montgomery conversion is not supported for this curve");
			return toMontgomery(Point.fromBytes(publicKey));
		},
		toMontgomerySecret(secretKey) {
			if (toMontgomerySecret === void 0) throw new Error("Montgomery conversion is not supported for this curve");
			return toMontgomerySecret(secretKey);
		}
	};
	Object.freeze(lengths);
	Object.freeze(utils);
	return Object.freeze({
		keygen: createKeygen(randomSecretKey, getPublicKey),
		getPublicKey,
		sign,
		verify,
		utils,
		Point,
		lengths
	});
}
//#endregion
//#region node_modules/@noble/curves/ed25519.js
/**
* ed25519 Twisted Edwards curve with following addons:
* - X25519 ECDH
* - Ristretto cofactor elimination
* - Elligator hash-to-group / point indistinguishability
* @module
*/
/*! noble-curves - MIT License (c) 2022 Paul Miller (paulmillr.com) */
var _1n = /* @__PURE__ */ BigInt(1);
var _2n = /* @__PURE__ */ BigInt(2);
var _5n = /* @__PURE__ */ BigInt(5);
var _8n = /* @__PURE__ */ BigInt(8);
var ed25519_CURVE_p = /* @__PURE__ */ BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffed");
var ed25519_CURVE = /* @__PURE__ */ (() => ({
	p: ed25519_CURVE_p,
	n: BigInt("0x1000000000000000000000000000000014def9dea2f79cd65812631a5cf5d3ed"),
	h: _8n,
	a: BigInt("0x7fffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffec"),
	d: BigInt("0x52036cee2b6ffe738cc740797779e89800700a4d4141d8ab75eb4dca135978a3"),
	Gx: BigInt("0x216936d3cd6e53fec0a4e231fdd6dc5c692cc7609525a7b2c9562d608f25d51a"),
	Gy: BigInt("0x6666666666666666666666666666666666666666666666666666666666666658")
}))();
function ed25519_pow_2_252_3(x) {
	const _10n = BigInt(10), _20n = BigInt(20), _40n = BigInt(40), _80n = BigInt(80);
	const P = ed25519_CURVE_p;
	const b2 = x * x % P * x % P;
	const b5 = pow2(pow2(b2, _2n, P) * b2 % P, _1n, P) * x % P;
	const b10 = pow2(b5, _5n, P) * b5 % P;
	const b20 = pow2(b10, _10n, P) * b10 % P;
	const b40 = pow2(b20, _20n, P) * b20 % P;
	const b80 = pow2(b40, _40n, P) * b40 % P;
	return {
		pow_p_5_8: pow2(pow2(pow2(pow2(b80, _80n, P) * b80 % P, _80n, P) * b80 % P, _10n, P) * b10 % P, _2n, P) * x % P,
		b2
	};
}
function adjustScalarBytes(bytes) {
	bytes[0] &= 248;
	bytes[31] &= 127;
	bytes[31] |= 64;
	return bytes;
}
var ED25519_SQRT_M1 = /* @__PURE__ */ BigInt("19681161376707505956807079304988542015446066515923890162744021073123829784752");
function uvRatio(u, v) {
	const P = ed25519_CURVE_p;
	const v3 = mod(v * v * v, P);
	const pow = ed25519_pow_2_252_3(u * mod(v3 * v3 * v, P)).pow_p_5_8;
	let x = mod(u * v3 * pow, P);
	const vx2 = mod(v * x * x, P);
	const root1 = x;
	const root2 = mod(x * ED25519_SQRT_M1, P);
	const useRoot1 = vx2 === u;
	const useRoot2 = vx2 === mod(-u, P);
	const noRoot = vx2 === mod(-u * ED25519_SQRT_M1, P);
	if (useRoot1) x = root1;
	if (useRoot2 || noRoot) x = root2;
	if (isNegativeLE(x, P)) x = mod(-x, P);
	return {
		isValid: useRoot1 || useRoot2,
		value: x
	};
}
var ed25519_Point = /* @__PURE__ */ edwards(ed25519_CURVE, { uvRatio });
var Fp = /* @__PURE__ */ (() => ed25519_Point.Fp)();
function toMontgomery(point) {
	const { y } = point;
	return Fp.toBytes(Fp.div(_1n + y, _1n - y));
}
function toMontgomerySecret(secretKey) {
	const size = ed25519_Point.Fp.BYTES;
	abytes$1(secretKey, size);
	return adjustScalarBytes(sha512(secretKey.subarray(0, size))).subarray(0, size);
}
function ed(opts) {
	return eddsa(ed25519_Point, sha512, Object.assign({
		adjustScalarBytes,
		toMontgomery,
		toMontgomerySecret,
		zip215: true
	}, opts));
}
/**
* ed25519 curve with EdDSA signatures.
* Seeded `keygen(seed)` / `utils.randomSecretKey(seed)` reuse the provided
* 32-byte seed buffer instead of copying it.
* @example
* Generate one Ed25519 keypair, sign a message, and verify it.
*
* ```js
* import { ed25519 } from '@noble/curves/ed25519.js';
* const { secretKey, publicKey } = ed25519.keygen();
* // const publicKey = ed25519.getPublicKey(secretKey);
* const msg = new TextEncoder().encode('hello noble');
* const sig = ed25519.sign(msg, secretKey);
* const isValid = ed25519.verify(sig, msg, publicKey); // ZIP215
* // RFC8032 / FIPS 186-5
* const isValid2 = ed25519.verify(sig, msg, publicKey, { zip215: false });
* ```
*/
var ed25519 = /* @__PURE__ */ ed({});
//#endregion
//#region node_modules/@mysten/sui/dist/keypairs/ed25519/publickey.mjs
var PUBLIC_KEY_SIZE = 32;
/**
* An Ed25519 public key
*/
var Ed25519PublicKey = class extends PublicKey {
	static {
		this.SIZE = PUBLIC_KEY_SIZE;
	}
	/**
	* Create a new Ed25519PublicKey object
	* @param value ed25519 public key as buffer or base-64 encoded string
	*/
	constructor(value) {
		super();
		if (typeof value === "string") this.data = fromBase64(value);
		else if (value instanceof Uint8Array) this.data = value;
		else this.data = Uint8Array.from(value);
		if (this.data.length !== PUBLIC_KEY_SIZE) throw new Error(`Invalid public key input. Expected ${PUBLIC_KEY_SIZE} bytes, got ${this.data.length}`);
	}
	/**
	* Checks if two Ed25519 public keys are equal
	*/
	equals(publicKey) {
		return super.equals(publicKey);
	}
	/**
	* Return the byte array representation of the Ed25519 public key
	*/
	toRawBytes() {
		return this.data;
	}
	/**
	* Return the Sui address associated with this Ed25519 public key
	*/
	flag() {
		return SIGNATURE_SCHEME_TO_FLAG["ED25519"];
	}
	/**
	* Verifies that the signature is valid for for the provided message
	*/
	async verify(message, signature) {
		let bytes;
		if (typeof signature === "string") {
			const parsed = parseSerializedKeypairSignature(signature);
			if (parsed.signatureScheme !== "ED25519") throw new Error("Invalid signature scheme");
			if (!bytesEqual(this.toRawBytes(), parsed.publicKey)) throw new Error("Signature does not match public key");
			bytes = parsed.signature;
		} else bytes = signature;
		return ed25519.verify(bytes, message, this.toRawBytes());
	}
};
//#endregion
//#region node_modules/@noble/hashes/pbkdf2.js
/**
* PBKDF (RFC 2898). Can be used to create a key from password and salt.
* @module
*/
function pbkdf2Init(hash, _password, _salt, _opts) {
	ahash(hash);
	const { c, dkLen, asyncTick } = checkOpts({
		dkLen: 32,
		asyncTick: 10
	}, _opts);
	anumber$1(c, "c");
	anumber$1(dkLen, "dkLen");
	anumber$1(asyncTick, "asyncTick");
	if (c < 1) throw new Error("\"c\" (iterations) must be >= 1");
	if (dkLen < 1) throw new Error("\"dkLen\" must be >= 1");
	if (dkLen > (2 ** 32 - 1) * hash.outputLen) throw new Error("derived key too long");
	const p = kdfInputToBytes(_password, "password");
	try {
		const s = kdfInputToBytes(_salt, "salt");
		try {
			const DK = new Uint8Array(dkLen);
			const { iHash, oHash, outputLen } = hmac.create(hash, p);
			return {
				c,
				dkLen,
				asyncTick,
				DK,
				outputLen,
				eng: pbkdf2Engine(iHash, oHash, s, new Uint8Array(outputLen))
			};
		} finally {
			if (typeof _salt === "string") clean(s);
		}
	} finally {
		if (typeof _password === "string") clean(p);
	}
}
function pbkdf2Engine(iHash, oHash, salt, u) {
	const counter = /* @__PURE__ */ new Uint8Array(4);
	const view = createView(counter);
	const salted = iHash._cloneInto().update(salt);
	const work = oHash._cloneInto();
	const iClone = iHash._cloneInto;
	const oClone = oHash._cloneInto;
	return {
		u1: (ti, Ti) => {
			view.setInt32(0, ti, false);
			salted._cloneInto(work).update(counter).digestInto(u);
			oHash._cloneInto(work).update(u).digestInto(u);
			Ti.set(u.subarray(0, Ti.length));
		},
		rounds: (c, Ti) => {
			for (let ui = 1; ui < c; ui++) {
				iClone.call(iHash, work).update(u).digestInto(u);
				oClone.call(oHash, work).update(u).digestInto(u);
				for (let i = 0; i < Ti.length; i++) Ti[i] ^= u[i];
			}
		},
		output: (DK) => {
			iHash.destroy();
			oHash.destroy();
			salted.destroy();
			work.destroy();
			clean(u);
			return DK;
		}
	};
}
/**
* PBKDF2-HMAC: RFC 8018 key derivation function.
* @param hash - hash function that would be used e.g. sha256
* @param password - password from which a derived key is generated;
*   JS string inputs are UTF-8 encoded first
* @param salt - cryptographic salt; JS string inputs are UTF-8 encoded first
* @param opts - PBKDF2 work factor and output settings. `dkLen`, if provided,
*   must be `>= 1` per RFC 8018 §5.2. See {@link Pbkdf2Opt}.
* @returns Derived key bytes.
* @throws If the PBKDF2 iteration count or derived-key settings are invalid. {@link Error}
* @example
* PBKDF2-HMAC: RFC 2898 key derivation function.
* ```ts
* import { pbkdf2 } from '@noble/hashes/pbkdf2.js';
* import { sha256 } from '@noble/hashes/sha2.js';
* const key = pbkdf2(sha256, 'password', 'salt', { dkLen: 32, c: Math.pow(2, 18) });
* ```
*/
function pbkdf2(hash, password, salt, opts) {
	const { c, dkLen, DK, outputLen, eng } = pbkdf2Init(hash, password, salt, opts);
	for (let ti = 1, pos = 0; pos < dkLen; ti++, pos += outputLen) {
		const Ti = DK.subarray(pos, pos + outputLen);
		eng.u1(ti, Ti);
		eng.rounds(c, Ti);
	}
	return eng.output(DK);
}
//#endregion
//#region node_modules/@scure/bip39/index.js
/*! scure-bip39 - MIT License (c) 2022 Patricio Palladino, Paul Miller (paulmillr.com) */
function isWellFormedUnicode(value) {
	for (let i = 0; i < value.length; i++) {
		const current = value.charCodeAt(i);
		if (current >= 55296 && current <= 56319) {
			if (i + 1 >= value.length) return false;
			const next = value.charCodeAt(++i);
			if (next < 56320 || next > 57343) return false;
		} else if (current >= 56320 && current <= 57343) return false;
	}
	return true;
}
function nfkd(str) {
	if (typeof str !== "string") throw new TypeError("invalid mnemonic type: " + typeof str);
	if (!isWellFormedUnicode(str)) throw new TypeError("expected well-formed Unicode string");
	return str.normalize("NFKD");
}
function normalize(str) {
	const norm = nfkd(str);
	const words = norm.split(" ");
	if (![
		12,
		15,
		18,
		21,
		24
	].includes(words.length)) throw new Error("Invalid mnemonic");
	return {
		nfkd: norm,
		words
	};
}
var psalt = (passphrase) => {
	if (typeof passphrase !== "string") throw new TypeError("invalid passphrase type: " + typeof passphrase);
	return nfkd("mnemonic" + passphrase);
};
/**
* Irreversible: Uses KDF to derive 64 bytes of key data from mnemonic + optional password.
* @param mnemonic - 12-24 words.
* @param passphrase - String that will additionally protect the key.
* @returns 64 bytes of key data.
* @throws If the mnemonic shape is invalid. {@link Error}
* @throws On wrong argument types. {@link TypeError}
* @example
* Derive a seed from a mnemonic with the sync PBKDF2 helper.
* ```ts
* const mnem = 'legal winner thank year wave sausage worth useful legal winner thank yellow';
* const seed = mnemonicToSeedSync(mnem, 'password');
* // => new Uint8Array([...64 bytes])
* ```
*/
function mnemonicToSeedSync(mnemonic, passphrase = "") {
	return pbkdf2(sha512, normalize(mnemonic).nfkd, psalt(passphrase), {
		c: 2048,
		dkLen: 64
	});
}
//#endregion
//#region node_modules/@mysten/sui/dist/cryptography/mnemonics.mjs
/**
* Parse and validate a path that is compliant to SLIP-0010 in form m/44'/784'/{account_index}'/{change_index}'/{address_index}'.
*
* @param path path string (e.g. `m/44'/784'/0'/0'/0'`).
*/
function isValidHardenedPath(path) {
	if (!(/* @__PURE__ */ new RegExp("^m\\/44'\\/784'\\/[0-9]+'\\/[0-9]+'\\/[0-9]+'+$")).test(path)) return false;
	return true;
}
/**
* Uses KDF to derive 64 bytes of key data from mnemonic with empty password.
*
* @param mnemonics 12 words string split by spaces.
*/
function mnemonicToSeed(mnemonics) {
	return mnemonicToSeedSync(mnemonics, "");
}
/**
* Derive the seed in hex format from a 12-word mnemonic string.
*
* @param mnemonics 12 words string split by spaces.
*/
function mnemonicToSeedHex(mnemonics) {
	return toHex(mnemonicToSeed(mnemonics));
}
//#endregion
//#region node_modules/@mysten/sui/dist/cryptography/signature.mjs
/**
* Takes in a signature, its associated signing scheme and a public key, then serializes this data
*/
function toSerializedSignature({ signature, signatureScheme, publicKey }) {
	if (!publicKey) throw new Error("`publicKey` is required");
	const pubKeyBytes = publicKey.toRawBytes();
	const serializedSignature = new Uint8Array(1 + signature.length + pubKeyBytes.length);
	serializedSignature.set([SIGNATURE_SCHEME_TO_FLAG[signatureScheme]]);
	serializedSignature.set(signature, 1);
	serializedSignature.set(pubKeyBytes, 1 + signature.length);
	return toBase64(serializedSignature);
}
var SUI_PRIVATE_KEY_PREFIX = "suiprivkey";
/**
* TODO: Document
*/
var Signer = class {
	/**
	* Sign messages with a specific intent. By combining the message bytes with the intent before hashing and signing,
	* it ensures that a signed message is tied to a specific purpose and domain separator is provided
	*/
	async signWithIntent(bytes, intent) {
		const digest = blake2b(messageWithIntent(intent, bytes), { dkLen: 32 });
		return {
			signature: toSerializedSignature({
				signature: await this.sign(digest),
				signatureScheme: this.getKeyScheme(),
				publicKey: this.getPublicKey()
			}),
			bytes: toBase64(bytes)
		};
	}
	/**
	* Signs provided transaction by calling `signWithIntent()` with a `TransactionData` provided as intent scope
	*/
	async signTransaction(bytes) {
		return this.signWithIntent(bytes, "TransactionData");
	}
	/**
	* Signs provided personal message by calling `signWithIntent()` with a `PersonalMessage` provided as intent scope
	*/
	async signPersonalMessage(bytes) {
		const { signature } = await this.signWithIntent(bcs.byteVector().serialize(bytes).toBytes(), "PersonalMessage");
		return {
			bytes: toBase64(bytes),
			signature
		};
	}
	async signAndExecuteTransaction({ transaction, client }) {
		transaction.setSenderIfNotSet(this.toSuiAddress());
		const bytes = await transaction.build({ client });
		const { signature } = await this.signTransaction(bytes);
		return client.core.executeTransaction({
			transaction: bytes,
			signatures: [signature],
			include: {
				transaction: true,
				effects: true
			}
		});
	}
	toSuiAddress() {
		return this.getPublicKey().toSuiAddress();
	}
};
var Keypair = class extends Signer {};
/**
* This returns an ParsedKeypair object based by validating the
* 33-byte Bech32 encoded string starting with `suiprivkey`, and
* parse out the signature scheme and the private key in bytes.
*/
function decodeSuiPrivateKey(value) {
	const { prefix, words } = bech32.decode(value);
	if (prefix !== "suiprivkey") throw new Error("invalid private key prefix");
	const extendedSecretKey = new Uint8Array(bech32.fromWords(words));
	const secretKey = extendedSecretKey.slice(1);
	return {
		scheme: SIGNATURE_FLAG_TO_SCHEME[extendedSecretKey[0]],
		secretKey
	};
}
/**
* This returns a Bech32 encoded string starting with `suiprivkey`,
* encoding 33-byte `flag || bytes` for the given the 32-byte private
* key and its signature scheme.
*/
function encodeSuiPrivateKey(bytes, scheme) {
	if (bytes.length !== 32) throw new Error("Invalid bytes length");
	const flag = SIGNATURE_SCHEME_TO_FLAG[scheme];
	const privKeyBytes = new Uint8Array(bytes.length + 1);
	privKeyBytes.set([flag]);
	privKeyBytes.set(bytes, 1);
	return bech32.encode(SUI_PRIVATE_KEY_PREFIX, bech32.toWords(privKeyBytes));
}
//#endregion
//#region node_modules/@mysten/sui/dist/keypairs/ed25519/ed25519-hd-key.mjs
var ED25519_CURVE = "ed25519 seed";
var HARDENED_OFFSET = 2147483648;
var pathRegex = /* @__PURE__ */ new RegExp("^m(\\/[0-9]+')+$");
var replaceDerive = (val) => val.replace("'", "");
var getMasterKeyFromSeed = (seed) => {
	const I = hmac.create(sha512, new TextEncoder().encode(ED25519_CURVE)).update(fromHex(seed)).digest();
	return {
		key: I.slice(0, 32),
		chainCode: I.slice(32)
	};
};
var CKDPriv = ({ key, chainCode }, index) => {
	const indexBuffer = /* @__PURE__ */ new ArrayBuffer(4);
	new DataView(indexBuffer).setUint32(0, index);
	const data = new Uint8Array(1 + key.length + indexBuffer.byteLength);
	data.set((/* @__PURE__ */ new Uint8Array(1)).fill(0));
	data.set(key, 1);
	data.set(new Uint8Array(indexBuffer, 0, indexBuffer.byteLength), key.length + 1);
	const I = hmac.create(sha512, chainCode).update(data).digest();
	return {
		key: I.slice(0, 32),
		chainCode: I.slice(32)
	};
};
var isValidPath = (path) => {
	if (!pathRegex.test(path)) return false;
	return !path.split("/").slice(1).map(replaceDerive).some(isNaN);
};
var derivePath = (path, seed, offset = HARDENED_OFFSET) => {
	if (!isValidPath(path)) throw new Error("Invalid derivation path");
	const { key, chainCode } = getMasterKeyFromSeed(seed);
	return path.split("/").slice(1).map(replaceDerive).map((el) => parseInt(el, 10)).reduce((parentKeys, segment) => CKDPriv(parentKeys, segment + offset), {
		key,
		chainCode
	});
};
//#endregion
//#region node_modules/@mysten/sui/dist/keypairs/ed25519/keypair.mjs
var DEFAULT_ED25519_DERIVATION_PATH = "m/44'/784'/0'/0'/0'";
/**
* An Ed25519 Keypair used for signing transactions.
*/
var Ed25519Keypair = class Ed25519Keypair extends Keypair {
	/**
	* Create a new Ed25519 keypair instance.
	* Generate random keypair if no {@link Ed25519Keypair} is provided.
	*
	* @param keypair Ed25519 keypair
	*/
	constructor(keypair) {
		super();
		if (keypair) this.keypair = {
			publicKey: keypair.publicKey,
			secretKey: keypair.secretKey.slice(0, 32)
		};
		else {
			const privateKey = ed25519.utils.randomSecretKey();
			this.keypair = {
				publicKey: ed25519.getPublicKey(privateKey),
				secretKey: privateKey
			};
		}
	}
	/**
	* Get the key scheme of the keypair ED25519
	*/
	getKeyScheme() {
		return "ED25519";
	}
	/**
	* Generate a new random Ed25519 keypair
	*/
	static generate() {
		const secretKey = ed25519.utils.randomSecretKey();
		return new Ed25519Keypair({
			publicKey: ed25519.getPublicKey(secretKey),
			secretKey
		});
	}
	/**
	* Create a Ed25519 keypair from a raw secret key byte array, also known as seed.
	* This is NOT the private scalar which is result of hashing and bit clamping of
	* the raw secret key.
	*
	* @throws error if the provided secret key is invalid and validation is not skipped.
	*
	* @param secretKey secret key as a byte array or Bech32 secret key string
	* @param options: skip secret key validation
	*/
	static fromSecretKey(secretKey, options) {
		if (typeof secretKey === "string") {
			const decoded = decodeSuiPrivateKey(secretKey);
			if (decoded.scheme !== "ED25519") throw new Error(`Expected a ED25519 keypair, got ${decoded.scheme}`);
			return this.fromSecretKey(decoded.secretKey, options);
		}
		const secretKeyLength = secretKey.length;
		if (secretKeyLength !== 32) throw new Error(`Wrong secretKey size. Expected 32 bytes, got ${secretKeyLength}.`);
		const keypair = {
			publicKey: ed25519.getPublicKey(secretKey),
			secretKey
		};
		if (!options || !options.skipValidation) {
			const signData = new TextEncoder().encode("sui validation");
			const signature = ed25519.sign(signData, secretKey);
			if (!ed25519.verify(signature, signData, keypair.publicKey)) throw new Error("provided secretKey is invalid");
		}
		return new Ed25519Keypair(keypair);
	}
	/**
	* The public key for this Ed25519 keypair
	*/
	getPublicKey() {
		return new Ed25519PublicKey(this.keypair.publicKey);
	}
	/**
	* The Bech32 secret key string for this Ed25519 keypair
	*/
	getSecretKey() {
		return encodeSuiPrivateKey(this.keypair.secretKey.slice(0, 32), this.getKeyScheme());
	}
	/**
	* Return the signature for the provided data using Ed25519.
	*/
	async sign(data) {
		return ed25519.sign(data, this.keypair.secretKey);
	}
	/**
	* Derive Ed25519 keypair from mnemonics and path. The mnemonics must be normalized
	* and validated against the english wordlist.
	*
	* If path is none, it will default to m/44'/784'/0'/0'/0', otherwise the path must
	* be compliant to SLIP-0010 in form m/44'/784'/{account_index}'/{change_index}'/{address_index}'.
	*/
	static deriveKeypair(mnemonics, path) {
		if (path == null) path = DEFAULT_ED25519_DERIVATION_PATH;
		if (!isValidHardenedPath(path)) throw new Error("Invalid derivation path");
		const { key } = derivePath(path, mnemonicToSeedHex(mnemonics));
		return Ed25519Keypair.fromSecretKey(key);
	}
	/**
	* Derive Ed25519 keypair from mnemonicSeed and path.
	*
	* If path is none, it will default to m/44'/784'/0'/0'/0', otherwise the path must
	* be compliant to SLIP-0010 in form m/44'/784'/{account_index}'/{change_index}'/{address_index}'.
	*
	* @param seed - The seed as a hex string or Uint8Array.
	*/
	static deriveKeypairFromSeed(seed, path) {
		if (path == null) path = DEFAULT_ED25519_DERIVATION_PATH;
		if (!isValidHardenedPath(path)) throw new Error("Invalid derivation path");
		const seedHex = typeof seed === "string" ? seed : toHex(seed);
		const { key } = derivePath(path, seedHex);
		return Ed25519Keypair.fromSecretKey(key);
	}
};
//#endregion
//#region node_modules/zustand/esm/middleware.mjs
var import_vanilla_extract_recipes_createRuntimeFn_cjs = require_vanilla_extract_recipes_createRuntimeFn_cjs();
function createJSONStorage(getStorage, options) {
	let storage;
	try {
		storage = getStorage();
	} catch (e) {
		return;
	}
	return {
		getItem: (name) => {
			var _a;
			const parse = (str2) => {
				if (str2 === null) return null;
				return JSON.parse(str2, options == null ? void 0 : options.reviver);
			};
			const str = (_a = storage.getItem(name)) != null ? _a : null;
			if (str instanceof Promise) return str.then(parse);
			return parse(str);
		},
		setItem: (name, newValue) => storage.setItem(name, JSON.stringify(newValue, options == null ? void 0 : options.replacer)),
		removeItem: (name) => storage.removeItem(name)
	};
}
var toThenable = (fn) => (input) => {
	try {
		const result = fn(input);
		if (result instanceof Promise) return result;
		return {
			then(onFulfilled) {
				return toThenable(onFulfilled)(result);
			},
			catch(_onRejected) {
				return this;
			}
		};
	} catch (e) {
		return {
			then(_onFulfilled) {
				return this;
			},
			catch(onRejected) {
				return toThenable(onRejected)(e);
			}
		};
	}
};
var persistImpl = (config, baseOptions) => (set, get, api) => {
	let options = {
		storage: createJSONStorage(() => window.localStorage),
		partialize: (state) => state,
		version: 0,
		merge: (persistedState, currentState) => ({
			...currentState,
			...persistedState
		}),
		...baseOptions
	};
	let hasHydrated = false;
	let hydrationVersion = 0;
	const hydrationListeners = /* @__PURE__ */ new Set();
	const finishHydrationListeners = /* @__PURE__ */ new Set();
	let storage = options.storage;
	if (!storage) return config((...args) => {
		console.warn(`[zustand persist middleware] Unable to update item '${options.name}', the given storage is currently unavailable.`);
		set(...args);
	}, get, api);
	const setItem = () => {
		const state = options.partialize({ ...get() });
		return storage.setItem(options.name, {
			state,
			version: options.version
		});
	};
	const savedSetState = api.setState;
	api.setState = (state, replace) => {
		savedSetState(state, replace);
		return setItem();
	};
	const configResult = config((...args) => {
		set(...args);
		return setItem();
	}, get, api);
	api.getInitialState = () => configResult;
	let stateFromStorage;
	const hydrate = () => {
		var _a, _b;
		if (!storage) return;
		const currentVersion = ++hydrationVersion;
		hasHydrated = false;
		hydrationListeners.forEach((cb) => {
			var _a2;
			return cb((_a2 = get()) != null ? _a2 : configResult);
		});
		const postRehydrationCallback = ((_b = options.onRehydrateStorage) == null ? void 0 : _b.call(options, (_a = get()) != null ? _a : configResult)) || void 0;
		return toThenable(storage.getItem.bind(storage))(options.name).then((deserializedStorageValue) => {
			if (deserializedStorageValue) {
				if (typeof deserializedStorageValue.version === "number" && deserializedStorageValue.version !== options.version) {
					if (options.migrate) {
						const migration = options.migrate(deserializedStorageValue.state, deserializedStorageValue.version);
						if (migration instanceof Promise) return migration.then((result) => [true, result]);
						return [true, migration];
					}
					console.error(`State loaded from storage couldn't be migrated since no migrate function was provided`);
				} else return [false, deserializedStorageValue.state];
			}
			return [false, void 0];
		}).then((migrationResult) => {
			var _a2;
			if (currentVersion !== hydrationVersion) return;
			const [migrated, migratedState] = migrationResult;
			stateFromStorage = options.merge(migratedState, (_a2 = get()) != null ? _a2 : configResult);
			set(stateFromStorage, true);
			if (migrated) return setItem();
		}).then(() => {
			if (currentVersion !== hydrationVersion) return;
			postRehydrationCallback?.(get(), void 0);
			stateFromStorage = get();
			hasHydrated = true;
			finishHydrationListeners.forEach((cb) => cb(stateFromStorage));
		}).catch((e) => {
			if (currentVersion !== hydrationVersion) return;
			postRehydrationCallback?.(void 0, e);
		});
	};
	api.persist = {
		setOptions: (newOptions) => {
			options = {
				...options,
				...newOptions
			};
			if (newOptions.storage) storage = newOptions.storage;
		},
		clearStorage: () => {
			++hydrationVersion;
			storage?.removeItem(options.name);
		},
		getOptions: () => options,
		rehydrate: () => hydrate(),
		hasHydrated: () => hasHydrated,
		onHydrate: (cb) => {
			hydrationListeners.add(cb);
			return () => {
				hydrationListeners.delete(cb);
			};
		},
		onFinishHydration: (cb) => {
			finishHydrationListeners.add(cb);
			return () => {
				finishHydrationListeners.delete(cb);
			};
		}
	};
	if (!options.skipHydration) hydrate();
	return stateFromStorage || configResult;
};
var persist = persistImpl;
//#endregion
//#region node_modules/@vanilla-extract/private/dist/vanilla-extract-private.esm.js
var vanilla_extract_private_esm_exports = /* @__PURE__ */ __exportAll({
	get: () => get,
	getVarName: () => getVarName,
	walkObject: () => walkObject
});
function getVarName(variable) {
	var matches = variable.match(/^var\((.*)\)$/);
	if (matches) return matches[1];
	return variable;
}
function get(obj, path) {
	var result = obj;
	for (var key of path) {
		if (!(key in result)) throw new Error("Path ".concat(path.join(" -> "), " does not exist in object"));
		result = result[key];
	}
	return result;
}
function walkObject(obj, fn) {
	var path = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
	var clone = {};
	for (var key in obj) {
		var _value = obj[key];
		var currentPath = [...path, key];
		if (typeof _value === "string" || typeof _value === "number" || _value == null) clone[key] = fn(_value, currentPath);
		else if (typeof _value === "object" && !Array.isArray(_value)) clone[key] = walkObject(_value, fn, currentPath);
		else console.warn("Skipping invalid key \"".concat(currentPath.join("."), "\". Should be a string, number, null or object. Received: \"").concat(Array.isArray(_value) ? "Array" : typeof _value, "\""));
	}
	return clone;
}
__esmMin((() => {}));
//#endregion
//#region node_modules/@vanilla-extract/dynamic/dist/vanilla-extract-dynamic.cjs.prod.js
var require_vanilla_extract_dynamic_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var _private = __toCommonJS(vanilla_extract_private_esm_exports);
	function assignInlineVars(varsOrContract, tokens) {
		var styles = {};
		if (typeof tokens === "object") {
			var _contract = varsOrContract;
			_private.walkObject(tokens, (value, path) => {
				if (value == null) return;
				var varName = _private.get(_contract, path);
				styles[_private.getVarName(varName)] = String(value);
			});
		} else {
			var _vars = varsOrContract;
			for (var varName in _vars) {
				var value = _vars[varName];
				if (value == null) continue;
				styles[_private.getVarName(varName)] = value;
			}
		}
		Object.defineProperty(styles, "toString", {
			value: function value() {
				return Object.keys(this).map((key) => "".concat(key, ":").concat(this[key])).join(";");
			},
			writable: false
		});
		return styles;
	}
	exports.assignInlineVars = assignInlineVars;
}));
//#endregion
//#region node_modules/@vanilla-extract/dynamic/dist/vanilla-extract-dynamic.cjs.js
var require_vanilla_extract_dynamic_cjs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_vanilla_extract_dynamic_cjs_prod();
}));
//#endregion
//#region node_modules/@vanilla-extract/css/injectStyles/dist/vanilla-extract-css-injectStyles.cjs.prod.js
var require_vanilla_extract_css_injectStyles_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var stylesheets = {};
	var injectStyles = (_ref) => {
		var { fileScope, css } = _ref;
		var fileScopeId = fileScope.packageName ? [fileScope.packageName, fileScope.filePath].join("/") : fileScope.filePath;
		var stylesheet = stylesheets[fileScopeId];
		if (!stylesheet) {
			var styleEl = document.createElement("style");
			if (fileScope.packageName) styleEl.setAttribute("data-package", fileScope.packageName);
			styleEl.setAttribute("data-file", fileScope.filePath);
			styleEl.setAttribute("type", "text/css");
			stylesheet = stylesheets[fileScopeId] = styleEl;
			document.head.appendChild(styleEl);
		}
		stylesheet.innerHTML = css;
	};
	exports.injectStyles = injectStyles;
}));
//#endregion
//#region node_modules/modern-ahocorasick/dist/_private/runtime-aoctzF3W.cjs
var require_runtime_aoctzF3W = /* @__PURE__ */ __commonJSMin(((exports) => {
	function advanceBuildSymbol(table, state, symbol) {
		while (state !== 0) {
			let low = table.edges[state];
			let high = table.edges[state + 1] - 1;
			while (low <= high) {
				const middle = low + high >>> 1;
				const label = table.labels[middle];
				if (label === symbol) return table.targets[middle];
				if (label < symbol) low = middle + 1;
				else high = middle - 1;
			}
			state = table.failures[state];
		}
		return table.roots[symbol];
	}
	function advanceCompact(table, state, segment) {
		const symbol = table.symbols.get(segment);
		if (symbol === void 0) return 0;
		while (state !== 0) {
			let low = table.edges[state];
			let high = table.edges[state + 1] - 1;
			while (low <= high) {
				const middle = low + high >>> 1;
				const label = table.labels[middle];
				if (label === symbol) return table.targets[middle];
				if (label < symbol) low = middle + 1;
				else high = middle - 1;
			}
			state = table.failures[state];
		}
		return table.roots[symbol];
	}
	/** Internal only: consumers must read each value before advancing the cursor. */
	var AsciiCursor = class {
		text;
		position = 0;
		result;
		constructor(text) {
			this.text = text;
			this.result = {
				done: false,
				value: {
					segment: "",
					index: 0,
					input: text
				}
			};
		}
		[Symbol.iterator]() {
			return this;
		}
		next() {
			const start = this.position;
			if (start === this.text.length) return {
				done: true,
				value: void 0
			};
			const code = this.text.charCodeAt(start);
			const end = start + (code === 13 && this.text.charCodeAt(start + 1) === 10 ? 2 : 1);
			if (code > 127 || end < this.text.length && this.text.charCodeAt(end) > 127) return {
				done: true,
				value: void 0
			};
			this.position = end;
			this.result.value.segment = this.text.slice(start, end);
			this.result.value.index = start;
			return this.result;
		}
	};
	/**
	* Bounded startup probe, never a full-text preflight. Short mixed prefixes
	* cannot amortize cursor setup before an early native hit, so use the original
	* string directly. Longer ASCII prefixes stop at the first unsettled boundary.
	*/
	function asciiPrefix(text) {
		for (let index = 0, length = Math.min(8, text.length); index < length; index++) if (text.charCodeAt(index) > 127) return;
		return new AsciiCursor(text);
	}
	function* asciiRuns(text, segmenter, ascii) {
		yield ascii;
		if (ascii.position < text.length) yield segmenter.segment(text.slice(ascii.position));
	}
	/**
	* At most two runs: reusable ASCII values, then unwrapped native iteration.
	* Aggregate scans only need tokens; native suffix offsets remain run-relative.
	*/
	function graphemeRuns(text, segmenter) {
		const ascii = asciiPrefix(text);
		if (ascii === void 0) return [segmenter.segment(text)];
		return asciiRuns(text, segmenter, ascii);
	}
	var blockBits = 10;
	var blockSize = 1024;
	var blockMask = 1023;
	var branching = 4294967295;
	var patternMemoLimit = 256;
	function buildAutomaton(patterns, segmenter, units) {
		const symbols = /* @__PURE__ */ new Map();
		let firstCapacity = 16;
		const labelBlocks = [new Uint32Array(firstCapacity)];
		const targetBlocks = [new Uint32Array(firstCapacity)];
		const forks = [];
		const lengths = new Uint32Array(patterns.length);
		const patternMemo = patterns.length > 1 ? /* @__PURE__ */ new Map() : void 0;
		let terminalStates = new Uint32Array(patterns.length);
		let size = 1;
		let maxLength = 0;
		function append(state, segment) {
			let symbol = symbols.get(segment);
			if (symbol === void 0) {
				symbol = symbols.size;
				symbols.set(segment, symbol);
			}
			const block = state >>> blockBits;
			const offset = state & blockMask;
			const labels = labelBlocks[block];
			const targets = targetBlocks[block];
			const label = labels[offset];
			if (label === symbol + 1) return targets[offset];
			const fork = label === branching ? forks[targets[offset]] : void 0;
			if (fork) {
				const child = fork.get(symbol);
				if (child !== void 0) return child;
			}
			const child = size++;
			if (fork) fork.set(symbol, child);
			else if (label === 0) {
				labels[offset] = symbol + 1;
				targets[offset] = child;
			} else {
				const branch = /* @__PURE__ */ new Map();
				branch.set(label - 1, targets[offset]);
				branch.set(symbol, child);
				labels[offset] = branching;
				targets[offset] = forks.length;
				forks.push(branch);
			}
			if (child === firstCapacity && firstCapacity < blockSize) {
				firstCapacity *= 2;
				const grownLabels = new Uint32Array(firstCapacity);
				const grownTargets = new Uint32Array(firstCapacity);
				grownLabels.set(labelBlocks[0]);
				grownTargets.set(targetBlocks[0]);
				labelBlocks[0] = grownLabels;
				targetBlocks[0] = grownTargets;
			} else if ((child & blockMask) === 0) {
				labelBlocks.push(new Uint32Array(blockSize));
				targetBlocks.push(new Uint32Array(blockSize));
			}
			return child;
		}
		for (let index = 0; index < patterns.length; index++) {
			const { pattern } = patterns[index];
			const previous = patternMemo?.get(pattern);
			if (previous !== void 0) {
				terminalStates[index] = terminalStates[previous];
				lengths[index] = lengths[previous];
				continue;
			}
			let state = 0;
			let length = 0;
			for (const segments of graphemeRuns(pattern, segmenter)) for (const { segment } of segments) if (units) for (const unit of units(segment)) {
				state = append(state, unit);
				length++;
			}
			else {
				state = append(state, segment);
				length++;
			}
			terminalStates[index] = state;
			lengths[index] = length;
			maxLength = Math.max(maxLength, length);
			if (patternMemo && patternMemo.size < patternMemoLimit) patternMemo.set(pattern, index);
		}
		patternMemo?.clear();
		const edges = new Uint32Array(size + 1);
		const labels = new Uint32Array(size - 1);
		const targets = new Uint32Array(size - 1);
		let edge = 0;
		for (let block = 0; block < labelBlocks.length; block++) {
			const blockLabels = labelBlocks[block];
			const blockTargets = targetBlocks[block];
			const start = block * blockSize;
			const end = Math.min(size - start, blockSize);
			for (let offset = 0; offset < end; offset++) {
				edges[start + offset] = edge;
				const label = blockLabels[offset];
				if (label === branching) {
					const forkIndex = blockTargets[offset];
					const fork = forks[forkIndex];
					const sorted = Array.from(fork.keys()).sort((a, b) => a - b);
					for (const symbol of sorted) {
						labels[edge] = symbol;
						targets[edge++] = fork.get(symbol);
					}
					forks[forkIndex] = void 0;
				} else if (label !== 0) {
					labels[edge] = label - 1;
					targets[edge++] = blockTargets[offset];
				}
			}
			labelBlocks[block] = void 0;
			targetBlocks[block] = void 0;
		}
		edges[size] = edge;
		const roots = new Uint32Array(symbols.size);
		for (let edge = edges[0]; edge < edges[1]; edge++) roots[labels[edge]] = targets[edge];
		const terminals = new Uint32Array(size + 1);
		for (const state of terminalStates) terminals[state + 1]++;
		const counts = new Uint32Array(size);
		for (let state = 0; state < size; state++) {
			terminals[state + 1] += terminals[state];
			counts[state] = terminals[state];
		}
		const patternIndices = new Uint32Array(patterns.length);
		for (let index = 0; index < terminalStates.length; index++) patternIndices[counts[terminalStates[index]]++] = index;
		terminalStates = /* @__PURE__ */ new Uint32Array(0);
		const failures = new Uint32Array(size);
		const outputs = new Int32Array(size).fill(-1);
		const compact = {
			symbols,
			roots,
			edges,
			labels,
			targets,
			failures,
			outputs,
			terminals,
			patterns: patternIndices
		};
		const order = new Uint32Array(size - 1);
		let tail = 0;
		for (let edge = edges[0]; edge < edges[1]; edge++) order[tail++] = targets[edge];
		counts[0] = 0;
		for (let head = 0; head < order.length; head++) {
			const state = order[head];
			counts[state] = terminals[state + 1] - terminals[state] + counts[failures[state]];
			for (let edge = edges[state]; edge < edges[state + 1]; edge++) {
				const child = targets[edge];
				order[tail++] = child;
				const failure = advanceBuildSymbol(compact, failures[state], labels[edge]);
				failures[child] = failure;
				outputs[child] = terminals[failure] < terminals[failure + 1] ? failure : outputs[failure];
			}
		}
		return {
			compact,
			lengths,
			counts,
			order,
			maxLength
		};
	}
	var profileKey = Symbol.for("modern-ahocorasick.profile.v1");
	var scannerKey = Symbol.for("modern-ahocorasick.scanner.v1");
	var replacementKey = Symbol.for("modern-ahocorasick.replacement.v1");
	function operationReplacement(replacement) {
		const factory = typeof replacement === "function" ? Reflect.get(replacement, replacementKey) : void 0;
		return typeof factory === "function" ? factory() : replacement;
	}
	function replacementFactory(factory) {
		const replacement = factory();
		Object.defineProperty(replacement, replacementKey, { value: factory });
		return replacement;
	}
	function defineProfile(target, profile) {
		Object.defineProperty(target, profileKey, { value: Object.freeze(profile) });
	}
	function getProfile(target) {
		return Reflect.get(target, profileKey) ?? {};
	}
	function registerScanner(target, create) {
		Object.defineProperty(target, scannerKey, { value: create });
	}
	function scanner(matcher, strategy, range) {
		const create = Reflect.get(matcher, scannerKey);
		if (typeof create !== "function") throw new TypeError("matcher must be a modern-ahocorasick compiled matcher");
		return create(strategy, range);
	}
	function resolveCharacterBoundary(options) {
		if (options !== void 0 && (options === null || typeof options !== "object" || Array.isArray(options))) throw new TypeError("options must be an object");
		const boundary = options?.boundary === void 0 ? "none" : options.boundary;
		if (typeof boundary !== "function" && ![
			"none",
			"ascii",
			"ascii-edge",
			"unicode",
			"whitespace"
		].includes(boundary)) throw new TypeError("unknown boundary rule");
		return boundary;
	}
	function accepts(boundary, context) {
		if (typeof boundary === "function") {
			const value = boundary(context);
			if (typeof value !== "boolean") throw new TypeError("boundary callback must return a boolean");
			return value;
		}
		const { left, right, first, last } = context;
		const asciiWord = (text) => text !== void 0 && /^[a-z0-9]/i.test(text);
		switch (boundary) {
			case "ascii": return !asciiWord(left) && !asciiWord(right);
			case "ascii-edge": return (!asciiWord(first) || !asciiWord(left)) && (!asciiWord(last) || !asciiWord(right));
			case "unicode": return (left === void 0 || !/[\p{L}\p{N}\p{M}_]/u.test(left)) && (right === void 0 || !/[\p{L}\p{N}\p{M}_]/u.test(right));
			case "whitespace": return (left === void 0 || /^\s+$/u.test(left)) && (right === void 0 || /^\s+$/u.test(right));
			default: return true;
		}
	}
	function compactBackend(table) {
		return {
			stats: {
				backend: "compact",
				stateCount: table.failures.length,
				transitionCount: table.targets.length,
				alphabetSize: table.symbols.size,
				typedArrayBytes: table.roots.byteLength + table.edges.byteLength + table.labels.byteLength + table.targets.byteLength + table.failures.byteLength + table.outputs.byteLength + table.terminals.byteLength + table.patterns.byteLength
			},
			advance: (state, unit) => advanceCompact(table, state, unit),
			*outputs(state) {
				for (let output = state; output !== -1; output = table.outputs[output]) for (let index = table.terminals[output]; index < table.terminals[output + 1]; index++) yield table.patterns[index];
			}
		};
	}
	/** A cursor owns all mutable scan state; the compiled backend is read-only. */
	function createScanner(backend, patterns, lengths, maxLength, boundary, units, strategy, range) {
		if (strategy === "longest-first") throw new TypeError("longest-first requires complete input");
		let state = 0;
		let unitPosition = 0;
		let position = 0;
		let cursor = 0;
		let end = 0;
		let safeOffset = 0;
		let left;
		const capacity = maxLength + 1;
		const starts = [];
		const offsets = [0];
		const candidates = /* @__PURE__ */ new Map();
		function settle(limit) {
			const output = [];
			while (cursor <= limit) {
				const candidate = candidates.get(cursor);
				if (candidate) {
					const next = cursor + candidate.length;
					while (cursor < next) candidates.delete(cursor++);
					output.push(candidate.match);
				} else cursor++;
			}
			safeOffset = cursor >= position ? end : offsets[cursor % capacity];
			return output;
		}
		return {
			maxLength,
			get safeOffset() {
				return safeOffset;
			},
			get retainOffset() {
				return Math.min(safeOffset, offsets[Math.max(0, position - maxLength) % capacity] ?? 0);
			},
			feed(segment, start, right, protectedText = false) {
				end = start + segment.length;
				offsets[position % capacity] = start;
				offsets[(position + 1) % capacity] = end;
				if (protectedText || maxLength === 0) {
					const output = settle(position - 1);
					state = 0;
					cursor = ++position;
					safeOffset = end;
					left = segment;
					return output;
				}
				const values = units ? units(segment) : [segment];
				const hits = [];
				for (let index = 0; index < values.length; index++) {
					starts[unitPosition % capacity] = index === 0 ? {
						offset: start,
						graph: position,
						left,
						first: segment
					} : void 0;
					state = backend.advance(state, values[index]);
					unitPosition++;
					if (index !== values.length - 1) continue;
					for (const patternIndex of backend.outputs(state)) {
						const first = starts[(unitPosition - lengths[patternIndex]) % capacity];
						if (!first) continue;
						const { pattern, data } = patterns[patternIndex];
						if (range && !range(first.offset, end) || !accepts(boundary, {
							left: first.left,
							right,
							first: first.first,
							last: segment,
							pattern,
							patternIndex
						})) continue;
						const match = {
							pattern,
							patternIndex,
							data,
							start: first.offset,
							end
						};
						const length = position - first.graph + 1;
						if (strategy === "all") hits.push({
							match,
							length
						});
						else if (first.graph >= cursor) {
							const previous = candidates.get(first.graph);
							if (!previous || (strategy === "leftmost-first" ? patternIndex < previous.match.patternIndex : length > previous.length || length === previous.length && patternIndex < previous.match.patternIndex)) candidates.set(first.graph, {
								match,
								length
							});
						}
					}
				}
				position++;
				left = segment;
				if (strategy === "all") {
					cursor = position;
					safeOffset = end;
					return hits.sort((a, b) => b.length - a.length || a.match.patternIndex - b.match.patternIndex).map((hit) => hit.match);
				}
				return settle(position - maxLength);
			},
			end() {
				return settle(position - 1);
			}
		};
	}
	function* scanText(text, segmenter, session) {
		const iterator = segmenter.segment(text)[Symbol.iterator]();
		let current = iterator.next();
		while (!current.done) {
			const next = iterator.next();
			yield* session.feed(current.value.segment, current.value.index, next.done ? void 0 : next.value.segment);
			current = next;
		}
		yield* session.end();
	}
	/** Offline global length priority, using original graphemes rather than pattern length. */
	function* selectLongest(matches, text, segmenter) {
		const positions = /* @__PURE__ */ new Map();
		let index = 0;
		for (const segment of segmenter.segment(text)) positions.set(segment.index, index++);
		positions.set(text.length, index);
		const candidates = Array.from(matches, (match) => ({
			match,
			length: positions.get(match.end) - positions.get(match.start)
		}));
		candidates.sort((a, b) => b.length - a.length || a.match.start - b.match.start || a.match.patternIndex - b.match.patternIndex);
		const tree = new Float64Array(index + 1);
		const prefix = (end) => {
			let total = 0;
			for (let i = end; i > 0; i -= i & -i) total += tree[i];
			return total;
		};
		const selected = [];
		for (const { match } of candidates) {
			const start = positions.get(match.start);
			const end = positions.get(match.end);
			if (prefix(end) !== prefix(start)) continue;
			selected.push(match);
			for (let point = start; point < end; point++) for (let i = point + 1; i < tree.length; i += i & -i) tree[i]++;
		}
		yield* selected.sort((a, b) => a.start - b.start);
	}
	Object.defineProperty(exports, "advanceCompact", {
		enumerable: true,
		get: function() {
			return advanceCompact;
		}
	});
	Object.defineProperty(exports, "asciiPrefix", {
		enumerable: true,
		get: function() {
			return asciiPrefix;
		}
	});
	Object.defineProperty(exports, "buildAutomaton", {
		enumerable: true,
		get: function() {
			return buildAutomaton;
		}
	});
	Object.defineProperty(exports, "compactBackend", {
		enumerable: true,
		get: function() {
			return compactBackend;
		}
	});
	Object.defineProperty(exports, "createScanner", {
		enumerable: true,
		get: function() {
			return createScanner;
		}
	});
	Object.defineProperty(exports, "defineProfile", {
		enumerable: true,
		get: function() {
			return defineProfile;
		}
	});
	Object.defineProperty(exports, "getProfile", {
		enumerable: true,
		get: function() {
			return getProfile;
		}
	});
	Object.defineProperty(exports, "graphemeRuns", {
		enumerable: true,
		get: function() {
			return graphemeRuns;
		}
	});
	Object.defineProperty(exports, "operationReplacement", {
		enumerable: true,
		get: function() {
			return operationReplacement;
		}
	});
	Object.defineProperty(exports, "registerScanner", {
		enumerable: true,
		get: function() {
			return registerScanner;
		}
	});
	Object.defineProperty(exports, "replacementFactory", {
		enumerable: true,
		get: function() {
			return replacementFactory;
		}
	});
	Object.defineProperty(exports, "resolveCharacterBoundary", {
		enumerable: true,
		get: function() {
			return resolveCharacterBoundary;
		}
	});
	Object.defineProperty(exports, "scanText", {
		enumerable: true,
		get: function() {
			return scanText;
		}
	});
	Object.defineProperty(exports, "scanner", {
		enumerable: true,
		get: function() {
			return scanner;
		}
	});
	Object.defineProperty(exports, "selectLongest", {
		enumerable: true,
		get: function() {
			return selectLongest;
		}
	});
}));
//#endregion
//#region node_modules/modern-ahocorasick/dist/_private/stream-CvP3nR7V.cjs
var require_stream_CvP3nR7V = /* @__PURE__ */ __commonJSMin(((exports) => {
	var require_runtime = require_runtime_aoctzF3W();
	function assertText(text) {
		if (typeof text !== "string") throw new TypeError("text must be a string");
	}
	function resolveStrategy(options, fallback) {
		if (options !== void 0 && (options === null || typeof options !== "object" || Array.isArray(options))) throw new TypeError("options must be an object");
		const strategy = options?.strategy === void 0 ? fallback : options.strategy;
		if (strategy !== "all" && strategy !== "leftmost-first" && strategy !== "leftmost-longest" && strategy !== "longest-first") throw new TypeError(`Unknown match strategy: ${String(strategy)}`);
		return strategy;
	}
	function resolveBoundary(text, options) {
		if (options !== void 0 && (options === null || typeof options !== "object" || Array.isArray(options))) throw new TypeError("options must be an object");
		if (options?.wholeWord !== void 0 && typeof options.wholeWord !== "boolean") throw new TypeError("wholeWord must be a boolean");
		if (options?.locale !== void 0 && typeof options.locale !== "string") throw new TypeError("locale must be a string");
		const locales = options?.locale === void 0 ? void 0 : Intl.getCanonicalLocales(options.locale);
		if (!options?.wholeWord) return;
		const starts = /* @__PURE__ */ new Set();
		const ends = /* @__PURE__ */ new Set();
		for (const { index, segment, isWordLike } of new Intl.Segmenter(locales, { granularity: "word" }).segment(text)) if (isWordLike) {
			starts.add(index);
			ends.add(index + segment.length);
		}
		return (start, end) => starts.has(start) && ends.has(end);
	}
	/** Validate original offsets before selection, without slicing away word context. */
	function resolveQuery(text, options, segmenter) {
		const boundary = resolveBoundary(text, options);
		if (options?.anchored !== void 0 && typeof options.anchored !== "boolean") throw new TypeError("anchored must be a boolean");
		if (options?.start === void 0 && options?.end === void 0 && !options?.anchored) return boundary;
		const start = options?.start === void 0 ? 0 : options.start;
		const end = options?.end === void 0 ? text.length : options.end;
		if (!Number.isSafeInteger(start) || !Number.isSafeInteger(end) || start < 0 || end < start || end > text.length) throw new RangeError("range must be ordered UTF-16 offsets within the input");
		const segments = segmenter.segment(text);
		for (const offset of [start, end]) if (offset !== text.length && segments.containing(offset)?.index !== offset) throw new RangeError("range offsets must be original grapheme boundaries");
		const anchored = options?.anchored === true;
		return (from, to) => from >= start && to <= end && (!anchored || from === start) && (!boundary || boundary(from, to));
	}
	function assertStreamRange(options) {
		if (options && ("start" in options || "end" in options || "anchored" in options)) throw new TypeError("start, end and anchored are only supported by whole-text queries");
	}
	function validateOptions(options, tokenMode) {
		resolveBoundary("", options);
		assertStreamRange(options);
		const strategy = resolveStrategy(options, tokenMode ? "leftmost-longest" : "all");
		if (strategy === "longest-first" || tokenMode && strategy === "all") throw new TypeError("strategy is not supported by this stream");
		const maxBufferLength = options?.maxBufferLength ?? options?.maxBufferedUnits ?? 1048576;
		if (maxBufferLength !== Number.POSITIVE_INFINITY && (!Number.isSafeInteger(maxBufferLength) || maxBufferLength < 1)) throw new RangeError("maxBufferLength must be a positive safe integer or Infinity");
		if (options?.filter !== void 0 && typeof options.filter?.create !== "function") throw new TypeError("filter must provide create()");
		return {
			strategy,
			maxBufferLength,
			filter: options?.filter
		};
	}
	/** Incremental segmentation, filtering and output accounting shared by every adapter. */
	function core(matcher, options, tokenMode) {
		const { strategy, maxBufferLength, filter } = validateOptions(options, tokenMode);
		const wordSegmenter = options?.wholeWord ? new Intl.Segmenter(options.locale, { granularity: "word" }) : void 0;
		const wordStarts = /* @__PURE__ */ new Set();
		const wordEnds = /* @__PURE__ */ new Set();
		let session = require_runtime.scanner(matcher, strategy, wordSegmenter ? (start, end) => wordStarts.has(start) && wordEnds.has(end) : void 0);
		const segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
		const parser = filter?.create();
		let raw = "";
		let rawBase = 0;
		let rawStartsLine = true;
		let tail = "";
		let tailBase = 0;
		let classifiedEnd = 0;
		let protectedRanges = [];
		let lifecycle = "open";
		function destroy() {
			lifecycle = "destroyed";
			raw = tail = "";
			protectedRanges = [];
			wordStarts.clear();
			wordEnds.clear();
			parser?.destroy();
			session?.destroy?.();
			session = void 0;
		}
		function process(parts, final) {
			for (const part of parts) {
				if (part.protected && part.text.length) protectedRanges.push({
					start: classifiedEnd,
					end: classifiedEnd + part.text.length
				});
				tail += part.text;
				classifiedEnd += part.text.length;
			}
			const output = [];
			let settledText = tail;
			if (wordSegmenter && !final) {
				let cut = 0;
				for (let i = 0; i < tail.length; i++) {
					const code = tail.charCodeAt(i);
					if (code === 10 || code === 8232 || code === 8233 || code === 13 && i + 1 < tail.length && tail.charCodeAt(i + 1) !== 10) cut = i + 1;
				}
				settledText = tail.slice(0, cut);
			}
			const segments = Array.from(segmenter.segment(settledText));
			if (wordSegmenter) {
				for (const part of wordSegmenter.segment(settledText)) if (part.isWordLike) {
					wordStarts.add(tailBase + part.index);
					wordEnds.add(tailBase + part.index + part.segment.length);
				}
			}
			const count = final || wordSegmenter ? segments.length : Math.max(0, segments.length - 3);
			let consumed = 0;
			let range = 0;
			const hits = [];
			for (let index = 0; index < count; index++) {
				const { segment, index: offset } = segments[index];
				const start = tailBase + offset;
				const end = start + segment.length;
				while (range < protectedRanges.length && protectedRanges[range].end <= start) range++;
				const protectedText = range < protectedRanges.length && protectedRanges[range].start < end;
				for (const hit of session.feed(segment, start, segments[index + 1]?.segment, protectedText)) hits.push(hit);
				consumed = offset + segment.length;
			}
			if (final) for (const hit of session.end()) hits.push(hit);
			if (tokenMode) {
				let cursor = rawBase;
				for (const match of hits) {
					if (cursor < match.start) output.push({
						type: "text",
						text: raw.slice(cursor - rawBase, match.start - rawBase),
						start: cursor,
						end: match.start
					});
					output.push({
						type: "match",
						text: raw.slice(match.start - rawBase, match.end - rawBase),
						start: match.start,
						end: match.end,
						match
					});
					cursor = match.end;
				}
				if (cursor < session.safeOffset) output.push({
					type: "text",
					text: raw.slice(cursor - rawBase, session.safeOffset - rawBase),
					start: cursor,
					end: session.safeOffset
				});
			} else for (const hit of hits) output.push(hit);
			if (wordSegmenter) {
				for (const boundaries of [wordStarts, wordEnds]) for (const boundary of boundaries) if (boundary < session.retainOffset) boundaries.delete(boundary);
			}
			const released = session.safeOffset - rawBase;
			if (released > 0) {
				const previous = raw.charCodeAt(released - 1);
				rawStartsLine = previous === 10 || previous === 13 || previous === 8232 || previous === 8233;
			}
			raw = raw.slice(released);
			rawBase = session.safeOffset;
			tail = tail.slice(consumed);
			tailBase += consumed;
			protectedRanges = protectedRanges.filter((range) => range.end > Math.min(tailBase, rawBase));
			if (raw.length > maxBufferLength) throw new RangeError("undecided original text exceeds maxBufferLength");
			return output;
		}
		function requireOpen() {
			if (lifecycle !== "open") throw new Error(`stream is ${lifecycle}`);
		}
		return {
			write(chunk) {
				requireOpen();
				assertText(chunk);
				try {
					if (!Number.isSafeInteger(rawBase + raw.length + chunk.length)) throw new RangeError("stream offset exceeds Number.MAX_SAFE_INTEGER");
					const output = [];
					for (let offset = 0; offset < chunk.length; offset += 4096) {
						const piece = chunk.slice(offset, offset + 4096);
						raw += piece;
						const parts = parser ? parser.write(piece) : [{
							text: piece,
							protected: false
						}];
						for (const item of process(parts, false)) output.push(item);
					}
					return output;
				} catch (error) {
					destroy();
					throw error;
				}
			},
			end() {
				if (lifecycle === "ended") return [];
				requireOpen();
				try {
					const result = process(parser ? parser.write("", true) : [], true);
					destroy();
					lifecycle = "ended";
					return result;
				} catch (error) {
					destroy();
					throw error;
				}
			},
			destroy,
			preview() {
				if (lifecycle === "destroyed") throw new Error("stream is destroyed");
				const localBoundary = wordSegmenter ? resolveBoundary(raw, options) : void 0;
				const preview = require_runtime.scanner(matcher, strategy === "all" ? "leftmost-longest" : strategy, localBoundary ? (start, end) => (start !== rawBase || rawStartsLine || wordStarts.has(start)) && localBoundary(start - rawBase, end - rawBase) : void 0);
				const tokens = [];
				let cursor = rawBase;
				const append = (matches) => {
					for (const match of matches) {
						if (cursor < match.start) tokens.push({
							type: "text",
							text: raw.slice(cursor - rawBase, match.start - rawBase),
							start: cursor,
							end: match.start
						});
						tokens.push({
							type: "match",
							text: raw.slice(match.start - rawBase, match.end - rawBase),
							start: match.start,
							end: match.end,
							match
						});
						cursor = match.end;
					}
				};
				try {
					const segments = Array.from(segmenter.segment(raw));
					let range = 0;
					for (let index = 0; index < segments.length; index++) {
						const part = segments[index];
						const start = rawBase + part.index;
						const end = start + part.segment.length;
						while (range < protectedRanges.length && protectedRanges[range].end <= start) range++;
						const protectedText = end > classifiedEnd || range < protectedRanges.length && protectedRanges[range].start < end;
						append(preview.feed(part.segment, start, segments[index + 1]?.segment, protectedText));
					}
					append(preview.end());
				} finally {
					preview.destroy?.();
				}
				if (cursor < rawBase + raw.length) tokens.push({
					type: "text",
					text: raw.slice(cursor - rawBase),
					start: cursor,
					end: rawBase + raw.length
				});
				return {
					start: rawBase,
					text: raw,
					tokens
				};
			}
		};
	}
	function createMatchStream(matcher, options) {
		return core(matcher, options, false);
	}
	function createTokenStream(matcher, options) {
		return core(matcher, options, true);
	}
	function validateReplacement(replacement) {
		if (typeof replacement !== "string" && typeof replacement !== "function") throw new TypeError("replacement must be a string or function");
	}
	function replacementValue(value) {
		if (typeof value !== "string") throw new TypeError("replacement callback must return a string");
		return value;
	}
	function createReplaceStream(matcher, replacement, options) {
		validateReplacement(replacement);
		replacement = require_runtime.operationReplacement(replacement);
		const handle = createTokenStream(matcher, options);
		function replace(tokens) {
			try {
				return tokens.map((token) => token.type === "text" ? token.text : replacementValue(typeof replacement === "string" ? replacement : replacement(token.match, token.text)));
			} catch (error) {
				handle.destroy();
				throw error;
			}
		}
		return {
			write: (chunk) => replace(handle.write(chunk)),
			end: () => replace(handle.end()),
			destroy: () => handle.destroy()
		};
	}
	function* consume(source, handle) {
		try {
			for (const chunk of source) yield* handle.write(chunk);
			yield* handle.end();
		} finally {
			handle.destroy();
		}
	}
	function iterateChunks(matcher, source, options) {
		return consume(source, createMatchStream(matcher, options));
	}
	function tokenizeChunks(matcher, source, options) {
		return consume(source, createTokenStream(matcher, options));
	}
	function replaceChunks(matcher, source, replacement, options) {
		return consume(source, createReplaceStream(matcher, replacement, options));
	}
	function abortReason(signal) {
		return signal.reason ?? new DOMException("The operation was aborted", "AbortError");
	}
	/** Race pending sources/callbacks without retaining an abort listener after settlement. */
	async function abortable(promise, signal) {
		if (!signal) return promise;
		if (signal.aborted) {
			Promise.resolve(promise).catch(() => {});
			throw abortReason(signal);
		}
		let remove = () => {};
		try {
			return await Promise.race([promise, new Promise((_resolve, reject) => {
				const abort = () => reject(abortReason(signal));
				signal.addEventListener("abort", abort, { once: true });
				remove = () => signal.removeEventListener("abort", abort);
			})]);
		} finally {
			remove();
		}
	}
	async function* consumeAsync(source, handle, options) {
		const step = options?.yieldEvery === void 0 ? 4096 : options.yieldEvery;
		if (!Number.isSafeInteger(step) || step < 1) {
			handle.destroy();
			throw new RangeError("yieldEvery must be a positive safe integer");
		}
		const signal = options?.signal;
		const iterator = Symbol.asyncIterator in source ? source[Symbol.asyncIterator]() : source[Symbol.iterator]();
		let complete = false;
		let processed = 0;
		try {
			while (true) {
				if (signal?.aborted) throw abortReason(signal);
				const next = await abortable(iterator.next(), signal);
				if (next.done) {
					complete = true;
					break;
				}
				assertText(next.value);
				for (let start = 0; start < next.value.length; start += step) {
					if (signal?.aborted) throw abortReason(signal);
					const piece = next.value.slice(start, start + step);
					for (const item of handle.write(piece)) {
						if (signal?.aborted) throw abortReason(signal);
						yield item;
					}
					processed += piece.length;
					if (processed >= step) {
						await abortable(new Promise((resolve) => setTimeout(resolve, 0)), signal);
						processed = 0;
					}
				}
			}
			for (const item of handle.end()) {
				if (signal?.aborted) throw abortReason(signal);
				yield item;
			}
		} finally {
			handle.destroy();
			if (!complete && iterator.return) {
				const closing = Promise.resolve(iterator.return());
				if (signal?.aborted) closing.catch(() => {});
				else await closing;
			}
		}
	}
	function iterateChunksAsync(matcher, source, options) {
		return consumeAsync(source, createMatchStream(matcher, options), options);
	}
	function tokenizeChunksAsync(matcher, source, options) {
		return consumeAsync(source, createTokenStream(matcher, options), options);
	}
	function replaceChunksAsync(matcher, source, replacement, options) {
		validateReplacement(replacement);
		replacement = require_runtime.operationReplacement(replacement);
		const tokens = tokenizeChunksAsync(matcher, source, options);
		return (async function* () {
			for await (const token of tokens) yield token.type === "text" ? token.text : replacementValue(await abortable(typeof replacement === "string" ? replacement : replacement(token.match, token.text), options?.signal));
		})();
	}
	/** Consume synchronous chunks directly into a caller-owned sink. */
	function consumeChunks(matcher, source, consumer, options) {
		if (typeof consumer !== "function") throw new TypeError("consumer must be a function");
		for (const match of iterateChunks(matcher, source, options)) consumer(match);
	}
	/** Consume asynchronous chunks directly into a caller-owned sink. */
	async function consumeChunksAsync(matcher, source, consumer, options) {
		if (typeof consumer !== "function") throw new TypeError("consumer must be a function");
		for await (const match of iterateChunksAsync(matcher, source, options)) await consumer(match);
	}
	function asyncSession(handle, convert, options) {
		const step = options?.yieldEvery === void 0 ? 4096 : options.yieldEvery;
		if (!Number.isSafeInteger(step) || step < 1) {
			handle.destroy();
			throw new RangeError("yieldEvery must be a positive safe integer");
		}
		const controller = new AbortController();
		const signal = options?.signal ? AbortSignal.any([options.signal, controller.signal]) : controller.signal;
		let busy = false;
		const destroy = () => {
			controller.abort();
			handle.destroy();
		};
		async function run(chunk, final) {
			if (busy) throw new Error("await the pending stream operation before writing or ending");
			busy = true;
			try {
				if (signal.aborted) throw abortReason(signal);
				const result = [];
				async function append(items) {
					for (const item of items) {
						if (signal.aborted) throw abortReason(signal);
						result.push(await abortable(convert(item), signal));
					}
				}
				if (final) await append(handle.end());
				else {
					assertText(chunk);
					const input = chunk;
					if (input.length === 0) await append(handle.write(""));
					for (let start = 0; start < input.length; start += step) {
						if (signal.aborted) throw abortReason(signal);
						await append(handle.write(input.slice(start, start + step)));
						await abortable(new Promise((resolve) => setTimeout(resolve, 0)), signal);
					}
				}
				return result;
			} catch (error) {
				destroy();
				throw error;
			} finally {
				busy = false;
			}
		}
		return {
			write: (chunk) => run(chunk, false),
			end: () => run(void 0, true),
			destroy
		};
	}
	function createMatchStreamAsync(matcher, options) {
		return asyncSession(createMatchStream(matcher, options), (item) => item, options);
	}
	function createTokenStreamAsync(matcher, options) {
		return asyncSession(createTokenStream(matcher, options), (item) => item, options);
	}
	function createReplaceStreamAsync(matcher, replacement, options) {
		validateReplacement(replacement);
		replacement = require_runtime.operationReplacement(replacement);
		return asyncSession(createTokenStream(matcher, options), async (token) => token.type === "text" ? token.text : replacementValue(await (typeof replacement === "string" ? replacement : replacement(token.match, token.text))), options);
	}
	Object.defineProperty(exports, "assertStreamRange", {
		enumerable: true,
		get: function() {
			return assertStreamRange;
		}
	});
	Object.defineProperty(exports, "assertText", {
		enumerable: true,
		get: function() {
			return assertText;
		}
	});
	Object.defineProperty(exports, "consumeChunks", {
		enumerable: true,
		get: function() {
			return consumeChunks;
		}
	});
	Object.defineProperty(exports, "consumeChunksAsync", {
		enumerable: true,
		get: function() {
			return consumeChunksAsync;
		}
	});
	Object.defineProperty(exports, "createMatchStream", {
		enumerable: true,
		get: function() {
			return createMatchStream;
		}
	});
	Object.defineProperty(exports, "createMatchStreamAsync", {
		enumerable: true,
		get: function() {
			return createMatchStreamAsync;
		}
	});
	Object.defineProperty(exports, "createReplaceStream", {
		enumerable: true,
		get: function() {
			return createReplaceStream;
		}
	});
	Object.defineProperty(exports, "createReplaceStreamAsync", {
		enumerable: true,
		get: function() {
			return createReplaceStreamAsync;
		}
	});
	Object.defineProperty(exports, "createTokenStream", {
		enumerable: true,
		get: function() {
			return createTokenStream;
		}
	});
	Object.defineProperty(exports, "createTokenStreamAsync", {
		enumerable: true,
		get: function() {
			return createTokenStreamAsync;
		}
	});
	Object.defineProperty(exports, "iterateChunks", {
		enumerable: true,
		get: function() {
			return iterateChunks;
		}
	});
	Object.defineProperty(exports, "iterateChunksAsync", {
		enumerable: true,
		get: function() {
			return iterateChunksAsync;
		}
	});
	Object.defineProperty(exports, "replaceChunks", {
		enumerable: true,
		get: function() {
			return replaceChunks;
		}
	});
	Object.defineProperty(exports, "replaceChunksAsync", {
		enumerable: true,
		get: function() {
			return replaceChunksAsync;
		}
	});
	Object.defineProperty(exports, "resolveBoundary", {
		enumerable: true,
		get: function() {
			return resolveBoundary;
		}
	});
	Object.defineProperty(exports, "resolveQuery", {
		enumerable: true,
		get: function() {
			return resolveQuery;
		}
	});
	Object.defineProperty(exports, "resolveStrategy", {
		enumerable: true,
		get: function() {
			return resolveStrategy;
		}
	});
	Object.defineProperty(exports, "tokenizeChunks", {
		enumerable: true,
		get: function() {
			return tokenizeChunks;
		}
	});
	Object.defineProperty(exports, "tokenizeChunksAsync", {
		enumerable: true,
		get: function() {
			return tokenizeChunksAsync;
		}
	});
}));
//#endregion
//#region node_modules/modern-ahocorasick/dist/_private/src-Y0gayY8y.cjs
var require_src_Y0gayY8y = /* @__PURE__ */ __commonJSMin(((exports) => {
	var require_runtime = require_runtime_aoctzF3W();
	var require_stream = require_stream_CvP3nR7V();
	/** Internal stream session; no automaton tables escape through its public facade. */
	function createStream(table, patterns, lengths, maxLength, strategy, maxBufferedUnits, wordSegmenter) {
		const segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
		let pending = "";
		let offset = 0;
		let state = 0;
		let position = 0;
		let cursor = 0;
		let closed = false;
		const candidates = /* @__PURE__ */ new Map();
		const wordStarts = /* @__PURE__ */ new Set();
		let maxUnits = 0;
		if (wordSegmenter) for (const { pattern } of patterns) maxUnits = Math.max(maxUnits, pattern.length);
		function assertOpen() {
			if (closed) throw new Error("Stream is finished or cancelled");
		}
		function match(patternIndex, start, end) {
			const { pattern, data } = patterns[patternIndex];
			return {
				pattern,
				patternIndex,
				start,
				end,
				data
			};
		}
		function settle(until, result) {
			while (cursor <= until) {
				const candidate = candidates.get(cursor);
				if (candidate) {
					const next = cursor + lengths[candidate.patternIndex];
					for (; cursor < next; cursor++) candidates.delete(cursor);
					result.push(match(candidate.patternIndex, candidate.start, candidate.end));
				} else cursor++;
			}
		}
		function consume(text, result) {
			const wordEnds = /* @__PURE__ */ new Set();
			if (wordSegmenter) {
				for (const part of wordSegmenter.segment(text)) if (part.isWordLike) {
					wordStarts.add(offset + part.index);
					wordEnds.add(offset + part.index + part.segment.length);
				}
			}
			for (const { segment, index } of segmenter.segment(text)) {
				state = require_runtime.advanceCompact(table, state, segment);
				position++;
				const end = offset + index + segment.length;
				for (let output = state; output !== -1; output = table.outputs[output]) {
					const from = table.terminals[output];
					const to = strategy === "all" ? table.terminals[output + 1] : Math.min(from + 1, table.terminals[output + 1]);
					for (let terminal = from; terminal < to; terminal++) {
						const patternIndex = table.patterns[terminal];
						const start = end - patterns[patternIndex].pattern.length;
						if (wordSegmenter && (!wordStarts.has(start) || !wordEnds.has(end))) continue;
						if (strategy === "all") {
							result.push(match(patternIndex, start, end));
							continue;
						}
						const at = position - lengths[patternIndex];
						if (at < cursor) continue;
						const previous = candidates.get(at);
						if (!previous || (strategy === "leftmost-first" ? patternIndex < previous.patternIndex : end > previous.end || end === previous.end && patternIndex < previous.patternIndex)) candidates.set(at, {
							patternIndex,
							start,
							end
						});
					}
				}
				if (strategy !== "all") settle(position - maxLength, result);
			}
			offset += text.length;
			for (const start of wordStarts) if (start < offset - maxUnits) wordStarts.delete(start);
		}
		function cancel() {
			closed = true;
			pending = "";
			candidates.clear();
			wordStarts.clear();
		}
		return {
			write(chunk) {
				assertOpen();
				if (typeof chunk !== "string") throw new TypeError("chunk must be a string");
				if (!Number.isSafeInteger(offset + pending.length + chunk.length)) {
					cancel();
					throw new RangeError("stream offset exceeds Number.MAX_SAFE_INTEGER");
				}
				const text = pending + chunk;
				let cut = 0;
				if (wordSegmenter) for (let index = 0; index < text.length; index++) {
					const code = text.charCodeAt(index);
					if (code === 10 || code === 8232 || code === 8233 || code === 13 && index + 1 < text.length && text.charCodeAt(index + 1) !== 10) cut = index + 1;
				}
				else {
					let previous = 0;
					for (const { index } of segmenter.segment(text)) {
						previous = cut;
						cut = index;
					}
					const last = text.charCodeAt(text.length - 1);
					if (last >= 55296 && last <= 56319) cut = previous;
				}
				if (text.length - cut > maxBufferedUnits) {
					cancel();
					throw new RangeError("unsettled stream tail exceeds maxBufferedUnits");
				}
				const result = [];
				consume(text.slice(0, cut), result);
				pending = text.slice(cut);
				return result;
			},
			finish() {
				assertOpen();
				const result = [];
				consume(pending, result);
				if (strategy !== "all") settle(position, result);
				cancel();
				return result;
			},
			cancel
		};
	}
	function invalid() {
		throw new TypeError("Invalid or incompatible compiled dictionary");
	}
	function record(value) {
		if (value === null || typeof value !== "object" || Array.isArray(value)) return invalid();
		return value;
	}
	function numbers(value, min, max) {
		if (!Array.isArray(value) || value.some((item) => !Number.isInteger(item) || item < min || item > max)) return invalid();
		return value;
	}
	/** Do not silently lose metadata through JSON's coercion or toJSON hooks. */
	function assertJson(value, seen = /* @__PURE__ */ new Set()) {
		if (value === null || typeof value === "string" || typeof value === "boolean" || typeof value === "number" && Number.isFinite(value)) return;
		if (typeof value !== "object" || seen.has(value) || !Array.isArray(value) && Object.getPrototypeOf(value) !== Object.prototype && Object.getPrototypeOf(value) !== null || typeof value.toJSON === "function" || Object.getOwnPropertySymbols(value).length !== 0) throw new TypeError("Metadata must be JSON-compatible; provide an encodeData codec");
		seen.add(value);
		for (const item of Array.isArray(value) ? value : Object.values(value)) assertJson(item, seen);
		seen.delete(value);
	}
	function codec(options, key) {
		if (options === void 0) return;
		const value = record(options)[key];
		if (value !== void 0 && typeof value !== "function") throw new TypeError(`${key} must be a function`);
	}
	function serialize(table, patterns, options) {
		codec(options, "encodeData");
		const entries = patterns.map(({ pattern, data }) => {
			if (data === void 0) return { pattern };
			const encoded = options?.encodeData ? options.encodeData(data) : data;
			assertJson(encoded);
			return {
				pattern,
				data: encoded
			};
		});
		return JSON.stringify({
			format: "modern-ahocorasick",
			version: 1,
			segmentation: "Intl.Segmenter:grapheme",
			symbols: [...table.symbols.keys()],
			edges: [...table.edges],
			labels: [...table.labels],
			targets: [...table.targets],
			failures: [...table.failures],
			outputs: [...table.outputs],
			terminals: [...table.terminals],
			patternIndices: [...table.patterns],
			patterns: entries
		});
	}
	function deserialize(serialized, segmenter, options) {
		codec(options, "decodeData");
		if (typeof serialized !== "string") return invalid();
		let source;
		try {
			source = record(JSON.parse(serialized));
		} catch {
			return invalid();
		}
		if (source["format"] !== "modern-ahocorasick" || source["version"] !== 1 || source["segmentation"] !== "Intl.Segmenter:grapheme") return invalid();
		if (!Array.isArray(source["symbols"]) || !source["symbols"].every((symbol) => typeof symbol === "string" && symbol.length > 0) || !Array.isArray(source["patterns"])) return invalid();
		const symbolNames = source["symbols"];
		const symbols = new Map(symbolNames.map((symbol, index) => [symbol, index]));
		if (symbols.size !== source["symbols"].length) return invalid();
		const failures = Uint32Array.from(numbers(source["failures"], 0, 4294967295));
		const size = failures.length;
		if (size === 0) return invalid();
		const table = {
			symbols,
			roots: new Uint32Array(symbols.size),
			edges: Uint32Array.from(numbers(source["edges"], 0, size - 1)),
			labels: Uint32Array.from(numbers(source["labels"], 0, symbols.size - 1)),
			targets: Uint32Array.from(numbers(source["targets"], 1, size - 1)),
			failures,
			outputs: Int32Array.from(numbers(source["outputs"], -1, size - 1)),
			terminals: Uint32Array.from(numbers(source["terminals"], 0, source["patterns"].length)),
			patterns: Uint32Array.from(numbers(source["patternIndices"], 0, source["patterns"].length - 1))
		};
		if (table.edges.length !== size + 1 || table.terminals.length !== size + 1 || table.outputs.length !== size || table.targets.length !== size - 1 || table.labels.length !== size - 1 || table.patterns.length !== source["patterns"].length || table.edges[0] !== 0 || table.edges[size] !== size - 1 || table.terminals[0] !== 0 || table.terminals[1] !== 0 || table.terminals[size] !== source["patterns"].length || failures[0] !== 0 || table.outputs[0] !== -1) return invalid();
		for (let state = 0; state < size; state++) {
			if (table.edges[state] > table.edges[state + 1] || table.terminals[state] > table.terminals[state + 1]) return invalid();
			for (let edge = table.edges[state] + 1; edge < table.edges[state + 1]; edge++) if (table.labels[edge - 1] >= table.labels[edge]) return invalid();
		}
		const parents = new Int32Array(size).fill(-1);
		const labels = new Uint32Array(size);
		const depths = new Uint32Array(size);
		const queue = [0];
		parents[0] = 0;
		for (let head = 0; head < queue.length; head++) {
			const state = queue[head];
			for (let edge = table.edges[state]; edge < table.edges[state + 1]; edge++) {
				const child = table.targets[edge];
				if (parents[child] !== -1) return invalid();
				parents[child] = state;
				labels[child] = table.labels[edge];
				depths[child] = depths[state] + 1;
				queue.push(child);
				if (state === 0) table.roots[table.labels[edge]] = child;
			}
		}
		if (queue.length !== size) return invalid();
		const counts = new Uint32Array(size);
		const terminals = new Int32Array(source["patterns"].length).fill(-1);
		for (const state of queue.slice(1)) {
			const parent = parents[state];
			const failure = parent === 0 ? 0 : require_runtime.advanceCompact(table, failures[parent], symbolNames[labels[state]]);
			if (failures[state] !== failure || table.outputs[state] !== (table.terminals[failure] < table.terminals[failure + 1] ? failure : table.outputs[failure])) return invalid();
			const start = table.terminals[state];
			const end = table.terminals[state + 1];
			counts[state] = end - start + counts[failure];
			for (let index = start; index < end; index++) {
				const patternIndex = table.patterns[index];
				if (terminals[patternIndex] !== -1 || index > start && table.patterns[index - 1] >= patternIndex) return invalid();
				terminals[patternIndex] = state;
			}
		}
		const lengths = new Uint32Array(source["patterns"].length);
		let maxLength = 0;
		return {
			table,
			patterns: source["patterns"].map((value, index) => {
				const entry = record(value);
				if (typeof entry["pattern"] !== "string" || entry["pattern"].length === 0 || terminals[index] === -1) return invalid();
				let state = 0;
				let depth = 0;
				for (const segments of require_runtime.graphemeRuns(entry["pattern"], segmenter)) for (const { segment } of segments) {
					state = require_runtime.advanceCompact(table, state, segment);
					depth++;
					if (depths[state] !== depth) return invalid();
				}
				if (state !== terminals[index]) return invalid();
				lengths[index] = depth;
				maxLength = Math.max(maxLength, depth);
				if (entry["data"] !== void 0) assertJson(entry["data"]);
				return {
					pattern: entry["pattern"],
					data: entry["data"] === void 0 ? void 0 : options?.decodeData ? options.decodeData(entry["data"]) : entry["data"]
				};
			}),
			lengths,
			counts,
			order: Uint32Array.from(queue.slice(1)),
			maxLength
		};
	}
	function checksum(value) {
		let hash = 2166136261;
		for (let index = 0; index < value.length; index++) hash = Math.imul(hash ^ value.charCodeAt(index), 16777619);
		return (hash >>> 0).toString(16).padStart(8, "0");
	}
	function hasDenseOutputs(counts) {
		for (let state = 0; state < counts.length; state++) if (counts[state] >= 32) return true;
		return false;
	}
	/** An immutable compiled dictionary for exact grapheme-cluster matching. */
	var AhoCorasick = class AhoCorasick {
		#boundary;
		#profile;
		#generalScan;
		#stats;
		#backend;
		#nodes;
		#patterns;
		#maxLength;
		/** Pattern lengths in graphemes; string.length and public ranges use UTF-16. */
		#lengths;
		#counts;
		#denseOutputs;
		#order;
		#segmenter = new Intl.Segmenter(void 0, { granularity: "grapheme" });
		constructor(patterns, options) {
			this.#boundary = require_runtime.resolveCharacterBoundary(options);
			this.#profile = require_runtime.getProfile(new.target);
			this.#generalScan = this.#boundary !== "none" || !!this.#profile.units || !!this.#profile.backend;
			if (!Array.isArray(patterns)) throw new TypeError("patterns must be an array");
			this.#patterns = Array.from(patterns, (input, index) => {
				const pattern = typeof input === "string" ? input : input !== null && typeof input === "object" && !Array.isArray(input) ? input.pattern : void 0;
				if (typeof pattern !== "string") throw new TypeError(`patterns[${index}].pattern must be a string`);
				if (pattern.length === 0) throw new RangeError(`patterns[${index}] must not be empty`);
				return {
					pattern,
					data: typeof input === "string" ? void 0 : input.data
				};
			});
			const { compact, lengths, counts, order, maxLength } = require_runtime.buildAutomaton(this.#patterns, this.#segmenter, this.#profile.units);
			this.#nodes = this.#profile.backend ? require_runtime.buildAutomaton([], this.#segmenter).compact : compact;
			this.#backend = this.#profile.backend ? this.#profile.backend(compact) : require_runtime.compactBackend(this.#nodes);
			this.#lengths = lengths;
			this.#counts = counts;
			this.#denseOutputs = hasDenseOutputs(counts);
			this.#order = order;
			this.#maxLength = maxLength;
			this.#stats = this.#compileStats();
			require_runtime.registerScanner(this, (strategy, range) => require_runtime.createScanner(this.#backend, this.#patterns, this.#lengths, this.#maxLength, this.#boundary, this.#profile.units, strategy, range));
		}
		#compileStats() {
			const layout = this.#backend.stats;
			const placeholderBytes = this.#profile.backend ? require_runtime.compactBackend(this.#nodes).stats.typedArrayBytes : 0;
			return Object.freeze({
				...layout,
				patternCount: this.#patterns.length,
				maxPatternUnits: this.#maxLength,
				unit: this.#profile.units ? "folded-codepoint" : "grapheme",
				typedArrayBytes: layout.typedArrayBytes + placeholderBytes + this.#lengths.byteLength + this.#counts.byteLength + this.#order.byteLength
			});
		}
		/** Constant-time immutable diagnostics; byte count excludes JS heap objects. */
		getStats() {
			return this.#stats;
		}
		/** Incremental matching with absolute original-text UTF-16 ranges. */
		createStream(options) {
			const strategy = require_stream.resolveStrategy(options, "all");
			if (strategy === "longest-first") throw new TypeError("longest-first requires complete input");
			require_stream.resolveBoundary("", options);
			require_stream.assertStreamRange(options);
			const maxBufferedUnits = options?.maxBufferedUnits === void 0 ? 1048576 : options.maxBufferedUnits;
			if (!Number.isSafeInteger(maxBufferedUnits) || maxBufferedUnits < 1) throw new RangeError("maxBufferedUnits must be a positive safe integer");
			if (this.#generalScan) {
				const handle = require_stream.createMatchStream(this, {
					...options,
					strategy,
					maxBufferLength: maxBufferedUnits
				});
				let closed = false;
				const assertOpen = () => {
					if (closed) throw new Error("Stream is finished or cancelled");
				};
				return {
					write: (chunk) => {
						assertOpen();
						return handle.write(chunk);
					},
					finish: () => {
						assertOpen();
						closed = true;
						return handle.end();
					},
					cancel: () => {
						closed = true;
						handle.destroy();
					}
				};
			}
			const wordSegmenter = options?.wholeWord ? new Intl.Segmenter(options.locale, { granularity: "word" }) : void 0;
			return createStream(this.#nodes, this.#patterns, this.#lengths, this.#maxLength, strategy, maxBufferedUnits, wordSegmenter);
		}
		/** Persist a versioned compiled dictionary; metadata must be JSON-compatible. */
		serialize(options) {
			if (this.#profile.units || this.#boundary !== "none") throw new TypeError("serialize supports exact matchers without constructor boundary rules");
			if (this.#profile.backend) {
				const patterns = this.#patterns.map(({ pattern, data }) => data === void 0 ? { pattern } : {
					pattern,
					data
				});
				return new AhoCorasick(patterns).serialize(options);
			}
			return serialize(this.#nodes, this.#patterns, options);
		}
		/** Wrap the compiled payload with profile and storage metadata for distribution. */
		serializeArtifact(options) {
			const payload = this.serialize(options);
			const backend = this.#profile.backend ? "compact" : this.#stats.backend;
			const stats = {
				...this.#stats,
				backend
			};
			return JSON.stringify({
				format: "modern-ahocorasick/artifact",
				version: 1,
				segmentation: "Intl.Segmenter:grapheme",
				backend,
				unit: this.#stats.unit,
				stats,
				dictionary: {
					patternCount: stats.patternCount,
					maxPatternUnits: stats.maxPatternUnits
				},
				checksum: checksum(payload),
				payload
			});
		}
		/** Load and validate scan tables without rebuilding a trie. */
		static deserialize(serialized, options) {
			const matcher = new AhoCorasick([]);
			const restored = deserialize(serialized, matcher.#segmenter, options);
			matcher.#nodes = restored.table;
			matcher.#backend = require_runtime.compactBackend(restored.table);
			matcher.#patterns = restored.patterns;
			matcher.#lengths = restored.lengths;
			matcher.#counts = restored.counts;
			matcher.#denseOutputs = hasDenseOutputs(restored.counts);
			matcher.#order = restored.order;
			matcher.#maxLength = restored.maxLength;
			matcher.#stats = matcher.#compileStats();
			return matcher;
		}
		/** Load a distributable artifact after validating its profile envelope. */
		static deserializeArtifact(serialized, options) {
			if (typeof serialized !== "string") throw new TypeError("serialized must be a string");
			let source;
			try {
				const parsed = JSON.parse(serialized);
				if (parsed === null || typeof parsed !== "object" || Array.isArray(parsed)) throw new Error("record expected");
				source = parsed;
			} catch {
				throw new TypeError("Invalid compiled artifact");
			}
			if (source["format"] !== "modern-ahocorasick/artifact" || source["version"] !== 1 || source["segmentation"] !== "Intl.Segmenter:grapheme" || typeof source["payload"] !== "string" || !["compact", "double-array"].includes(String(source["backend"])) || !["grapheme", "folded-codepoint"].includes(String(source["unit"])) || source["stats"] === null || typeof source["stats"] !== "object") throw new TypeError("Invalid or incompatible compiled artifact");
			const stats = source["stats"];
			if (stats["backend"] !== source["backend"] || stats["unit"] !== source["unit"]) throw new TypeError("Invalid or incompatible compiled artifact");
			if (source["checksum"] !== void 0 && source["checksum"] !== checksum(source["payload"])) throw new TypeError("Invalid or incompatible compiled artifact");
			const matcher = AhoCorasick.deserialize(source["payload"], options);
			const actual = matcher.getStats();
			for (const key of ["patternCount", "maxPatternUnits"]) {
				if (source["dictionary"] !== void 0) {
					const dictionary = source["dictionary"];
					if (dictionary === null || typeof dictionary !== "object" || Array.isArray(dictionary) || dictionary[key] !== actual[key]) throw new TypeError("Invalid or incompatible compiled artifact");
				}
				if (stats[key] !== actual[key]) throw new TypeError("Invalid or incompatible compiled artifact");
			}
			if (actual.unit !== source["unit"]) throw new TypeError("Compiled artifact requires a different Unicode unit profile");
			return matcher;
		}
		/** All matches, optionally reduced to a non-overlapping selection. */
		search(text, options) {
			const matches = [];
			for (const match of this.iterate(text, options)) matches.push(match);
			return matches;
		}
		/** Lazily emit the chosen strategy's results. Validates arguments immediately. */
		iterate(text, options) {
			require_stream.assertText(text);
			const strategy = require_stream.resolveStrategy(options, "all");
			const boundary = options === void 0 ? void 0 : require_stream.resolveQuery(text, options, this.#segmenter);
			return this.#iterate(text, strategy, boundary);
		}
		/** Return the first match without collecting the result array. */
		findFirst(text, options) {
			const iterator = this.iterate(text, options);
			const result = iterator.next();
			iterator.return?.();
			return result.done ? void 0 : result.value;
		}
		/** Return the first match beginning at an original grapheme boundary. */
		findAt(text, start, options) {
			if (!Number.isSafeInteger(start) || start < 0 || start > text.length) throw new RangeError("start must be a safe integer within the input");
			const iterator = this.iterate(text, {
				...options,
				start,
				anchored: true
			});
			const result = iterator.next();
			iterator.return?.();
			return result.done ? void 0 : result.value;
		}
		/** Reuse validated original-context filters; counting must not rebuild them. */
		#iterate(text, strategy, boundary) {
			if (strategy === "longest-first") return require_runtime.selectLongest(this.#iterate(text, "all", boundary), text, this.#segmenter);
			if (this.#generalScan) return require_runtime.scanText(text, this.#segmenter, require_runtime.createScanner(this.#backend, this.#patterns, this.#lengths, this.#maxLength, this.#boundary, this.#profile.units, strategy, boundary));
			return strategy === "all" ? this.#scan(text, boundary) : this.#select(text, strategy, boundary);
		}
		/** Count all occurrences, including overlaps and duplicate dictionary entries. */
		count(text, options) {
			require_stream.assertText(text);
			const boundary = options === void 0 ? void 0 : require_stream.resolveQuery(text, options, this.#segmenter);
			if (boundary || this.#generalScan) return this.#countMatches(this.#iterate(text, "all", boundary));
			if (this.#patterns.length === 0) return 0;
			let state = 0;
			let count = 0;
			const ascii = require_runtime.asciiPrefix(text);
			if (ascii !== void 0) {
				for (const { segment } of ascii) {
					state = require_runtime.advanceCompact(this.#nodes, state, segment);
					count += this.#counts[state];
					if (!Number.isSafeInteger(count)) throw new RangeError("match count exceeds Number.MAX_SAFE_INTEGER");
				}
				if (ascii.position === text.length) return count;
			}
			const suffix = ascii === void 0 ? text : text.slice(ascii.position);
			for (const { segment } of this.#segmenter.segment(suffix)) {
				state = require_runtime.advanceCompact(this.#nodes, state, segment);
				count += this.#counts[state];
				if (!Number.isSafeInteger(count)) throw new RangeError("match count exceeds Number.MAX_SAFE_INTEGER");
			}
			return count;
		}
		#countMatches(matches) {
			let count = 0;
			for (const _match of matches) if (!Number.isSafeInteger(++count)) throw new RangeError("match count exceeds Number.MAX_SAFE_INTEGER");
			return count;
		}
		/** Count occurrences per input pattern without enumerating individual hits. */
		countByPattern(text, options) {
			require_stream.assertText(text);
			const boundary = options === void 0 ? void 0 : require_stream.resolveQuery(text, options, this.#segmenter);
			const result = Array.from({ length: this.#patterns.length }).fill(0);
			if (text.length === 0 || result.length === 0) return result;
			if (boundary || this.#generalScan) {
				for (const match of this.#iterate(text, "all", boundary)) result[match.patternIndex]++;
				return result;
			}
			const visits = new Float64Array(this.#nodes.failures.length);
			let state = 0;
			for (const segments of require_runtime.graphemeRuns(text, this.#segmenter)) for (const { segment } of segments) {
				state = require_runtime.advanceCompact(this.#nodes, state, segment);
				visits[state]++;
			}
			for (let index = this.#order.length - 1; index >= 0; index--) {
				const current = this.#order[index];
				for (let index = this.#nodes.terminals[current]; index < this.#nodes.terminals[current + 1]; index++) result[this.#nodes.patterns[index]] = visits[current];
				visits[this.#nodes.failures[current]] += visits[current];
			}
			return result;
		}
		/** Stop scanning as soon as a match is found. */
		match(text, options) {
			require_stream.assertText(text);
			const boundary = options === void 0 ? void 0 : require_stream.resolveQuery(text, options, this.#segmenter);
			if (boundary || this.#generalScan) {
				const iterator = this.#iterate(text, "all", boundary);
				const found = !iterator.next().done;
				iterator.return?.();
				return found;
			}
			if (this.#patterns.length === 0) return false;
			let state = 0;
			const ascii = require_runtime.asciiPrefix(text);
			if (ascii !== void 0) {
				for (const { segment } of ascii) {
					state = require_runtime.advanceCompact(this.#nodes, state, segment);
					if (this.#counts[state] !== 0) return true;
				}
				if (ascii.position === text.length) return false;
			}
			const suffix = ascii === void 0 ? text : text.slice(ascii.position);
			for (const { segment } of this.#segmenter.segment(suffix)) {
				state = require_runtime.advanceCompact(this.#nodes, state, segment);
				if (this.#counts[state] !== 0) return true;
			}
			return false;
		}
		/** Replace selected original ranges once; replacement strings are literal. */
		replace(text, replacement, options) {
			require_stream.assertText(text);
			if (typeof replacement !== "string" && typeof replacement !== "function") throw new TypeError("replacement must be a string or a function");
			const strategy = require_stream.resolveStrategy(options, "leftmost-longest");
			if (strategy === "all") throw new TypeError("replace requires a non-overlapping strategy");
			replacement = require_runtime.operationReplacement(replacement);
			const selected = this.iterate(text, {
				...options,
				strategy
			});
			const parts = [];
			let cursor = 0;
			for (const match of selected) {
				const { start, end } = match;
				const value = typeof replacement === "string" ? replacement : replacement(match, text.slice(start, end));
				if (typeof value !== "string") throw new TypeError("replacement callback must return a string");
				parts.push(text.slice(cursor, start), value);
				cursor = end;
			}
			parts.push(text.slice(cursor));
			return parts.join("");
		}
		/** Partition original text into non-empty literal and selected match tokens. */
		tokenize(text, options) {
			require_stream.assertText(text);
			const strategy = require_stream.resolveStrategy(options, "leftmost-longest");
			if (strategy === "all") throw new TypeError("tokenize requires a non-overlapping strategy");
			const tokens = [];
			let cursor = 0;
			for (const match of this.iterate(text, {
				...options,
				strategy
			})) {
				if (cursor < match.start) tokens.push({
					type: "text",
					text: text.slice(cursor, match.start),
					start: cursor,
					end: match.start
				});
				tokens.push({
					type: "match",
					text: text.slice(match.start, match.end),
					start: match.start,
					end: match.end,
					match
				});
				cursor = match.end;
			}
			if (cursor < text.length) tokens.push({
				type: "text",
				text: text.slice(cursor),
				start: cursor,
				end: text.length
			});
			return tokens;
		}
		#scan(text, boundary) {
			return this.#denseOutputs ? this.#scanNative(text, boundary) : this.#scanAscii(text, boundary);
		}
		*#scanAscii(text, boundary) {
			if (this.#patterns.length === 0) return;
			let state = 0;
			let ascii = require_runtime.asciiPrefix(text);
			let native = ascii === void 0 ? this.#segmenter.segment(text)[Symbol.iterator]() : void 0;
			let offset = 0;
			while (true) {
				let segment;
				let end;
				if (ascii !== void 0) {
					const next = ascii.next();
					if (next.done) {
						offset = ascii.position;
						if (offset === text.length) break;
						native = this.#segmenter.segment(text.slice(offset))[Symbol.iterator]();
						ascii = void 0;
						continue;
					}
					segment = next.value.segment;
					end = next.value.index + segment.length;
				} else {
					const next = native.next();
					if (next.done) break;
					segment = next.value.segment;
					end = offset + next.value.index + segment.length;
				}
				state = require_runtime.advanceCompact(this.#nodes, state, segment);
				if (this.#counts[state] === 0) continue;
				for (let output = state; output !== -1; output = this.#nodes.outputs[output]) for (let terminal = this.#nodes.terminals[output]; terminal < this.#nodes.terminals[output + 1]; terminal++) {
					const patternIndex = this.#nodes.patterns[terminal];
					const { pattern, data } = this.#patterns[patternIndex];
					const start = end - pattern.length;
					if (!boundary || boundary(start, end)) yield {
						pattern,
						patternIndex,
						start,
						end,
						data
					};
				}
			}
		}
		*#scanNative(text, boundary) {
			if (this.#patterns.length === 0) return;
			let state = 0;
			for (const { segment, index } of this.#segmenter.segment(text)) {
				state = require_runtime.advanceCompact(this.#nodes, state, segment);
				if (this.#counts[state] === 0) continue;
				const end = index + segment.length;
				for (let output = state; output !== -1; output = this.#nodes.outputs[output]) for (let terminal = this.#nodes.terminals[output]; terminal < this.#nodes.terminals[output + 1]; terminal++) {
					const patternIndex = this.#nodes.patterns[terminal];
					const { pattern, data } = this.#patterns[patternIndex];
					const start = end - pattern.length;
					if (!boundary || boundary(start, end)) yield {
						pattern,
						patternIndex,
						start,
						end,
						data
					};
				}
			}
		}
		*#select(text, strategy, boundary) {
			const capacity = this.#maxLength;
			if (capacity === 0) return;
			const stamps = [];
			const candidates = [];
			const starts = [];
			let state = 0;
			let position = 0;
			let cursor = 0;
			let lastCandidateStart = -1;
			let earliest = -1;
			let earliestEnd = -1;
			let ascii = require_runtime.asciiPrefix(text);
			let native = ascii === void 0 ? this.#segmenter.segment(text)[Symbol.iterator]() : void 0;
			let offset = 0;
			while (true) {
				let segment;
				let end;
				if (ascii !== void 0) {
					const next = ascii.next();
					if (next.done) {
						offset = ascii.position;
						if (offset === text.length) break;
						native = this.#segmenter.segment(text.slice(offset))[Symbol.iterator]();
						ascii = void 0;
						continue;
					}
					segment = next.value.segment;
					end = next.value.index + segment.length;
				} else {
					const next = native.next();
					if (next.done) break;
					segment = next.value.segment;
					end = offset + next.value.index + segment.length;
				}
				state = require_runtime.advanceCompact(this.#nodes, state, segment);
				position++;
				if (this.#counts[state] === 0 && cursor > lastCandidateStart) continue;
				if (cursor > lastCandidateStart) cursor = Math.max(cursor, position - capacity);
				for (let output = this.#counts[state] === 0 ? -1 : state; output !== -1; output = this.#nodes.outputs[output]) {
					const terminal = this.#nodes.terminals[output];
					if (terminal === this.#nodes.terminals[output + 1]) continue;
					const patternIndex = this.#nodes.patterns[terminal];
					const pattern = this.#patterns[patternIndex];
					if (boundary && !boundary(end - pattern.pattern.length, end)) continue;
					const length = this.#lengths[patternIndex];
					const start = position - length;
					if (start < cursor || start > earliest && start < earliestEnd) continue;
					lastCandidateStart = Math.max(lastCandidateStart, start);
					const slot = start % capacity;
					const previous = candidates[slot];
					if (stamps[slot] !== start || (strategy === "leftmost-first" ? patternIndex < previous : length > this.#lengths[previous] || length === this.#lengths[previous] && patternIndex < previous)) {
						stamps[slot] = start;
						candidates[slot] = patternIndex;
						starts[slot] = end - pattern.pattern.length;
					}
					if (earliest === -1 || start < earliest) earliest = start;
					if (start === earliest) earliestEnd = start + this.#lengths[candidates[slot]];
					if (earliestEnd === position) break;
				}
				while (cursor <= position) {
					if (cursor > position - capacity && !(strategy === "leftmost-first" && earliest === cursor && candidates[cursor % capacity] === 0)) break;
					const slot = cursor % capacity;
					if (stamps[slot] === cursor) {
						const patternIndex = candidates[slot];
						const { pattern, data } = this.#patterns[patternIndex];
						const start = starts[slot];
						cursor += this.#lengths[patternIndex];
						earliest = -1;
						earliestEnd = -1;
						for (let next = cursor; next <= lastCandidateStart; next++) if (stamps[next % capacity] === next) {
							earliest = next;
							earliestEnd = next + this.#lengths[candidates[next % capacity]];
							break;
						}
						if (cursor === position) state = 0;
						yield {
							pattern,
							patternIndex,
							start,
							end: start + pattern.length,
							data
						};
					} else cursor++;
				}
			}
			while (cursor <= lastCandidateStart) {
				const slot = cursor % capacity;
				if (stamps[slot] === cursor) {
					const patternIndex = candidates[slot];
					const { pattern, data } = this.#patterns[patternIndex];
					const start = starts[slot];
					cursor += this.#lengths[patternIndex];
					yield {
						pattern,
						patternIndex,
						start,
						end: start + pattern.length,
						data
					};
				} else cursor++;
			}
		}
	};
	Object.defineProperty(exports, "AhoCorasick", {
		enumerable: true,
		get: function() {
			return AhoCorasick;
		}
	});
}));
//#endregion
//#region node_modules/modern-ahocorasick/dist/index.cjs
var require_dist$1 = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_src_Y0gayY8y().AhoCorasick;
}));
//#endregion
//#region node_modules/@vanilla-extract/css/adapter/dist/vanilla-extract-css-adapter.cjs.prod.js
var require_vanilla_extract_css_adapter_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var mockAdapter = {
		appendCss: () => {},
		registerClassName: () => {},
		onEndFileScope: () => {},
		registerComposition: () => {},
		markCompositionUsed: () => {},
		getIdentOption: () => "short"
	};
	var adapterStack = [mockAdapter];
	var currentAdapter = () => {
		if (adapterStack.length < 1) throw new Error("No adapter configured");
		return adapterStack[adapterStack.length - 1];
	};
	var hasConfiguredAdapter = false;
	var setAdapterIfNotSet = (newAdapter) => {
		if (!hasConfiguredAdapter) setAdapter(newAdapter);
	};
	var setAdapter = (newAdapter) => {
		if (!newAdapter) throw new Error("No adapter provided when calling \"setAdapter\"");
		hasConfiguredAdapter = true;
		adapterStack.push(newAdapter);
	};
	var removeAdapter = () => {
		adapterStack.pop();
	};
	var appendCss = function appendCss() {
		return currentAdapter().appendCss(...arguments);
	};
	var registerClassName = function registerClassName() {
		return currentAdapter().registerClassName(...arguments);
	};
	var registerComposition = function registerComposition() {
		return currentAdapter().registerComposition(...arguments);
	};
	var markCompositionUsed = function markCompositionUsed() {
		return currentAdapter().markCompositionUsed(...arguments);
	};
	var onBeginFileScope = function onBeginFileScope() {
		var _currentAdapter$onBeg, _currentAdapter;
		for (var _len = arguments.length, props = new Array(_len), _key = 0; _key < _len; _key++) props[_key] = arguments[_key];
		return (_currentAdapter$onBeg = (_currentAdapter = currentAdapter()).onBeginFileScope) === null || _currentAdapter$onBeg === void 0 ? void 0 : _currentAdapter$onBeg.call(_currentAdapter, ...props);
	};
	var onEndFileScope = function onEndFileScope() {
		return currentAdapter().onEndFileScope(...arguments);
	};
	var getIdentOption = function getIdentOption() {
		var adapter = currentAdapter();
		if (!("getIdentOption" in adapter)) return "short";
		return adapter.getIdentOption(...arguments);
	};
	exports.appendCss = appendCss;
	exports.getIdentOption = getIdentOption;
	exports.markCompositionUsed = markCompositionUsed;
	exports.mockAdapter = mockAdapter;
	exports.onBeginFileScope = onBeginFileScope;
	exports.onEndFileScope = onEndFileScope;
	exports.registerClassName = registerClassName;
	exports.registerComposition = registerComposition;
	exports.removeAdapter = removeAdapter;
	exports.setAdapter = setAdapter;
	exports.setAdapterIfNotSet = setAdapterIfNotSet;
}));
//#endregion
//#region node_modules/@vanilla-extract/css/dist/taggedTemplateLiteral-0bfb2e96.cjs.prod.js
var require_taggedTemplateLiteral_0bfb2e96_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	function _taggedTemplateLiteral(strings, raw) {
		if (!raw) raw = strings.slice(0);
		return Object.freeze(Object.defineProperties(strings, { raw: { value: Object.freeze(raw) } }));
	}
	exports._taggedTemplateLiteral = _taggedTemplateLiteral;
}));
//#endregion
//#region node_modules/css-what/lib/es/types.js
var SelectorType, IgnoreCaseMode, AttributeAction;
var init_types = __esmMin((() => {
	(function(SelectorType) {
		SelectorType["Attribute"] = "attribute";
		SelectorType["Pseudo"] = "pseudo";
		SelectorType["PseudoElement"] = "pseudo-element";
		SelectorType["Tag"] = "tag";
		SelectorType["Universal"] = "universal";
		SelectorType["Adjacent"] = "adjacent";
		SelectorType["Child"] = "child";
		SelectorType["Descendant"] = "descendant";
		SelectorType["Parent"] = "parent";
		SelectorType["Sibling"] = "sibling";
		SelectorType["ColumnCombinator"] = "column-combinator";
	})(SelectorType || (SelectorType = {}));
	IgnoreCaseMode = {
		Unknown: null,
		QuirksMode: "quirks",
		IgnoreCase: true,
		CaseSensitive: false
	};
	(function(AttributeAction) {
		AttributeAction["Any"] = "any";
		AttributeAction["Element"] = "element";
		AttributeAction["End"] = "end";
		AttributeAction["Equals"] = "equals";
		AttributeAction["Exists"] = "exists";
		AttributeAction["Hyphen"] = "hyphen";
		AttributeAction["Not"] = "not";
		AttributeAction["Start"] = "start";
	})(AttributeAction || (AttributeAction = {}));
}));
//#endregion
//#region node_modules/css-what/lib/es/parse.js
/**
* Checks whether a specific selector is a traversal.
* This is useful eg. in swapping the order of elements that
* are not traversals.
*
* @param selector Selector to check.
*/
function isTraversal(selector) {
	switch (selector.type) {
		case SelectorType.Adjacent:
		case SelectorType.Child:
		case SelectorType.Descendant:
		case SelectorType.Parent:
		case SelectorType.Sibling:
		case SelectorType.ColumnCombinator: return true;
		default: return false;
	}
}
function funescape(_, escaped, escapedWhitespace) {
	const high = parseInt(escaped, 16) - 65536;
	return high !== high || escapedWhitespace ? escaped : high < 0 ? String.fromCharCode(high + 65536) : String.fromCharCode(high >> 10 | 55296, high & 1023 | 56320);
}
function unescapeCSS(str) {
	return str.replace(reEscape, funescape);
}
function isQuote(c) {
	return c === 39 || c === 34;
}
function isWhitespace(c) {
	return c === 32 || c === 9 || c === 10 || c === 12 || c === 13;
}
/**
* Parses `selector`, optionally with the passed `options`.
*
* @param selector Selector to parse.
* @param options Options for parsing.
* @returns Returns a two-dimensional array.
* The first dimension represents selectors separated by commas (eg. `sub1, sub2`),
* the second contains the relevant tokens for that selector.
*/
function parse(selector) {
	const subselects = [];
	const endIndex = parseSelector(subselects, `${selector}`, 0);
	if (endIndex < selector.length) throw new Error(`Unmatched selector: ${selector.slice(endIndex)}`);
	return subselects;
}
function parseSelector(subselects, selector, selectorIndex) {
	let tokens = [];
	function getName(offset) {
		const match = selector.slice(selectorIndex + offset).match(reName);
		if (!match) throw new Error(`Expected name, found ${selector.slice(selectorIndex)}`);
		const [name] = match;
		selectorIndex += offset + name.length;
		return unescapeCSS(name);
	}
	function stripWhitespace(offset) {
		selectorIndex += offset;
		while (selectorIndex < selector.length && isWhitespace(selector.charCodeAt(selectorIndex))) selectorIndex++;
	}
	function readValueWithParenthesis() {
		selectorIndex += 1;
		const start = selectorIndex;
		let counter = 1;
		for (; counter > 0 && selectorIndex < selector.length; selectorIndex++) if (selector.charCodeAt(selectorIndex) === 40 && !isEscaped(selectorIndex)) counter++;
		else if (selector.charCodeAt(selectorIndex) === 41 && !isEscaped(selectorIndex)) counter--;
		if (counter) throw new Error("Parenthesis not matched");
		return unescapeCSS(selector.slice(start, selectorIndex - 1));
	}
	function isEscaped(pos) {
		let slashCount = 0;
		while (selector.charCodeAt(--pos) === 92) slashCount++;
		return (slashCount & 1) === 1;
	}
	function ensureNotTraversal() {
		if (tokens.length > 0 && isTraversal(tokens[tokens.length - 1])) throw new Error("Did not expect successive traversals.");
	}
	function addTraversal(type) {
		if (tokens.length > 0 && tokens[tokens.length - 1].type === SelectorType.Descendant) {
			tokens[tokens.length - 1].type = type;
			return;
		}
		ensureNotTraversal();
		tokens.push({ type });
	}
	function addSpecialAttribute(name, action) {
		tokens.push({
			type: SelectorType.Attribute,
			name,
			action,
			value: getName(1),
			namespace: null,
			ignoreCase: "quirks"
		});
	}
	/**
	* We have finished parsing the current part of the selector.
	*
	* Remove descendant tokens at the end if they exist,
	* and return the last index, so that parsing can be
	* picked up from here.
	*/
	function finalizeSubselector() {
		if (tokens.length && tokens[tokens.length - 1].type === SelectorType.Descendant) tokens.pop();
		if (tokens.length === 0) throw new Error("Empty sub-selector");
		subselects.push(tokens);
	}
	stripWhitespace(0);
	if (selector.length === selectorIndex) return selectorIndex;
	loop: while (selectorIndex < selector.length) {
		const firstChar = selector.charCodeAt(selectorIndex);
		switch (firstChar) {
			case 32:
			case 9:
			case 10:
			case 12:
			case 13:
				if (tokens.length === 0 || tokens[0].type !== SelectorType.Descendant) {
					ensureNotTraversal();
					tokens.push({ type: SelectorType.Descendant });
				}
				stripWhitespace(1);
				break;
			case 62:
				addTraversal(SelectorType.Child);
				stripWhitespace(1);
				break;
			case 60:
				addTraversal(SelectorType.Parent);
				stripWhitespace(1);
				break;
			case 126:
				addTraversal(SelectorType.Sibling);
				stripWhitespace(1);
				break;
			case 43:
				addTraversal(SelectorType.Adjacent);
				stripWhitespace(1);
				break;
			case 46:
				addSpecialAttribute("class", AttributeAction.Element);
				break;
			case 35:
				addSpecialAttribute("id", AttributeAction.Equals);
				break;
			case 91: {
				stripWhitespace(1);
				let name;
				let namespace = null;
				if (selector.charCodeAt(selectorIndex) === 124) name = getName(1);
				else if (selector.startsWith("*|", selectorIndex)) {
					namespace = "*";
					name = getName(2);
				} else {
					name = getName(0);
					if (selector.charCodeAt(selectorIndex) === 124 && selector.charCodeAt(selectorIndex + 1) !== 61) {
						namespace = name;
						name = getName(1);
					}
				}
				stripWhitespace(0);
				let action = AttributeAction.Exists;
				const possibleAction = actionTypes.get(selector.charCodeAt(selectorIndex));
				if (possibleAction) {
					action = possibleAction;
					if (selector.charCodeAt(selectorIndex + 1) !== 61) throw new Error("Expected `=`");
					stripWhitespace(2);
				} else if (selector.charCodeAt(selectorIndex) === 61) {
					action = AttributeAction.Equals;
					stripWhitespace(1);
				}
				let value = "";
				let ignoreCase = null;
				if (action !== "exists") {
					if (isQuote(selector.charCodeAt(selectorIndex))) {
						const quote = selector.charCodeAt(selectorIndex);
						let sectionEnd = selectorIndex + 1;
						while (sectionEnd < selector.length && (selector.charCodeAt(sectionEnd) !== quote || isEscaped(sectionEnd))) sectionEnd += 1;
						if (selector.charCodeAt(sectionEnd) !== quote) throw new Error("Attribute value didn't end");
						value = unescapeCSS(selector.slice(selectorIndex + 1, sectionEnd));
						selectorIndex = sectionEnd + 1;
					} else {
						const valueStart = selectorIndex;
						while (selectorIndex < selector.length && (!isWhitespace(selector.charCodeAt(selectorIndex)) && selector.charCodeAt(selectorIndex) !== 93 || isEscaped(selectorIndex))) selectorIndex += 1;
						value = unescapeCSS(selector.slice(valueStart, selectorIndex));
					}
					stripWhitespace(0);
					const forceIgnore = selector.charCodeAt(selectorIndex) | 32;
					if (forceIgnore === 115) {
						ignoreCase = false;
						stripWhitespace(1);
					} else if (forceIgnore === 105) {
						ignoreCase = true;
						stripWhitespace(1);
					}
				}
				if (selector.charCodeAt(selectorIndex) !== 93) throw new Error("Attribute selector didn't terminate");
				selectorIndex += 1;
				const attributeSelector = {
					type: SelectorType.Attribute,
					name,
					action,
					value,
					namespace,
					ignoreCase
				};
				tokens.push(attributeSelector);
				break;
			}
			case 58: {
				if (selector.charCodeAt(selectorIndex + 1) === 58) {
					tokens.push({
						type: SelectorType.PseudoElement,
						name: getName(2).toLowerCase(),
						data: selector.charCodeAt(selectorIndex) === 40 ? readValueWithParenthesis() : null
					});
					continue;
				}
				const name = getName(1).toLowerCase();
				let data = null;
				if (selector.charCodeAt(selectorIndex) === 40) {
					if (unpackPseudos.has(name)) {
						if (isQuote(selector.charCodeAt(selectorIndex + 1))) throw new Error(`Pseudo-selector ${name} cannot be quoted`);
						data = [];
						selectorIndex = parseSelector(data, selector, selectorIndex + 1);
						if (selector.charCodeAt(selectorIndex) !== 41) throw new Error(`Missing closing parenthesis in :${name} (${selector})`);
						selectorIndex += 1;
					} else {
						data = readValueWithParenthesis();
						if (stripQuotesFromPseudos.has(name)) {
							const quot = data.charCodeAt(0);
							if (quot === data.charCodeAt(data.length - 1) && isQuote(quot)) data = data.slice(1, -1);
						}
						data = unescapeCSS(data);
					}
				}
				tokens.push({
					type: SelectorType.Pseudo,
					name,
					data
				});
				break;
			}
			case 44:
				finalizeSubselector();
				tokens = [];
				stripWhitespace(1);
				break;
			default: {
				if (selector.startsWith("/*", selectorIndex)) {
					const endIndex = selector.indexOf("*/", selectorIndex + 2);
					if (endIndex < 0) throw new Error("Comment was not terminated");
					selectorIndex = endIndex + 2;
					if (tokens.length === 0) stripWhitespace(0);
					break;
				}
				let namespace = null;
				let name;
				if (firstChar === 42) {
					selectorIndex += 1;
					name = "*";
				} else if (firstChar === 124) {
					name = "";
					if (selector.charCodeAt(selectorIndex + 1) === 124) {
						addTraversal(SelectorType.ColumnCombinator);
						stripWhitespace(2);
						break;
					}
				} else if (reName.test(selector.slice(selectorIndex))) name = getName(0);
				else break loop;
				if (selector.charCodeAt(selectorIndex) === 124 && selector.charCodeAt(selectorIndex + 1) !== 124) {
					namespace = name;
					if (selector.charCodeAt(selectorIndex + 1) === 42) {
						name = "*";
						selectorIndex += 2;
					} else name = getName(1);
				}
				tokens.push(name === "*" ? {
					type: SelectorType.Universal,
					namespace
				} : {
					type: SelectorType.Tag,
					name,
					namespace
				});
			}
		}
	}
	finalizeSubselector();
	return selectorIndex;
}
var reName, reEscape, actionTypes, unpackPseudos, stripQuotesFromPseudos;
var init_parse = __esmMin((() => {
	init_types();
	reName = /^[^\\#]?(?:\\(?:[\da-f]{1,6}\s?|.)|[\w\-\u00b0-\uFFFF])+/;
	reEscape = /\\([\da-f]{1,6}\s?|(\s)|.)/gi;
	actionTypes = /* @__PURE__ */ new Map([
		[126, AttributeAction.Element],
		[94, AttributeAction.Start],
		[36, AttributeAction.End],
		[42, AttributeAction.Any],
		[33, AttributeAction.Not],
		[124, AttributeAction.Hyphen]
	]);
	unpackPseudos = /* @__PURE__ */ new Set([
		"has",
		"not",
		"matches",
		"is",
		"where",
		"host",
		"host-context"
	]);
	stripQuotesFromPseudos = /* @__PURE__ */ new Set(["contains", "icontains"]);
}));
//#endregion
//#region node_modules/css-what/lib/es/stringify.js
/**
* Turns `selector` back into a string.
*
* @param selector Selector to stringify.
*/
function stringify(selector) {
	return selector.map((token) => token.map(stringifyToken).join("")).join(", ");
}
function stringifyToken(token, index, arr) {
	switch (token.type) {
		case SelectorType.Child: return index === 0 ? "> " : " > ";
		case SelectorType.Parent: return index === 0 ? "< " : " < ";
		case SelectorType.Sibling: return index === 0 ? "~ " : " ~ ";
		case SelectorType.Adjacent: return index === 0 ? "+ " : " + ";
		case SelectorType.Descendant: return " ";
		case SelectorType.ColumnCombinator: return index === 0 ? "|| " : " || ";
		case SelectorType.Universal: return token.namespace === "*" && index + 1 < arr.length && "name" in arr[index + 1] ? "" : `${getNamespace(token.namespace)}*`;
		case SelectorType.Tag: return getNamespacedName(token);
		case SelectorType.PseudoElement: return `::${escapeName(token.name, charsToEscapeInName)}${token.data === null ? "" : `(${escapeName(token.data, charsToEscapeInPseudoValue)})`}`;
		case SelectorType.Pseudo: return `:${escapeName(token.name, charsToEscapeInName)}${token.data === null ? "" : `(${typeof token.data === "string" ? escapeName(token.data, charsToEscapeInPseudoValue) : stringify(token.data)})`}`;
		case SelectorType.Attribute: {
			if (token.name === "id" && token.action === AttributeAction.Equals && token.ignoreCase === "quirks" && !token.namespace) return `#${escapeName(token.value, charsToEscapeInName)}`;
			if (token.name === "class" && token.action === AttributeAction.Element && token.ignoreCase === "quirks" && !token.namespace) return `.${escapeName(token.value, charsToEscapeInName)}`;
			const name = getNamespacedName(token);
			if (token.action === AttributeAction.Exists) return `[${name}]`;
			return `[${name}${getActionValue(token.action)}="${escapeName(token.value, charsToEscapeInAttributeValue)}"${token.ignoreCase === null ? "" : token.ignoreCase ? " i" : " s"}]`;
		}
	}
}
function getActionValue(action) {
	switch (action) {
		case AttributeAction.Equals: return "";
		case AttributeAction.Element: return "~";
		case AttributeAction.Start: return "^";
		case AttributeAction.End: return "$";
		case AttributeAction.Any: return "*";
		case AttributeAction.Not: return "!";
		case AttributeAction.Hyphen: return "|";
		case AttributeAction.Exists: throw new Error("Shouldn't be here");
	}
}
function getNamespacedName(token) {
	return `${getNamespace(token.namespace)}${escapeName(token.name, charsToEscapeInName)}`;
}
function getNamespace(namespace) {
	return namespace !== null ? `${namespace === "*" ? "*" : escapeName(namespace, charsToEscapeInName)}|` : "";
}
function escapeName(str, charsToEscape) {
	let lastIdx = 0;
	let ret = "";
	for (let i = 0; i < str.length; i++) if (charsToEscape.has(str.charCodeAt(i))) {
		ret += `${str.slice(lastIdx, i)}\\${str.charAt(i)}`;
		lastIdx = i + 1;
	}
	return ret.length > 0 ? ret + str.slice(lastIdx) : str;
}
var attribValChars, pseudoValChars, charsToEscapeInAttributeValue, charsToEscapeInPseudoValue, charsToEscapeInName;
var init_stringify = __esmMin((() => {
	init_types();
	attribValChars = ["\\", "\""];
	pseudoValChars = [
		...attribValChars,
		"(",
		")"
	];
	charsToEscapeInAttributeValue = new Set(attribValChars.map((c) => c.charCodeAt(0)));
	charsToEscapeInPseudoValue = new Set(pseudoValChars.map((c) => c.charCodeAt(0)));
	charsToEscapeInName = new Set([
		...pseudoValChars,
		"~",
		"^",
		"$",
		"*",
		"+",
		"!",
		"|",
		":",
		"[",
		"]",
		" ",
		"."
	].map((c) => c.charCodeAt(0)));
}));
//#endregion
//#region node_modules/css-what/lib/es/index.js
var es_exports = /* @__PURE__ */ __exportAll({
	AttributeAction: () => AttributeAction,
	IgnoreCaseMode: () => IgnoreCaseMode,
	SelectorType: () => SelectorType,
	isTraversal: () => isTraversal,
	parse: () => parse,
	stringify: () => stringify
});
var init_es = __esmMin((() => {
	init_types();
	init_parse();
	init_stringify();
}));
//#endregion
//#region node_modules/dedent/dist/dedent.js
var require_dedent = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = void 0;
	exports.default = createDedent({});
	function createDedent(options) {
		dedent.withOptions = (newOptions) => createDedent({
			...options,
			...newOptions
		});
		return dedent;
		function dedent(strings, ...values) {
			const raw = typeof strings === "string" ? [strings] : strings.raw;
			const { alignValues = false, escapeSpecialCharacters = Array.isArray(strings), trimWhitespace = true } = options;
			let result = "";
			for (let i = 0; i < raw.length; i++) {
				let next = raw[i];
				if (escapeSpecialCharacters) next = next.replace(/\\\n[ \t]*/g, "").replace(/\\`/g, "`").replace(/\\\$/g, "$").replace(/\\\{/g, "{");
				result += next;
				if (i < values.length) {
					const value = alignValues ? alignValue(values[i], result) : values[i];
					result += value;
				}
			}
			const lines = result.split("\n");
			let mindent = null;
			for (const l of lines) {
				const m = l.match(/^(\s+)\S+/);
				if (m) {
					const indent = m[1].length;
					if (!mindent) mindent = indent;
					else mindent = Math.min(mindent, indent);
				}
			}
			if (mindent !== null) {
				const m = mindent;
				result = lines.map((l) => l[0] === " " || l[0] === "	" ? l.slice(m) : l).join("\n");
			}
			if (trimWhitespace) result = result.trim();
			if (escapeSpecialCharacters) result = result.replace(/\\n/g, "\n").replace(/\\t/g, "	").replace(/\\r/g, "\r").replace(/\\v/g, "\v").replace(/\\b/g, "\b").replace(/\\f/g, "\f").replace(/\\0/g, "\0").replace(/\\x([\da-fA-F]{2})/g, (_, h) => String.fromCharCode(parseInt(h, 16))).replace(/\\u\{([\da-fA-F]{1,6})\}/g, (_, h) => String.fromCodePoint(parseInt(h, 16))).replace(/\\u([\da-fA-F]{4})/g, (_, h) => String.fromCharCode(parseInt(h, 16)));
			if (typeof Bun !== "undefined") result = result.replace(/\\u(?:\{([\da-fA-F]{1,6})\}|([\da-fA-F]{4}))/g, (_, braced, unbraced) => {
				var _ref;
				const hex = (_ref = braced !== null && braced !== void 0 ? braced : unbraced) !== null && _ref !== void 0 ? _ref : "";
				return String.fromCodePoint(parseInt(hex, 16));
			});
			return result;
		}
	}
	/**
	* Adjusts the indentation of a multi-line interpolated value to match the current line.
	*/
	function alignValue(value, precedingText) {
		if (typeof value !== "string" || !value.includes("\n")) return value;
		const indentMatch = precedingText.slice(precedingText.lastIndexOf("\n") + 1).match(/^(\s+)/);
		if (indentMatch) {
			const indent = indentMatch[1];
			return value.replace(/\n/g, `\n${indent}`);
		}
		return value;
	}
	module.exports = exports.default;
	module.exports.default = exports.default;
}));
//#endregion
//#region node_modules/media-query-parser/dist/media-query-parser.esm.js
var media_query_parser_esm_exports = /* @__PURE__ */ __exportAll({
	consumeEscape: () => consumeEscape,
	consumeIdent: () => consumeIdent,
	consumeIdentLike: () => consumeIdentLike,
	consumeIdentUnsafe: () => consumeIdentUnsafe,
	consumeNumber: () => consumeNumber,
	consumeNumeric: () => consumeNumeric,
	consumeString: () => consumeString,
	consumeUrl: () => consumeUrl,
	lexicalAnalysis: () => lexicalAnalysis,
	removeWhitespace: () => removeWhitespace,
	syntacticAnalysis: () => syntacticAnalysis,
	toAST: () => toAST,
	toUnflattenedAST: () => toUnflattenedAST,
	tokenizeMediaCondition: () => tokenizeMediaCondition,
	tokenizeMediaFeature: () => tokenizeMediaFeature,
	tokenizeMediaQuery: () => tokenizeMediaQuery,
	tokenizeRange: () => tokenizeRange,
	wouldStartIdentifier: () => wouldStartIdentifier
});
/*! @license MediaQueryParser - MIT License - Tom Golden (github@tbjgolden.com) */
/*! *****************************************************************************
Copyright (c) Microsoft Corporation.

Permission to use, copy, modify, and/or distribute this software for any
purpose with or without fee is hereby granted.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH
REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY
AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT,
INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM
LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR
OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR
PERFORMANCE OF THIS SOFTWARE.
***************************************************************************** */
function __rest$1(s, e) {
	var t = {};
	for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0) t[p] = s[p];
	if (s != null && typeof Object.getOwnPropertySymbols === "function") {
		for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0 && Object.prototype.propertyIsEnumerable.call(s, p[i])) t[p[i]] = s[p[i]];
	}
	return t;
}
function __values(o) {
	var s = typeof Symbol === "function" && Symbol.iterator, m = s && o[s], i = 0;
	if (m) return m.call(o);
	if (o && typeof o.length === "number") return { next: function() {
		if (o && i >= o.length) o = void 0;
		return {
			value: o && o[i++],
			done: !o
		};
	} };
	throw new TypeError(s ? "Object is not iterable." : "Symbol.iterator is not defined.");
}
function __read(o, n) {
	var m = typeof Symbol === "function" && o[Symbol.iterator];
	if (!m) return o;
	var i = m.call(o), r, ar = [], e;
	try {
		while ((n === void 0 || n-- > 0) && !(r = i.next()).done) ar.push(r.value);
	} catch (error) {
		e = { error };
	} finally {
		try {
			if (r && !r.done && (m = i["return"])) m.call(i);
		} finally {
			if (e) throw e.error;
		}
	}
	return ar;
}
var __assign$1, weirdNewlines, nullOrSurrogates, commentRegex, lexicalAnalysis, consumeString, wouldStartIdentifier, consumeEscape, consumeNumeric, consumeNumber, consumeIdentUnsafe, consumeIdent, consumeUrl, consumeIdentLike, simplifyAST, simplifyMediaQuery, simplifyMediaCondition, createError, toAST, toUnflattenedAST, removeWhitespace, syntacticAnalysis, tokenizeMediaQuery, tokenizeMediaCondition, tokenizeMediaFeature, tokenizeRange;
var init_media_query_parser_esm = __esmMin((() => {
	__assign$1 = function() {
		__assign$1 = Object.assign || function __assign(t) {
			for (var s, i = 1, n = arguments.length; i < n; i++) {
				s = arguments[i];
				for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p)) t[p] = s[p];
			}
			return t;
		};
		return __assign$1.apply(this, arguments);
	};
	weirdNewlines = /(\u000D|\u000C|\u000D\u000A)/g;
	nullOrSurrogates = /[\u0000\uD800-\uDFFF]/g;
	commentRegex = /(\/\*)[\s\S]*?(\*\/)/g;
	lexicalAnalysis = function lexicalAnalysis(str, index) {
		if (index === void 0) index = 0;
		str = str.replace(weirdNewlines, "\n").replace(nullOrSurrogates, "�");
		str = str.replace(commentRegex, "");
		var tokens = [];
		for (; index < str.length; index += 1) {
			var code = str.charCodeAt(index);
			if (code === 9 || code === 32 || code === 10) {
				var code_1 = str.charCodeAt(++index);
				while (code_1 === 9 || code_1 === 32 || code_1 === 10) code_1 = str.charCodeAt(++index);
				index -= 1;
				tokens.push({ type: "<whitespace-token>" });
			} else if (code === 34) {
				var result = consumeString(str, index);
				if (result === null) return null;
				var _a = __read(result, 2), lastIndex = _a[0], value = _a[1];
				tokens.push({
					type: "<string-token>",
					value
				});
				index = lastIndex;
			} else if (code === 35) {
				if (index + 1 < str.length) {
					var nextCode = str.charCodeAt(index + 1);
					if (nextCode === 95 || nextCode >= 65 && nextCode <= 90 || nextCode >= 97 && nextCode <= 122 || nextCode >= 128 || nextCode >= 48 && nextCode <= 57 || nextCode === 92 && index + 2 < str.length && str.charCodeAt(index + 2) !== 10) {
						var flag = wouldStartIdentifier(str, index + 1) ? "id" : "unrestricted";
						var result = consumeIdentUnsafe(str, index + 1);
						if (result !== null) {
							var _b = __read(result, 2), lastIndex = _b[0], value = _b[1];
							tokens.push({
								type: "<hash-token>",
								value: value.toLowerCase(),
								flag
							});
							index = lastIndex;
							continue;
						}
					}
				}
				tokens.push({
					type: "<delim-token>",
					value: code
				});
			} else if (code === 39) {
				var result = consumeString(str, index);
				if (result === null) return null;
				var _c = __read(result, 2), lastIndex = _c[0], value = _c[1];
				tokens.push({
					type: "<string-token>",
					value
				});
				index = lastIndex;
			} else if (code === 40) tokens.push({ type: "<(-token>" });
			else if (code === 41) tokens.push({ type: "<)-token>" });
			else if (code === 43) {
				var plusNumeric = consumeNumeric(str, index);
				if (plusNumeric === null) tokens.push({
					type: "<delim-token>",
					value: code
				});
				else {
					var _d = __read(plusNumeric, 2), lastIndex = _d[0], tokenTuple = _d[1];
					if (tokenTuple[0] === "<dimension-token>") tokens.push({
						type: "<dimension-token>",
						value: tokenTuple[1],
						unit: tokenTuple[2].toLowerCase(),
						flag: "number"
					});
					else if (tokenTuple[0] === "<number-token>") tokens.push({
						type: tokenTuple[0],
						value: tokenTuple[1],
						flag: tokenTuple[2]
					});
					else tokens.push({
						type: tokenTuple[0],
						value: tokenTuple[1],
						flag: "number"
					});
					index = lastIndex;
				}
			} else if (code === 44) tokens.push({ type: "<comma-token>" });
			else if (code === 45) {
				var minusNumeric = consumeNumeric(str, index);
				if (minusNumeric !== null) {
					var _e = __read(minusNumeric, 2), lastIndex = _e[0], tokenTuple = _e[1];
					if (tokenTuple[0] === "<dimension-token>") tokens.push({
						type: "<dimension-token>",
						value: tokenTuple[1],
						unit: tokenTuple[2].toLowerCase(),
						flag: "number"
					});
					else if (tokenTuple[0] === "<number-token>") tokens.push({
						type: tokenTuple[0],
						value: tokenTuple[1],
						flag: tokenTuple[2]
					});
					else tokens.push({
						type: tokenTuple[0],
						value: tokenTuple[1],
						flag: "number"
					});
					index = lastIndex;
					continue;
				}
				if (index + 2 < str.length) {
					var nextCode = str.charCodeAt(index + 1);
					var nextNextCode = str.charCodeAt(index + 2);
					if (nextCode === 45 && nextNextCode === 62) {
						tokens.push({ type: "<CDC-token>" });
						index += 2;
						continue;
					}
				}
				var result = consumeIdentLike(str, index);
				if (result !== null) {
					var _f = __read(result, 3), lastIndex = _f[0], value = _f[1], type = _f[2];
					tokens.push({
						type,
						value
					});
					index = lastIndex;
					continue;
				}
				tokens.push({
					type: "<delim-token>",
					value: code
				});
			} else if (code === 46) {
				var minusNumeric = consumeNumeric(str, index);
				if (minusNumeric === null) tokens.push({
					type: "<delim-token>",
					value: code
				});
				else {
					var _g = __read(minusNumeric, 2), lastIndex = _g[0], tokenTuple = _g[1];
					if (tokenTuple[0] === "<dimension-token>") tokens.push({
						type: "<dimension-token>",
						value: tokenTuple[1],
						unit: tokenTuple[2].toLowerCase(),
						flag: "number"
					});
					else if (tokenTuple[0] === "<number-token>") tokens.push({
						type: tokenTuple[0],
						value: tokenTuple[1],
						flag: tokenTuple[2]
					});
					else tokens.push({
						type: tokenTuple[0],
						value: tokenTuple[1],
						flag: "number"
					});
					index = lastIndex;
					continue;
				}
			} else if (code === 58) tokens.push({ type: "<colon-token>" });
			else if (code === 59) tokens.push({ type: "<semicolon-token>" });
			else if (code === 60) {
				if (index + 3 < str.length) {
					var nextCode = str.charCodeAt(index + 1);
					var nextNextCode = str.charCodeAt(index + 2);
					var nextNextNextCode = str.charCodeAt(index + 3);
					if (nextCode === 33 && nextNextCode === 45 && nextNextNextCode === 45) {
						tokens.push({ type: "<CDO-token>" });
						index += 3;
						continue;
					}
				}
				tokens.push({
					type: "<delim-token>",
					value: code
				});
			} else if (code === 64) {
				var result = consumeIdent(str, index + 1);
				if (result !== null) {
					var _h = __read(result, 2), lastIndex = _h[0], value = _h[1];
					tokens.push({
						type: "<at-keyword-token>",
						value: value.toLowerCase()
					});
					index = lastIndex;
					continue;
				}
				tokens.push({
					type: "<delim-token>",
					value: code
				});
			} else if (code === 91) tokens.push({ type: "<[-token>" });
			else if (code === 92) {
				var result = consumeEscape(str, index);
				if (result === null) return null;
				var _j = __read(result, 2), lastIndex = _j[0], value = _j[1];
				str = str.slice(0, index) + value + str.slice(lastIndex + 1);
				index -= 1;
			} else if (code === 93) tokens.push({ type: "<]-token>" });
			else if (code === 123) tokens.push({ type: "<{-token>" });
			else if (code === 125) tokens.push({ type: "<}-token>" });
			else if (code >= 48 && code <= 57) {
				var result = consumeNumeric(str, index);
				var _k = __read(result, 2), lastIndex = _k[0], tokenTuple = _k[1];
				if (tokenTuple[0] === "<dimension-token>") tokens.push({
					type: "<dimension-token>",
					value: tokenTuple[1],
					unit: tokenTuple[2].toLowerCase(),
					flag: "number"
				});
				else if (tokenTuple[0] === "<number-token>") tokens.push({
					type: tokenTuple[0],
					value: tokenTuple[1],
					flag: tokenTuple[2]
				});
				else tokens.push({
					type: tokenTuple[0],
					value: tokenTuple[1],
					flag: "number"
				});
				index = lastIndex;
			} else if (code === 95 || code >= 65 && code <= 90 || code >= 97 && code <= 122 || code >= 128) {
				var result = consumeIdentLike(str, index);
				if (result === null) return null;
				var _l = __read(result, 3), lastIndex = _l[0], value = _l[1], type = _l[2];
				tokens.push({
					type,
					value
				});
				index = lastIndex;
			} else tokens.push({
				type: "<delim-token>",
				value: code
			});
		}
		tokens.push({ type: "<EOF-token>" });
		return tokens;
	};
	consumeString = function consumeString(str, index) {
		if (str.length <= index + 1) return null;
		var firstCode = str.charCodeAt(index);
		var charCodes = [];
		for (var i = index + 1; i < str.length; i += 1) {
			var code = str.charCodeAt(i);
			if (code === firstCode) return [i, String.fromCharCode.apply(null, charCodes)];
			else if (code === 92) {
				var result = consumeEscape(str, i);
				if (result === null) return null;
				var _a = __read(result, 2), lastIndex = _a[0], charCode = _a[1];
				charCodes.push(charCode);
				i = lastIndex;
			} else if (code === 10) return null;
			else charCodes.push(code);
		}
		return null;
	};
	wouldStartIdentifier = function wouldStartIdentifier(str, index) {
		if (str.length <= index) return false;
		var code = str.charCodeAt(index);
		if (code === 45) {
			if (str.length <= index + 1) return false;
			var nextCode = str.charCodeAt(index + 1);
			if (nextCode === 45 || nextCode === 95 || nextCode >= 65 && nextCode <= 90 || nextCode >= 97 && nextCode <= 122 || nextCode >= 128) return true;
			else if (nextCode === 92) {
				if (str.length <= index + 2) return false;
				return str.charCodeAt(index + 2) !== 10;
			} else return false;
		} else if (code === 95 || code >= 65 && code <= 90 || code >= 97 && code <= 122 || code >= 128) return true;
		else if (code === 92) {
			if (str.length <= index + 1) return false;
			var nextCode = str.charCodeAt(index + 1);
			return nextCode !== 10;
		} else return false;
	};
	consumeEscape = function consumeEscape(str, index) {
		if (str.length <= index + 1) return null;
		if (str.charCodeAt(index) !== 92) return null;
		var code = str.charCodeAt(index + 1);
		if (code === 10) return null;
		else if (code >= 48 && code <= 57 || code >= 65 && code <= 70 || code >= 97 && code <= 102) {
			var hexCharCodes = [code];
			var min = Math.min(index + 7, str.length);
			var i = index + 2;
			for (; i < min; i += 1) {
				var code_2 = str.charCodeAt(i);
				if (code_2 >= 48 && code_2 <= 57 || code_2 >= 65 && code_2 <= 70 || code_2 >= 97 && code_2 <= 102) hexCharCodes.push(code_2);
				else break;
			}
			if (i < str.length) {
				var code_3 = str.charCodeAt(i);
				if (code_3 === 9 || code_3 === 32 || code_3 === 10) i += 1;
			}
			return [i - 1, parseInt(String.fromCharCode.apply(null, hexCharCodes), 16)];
		} else return [index + 1, code];
	};
	consumeNumeric = function consumeNumeric(str, index) {
		var numberResult = consumeNumber(str, index);
		if (numberResult === null) return null;
		var _a = __read(numberResult, 3), numberEndIndex = _a[0], numberValue = _a[1], numberFlag = _a[2];
		var identResult = consumeIdent(str, numberEndIndex + 1);
		if (identResult !== null) {
			var _b = __read(identResult, 2);
			return [_b[0], [
				"<dimension-token>",
				numberValue,
				_b[1]
			]];
		}
		if (numberEndIndex + 1 < str.length && str.charCodeAt(numberEndIndex + 1) === 37) return [numberEndIndex + 1, ["<percentage-token>", numberValue]];
		return [numberEndIndex, [
			"<number-token>",
			numberValue,
			numberFlag
		]];
	};
	consumeNumber = function consumeNumber(str, index) {
		if (str.length <= index) return null;
		var flag = "integer";
		var numberChars = [];
		var firstCode = str.charCodeAt(index);
		if (firstCode === 43 || firstCode === 45) {
			index += 1;
			if (firstCode === 45) numberChars.push(45);
		}
		while (index < str.length) {
			var code = str.charCodeAt(index);
			if (code >= 48 && code <= 57) {
				numberChars.push(code);
				index += 1;
			} else break;
		}
		if (index + 1 < str.length) {
			var nextCode = str.charCodeAt(index);
			var nextNextCode = str.charCodeAt(index + 1);
			if (nextCode === 46 && nextNextCode >= 48 && nextNextCode <= 57) {
				numberChars.push(nextCode, nextNextCode);
				flag = "number";
				index += 2;
				while (index < str.length) {
					var code = str.charCodeAt(index);
					if (code >= 48 && code <= 57) {
						numberChars.push(code);
						index += 1;
					} else break;
				}
			}
		}
		if (index + 1 < str.length) {
			var nextCode = str.charCodeAt(index);
			var nextNextCode = str.charCodeAt(index + 1);
			var nextNextNextCode = str.charCodeAt(index + 2);
			if (nextCode === 69 || nextCode === 101) {
				var nextNextIsDigit = nextNextCode >= 48 && nextNextCode <= 57;
				if (nextNextIsDigit || (nextNextCode === 43 || nextNextCode === 45) && nextNextNextCode >= 48 && nextNextNextCode <= 57) {
					flag = "number";
					if (nextNextIsDigit) {
						numberChars.push(69, nextNextCode);
						index += 2;
					} else if (nextNextCode === 45) {
						numberChars.push(69, 45, nextNextNextCode);
						index += 3;
					} else {
						numberChars.push(69, nextNextNextCode);
						index += 3;
					}
					while (index < str.length) {
						var code = str.charCodeAt(index);
						if (code >= 48 && code <= 57) {
							numberChars.push(code);
							index += 1;
						} else break;
					}
				}
			}
		}
		var numberString = String.fromCharCode.apply(null, numberChars);
		var value = flag === "number" ? parseFloat(numberString) : parseInt(numberString);
		if (value === -0) value = 0;
		return Number.isNaN(value) ? null : [
			index - 1,
			value,
			flag
		];
	};
	consumeIdentUnsafe = function consumeIdentUnsafe(str, index) {
		if (str.length <= index) return null;
		var identChars = [];
		for (var code = str.charCodeAt(index); index < str.length; code = str.charCodeAt(++index)) {
			if (code === 45 || code === 95 || code >= 65 && code <= 90 || code >= 97 && code <= 122 || code >= 128 || code >= 48 && code <= 57) {
				identChars.push(code);
				continue;
			} else {
				var result = consumeEscape(str, index);
				if (result !== null) {
					var _a = __read(result, 2), lastIndex = _a[0], code_4 = _a[1];
					identChars.push(code_4);
					index = lastIndex;
					continue;
				}
			}
			break;
		}
		return index === 0 ? null : [index - 1, String.fromCharCode.apply(null, identChars)];
	};
	consumeIdent = function consumeIdent(str, index) {
		if (str.length <= index || !wouldStartIdentifier(str, index)) return null;
		var identChars = [];
		for (var code = str.charCodeAt(index); index < str.length; code = str.charCodeAt(++index)) {
			if (code === 45 || code === 95 || code >= 65 && code <= 90 || code >= 97 && code <= 122 || code >= 128 || code >= 48 && code <= 57) {
				identChars.push(code);
				continue;
			} else {
				var result = consumeEscape(str, index);
				if (result !== null) {
					var _a = __read(result, 2), lastIndex = _a[0], code_5 = _a[1];
					identChars.push(code_5);
					index = lastIndex;
					continue;
				}
			}
			break;
		}
		return [index - 1, String.fromCharCode.apply(null, identChars)];
	};
	consumeUrl = function consumeUrl(str, index) {
		var code = str.charCodeAt(index);
		while (code === 9 || code === 32 || code === 10) code = str.charCodeAt(++index);
		var urlChars = [];
		var hasFinishedWord = false;
		while (index < str.length) {
			if (code === 41) return [index, String.fromCharCode.apply(null, urlChars)];
			else if (code === 34 || code === 39 || code === 40) return null;
			else if (code === 9 || code === 32 || code === 10) {
				if (!hasFinishedWord && urlChars.length !== 0) hasFinishedWord = true;
			} else if (code === 92) {
				var result = consumeEscape(str, index);
				if (result === null || hasFinishedWord) return null;
				var _a = __read(result, 2), lastIndex = _a[0], value = _a[1];
				urlChars.push(value);
				index = lastIndex;
			} else {
				if (hasFinishedWord) return null;
				urlChars.push(code);
			}
			code = str.charCodeAt(++index);
		}
		return null;
	};
	consumeIdentLike = function consumeIdentLike(str, index) {
		var result = consumeIdent(str, index);
		if (result === null) return null;
		var _a = __read(result, 2), lastIndex = _a[0], value = _a[1];
		if (value.toLowerCase() === "url") {
			if (str.length > lastIndex + 1) {
				var nextCode = str.charCodeAt(lastIndex + 1);
				if (nextCode === 40) {
					for (var offset = 2; lastIndex + offset < str.length; offset += 1) {
						var nextNextCode = str.charCodeAt(lastIndex + offset);
						if (nextNextCode === 34 || nextNextCode === 39) return [
							lastIndex + 1,
							value.toLowerCase(),
							"<function-token>"
						];
						else if (nextNextCode !== 9 && nextNextCode !== 32 && nextNextCode !== 10) {
							var result_1 = consumeUrl(str, lastIndex + offset);
							if (result_1 === null) return null;
							var _b = __read(result_1, 2);
							return [
								_b[0],
								_b[1],
								"<url-token>"
							];
						}
					}
					return [
						lastIndex + 1,
						value.toLowerCase(),
						"<function-token>"
					];
				}
			}
		} else if (str.length > lastIndex + 1) {
			var nextCode = str.charCodeAt(lastIndex + 1);
			if (nextCode === 40) return [
				lastIndex + 1,
				value.toLowerCase(),
				"<function-token>"
			];
		}
		return [
			lastIndex,
			value.toLowerCase(),
			"<ident-token>"
		];
	};
	simplifyAST = function simplifyAST(ast) {
		for (var i = ast.length - 1; i >= 0; i--) ast[i] = simplifyMediaQuery(ast[i]);
		return ast;
	};
	simplifyMediaQuery = function simplifyMediaQuery(mediaQuery) {
		if (mediaQuery.mediaCondition === null) return mediaQuery;
		var mediaCondition = simplifyMediaCondition(mediaQuery.mediaCondition);
		if (mediaCondition.operator === null && mediaCondition.children.length === 1 && "children" in mediaCondition.children[0]) mediaCondition = mediaCondition.children[0];
		return {
			mediaPrefix: mediaQuery.mediaPrefix,
			mediaType: mediaQuery.mediaType,
			mediaCondition
		};
	};
	simplifyMediaCondition = function simplifyMediaCondition(mediaCondition) {
		for (var i = mediaCondition.children.length - 1; i >= 0; i--) {
			var unsimplifiedChild = mediaCondition.children[i];
			if (!("context" in unsimplifiedChild)) {
				var child = simplifyMediaCondition(unsimplifiedChild);
				if (child.operator === null && child.children.length === 1) mediaCondition.children[i] = child.children[0];
				else if (child.operator === mediaCondition.operator && (child.operator === "and" || child.operator === "or")) {
					var spliceArgs = [i, 1];
					for (var i_1 = 0; i_1 < child.children.length; i_1++) spliceArgs.push(child.children[i_1]);
					mediaCondition.children.splice.apply(mediaCondition.children, spliceArgs);
				}
			}
		}
		return mediaCondition;
	};
	createError = function createError(message, err) {
		if (err instanceof Error) return new Error("".concat(err.message.trim(), "\n").concat(message.trim()));
		else return new Error(message.trim());
	};
	toAST = function toAST(str) {
		return simplifyAST(toUnflattenedAST(str));
	};
	toUnflattenedAST = function toUnflattenedAST(str) {
		var tokenList = lexicalAnalysis(str.trim());
		if (tokenList === null) throw createError("Failed tokenizing");
		var startIndex = 0;
		var endIndex = tokenList.length - 1;
		if (tokenList[0].type === "<at-keyword-token>" && tokenList[0].value === "media") {
			if (tokenList[1].type !== "<whitespace-token>") throw createError("Expected whitespace after media");
			startIndex = 2;
			for (var i = 2; i < tokenList.length - 1; i++) {
				var token = tokenList[i];
				if (token.type === "<{-token>") {
					endIndex = i;
					break;
				} else if (token.type === "<semicolon-token>") throw createError("Expected '{' in media query but found ';'");
			}
		}
		tokenList = tokenList.slice(startIndex, endIndex);
		return syntacticAnalysis(tokenList);
	};
	removeWhitespace = function removeWhitespace(tokenList) {
		var newTokenList = [];
		var before = false;
		for (var i = 0; i < tokenList.length; i++) if (tokenList[i].type === "<whitespace-token>") {
			before = true;
			if (newTokenList.length > 0) newTokenList[newTokenList.length - 1].wsAfter = true;
		} else {
			newTokenList.push(__assign$1(__assign$1({}, tokenList[i]), {
				wsBefore: before,
				wsAfter: false
			}));
			before = false;
		}
		return newTokenList;
	};
	syntacticAnalysis = function syntacticAnalysis(tokenList) {
		var e_1, _a;
		var mediaQueryList = [[]];
		for (var i = 0; i < tokenList.length; i++) {
			var token = tokenList[i];
			if (token.type === "<comma-token>") mediaQueryList.push([]);
			else mediaQueryList[mediaQueryList.length - 1].push(token);
		}
		var mediaQueries = mediaQueryList.map(removeWhitespace);
		if (mediaQueries.length === 1 && mediaQueries[0].length === 0) return [{
			mediaCondition: null,
			mediaPrefix: null,
			mediaType: "all"
		}];
		else {
			var mediaQueryTokens = mediaQueries.map(function(mediaQueryTokens) {
				if (mediaQueryTokens.length === 0) return null;
				else return tokenizeMediaQuery(mediaQueryTokens);
			});
			var nonNullMediaQueryTokens = [];
			try {
				for (var mediaQueryTokens_1 = __values(mediaQueryTokens), mediaQueryTokens_1_1 = mediaQueryTokens_1.next(); !mediaQueryTokens_1_1.done; mediaQueryTokens_1_1 = mediaQueryTokens_1.next()) {
					var mediaQueryToken = mediaQueryTokens_1_1.value;
					if (mediaQueryToken !== null) nonNullMediaQueryTokens.push(mediaQueryToken);
				}
			} catch (e_1_1) {
				e_1 = { error: e_1_1 };
			} finally {
				try {
					if (mediaQueryTokens_1_1 && !mediaQueryTokens_1_1.done && (_a = mediaQueryTokens_1["return"])) _a.call(mediaQueryTokens_1);
				} finally {
					if (e_1) throw e_1.error;
				}
			}
			if (nonNullMediaQueryTokens.length === 0) throw createError("No valid media queries");
			return nonNullMediaQueryTokens;
		}
	};
	tokenizeMediaQuery = function tokenizeMediaQuery(tokens) {
		var firstToken = tokens[0];
		if (firstToken.type === "<(-token>") try {
			return {
				mediaPrefix: null,
				mediaType: "all",
				mediaCondition: tokenizeMediaCondition(tokens, true)
			};
		} catch (err) {
			throw createError("Expected media condition after '('", err);
		}
		else if (firstToken.type === "<ident-token>") {
			var mediaPrefix = null;
			var mediaType = void 0;
			var value = firstToken.value;
			if (value === "only" || value === "not") mediaPrefix = value;
			var firstIndex = mediaPrefix === null ? 0 : 1;
			if (tokens.length <= firstIndex) throw createError("Expected extra token in media query");
			var firstNonUnaryToken = tokens[firstIndex];
			if (firstNonUnaryToken.type === "<ident-token>") {
				var value_1 = firstNonUnaryToken.value;
				if (value_1 === "all") mediaType = "all";
				else if (value_1 === "print" || value_1 === "screen") mediaType = value_1;
				else if (value_1 === "tty" || value_1 === "tv" || value_1 === "projection" || value_1 === "handheld" || value_1 === "braille" || value_1 === "embossed" || value_1 === "aural" || value_1 === "speech") {
					mediaPrefix = mediaPrefix === "not" ? null : "not";
					mediaType = "all";
				} else throw createError("Unknown ident '".concat(value_1, "' in media query"));
			} else if (mediaPrefix === "not" && firstNonUnaryToken.type === "<(-token>") {
				var tokensWithParens = [{
					type: "<(-token>",
					wsBefore: false,
					wsAfter: false
				}];
				tokensWithParens.push.apply(tokensWithParens, tokens);
				tokensWithParens.push({
					type: "<)-token>",
					wsBefore: false,
					wsAfter: false
				});
				try {
					return {
						mediaPrefix: null,
						mediaType: "all",
						mediaCondition: tokenizeMediaCondition(tokensWithParens, true)
					};
				} catch (err) {
					throw createError("Expected media condition after '('", err);
				}
			} else throw createError("Invalid media query");
			if (firstIndex + 1 === tokens.length) return {
				mediaPrefix,
				mediaType,
				mediaCondition: null
			};
			else if (firstIndex + 4 < tokens.length) {
				var secondNonUnaryToken = tokens[firstIndex + 1];
				if (secondNonUnaryToken.type === "<ident-token>" && secondNonUnaryToken.value === "and") try {
					return {
						mediaPrefix,
						mediaType,
						mediaCondition: tokenizeMediaCondition(tokens.slice(firstIndex + 2), false)
					};
				} catch (err) {
					throw createError("Expected media condition after 'and'", err);
				}
				else throw createError("Expected 'and' after media prefix");
			} else throw createError("Expected media condition after media prefix");
		} else throw createError("Expected media condition or media prefix");
	};
	tokenizeMediaCondition = function tokenizeMediaCondition(tokens, mayContainOr, previousOperator) {
		if (previousOperator === void 0) previousOperator = null;
		if (tokens.length < 3 || tokens[0].type !== "<(-token>" || tokens[tokens.length - 1].type !== "<)-token>") throw new Error("Invalid media condition");
		var endIndexOfFirstFeature = tokens.length - 1;
		var maxDepth = 0;
		var count = 0;
		for (var i = 0; i < tokens.length; i++) {
			var token = tokens[i];
			if (token.type === "<(-token>") {
				count += 1;
				maxDepth = Math.max(maxDepth, count);
			} else if (token.type === "<)-token>") count -= 1;
			if (count === 0) {
				endIndexOfFirstFeature = i;
				break;
			}
		}
		if (count !== 0) throw new Error("Mismatched parens\nInvalid media condition");
		var child;
		var featureTokens = tokens.slice(0, endIndexOfFirstFeature + 1);
		if (maxDepth === 1) child = tokenizeMediaFeature(featureTokens);
		else if (featureTokens[1].type === "<ident-token>" && featureTokens[1].value === "not") child = tokenizeMediaCondition(featureTokens.slice(2, -1), true, "not");
		else child = tokenizeMediaCondition(featureTokens.slice(1, -1), true);
		if (endIndexOfFirstFeature === tokens.length - 1) return {
			operator: previousOperator,
			children: [child]
		};
		else {
			var nextToken = tokens[endIndexOfFirstFeature + 1];
			if (nextToken.type !== "<ident-token>") throw new Error("Invalid operator\nInvalid media condition");
			else if (previousOperator !== null && previousOperator !== nextToken.value) throw new Error("'".concat(nextToken.value, "' and '").concat(previousOperator, "' must not be at same level\nInvalid media condition"));
			else if (nextToken.value === "or" && !mayContainOr) throw new Error("Cannot use 'or' at top level of a media query\nInvalid media condition");
			else if (nextToken.value !== "and" && nextToken.value !== "or") throw new Error("Invalid operator: '".concat(nextToken.value, "'\nInvalid media condition"));
			var siblings = tokenizeMediaCondition(tokens.slice(endIndexOfFirstFeature + 2), mayContainOr, nextToken.value);
			return {
				operator: nextToken.value,
				children: [child].concat(siblings.children)
			};
		}
	};
	tokenizeMediaFeature = function tokenizeMediaFeature(rawTokens) {
		if (rawTokens.length < 3 || rawTokens[0].type !== "<(-token>" || rawTokens[rawTokens.length - 1].type !== "<)-token>") throw new Error("Invalid media feature");
		var tokens = [rawTokens[0]];
		for (var i = 1; i < rawTokens.length; i++) {
			if (i < rawTokens.length - 2) {
				var a = rawTokens[i];
				var b = rawTokens[i + 1];
				var c = rawTokens[i + 2];
				if (a.type === "<number-token>" && a.value > 0 && b.type === "<delim-token>" && b.value === 47 && c.type === "<number-token>" && c.value > 0) {
					tokens.push({
						type: "<ratio-token>",
						numerator: a.value,
						denominator: c.value,
						wsBefore: a.wsBefore,
						wsAfter: c.wsAfter
					});
					i += 2;
					continue;
				}
			}
			tokens.push(rawTokens[i]);
		}
		var nextToken = tokens[1];
		if (nextToken.type === "<ident-token>" && tokens.length === 3) return {
			context: "boolean",
			feature: nextToken.value
		};
		else if (tokens.length === 5 && tokens[1].type === "<ident-token>" && tokens[2].type === "<colon-token>") {
			var valueToken = tokens[3];
			if (valueToken.type === "<number-token>" || valueToken.type === "<dimension-token>" || valueToken.type === "<ratio-token>" || valueToken.type === "<ident-token>") {
				var feature = tokens[1].value;
				var prefix = null;
				var slice = feature.slice(0, 4);
				if (slice === "min-") {
					prefix = "min";
					feature = feature.slice(4);
				} else if (slice === "max-") {
					prefix = "max";
					feature = feature.slice(4);
				}
				valueToken.wsBefore;
				valueToken.wsAfter;
				var value = __rest$1(valueToken, ["wsBefore", "wsAfter"]);
				return {
					context: "value",
					prefix,
					feature,
					value
				};
			}
		} else if (tokens.length >= 5) try {
			var range = tokenizeRange(tokens);
			return {
				context: "range",
				feature: range.featureName,
				range
			};
		} catch (err) {
			throw createError("Invalid media feature", err);
		}
		throw new Error("Invalid media feature");
	};
	tokenizeRange = function tokenizeRange(tokens) {
		var _a, _b, _c, _d;
		if (tokens.length < 5 || tokens[0].type !== "<(-token>" || tokens[tokens.length - 1].type !== "<)-token>") throw new Error("Invalid range");
		var range = {
			leftToken: null,
			leftOp: null,
			featureName: "",
			rightOp: null,
			rightToken: null
		};
		var hasLeft = tokens[1].type === "<number-token>" || tokens[1].type === "<dimension-token>" || tokens[1].type === "<ratio-token>" || tokens[1].type === "<ident-token>" && tokens[1].value === "infinite";
		if (tokens[2].type === "<delim-token>") {
			if (tokens[2].value === 60) {
				if (tokens[3].type === "<delim-token>" && tokens[3].value === 61 && !tokens[3].wsBefore) range[hasLeft ? "leftOp" : "rightOp"] = "<=";
				else range[hasLeft ? "leftOp" : "rightOp"] = "<";
			} else if (tokens[2].value === 62) {
				if (tokens[3].type === "<delim-token>" && tokens[3].value === 61 && !tokens[3].wsBefore) range[hasLeft ? "leftOp" : "rightOp"] = ">=";
				else range[hasLeft ? "leftOp" : "rightOp"] = ">";
			} else if (tokens[2].value === 61) range[hasLeft ? "leftOp" : "rightOp"] = "=";
			else throw new Error("Invalid range");
			if (hasLeft) range.leftToken = tokens[1];
			else if (tokens[1].type === "<ident-token>") range.featureName = tokens[1].value;
			else throw new Error("Invalid range");
			var tokenIndexAfterFirstOp = 2 + ((_b = (_a = range[hasLeft ? "leftOp" : "rightOp"]) === null || _a === void 0 ? void 0 : _a.length) !== null && _b !== void 0 ? _b : 0);
			var tokenAfterFirstOp = tokens[tokenIndexAfterFirstOp];
			if (hasLeft) {
				if (tokenAfterFirstOp.type === "<ident-token>") {
					range.featureName = tokenAfterFirstOp.value;
					if (tokens.length >= 7) {
						var secondOpToken = tokens[tokenIndexAfterFirstOp + 1];
						var followingToken = tokens[tokenIndexAfterFirstOp + 2];
						if (secondOpToken.type === "<delim-token>") {
							var charCode = secondOpToken.value;
							if (charCode === 60) {
								if (followingToken.type === "<delim-token>" && followingToken.value === 61 && !followingToken.wsBefore) range.rightOp = "<=";
								else range.rightOp = "<";
							} else if (charCode === 62) {
								if (followingToken.type === "<delim-token>" && followingToken.value === 61 && !followingToken.wsBefore) range.rightOp = ">=";
								else range.rightOp = ">";
							} else throw new Error("Invalid range");
							range.rightToken = tokens[tokenIndexAfterFirstOp + 1 + ((_d = (_c = range.rightOp) === null || _c === void 0 ? void 0 : _c.length) !== null && _d !== void 0 ? _d : 0)];
						} else throw new Error("Invalid range");
					} else if (tokenIndexAfterFirstOp + 2 !== tokens.length) throw new Error("Invalid range");
				} else throw new Error("Invalid range");
			} else range.rightToken = tokenAfterFirstOp;
			var validRange = null;
			var lt = range.leftToken, leftOp = range.leftOp, featureName = range.featureName, rightOp = range.rightOp, rt = range.rightToken;
			var leftToken = null;
			if (lt !== null) {
				if (lt.type === "<ident-token>") {
					var type = lt.type, value = lt.value;
					if (value === "infinite") leftToken = {
						type,
						value
					};
				} else if (lt.type === "<number-token>" || lt.type === "<dimension-token>" || lt.type === "<ratio-token>") {
					lt.wsBefore;
					lt.wsAfter;
					leftToken = __rest$1(lt, ["wsBefore", "wsAfter"]);
				}
			}
			var rightToken = null;
			if (rt !== null) {
				if (rt.type === "<ident-token>") {
					var type = rt.type, value = rt.value;
					if (value === "infinite") rightToken = {
						type,
						value
					};
				} else if (rt.type === "<number-token>" || rt.type === "<dimension-token>" || rt.type === "<ratio-token>") {
					rt.wsBefore;
					rt.wsAfter;
					rightToken = __rest$1(rt, ["wsBefore", "wsAfter"]);
				}
			}
			if (leftToken !== null && rightToken !== null) {
				if ((leftOp === "<" || leftOp === "<=") && (rightOp === "<" || rightOp === "<=")) validRange = {
					leftToken,
					leftOp,
					featureName,
					rightOp,
					rightToken
				};
				else if ((leftOp === ">" || leftOp === ">=") && (rightOp === ">" || rightOp === ">=")) validRange = {
					leftToken,
					leftOp,
					featureName,
					rightOp,
					rightToken
				};
				else throw new Error("Invalid range");
			} else if (leftToken === null && leftOp === null && rightOp !== null && rightToken !== null) validRange = {
				leftToken,
				leftOp,
				featureName,
				rightOp,
				rightToken
			};
			else if (leftToken !== null && leftOp !== null && rightOp === null && rightToken === null) validRange = {
				leftToken,
				leftOp,
				featureName,
				rightOp,
				rightToken
			};
			return validRange;
		} else throw new Error("Invalid range");
	};
}));
//#endregion
//#region node_modules/@vanilla-extract/css/dist/transformCss-7fbca312.cjs.prod.js
var require_transformCss_7fbca312_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	var _private = __toCommonJS(vanilla_extract_private_esm_exports);
	var AhoCorasick = require_dist$1();
	var adapter_dist_vanillaExtractCssAdapter = require_vanilla_extract_css_adapter_cjs_prod();
	var taggedTemplateLiteral = require_taggedTemplateLiteral_0bfb2e96_cjs_prod();
	var cssWhat = (init_es(), __toCommonJS(es_exports));
	var dedent = require_dedent();
	var mediaQueryParser = (init_media_query_parser_esm(), __toCommonJS(media_query_parser_esm_exports));
	function _interopDefault(e) {
		return e && e.__esModule ? e : { "default": e };
	}
	var AhoCorasick__default = /*#__PURE__*/ _interopDefault(AhoCorasick);
	var dedent__default = /*#__PURE__*/ _interopDefault(dedent);
	function _objectWithoutPropertiesLoose(source, excluded) {
		if (source == null) return {};
		var target = {};
		var sourceKeys = Object.keys(source);
		var key, i = 0;
		for (; i < sourceKeys.length; i++) {
			key = sourceKeys[i];
			if (excluded.indexOf(key) >= 0) continue;
			target[key] = source[key];
		}
		return target;
	}
	function _objectWithoutProperties(source, excluded) {
		if (source == null) return {};
		var target = _objectWithoutPropertiesLoose(source, excluded);
		var key, i;
		if (Object.getOwnPropertySymbols) {
			var sourceSymbolKeys = Object.getOwnPropertySymbols(source);
			for (i = 0; i < sourceSymbolKeys.length; i++) {
				key = sourceSymbolKeys[i];
				if (excluded.indexOf(key) >= 0) continue;
				if (!Object.prototype.propertyIsEnumerable.call(source, key)) continue;
				target[key] = source[key];
			}
		}
		return target;
	}
	function toPrimitive(t, r) {
		if ("object" != typeof t || !t) return t;
		var e = t[Symbol.toPrimitive];
		if (void 0 !== e) {
			var i = e.call(t, r || "default");
			if ("object" != typeof i) return i;
			throw new TypeError("@@toPrimitive must return a primitive value.");
		}
		return ("string" === r ? String : Number)(t);
	}
	function toPropertyKey(t) {
		var i = toPrimitive(t, "string");
		return "symbol" == typeof i ? i : String(i);
	}
	function _defineProperty(obj, key, value) {
		key = toPropertyKey(key);
		if (key in obj) Object.defineProperty(obj, key, {
			value,
			enumerable: true,
			configurable: true,
			writable: true
		});
		else obj[key] = value;
		return obj;
	}
	function ownKeys(e, r) {
		var t = Object.keys(e);
		if (Object.getOwnPropertySymbols) {
			var o = Object.getOwnPropertySymbols(e);
			r && (o = o.filter(function(r) {
				return Object.getOwnPropertyDescriptor(e, r).enumerable;
			})), t.push.apply(t, o);
		}
		return t;
	}
	function _objectSpread2(e) {
		for (var r = 1; r < arguments.length; r++) {
			var t = null != arguments[r] ? arguments[r] : {};
			r % 2 ? ownKeys(Object(t), !0).forEach(function(r) {
				_defineProperty(e, r, t[r]);
			}) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(t)) : ownKeys(Object(t)).forEach(function(r) {
				Object.defineProperty(e, r, Object.getOwnPropertyDescriptor(t, r));
			});
		}
		return e;
	}
	/**
	* Matches an `&` that is not inside a quoted string. Used to substitute `&`
	* in `@scope` bounds with the enclosing rule's selector without touching
	* any `&` that appears inside an attribute-selector value such as `[title="a & b"]`.
	*
	* The lookbehind asserts that everything from the start of the string up to
	* the `&` is a sequence of either single non-quote characters or complete,
	* balanced single-/double-quoted strings (supporting backslash escapes).
	*
	* Each non-quote branch matches a single character (`[^"']`) rather than a run
	* (`[^"']*`). Nesting a quantifier inside the outer `*` would make the
	* lookbehind backtrack exponentially on input containing an unbalanced quote
	* (catastrophic backtracking / ReDoS).
	*/
	var nestingSelectorRegex = /(?<=^(?:[^"']|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*')*)&/g;
	function forEach(obj, fn) {
		for (var _key in obj) fn(obj[_key], _key);
	}
	function omit(obj, omitKeys) {
		var result = {};
		for (var _key2 in obj) if (omitKeys.indexOf(_key2) === -1) result[_key2] = obj[_key2];
		return result;
	}
	function mapKeys(obj, fn) {
		var result = {};
		for (var _key3 in obj) result[fn(obj[_key3], _key3)] = obj[_key3];
		return result;
	}
	function composeStylesIntoSet(set) {
		for (var _len = arguments.length, classNames = new Array(_len > 1 ? _len - 1 : 0), _key5 = 1; _key5 < _len; _key5++) classNames[_key5 - 1] = arguments[_key5];
		for (var className of classNames) {
			if (className.length === 0) continue;
			if (typeof className === "string") {
				if (className.includes(" ")) composeStylesIntoSet(set, ...className.trim().split(" "));
				else set.add(className);
			} else if (Array.isArray(className)) composeStylesIntoSet(set, ...className);
		}
	}
	function dedupeAndJoinClassList(classNames) {
		var set = /* @__PURE__ */ new Set();
		composeStylesIntoSet(set, ...classNames);
		return Array.from(set).join(" ");
	}
	function escapeRegex(string) {
		return string.replace(/[-/\\^$*+?.()|[\]{}]/g, "\\$&");
	}
	var regexAnySingleEscape = /[ -,\.\/:-@\[-\^`\{-~]/;
	var regexSingleEscape = /[ -,\.\/:-@\[\]\^`\{-~]/;
	var regexExcessiveSpaces = /(^|\\+)?(\\[A-F0-9]{1,6})\x20(?![a-fA-F0-9\x20])/g;
	var DEFAULT_OPTIONS = {
		escapeEverything: false,
		isIdentifier: false,
		quotes: "single",
		wrap: false
	};
	function cssesc(string) {
		var options = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : {};
		options = _objectSpread2(_objectSpread2({}, DEFAULT_OPTIONS), options);
		var quote = options.quotes === "double" ? "\"" : "'";
		var { isIdentifier } = options;
		var firstChar = string.charAt(0);
		var output = "";
		var counter = 0;
		var length = string.length;
		while (counter < length) {
			var character = string.charAt(counter++);
			var codePoint = character.charCodeAt(0);
			var value = void 0;
			if (codePoint < 32 || codePoint > 126) {
				if (codePoint >= 55296 && codePoint <= 56319 && counter < length) {
					var extra = string.charCodeAt(counter++);
					if ((extra & 64512) === 56320) codePoint = ((codePoint & 1023) << 10) + (extra & 1023) + 65536;
					else counter--;
				}
				value = "\\" + codePoint.toString(16).toUpperCase() + " ";
			} else if (options.escapeEverything) {
				if (regexAnySingleEscape.test(character)) value = "\\" + character;
				else value = "\\" + codePoint.toString(16).toUpperCase() + " ";
			} else if (/[\t\n\f\r\x0B]/.test(character)) value = "\\" + codePoint.toString(16).toUpperCase() + " ";
			else if (character === "\\" || !isIdentifier && (character === "\"" && quote === character || character === "'" && quote === character) || isIdentifier && regexSingleEscape.test(character)) value = "\\" + character;
			else value = character;
			output += value;
		}
		if (isIdentifier) {
			if (/^-[-\d]/.test(output)) output = "\\-" + output.slice(1);
			else if (/\d/.test(firstChar)) output = "\\3" + firstChar + " " + output.slice(1);
		}
		output = output.replace(regexExcessiveSpaces, function($0, $1, $2) {
			if ($1 && $1.length % 2) return $0;
			return ($1 || "") + $2;
		});
		if (!isIdentifier && options.wrap) return quote + output + quote;
		return output;
	}
	var _templateObject$1;
	function targetsClassName(tokens, targetClassName) {
		for (var i = tokens.length - 1; i >= 0; i--) {
			var token = tokens[i];
			if (token.type === "child" || token.type === "parent" || token.type === "sibling" || token.type === "adjacent" || token.type === "descendant") return false;
			if (token.type === "attribute" && token.name === "class" && token.value === targetClassName) return true;
			if (token.type === "pseudo" && Array.isArray(token.data) && (token.name === "is" || token.name === "where")) {
				if (token.data.every((sub) => targetsClassName(sub, targetClassName))) return true;
			}
		}
		return false;
	}
	var validateSelector = (selector, targetClassName) => {
		var replaceTarget = () => {
			var targetRegex = new RegExp(".".concat(escapeRegex(cssesc(targetClassName, { isIdentifier: true }))), "g");
			return selector.replace(targetRegex, "&");
		};
		var selectorParts;
		try {
			selectorParts = cssWhat.parse(selector);
		} catch (err) {
			throw new Error("Invalid selector: ".concat(replaceTarget()), { cause: err });
		}
		selectorParts.forEach((tokens) => {
			if (!targetsClassName(tokens, targetClassName)) throw new Error(dedent__default["default"](_templateObject$1 || (_templateObject$1 = taggedTemplateLiteral._taggedTemplateLiteral([
				"\n        Invalid selector: ",
				"\n\n        Style selectors must target the '&' character (along with any modifiers), e.g. ",
				" or ",
				".\n\n        This is to ensure that each style block only affects the styling of a single class.\n\n        If your selector is targeting another class, you should move it to the style definition for that class, e.g. given we have styles for 'parent' and 'child' elements, instead of adding a selector of ",
				") to 'parent', you should add ",
				" to 'child').\n\n        If your selector is targeting something global, use the 'globalStyle' function instead, e.g. if you wanted to write ",
				", you should instead write 'globalStyle(",
				", { ... })'\n      "
			])), replaceTarget(), "`${parent} &`", "`${parent} &:hover`", "`& ${child}`", "`${parent} &`", "`& h1`", "`${parent} h1`"));
		});
	};
	/** e.g. @media screen and (min-width: 500px) */
	var ConditionalRuleset = class ConditionalRuleset {
		/**
		* Stores information about where conditions must be in relation to other conditions
		*
		* e.g. mobile -> tablet, desktop
		*/
		constructor() {
			this.ruleset = /* @__PURE__ */ new Map();
			this.precedenceLookup = /* @__PURE__ */ new Map();
		}
		findOrCreateCondition(conditionQuery) {
			var targetCondition = this.ruleset.get(conditionQuery);
			if (!targetCondition) {
				targetCondition = {
					query: conditionQuery,
					rules: [],
					children: new ConditionalRuleset()
				};
				this.ruleset.set(conditionQuery, targetCondition);
			}
			return targetCondition;
		}
		getConditionalRulesetByPath(conditionPath) {
			var currRuleset = this;
			for (var query of conditionPath) currRuleset = currRuleset.findOrCreateCondition(query).children;
			return currRuleset;
		}
		addRule(rule, conditionQuery, conditionPath) {
			var targetCondition = this.getConditionalRulesetByPath(conditionPath).findOrCreateCondition(conditionQuery);
			if (!targetCondition) throw new Error("Failed to add conditional rule");
			targetCondition.rules.push(rule);
		}
		addConditionPrecedence(conditionPath, conditionOrder) {
			var ruleset = this.getConditionalRulesetByPath(conditionPath);
			for (var i = 0; i < conditionOrder.length; i++) {
				var _ruleset$precedenceLo;
				var query = conditionOrder[i];
				var conditionPrecedence = (_ruleset$precedenceLo = ruleset.precedenceLookup.get(query)) !== null && _ruleset$precedenceLo !== void 0 ? _ruleset$precedenceLo : /* @__PURE__ */ new Set();
				for (var lowerPrecedenceCondition of conditionOrder.slice(i + 1)) conditionPrecedence.add(lowerPrecedenceCondition);
				ruleset.precedenceLookup.set(query, conditionPrecedence);
			}
		}
		isCompatible(incomingRuleset) {
			for (var [condition, orderPrecedence] of this.precedenceLookup.entries()) for (var lowerPrecedenceCondition of orderPrecedence) {
				var _incomingRuleset$prec;
				if ((_incomingRuleset$prec = incomingRuleset.precedenceLookup.get(lowerPrecedenceCondition)) !== null && _incomingRuleset$prec !== void 0 && _incomingRuleset$prec.has(condition)) return false;
			}
			for (var { query, children } of incomingRuleset.ruleset.values()) {
				var matchingCondition = this.ruleset.get(query);
				if (matchingCondition && !matchingCondition.children.isCompatible(children)) return false;
			}
			return true;
		}
		merge(incomingRuleset) {
			for (var { query, rules, children } of incomingRuleset.ruleset.values()) {
				var matchingCondition = this.ruleset.get(query);
				if (matchingCondition) {
					matchingCondition.rules.push(...rules);
					matchingCondition.children.merge(children);
				} else this.ruleset.set(query, {
					query,
					rules,
					children
				});
			}
			for (var [condition, incomingOrderPrecedence] of incomingRuleset.precedenceLookup.entries()) {
				var _this$precedenceLooku;
				var orderPrecedence = (_this$precedenceLooku = this.precedenceLookup.get(condition)) !== null && _this$precedenceLooku !== void 0 ? _this$precedenceLooku : /* @__PURE__ */ new Set();
				this.precedenceLookup.set(condition, /* @__PURE__ */ new Set([...orderPrecedence, ...incomingOrderPrecedence]));
			}
		}
		/**
		* Merge another ConditionalRuleset into this one if they are compatible
		*
		* @returns true if successful, false if the ruleset is incompatible
		*/
		mergeIfCompatible(incomingRuleset) {
			if (!this.isCompatible(incomingRuleset)) return false;
			this.merge(incomingRuleset);
			return true;
		}
		getSortedRuleset() {
			var _this = this;
			var sortedRuleset = [];
			var _loop = function _loop(dependents) {
				var conditionForQuery = _this.ruleset.get(query);
				if (!conditionForQuery) throw new Error("Can't find condition for ".concat(query));
				var firstMatchingDependent = sortedRuleset.findIndex((condition) => dependents.has(condition.query));
				if (firstMatchingDependent > -1) sortedRuleset.splice(firstMatchingDependent, 0, conditionForQuery);
				else sortedRuleset.push(conditionForQuery);
			};
			for (var [query, dependents] of this.precedenceLookup.entries()) _loop(dependents);
			return sortedRuleset;
		}
		renderToArray() {
			var arr = [];
			for (var { query, rules, children } of this.getSortedRuleset()) {
				var selectors = {};
				for (var rule of rules) selectors[rule.selector] = _objectSpread2(_objectSpread2({}, selectors[rule.selector]), rule.rule);
				Object.assign(selectors, ...children.renderToArray());
				arr.push({ [query]: selectors });
			}
			return arr;
		}
	};
	var simplePseudoMap = {
		":-moz-any-link": true,
		":-moz-full-screen": true,
		":-moz-placeholder": true,
		":-moz-read-only": true,
		":-moz-read-write": true,
		":-ms-fullscreen": true,
		":-ms-input-placeholder": true,
		":-webkit-any-link": true,
		":-webkit-full-screen": true,
		"::-moz-color-swatch": true,
		"::-moz-list-bullet": true,
		"::-moz-list-number": true,
		"::-moz-page-sequence": true,
		"::-moz-page": true,
		"::-moz-placeholder": true,
		"::-moz-progress-bar": true,
		"::-moz-range-progress": true,
		"::-moz-range-thumb": true,
		"::-moz-range-track": true,
		"::-moz-scrolled-page-sequence": true,
		"::-moz-selection": true,
		"::-ms-backdrop": true,
		"::-ms-browse": true,
		"::-ms-check": true,
		"::-ms-clear": true,
		"::-ms-fill-lower": true,
		"::-ms-fill-upper": true,
		"::-ms-fill": true,
		"::-ms-reveal": true,
		"::-ms-thumb": true,
		"::-ms-ticks-after": true,
		"::-ms-ticks-before": true,
		"::-ms-tooltip": true,
		"::-ms-track": true,
		"::-ms-value": true,
		"::-webkit-backdrop": true,
		"::-webkit-calendar-picker-indicator": true,
		"::-webkit-inner-spin-button": true,
		"::-webkit-input-placeholder": true,
		"::-webkit-meter-bar": true,
		"::-webkit-meter-even-less-good-value": true,
		"::-webkit-meter-inner-element": true,
		"::-webkit-meter-optimum-value": true,
		"::-webkit-meter-suboptimum-value": true,
		"::-webkit-outer-spin-button": true,
		"::-webkit-progress-bar": true,
		"::-webkit-progress-inner-element": true,
		"::-webkit-progress-inner-value": true,
		"::-webkit-progress-value": true,
		"::-webkit-resizer": true,
		"::-webkit-scrollbar-button": true,
		"::-webkit-scrollbar-corner": true,
		"::-webkit-scrollbar-thumb": true,
		"::-webkit-scrollbar-track-piece": true,
		"::-webkit-scrollbar-track": true,
		"::-webkit-scrollbar": true,
		"::-webkit-search-cancel-button": true,
		"::-webkit-search-results-button": true,
		"::-webkit-slider-runnable-track": true,
		"::-webkit-slider-thumb": true,
		"::after": true,
		"::backdrop": true,
		"::before": true,
		"::cue": true,
		"::file-selector-button": true,
		"::first-letter": true,
		"::first-line": true,
		"::grammar-error": true,
		"::marker": true,
		"::placeholder": true,
		"::selection": true,
		"::spelling-error": true,
		"::target-text": true,
		"::view-transition-group": true,
		"::view-transition-image-pair": true,
		"::view-transition-new": true,
		"::view-transition-old": true,
		"::view-transition": true,
		":active": true,
		":after": true,
		":any-link": true,
		":before": true,
		":blank": true,
		":checked": true,
		":default": true,
		":defined": true,
		":disabled": true,
		":empty": true,
		":enabled": true,
		":first-child": true,
		":first-letter": true,
		":first-line": true,
		":first-of-type": true,
		":first": true,
		":focus-visible": true,
		":focus-within": true,
		":focus": true,
		":fullscreen": true,
		":hover": true,
		":in-range": true,
		":indeterminate": true,
		":invalid": true,
		":last-child": true,
		":last-of-type": true,
		":left": true,
		":link": true,
		":only-child": true,
		":only-of-type": true,
		":optional": true,
		":out-of-range": true,
		":placeholder-shown": true,
		":read-only": true,
		":read-write": true,
		":required": true,
		":right": true,
		":root": true,
		":scope": true,
		":target": true,
		":valid": true,
		":visited": true
	};
	var simplePseudos = Object.keys(simplePseudoMap);
	var simplePseudoLookup = simplePseudoMap;
	var _templateObject;
	var createMediaQueryError = (mediaQuery, msg) => new Error(dedent__default["default"](_templateObject || (_templateObject = taggedTemplateLiteral._taggedTemplateLiteral([
		"\n    Invalid media query: \"",
		"\"\n\n    ",
		"\n\n    Read more on MDN: https://developer.mozilla.org/en-US/docs/Web/CSS/Media_Queries/Using_media_queries\n  "
	])), mediaQuery, msg));
	var validateMediaQuery = (mediaQuery) => {
		if (mediaQuery === "@media ") throw createMediaQueryError(mediaQuery, "Query is empty");
		try {
			mediaQueryParser.toAST(mediaQuery);
		} catch (e) {
			throw createMediaQueryError(mediaQuery, e.message);
		}
	};
	var _excluded = ["vars"];
	var _excluded2 = ["content"];
	var DECLARATION = "__DECLARATION";
	var UNITLESS = {
		animationIterationCount: true,
		borderImage: true,
		borderImageOutset: true,
		borderImageSlice: true,
		borderImageWidth: true,
		boxFlex: true,
		boxFlexGroup: true,
		boxOrdinalGroup: true,
		columnCount: true,
		columns: true,
		flex: true,
		flexGrow: true,
		flexShrink: true,
		fontWeight: true,
		gridArea: true,
		gridColumn: true,
		gridColumnEnd: true,
		gridColumnStart: true,
		gridRow: true,
		gridRowEnd: true,
		gridRowStart: true,
		initialLetter: true,
		lineClamp: true,
		lineHeight: true,
		maxLines: true,
		opacity: true,
		order: true,
		orphans: true,
		scale: true,
		tabSize: true,
		WebkitLineClamp: true,
		widows: true,
		zIndex: true,
		zoom: true,
		fillOpacity: true,
		floodOpacity: true,
		maskBorder: true,
		maskBorderOutset: true,
		maskBorderSlice: true,
		maskBorderWidth: true,
		shapeImageThreshold: true,
		stopOpacity: true,
		strokeDashoffset: true,
		strokeMiterlimit: true,
		strokeOpacity: true,
		strokeWidth: true
	};
	function dashify(str) {
		return str.replace(/([A-Z])/g, "-$1").replace(/^ms-/, "-ms-").toLowerCase();
	}
	function replaceBetweenIndexes(target, startIndex, endIndex, replacement) {
		var start = target.slice(0, startIndex);
		var end = target.slice(endIndex);
		return "".concat(start).concat(replacement).concat(end);
	}
	var DOUBLE_SPACE = "  ";
	var specialKeys = [
		...simplePseudos,
		"@layer",
		"@scope",
		"@media",
		"@supports",
		"@container",
		"@starting-style",
		"selectors"
	];
	var Stylesheet = class {
		constructor(localClassNames, composedClassLists) {
			this.rules = [];
			this.conditionalRulesets = [new ConditionalRuleset()];
			this.fontFaceRules = [];
			this.keyframesRules = [];
			this.propertyRules = [];
			this.localClassNamesMap = new Map(localClassNames.map((localClassName) => [localClassName, localClassName]));
			this.localClassNames = localClassNames;
			this.layers = /* @__PURE__ */ new Map();
			this.composedClassLists = composedClassLists.map((_ref) => {
				var { identifier, classList } = _ref;
				return {
					identifier,
					regex: RegExp("(".concat(escapeRegex(classList), ")"), "g")
				};
			}).reverse();
		}
		processCssObj(root) {
			if (root.type === "fontFace") {
				this.fontFaceRules.push(root.rule);
				return;
			}
			if (root.type === "property") {
				this.propertyRules.push(root);
				return;
			}
			if (root.type === "keyframes") {
				root.rule = Object.fromEntries(Object.entries(root.rule).map((_ref2) => {
					var [keyframe, rule] = _ref2;
					return [keyframe, this.transformVars(this.transformProperties(rule))];
				}));
				this.keyframesRules.push(root);
				return;
			}
			this.currConditionalRuleset = new ConditionalRuleset();
			if (root.type === "layer") {
				var layerDefinition = "@layer ".concat(root.name);
				this.addLayer([layerDefinition]);
			} else {
				var mainRule = omit(root.rule, specialKeys);
				this.addRule({
					selector: root.selector,
					rule: mainRule
				});
				this.transformLayer(root, root.rule["@layer"]);
				this.transformScope(root, root.rule["@scope"]);
				this.transformMedia(root, root.rule["@media"]);
				this.transformSupports(root, root.rule["@supports"]);
				this.transformContainer(root, root.rule["@container"]);
				this.transformStartingStyle(root, root.rule["@starting-style"]);
				this.transformSimplePseudos(root, root.rule);
				this.transformSelectors(root, root.rule);
			}
			if (!this.conditionalRulesets[this.conditionalRulesets.length - 1].mergeIfCompatible(this.currConditionalRuleset)) this.conditionalRulesets.push(this.currConditionalRuleset);
		}
		addConditionalRule(cssRule, conditions) {
			var rule = this.transformVars(this.transformProperties(cssRule.rule));
			var selector = this.transformSelector(cssRule.selector);
			if (!this.currConditionalRuleset) throw new Error("Couldn't add conditional rule");
			var conditionQuery = conditions[conditions.length - 1];
			var parentConditions = conditions.slice(0, conditions.length - 1);
			this.currConditionalRuleset.addRule({
				selector,
				rule
			}, conditionQuery, parentConditions);
		}
		addRule(cssRule) {
			var rule = this.transformVars(this.transformProperties(cssRule.rule));
			var selector = this.transformSelector(cssRule.selector);
			this.rules.push({
				selector,
				rule
			});
		}
		addLayer(layer) {
			var uniqueLayerKey = layer.join(" - ");
			this.layers.set(uniqueLayerKey, layer);
		}
		transformProperties(cssRule) {
			return this.transformContent(this.pixelifyProperties(cssRule));
		}
		pixelifyProperties(cssRule) {
			var result = _objectSpread2({}, cssRule);
			forEach(cssRule, (value, key) => {
				if (typeof value === "number" && value !== 0 && !UNITLESS[key]) result[key] = "".concat(value, "px");
			});
			return result;
		}
		transformVars(_ref3) {
			var { vars } = _ref3, rest = _objectWithoutProperties(_ref3, _excluded);
			if (!vars) return rest;
			return _objectSpread2(_objectSpread2({}, mapKeys(vars, (_value, key) => _private.getVarName(key))), rest);
		}
		transformContent(_ref4) {
			var { content } = _ref4, rest = _objectWithoutProperties(_ref4, _excluded2);
			if (typeof content === "undefined") return rest;
			return _objectSpread2({ content: (Array.isArray(content) ? content : [content]).map((value) => value && (value.includes("\"") || value.includes("'") || /^([A-Za-z-]+\([^]*|[^]*-quote|inherit|initial|none|normal|revert|unset)(\s|$)/.test(value)) ? value : "\"".concat(value, "\"")) }, rest);
		}
		transformClassname(identifier) {
			return ".".concat(cssesc(identifier, { isIdentifier: true }));
		}
		transformSelector(selector) {
			var _this$localClassNames;
			var transformedSelector = selector;
			var _loop = function _loop(identifier) {
				transformedSelector = transformedSelector.replace(regex, () => {
					adapter_dist_vanillaExtractCssAdapter.markCompositionUsed(identifier);
					return identifier;
				});
			};
			for (var { identifier, regex } of this.composedClassLists) _loop(identifier);
			if (this.localClassNamesMap.has(transformedSelector)) return this.transformClassname(transformedSelector);
			(_this$localClassNames = this.localClassNamesSearch) !== null && _this$localClassNames !== void 0 || (this.localClassNamesSearch = new AhoCorasick__default["default"](this.localClassNames));
			var results = this.localClassNamesSearch.search(transformedSelector);
			var lastReplaceIndex = transformedSelector.length;
			for (var i = results.length - 1; i >= 0; i--) {
				var currentMatch = results[i];
				if (i > 0 && results[i - 1].end === currentMatch.end) continue;
				var { start: startIndex, end: endIndex, pattern: firstMatch } = currentMatch;
				if (lastReplaceIndex < endIndex) continue;
				lastReplaceIndex = startIndex;
				if (transformedSelector[startIndex - 1] !== ".") transformedSelector = replaceBetweenIndexes(transformedSelector, startIndex, endIndex, this.transformClassname(firstMatch));
			}
			return transformedSelector;
		}
		transformSelectors(root, rule, conditions) {
			forEach(rule.selectors, (selectorRule, selector) => {
				if (root.type !== "local") throw new Error("Selectors are not allowed within ".concat(root.type === "global" ? "\"globalStyle\"" : "\"selectors\""));
				var transformedSelector = this.transformSelector(selector.replace(RegExp("&", "g"), root.selector));
				validateSelector(transformedSelector, root.selector);
				var rule = {
					selector: transformedSelector,
					rule: omit(selectorRule, specialKeys)
				};
				if (conditions) this.addConditionalRule(rule, conditions);
				else this.addRule(rule);
				var selectorRoot = {
					type: "selector",
					selector: transformedSelector,
					rule: selectorRule
				};
				this.transformLayer(selectorRoot, selectorRule["@layer"], conditions);
				this.transformScope(selectorRoot, selectorRule["@scope"], conditions);
				this.transformSupports(selectorRoot, selectorRule["@supports"], conditions);
				this.transformMedia(selectorRoot, selectorRule["@media"], conditions);
				this.transformContainer(selectorRoot, selectorRule["@container"], conditions);
				this.transformStartingStyle(selectorRoot, selectorRule["@starting-style"], conditions);
			});
		}
		transformMedia(root, rules) {
			var parentConditions = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
			if (rules) {
				var _this$currConditional;
				(_this$currConditional = this.currConditionalRuleset) === null || _this$currConditional === void 0 || _this$currConditional.addConditionPrecedence(parentConditions, Object.keys(rules).map((query) => "@media ".concat(query)));
				for (var [query, mediaRule] of Object.entries(rules)) {
					var mediaQuery = "@media ".concat(query);
					validateMediaQuery(mediaQuery);
					var conditions = [...parentConditions, mediaQuery];
					this.addConditionalRule({
						selector: root.selector,
						rule: omit(mediaRule, specialKeys)
					}, conditions);
					if (root.type === "local") {
						this.transformSimplePseudos(root, mediaRule, conditions);
						this.transformSelectors(root, mediaRule, conditions);
					}
					this.transformLayer(root, mediaRule["@layer"], conditions);
					this.transformScope(root, mediaRule["@scope"], conditions);
					this.transformSupports(root, mediaRule["@supports"], conditions);
					this.transformContainer(root, mediaRule["@container"], conditions);
					this.transformStartingStyle(root, mediaRule["@starting-style"], conditions);
				}
			}
		}
		transformContainer(root, rules) {
			var parentConditions = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
			if (rules) {
				var _this$currConditional2;
				(_this$currConditional2 = this.currConditionalRuleset) === null || _this$currConditional2 === void 0 || _this$currConditional2.addConditionPrecedence(parentConditions, Object.keys(rules).map((query) => "@container ".concat(query)));
				forEach(rules, (containerRule, query) => {
					var containerQuery = "@container ".concat(query);
					var conditions = [...parentConditions, containerQuery];
					this.addConditionalRule({
						selector: root.selector,
						rule: omit(containerRule, specialKeys)
					}, conditions);
					if (root.type === "local") {
						this.transformSimplePseudos(root, containerRule, conditions);
						this.transformSelectors(root, containerRule, conditions);
					}
					this.transformLayer(root, containerRule["@layer"], conditions);
					this.transformScope(root, containerRule["@scope"], conditions);
					this.transformSupports(root, containerRule["@supports"], conditions);
					this.transformMedia(root, containerRule["@media"], conditions);
					this.transformStartingStyle(root, containerRule["@starting-style"], conditions);
				});
			}
		}
		transformLayer(root, rules) {
			var parentConditions = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
			if (rules) {
				var _this$currConditional3;
				(_this$currConditional3 = this.currConditionalRuleset) === null || _this$currConditional3 === void 0 || _this$currConditional3.addConditionPrecedence(parentConditions, Object.keys(rules).map((name) => "@layer ".concat(name)));
				forEach(rules, (layerRule, name) => {
					var conditions = [...parentConditions, "@layer ".concat(name)];
					this.addLayer(conditions);
					this.addConditionalRule({
						selector: root.selector,
						rule: omit(layerRule, specialKeys)
					}, conditions);
					if (root.type === "local") {
						this.transformSimplePseudos(root, layerRule, conditions);
						this.transformSelectors(root, layerRule, conditions);
					}
					this.transformScope(root, layerRule["@scope"], conditions);
					this.transformMedia(root, layerRule["@media"], conditions);
					this.transformSupports(root, layerRule["@supports"], conditions);
					this.transformContainer(root, layerRule["@container"], conditions);
					this.transformStartingStyle(root, layerRule["@starting-style"], conditions);
				});
			}
		}
		transformScope(root, rules) {
			var parentConditions = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
			if (rules) {
				var _this$currConditional4;
				var transformedScopeBounds = {};
				(_this$currConditional4 = this.currConditionalRuleset) === null || _this$currConditional4 === void 0 || _this$currConditional4.addConditionPrecedence(parentConditions, Object.keys(rules).map((bounds) => {
					transformedScopeBounds[bounds] = "@scope ".concat(this.transformSelector(bounds.replace(nestingSelectorRegex, root.selector)));
					return transformedScopeBounds[bounds];
				}));
				for (var [bounds, scopeRule] of Object.entries(rules)) {
					var conditions = [...parentConditions, transformedScopeBounds[bounds]];
					this.addConditionalRule({
						selector: root.selector,
						rule: omit(scopeRule, specialKeys)
					}, conditions);
					if (root.type === "local") {
						this.transformSimplePseudos(root, scopeRule, conditions);
						this.transformSelectors(root, scopeRule, conditions);
					}
					this.transformLayer(root, scopeRule["@layer"], conditions);
					this.transformMedia(root, scopeRule["@media"], conditions);
					this.transformSupports(root, scopeRule["@supports"], conditions);
					this.transformContainer(root, scopeRule["@container"], conditions);
					this.transformStartingStyle(root, scopeRule["@starting-style"], conditions);
				}
			}
		}
		transformSupports(root, rules) {
			var parentConditions = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
			if (rules) {
				var _this$currConditional5;
				(_this$currConditional5 = this.currConditionalRuleset) === null || _this$currConditional5 === void 0 || _this$currConditional5.addConditionPrecedence(parentConditions, Object.keys(rules).map((query) => "@supports ".concat(query)));
				forEach(rules, (supportsRule, query) => {
					var conditions = [...parentConditions, "@supports ".concat(query)];
					this.addConditionalRule({
						selector: root.selector,
						rule: omit(supportsRule, specialKeys)
					}, conditions);
					if (root.type === "local") {
						this.transformSimplePseudos(root, supportsRule, conditions);
						this.transformSelectors(root, supportsRule, conditions);
					}
					this.transformLayer(root, supportsRule["@layer"], conditions);
					this.transformScope(root, supportsRule["@scope"], conditions);
					this.transformMedia(root, supportsRule["@media"], conditions);
					this.transformContainer(root, supportsRule["@container"], conditions);
					this.transformStartingStyle(root, supportsRule["@starting-style"], conditions);
				});
			}
		}
		transformSimplePseudos(root, rule, conditions) {
			for (var key of Object.keys(rule)) if (simplePseudoLookup[key]) {
				if (root.type !== "local") throw new Error("Simple pseudos are not valid in ".concat(root.type === "global" ? "\"globalStyle\"" : "\"selectors\""));
				if (conditions) this.addConditionalRule({
					selector: "".concat(root.selector).concat(key),
					rule: rule[key]
				}, conditions);
				else this.addRule({
					conditions,
					selector: "".concat(root.selector).concat(key),
					rule: rule[key]
				});
			}
		}
		transformStartingStyle(root, rules) {
			var parentConditions = arguments.length > 2 && arguments[2] !== void 0 ? arguments[2] : [];
			if (rules) {
				var _this$currConditional6;
				var nestedAtRuleKey = Object.keys(rules).find((key) => key.startsWith("@"));
				if (nestedAtRuleKey) throw new Error("Nested at-rules (e.g. \"".concat(nestedAtRuleKey, "\") are not allowed inside @starting-style."));
				(_this$currConditional6 = this.currConditionalRuleset) === null || _this$currConditional6 === void 0 || _this$currConditional6.addConditionPrecedence(parentConditions, ["@starting-style"]);
				var conditions = [...parentConditions, "@starting-style"];
				this.addConditionalRule({
					selector: root.selector,
					rule: omit(rules, specialKeys)
				}, conditions);
				if (root.type === "local") {
					this.transformSimplePseudos(root, rules, conditions);
					this.transformSelectors(root, rules, conditions);
				}
			}
		}
		toCss() {
			var css = [];
			for (var fontFaceRule of this.fontFaceRules) css.push(renderCss({ "@font-face": fontFaceRule }));
			for (var property of this.propertyRules) css.push(renderCss({ ["@property ".concat(property.name)]: property.rule }));
			for (var keyframe of this.keyframesRules) css.push(renderCss({ ["@keyframes ".concat(keyframe.name)]: keyframe.rule }));
			for (var layer of this.layers.values()) {
				var [definition, ...nesting] = layer.reverse();
				var cssObj = { [definition]: DECLARATION };
				for (var part of nesting) cssObj = { [part]: cssObj };
				css.push(renderCss(cssObj));
			}
			for (var rule of this.rules) css.push(renderCss({ [rule.selector]: rule.rule }));
			for (var conditionalRuleset of this.conditionalRulesets) for (var conditionalRule of conditionalRuleset.renderToArray()) css.push(renderCss(conditionalRule));
			return css.filter(Boolean);
		}
	};
	function renderCss(v) {
		var indent = arguments.length > 1 && arguments[1] !== void 0 ? arguments[1] : "";
		var rules = [];
		var _loop2 = function _loop2(key) {
			var value = v[key];
			if (value && Array.isArray(value)) rules.push(...value.map((v) => renderCss({ [key]: v }, indent)));
			else if (value && typeof value === "object") {
				if (!(Object.keys(value).length === 0)) rules.push("".concat(indent).concat(key, " {\n").concat(renderCss(value, indent + DOUBLE_SPACE), "\n").concat(indent, "}"));
			} else if (value === DECLARATION) rules.push("".concat(indent).concat(key, ";"));
			else rules.push("".concat(indent).concat(key.startsWith("--") ? key : dashify(key), ": ").concat(value, ";"));
		};
		for (var key of Object.keys(v)) _loop2(key);
		return rules.join("\n");
	}
	function transformCss(_ref5) {
		var { localClassNames, cssObjs, composedClassLists } = _ref5;
		var stylesheet = new Stylesheet(localClassNames, composedClassLists);
		for (var root of cssObjs) stylesheet.processCssObj(root);
		return stylesheet.toCss();
	}
	exports._objectSpread2 = _objectSpread2;
	exports._objectWithoutProperties = _objectWithoutProperties;
	exports.cssesc = cssesc;
	exports.dedupeAndJoinClassList = dedupeAndJoinClassList;
	exports.transformCss = transformCss;
}));
//#endregion
//#region node_modules/@vanilla-extract/css/fileScope/dist/vanilla-extract-css-fileScope.cjs.prod.js
var require_vanilla_extract_css_fileScope_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var taggedTemplateLiteral = require_taggedTemplateLiteral_0bfb2e96_cjs_prod();
	var dedent = require_dedent();
	var adapter_dist_vanillaExtractCssAdapter = require_vanilla_extract_css_adapter_cjs_prod();
	function _interopDefault(e) {
		return e && e.__esModule ? e : { "default": e };
	}
	var dedent__default = /*#__PURE__*/ _interopDefault(dedent);
	var _templateObject;
	var refCounter = 0;
	var fileScopes = [];
	function setFileScope(filePath, packageName) {
		refCounter = 0;
		var fileScope = {
			filePath,
			packageName
		};
		fileScopes.unshift(fileScope);
		adapter_dist_vanillaExtractCssAdapter.onBeginFileScope(fileScope);
	}
	function endFileScope() {
		adapter_dist_vanillaExtractCssAdapter.onEndFileScope(getFileScope());
		refCounter = 0;
		fileScopes.splice(0, 1);
	}
	function hasFileScope() {
		return fileScopes.length > 0;
	}
	function getFileScope() {
		if (fileScopes.length === 0) throw new Error(dedent__default["default"](_templateObject || (_templateObject = taggedTemplateLiteral._taggedTemplateLiteral(["\n        Styles were unable to be assigned to a file. This is generally caused by one of the following:\n\n        - You may have created styles outside of a '.css.ts' context\n        - You may have incorrect configuration. See https://vanilla-extract.style/documentation/getting-started\n      "]))));
		return fileScopes[0];
	}
	function getAndIncrementRefCounter() {
		return refCounter++;
	}
	exports.endFileScope = endFileScope;
	exports.getAndIncrementRefCounter = getAndIncrementRefCounter;
	exports.getFileScope = getFileScope;
	exports.hasFileScope = hasFileScope;
	exports.setFileScope = setFileScope;
}));
//#endregion
//#region node_modules/@vanilla-extract/css/node_modules/lru-cache/dist/commonjs/index.js
var require_commonjs = /* @__PURE__ */ __commonJSMin(((exports) => {
	/**
	* @module LRUCache
	*/
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.LRUCache = void 0;
	var perf = typeof performance === "object" && performance && typeof performance.now === "function" ? performance : Date;
	var warned = /* @__PURE__ */ new Set();
	/* c8 ignore start */
	var PROCESS = typeof process === "object" && !!process ? process : {};
	/* c8 ignore start */
	var emitWarning = (msg, type, code, fn) => {
		typeof PROCESS.emitWarning === "function" ? PROCESS.emitWarning(msg, type, code, fn) : console.error(`[${code}] ${type}: ${msg}`);
	};
	var AC = globalThis.AbortController;
	var AS = globalThis.AbortSignal;
	/* c8 ignore start */
	if (typeof AC === "undefined") {
		AS = class AbortSignal {
			onabort;
			_onabort = [];
			reason;
			aborted = false;
			addEventListener(_, fn) {
				this._onabort.push(fn);
			}
		};
		AC = class AbortController {
			constructor() {
				warnACPolyfill();
			}
			signal = new AS();
			abort(reason) {
				if (this.signal.aborted) return;
				this.signal.reason = reason;
				this.signal.aborted = true;
				for (const fn of this.signal._onabort) fn(reason);
				this.signal.onabort?.(reason);
			}
		};
		let printACPolyfillWarning = PROCESS.env?.LRU_CACHE_IGNORE_AC_WARNING !== "1";
		const warnACPolyfill = () => {
			if (!printACPolyfillWarning) return;
			printACPolyfillWarning = false;
			emitWarning("AbortController is not defined. If using lru-cache in node 14, load an AbortController polyfill from the `node-abort-controller` package. A minimal polyfill is provided for use by LRUCache.fetch(), but it should not be relied upon in other contexts (eg, passing it to other APIs that use AbortController/AbortSignal might have undesirable effects). You may disable this with LRU_CACHE_IGNORE_AC_WARNING=1 in the env.", "NO_ABORT_CONTROLLER", "ENOTSUP", warnACPolyfill);
		};
	}
	/* c8 ignore stop */
	var shouldWarn = (code) => !warned.has(code);
	var isPosInt = (n) => n && n === Math.floor(n) && n > 0 && isFinite(n);
	/* c8 ignore start */
	var getUintArray = (max) => !isPosInt(max) ? null : max <= Math.pow(2, 8) ? Uint8Array : max <= Math.pow(2, 16) ? Uint16Array : max <= Math.pow(2, 32) ? Uint32Array : max <= Number.MAX_SAFE_INTEGER ? ZeroArray : null;
	/* c8 ignore stop */
	var ZeroArray = class extends Array {
		constructor(size) {
			super(size);
			this.fill(0);
		}
	};
	var Stack = class Stack {
		heap;
		length;
		static #constructing = false;
		static create(max) {
			const HeapCls = getUintArray(max);
			if (!HeapCls) return [];
			Stack.#constructing = true;
			const s = new Stack(max, HeapCls);
			Stack.#constructing = false;
			return s;
		}
		constructor(max, HeapCls) {
			/* c8 ignore start */
			if (!Stack.#constructing) throw new TypeError("instantiate Stack using Stack.create(n)");
			/* c8 ignore stop */
			this.heap = new HeapCls(max);
			this.length = 0;
		}
		push(n) {
			this.heap[this.length++] = n;
		}
		pop() {
			return this.heap[--this.length];
		}
	};
	exports.LRUCache = class LRUCache {
		#max;
		#maxSize;
		#dispose;
		#disposeAfter;
		#fetchMethod;
		#memoMethod;
		/**
		* {@link LRUCache.OptionsBase.ttl}
		*/
		ttl;
		/**
		* {@link LRUCache.OptionsBase.ttlResolution}
		*/
		ttlResolution;
		/**
		* {@link LRUCache.OptionsBase.ttlAutopurge}
		*/
		ttlAutopurge;
		/**
		* {@link LRUCache.OptionsBase.updateAgeOnGet}
		*/
		updateAgeOnGet;
		/**
		* {@link LRUCache.OptionsBase.updateAgeOnHas}
		*/
		updateAgeOnHas;
		/**
		* {@link LRUCache.OptionsBase.allowStale}
		*/
		allowStale;
		/**
		* {@link LRUCache.OptionsBase.noDisposeOnSet}
		*/
		noDisposeOnSet;
		/**
		* {@link LRUCache.OptionsBase.noUpdateTTL}
		*/
		noUpdateTTL;
		/**
		* {@link LRUCache.OptionsBase.maxEntrySize}
		*/
		maxEntrySize;
		/**
		* {@link LRUCache.OptionsBase.sizeCalculation}
		*/
		sizeCalculation;
		/**
		* {@link LRUCache.OptionsBase.noDeleteOnFetchRejection}
		*/
		noDeleteOnFetchRejection;
		/**
		* {@link LRUCache.OptionsBase.noDeleteOnStaleGet}
		*/
		noDeleteOnStaleGet;
		/**
		* {@link LRUCache.OptionsBase.allowStaleOnFetchAbort}
		*/
		allowStaleOnFetchAbort;
		/**
		* {@link LRUCache.OptionsBase.allowStaleOnFetchRejection}
		*/
		allowStaleOnFetchRejection;
		/**
		* {@link LRUCache.OptionsBase.ignoreFetchAbort}
		*/
		ignoreFetchAbort;
		#size;
		#calculatedSize;
		#keyMap;
		#keyList;
		#valList;
		#next;
		#prev;
		#head;
		#tail;
		#free;
		#disposed;
		#sizes;
		#starts;
		#ttls;
		#hasDispose;
		#hasFetchMethod;
		#hasDisposeAfter;
		/**
		* Do not call this method unless you need to inspect the
		* inner workings of the cache.  If anything returned by this
		* object is modified in any way, strange breakage may occur.
		*
		* These fields are private for a reason!
		*
		* @internal
		*/
		static unsafeExposeInternals(c) {
			return {
				starts: c.#starts,
				ttls: c.#ttls,
				sizes: c.#sizes,
				keyMap: c.#keyMap,
				keyList: c.#keyList,
				valList: c.#valList,
				next: c.#next,
				prev: c.#prev,
				get head() {
					return c.#head;
				},
				get tail() {
					return c.#tail;
				},
				free: c.#free,
				isBackgroundFetch: (p) => c.#isBackgroundFetch(p),
				backgroundFetch: (k, index, options, context) => c.#backgroundFetch(k, index, options, context),
				moveToTail: (index) => c.#moveToTail(index),
				indexes: (options) => c.#indexes(options),
				rindexes: (options) => c.#rindexes(options),
				isStale: (index) => c.#isStale(index)
			};
		}
		/**
		* {@link LRUCache.OptionsBase.max} (read-only)
		*/
		get max() {
			return this.#max;
		}
		/**
		* {@link LRUCache.OptionsBase.maxSize} (read-only)
		*/
		get maxSize() {
			return this.#maxSize;
		}
		/**
		* The total computed size of items in the cache (read-only)
		*/
		get calculatedSize() {
			return this.#calculatedSize;
		}
		/**
		* The number of items stored in the cache (read-only)
		*/
		get size() {
			return this.#size;
		}
		/**
		* {@link LRUCache.OptionsBase.fetchMethod} (read-only)
		*/
		get fetchMethod() {
			return this.#fetchMethod;
		}
		get memoMethod() {
			return this.#memoMethod;
		}
		/**
		* {@link LRUCache.OptionsBase.dispose} (read-only)
		*/
		get dispose() {
			return this.#dispose;
		}
		/**
		* {@link LRUCache.OptionsBase.disposeAfter} (read-only)
		*/
		get disposeAfter() {
			return this.#disposeAfter;
		}
		constructor(options) {
			const { max = 0, ttl, ttlResolution = 1, ttlAutopurge, updateAgeOnGet, updateAgeOnHas, allowStale, dispose, disposeAfter, noDisposeOnSet, noUpdateTTL, maxSize = 0, maxEntrySize = 0, sizeCalculation, fetchMethod, memoMethod, noDeleteOnFetchRejection, noDeleteOnStaleGet, allowStaleOnFetchRejection, allowStaleOnFetchAbort, ignoreFetchAbort } = options;
			if (max !== 0 && !isPosInt(max)) throw new TypeError("max option must be a nonnegative integer");
			const UintArray = max ? getUintArray(max) : Array;
			if (!UintArray) throw new Error("invalid max value: " + max);
			this.#max = max;
			this.#maxSize = maxSize;
			this.maxEntrySize = maxEntrySize || this.#maxSize;
			this.sizeCalculation = sizeCalculation;
			if (this.sizeCalculation) {
				if (!this.#maxSize && !this.maxEntrySize) throw new TypeError("cannot set sizeCalculation without setting maxSize or maxEntrySize");
				if (typeof this.sizeCalculation !== "function") throw new TypeError("sizeCalculation set to non-function");
			}
			if (memoMethod !== void 0 && typeof memoMethod !== "function") throw new TypeError("memoMethod must be a function if defined");
			this.#memoMethod = memoMethod;
			if (fetchMethod !== void 0 && typeof fetchMethod !== "function") throw new TypeError("fetchMethod must be a function if specified");
			this.#fetchMethod = fetchMethod;
			this.#hasFetchMethod = !!fetchMethod;
			this.#keyMap = /* @__PURE__ */ new Map();
			this.#keyList = new Array(max).fill(void 0);
			this.#valList = new Array(max).fill(void 0);
			this.#next = new UintArray(max);
			this.#prev = new UintArray(max);
			this.#head = 0;
			this.#tail = 0;
			this.#free = Stack.create(max);
			this.#size = 0;
			this.#calculatedSize = 0;
			if (typeof dispose === "function") this.#dispose = dispose;
			if (typeof disposeAfter === "function") {
				this.#disposeAfter = disposeAfter;
				this.#disposed = [];
			} else {
				this.#disposeAfter = void 0;
				this.#disposed = void 0;
			}
			this.#hasDispose = !!this.#dispose;
			this.#hasDisposeAfter = !!this.#disposeAfter;
			this.noDisposeOnSet = !!noDisposeOnSet;
			this.noUpdateTTL = !!noUpdateTTL;
			this.noDeleteOnFetchRejection = !!noDeleteOnFetchRejection;
			this.allowStaleOnFetchRejection = !!allowStaleOnFetchRejection;
			this.allowStaleOnFetchAbort = !!allowStaleOnFetchAbort;
			this.ignoreFetchAbort = !!ignoreFetchAbort;
			if (this.maxEntrySize !== 0) {
				if (this.#maxSize !== 0) {
					if (!isPosInt(this.#maxSize)) throw new TypeError("maxSize must be a positive integer if specified");
				}
				if (!isPosInt(this.maxEntrySize)) throw new TypeError("maxEntrySize must be a positive integer if specified");
				this.#initializeSizeTracking();
			}
			this.allowStale = !!allowStale;
			this.noDeleteOnStaleGet = !!noDeleteOnStaleGet;
			this.updateAgeOnGet = !!updateAgeOnGet;
			this.updateAgeOnHas = !!updateAgeOnHas;
			this.ttlResolution = isPosInt(ttlResolution) || ttlResolution === 0 ? ttlResolution : 1;
			this.ttlAutopurge = !!ttlAutopurge;
			this.ttl = ttl || 0;
			if (this.ttl) {
				if (!isPosInt(this.ttl)) throw new TypeError("ttl must be a positive integer if specified");
				this.#initializeTTLTracking();
			}
			if (this.#max === 0 && this.ttl === 0 && this.#maxSize === 0) throw new TypeError("At least one of max, maxSize, or ttl is required");
			if (!this.ttlAutopurge && !this.#max && !this.#maxSize) {
				const code = "LRU_CACHE_UNBOUNDED";
				if (shouldWarn(code)) {
					warned.add(code);
					emitWarning("TTL caching without ttlAutopurge, max, or maxSize can result in unbounded memory consumption.", "UnboundedCacheWarning", code, LRUCache);
				}
			}
		}
		/**
		* Return the number of ms left in the item's TTL. If item is not in cache,
		* returns `0`. Returns `Infinity` if item is in cache without a defined TTL.
		*/
		getRemainingTTL(key) {
			return this.#keyMap.has(key) ? Infinity : 0;
		}
		#initializeTTLTracking() {
			const ttls = new ZeroArray(this.#max);
			const starts = new ZeroArray(this.#max);
			this.#ttls = ttls;
			this.#starts = starts;
			this.#setItemTTL = (index, ttl, start = perf.now()) => {
				starts[index] = ttl !== 0 ? start : 0;
				ttls[index] = ttl;
				if (ttl !== 0 && this.ttlAutopurge) {
					const t = setTimeout(() => {
						if (this.#isStale(index)) this.#delete(this.#keyList[index], "expire");
					}, ttl + 1);
					/* c8 ignore start */
					if (t.unref) t.unref();
				}
			};
			this.#updateItemAge = (index) => {
				starts[index] = ttls[index] !== 0 ? perf.now() : 0;
			};
			this.#statusTTL = (status, index) => {
				if (ttls[index]) {
					const ttl = ttls[index];
					const start = starts[index];
					/* c8 ignore next */
					if (!ttl || !start) return;
					status.ttl = ttl;
					status.start = start;
					status.now = cachedNow || getNow();
					status.remainingTTL = ttl - (status.now - start);
				}
			};
			let cachedNow = 0;
			const getNow = () => {
				const n = perf.now();
				if (this.ttlResolution > 0) {
					cachedNow = n;
					const t = setTimeout(() => cachedNow = 0, this.ttlResolution);
					/* c8 ignore start */
					if (t.unref) t.unref();
				}
				return n;
			};
			this.getRemainingTTL = (key) => {
				const index = this.#keyMap.get(key);
				if (index === void 0) return 0;
				const ttl = ttls[index];
				const start = starts[index];
				if (!ttl || !start) return Infinity;
				return ttl - ((cachedNow || getNow()) - start);
			};
			this.#isStale = (index) => {
				const s = starts[index];
				const t = ttls[index];
				return !!t && !!s && (cachedNow || getNow()) - s > t;
			};
		}
		#updateItemAge = () => {};
		#statusTTL = () => {};
		#setItemTTL = () => {};
		/* c8 ignore stop */
		#isStale = () => false;
		#initializeSizeTracking() {
			const sizes = new ZeroArray(this.#max);
			this.#calculatedSize = 0;
			this.#sizes = sizes;
			this.#removeItemSize = (index) => {
				this.#calculatedSize -= sizes[index];
				sizes[index] = 0;
			};
			this.#requireSize = (k, v, size, sizeCalculation) => {
				if (this.#isBackgroundFetch(v)) return 0;
				if (!isPosInt(size)) {
					if (sizeCalculation) {
						if (typeof sizeCalculation !== "function") throw new TypeError("sizeCalculation must be a function");
						size = sizeCalculation(v, k);
						if (!isPosInt(size)) throw new TypeError("sizeCalculation return invalid (expect positive integer)");
					} else throw new TypeError("invalid size value (must be positive integer). When maxSize or maxEntrySize is used, sizeCalculation or size must be set.");
				}
				return size;
			};
			this.#addItemSize = (index, size, status) => {
				sizes[index] = size;
				if (this.#maxSize) {
					const maxSize = this.#maxSize - sizes[index];
					while (this.#calculatedSize > maxSize) this.#evict(true);
				}
				this.#calculatedSize += sizes[index];
				if (status) {
					status.entrySize = size;
					status.totalCalculatedSize = this.#calculatedSize;
				}
			};
		}
		#removeItemSize = (_i) => {};
		#addItemSize = (_i, _s, _st) => {};
		#requireSize = (_k, _v, size, sizeCalculation) => {
			if (size || sizeCalculation) throw new TypeError("cannot set size without setting maxSize or maxEntrySize on cache");
			return 0;
		};
		*#indexes({ allowStale = this.allowStale } = {}) {
			if (this.#size) for (let i = this.#tail;;) {
				if (!this.#isValidIndex(i)) break;
				if (allowStale || !this.#isStale(i)) yield i;
				if (i === this.#head) break;
				else i = this.#prev[i];
			}
		}
		*#rindexes({ allowStale = this.allowStale } = {}) {
			if (this.#size) for (let i = this.#head;;) {
				if (!this.#isValidIndex(i)) break;
				if (allowStale || !this.#isStale(i)) yield i;
				if (i === this.#tail) break;
				else i = this.#next[i];
			}
		}
		#isValidIndex(index) {
			return index !== void 0 && this.#keyMap.get(this.#keyList[index]) === index;
		}
		/**
		* Return a generator yielding `[key, value]` pairs,
		* in order from most recently used to least recently used.
		*/
		*entries() {
			for (const i of this.#indexes()) if (this.#valList[i] !== void 0 && this.#keyList[i] !== void 0 && !this.#isBackgroundFetch(this.#valList[i])) yield [this.#keyList[i], this.#valList[i]];
		}
		/**
		* Inverse order version of {@link LRUCache.entries}
		*
		* Return a generator yielding `[key, value]` pairs,
		* in order from least recently used to most recently used.
		*/
		*rentries() {
			for (const i of this.#rindexes()) if (this.#valList[i] !== void 0 && this.#keyList[i] !== void 0 && !this.#isBackgroundFetch(this.#valList[i])) yield [this.#keyList[i], this.#valList[i]];
		}
		/**
		* Return a generator yielding the keys in the cache,
		* in order from most recently used to least recently used.
		*/
		*keys() {
			for (const i of this.#indexes()) {
				const k = this.#keyList[i];
				if (k !== void 0 && !this.#isBackgroundFetch(this.#valList[i])) yield k;
			}
		}
		/**
		* Inverse order version of {@link LRUCache.keys}
		*
		* Return a generator yielding the keys in the cache,
		* in order from least recently used to most recently used.
		*/
		*rkeys() {
			for (const i of this.#rindexes()) {
				const k = this.#keyList[i];
				if (k !== void 0 && !this.#isBackgroundFetch(this.#valList[i])) yield k;
			}
		}
		/**
		* Return a generator yielding the values in the cache,
		* in order from most recently used to least recently used.
		*/
		*values() {
			for (const i of this.#indexes()) if (this.#valList[i] !== void 0 && !this.#isBackgroundFetch(this.#valList[i])) yield this.#valList[i];
		}
		/**
		* Inverse order version of {@link LRUCache.values}
		*
		* Return a generator yielding the values in the cache,
		* in order from least recently used to most recently used.
		*/
		*rvalues() {
			for (const i of this.#rindexes()) if (this.#valList[i] !== void 0 && !this.#isBackgroundFetch(this.#valList[i])) yield this.#valList[i];
		}
		/**
		* Iterating over the cache itself yields the same results as
		* {@link LRUCache.entries}
		*/
		[Symbol.iterator]() {
			return this.entries();
		}
		/**
		* A String value that is used in the creation of the default string
		* description of an object. Called by the built-in method
		* `Object.prototype.toString`.
		*/
		[Symbol.toStringTag] = "LRUCache";
		/**
		* Find a value for which the supplied fn method returns a truthy value,
		* similar to `Array.find()`. fn is called as `fn(value, key, cache)`.
		*/
		find(fn, getOptions = {}) {
			for (const i of this.#indexes()) {
				const v = this.#valList[i];
				const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
				if (value === void 0) continue;
				if (fn(value, this.#keyList[i], this)) return this.get(this.#keyList[i], getOptions);
			}
		}
		/**
		* Call the supplied function on each item in the cache, in order from most
		* recently used to least recently used.
		*
		* `fn` is called as `fn(value, key, cache)`.
		*
		* If `thisp` is provided, function will be called in the `this`-context of
		* the provided object, or the cache if no `thisp` object is provided.
		*
		* Does not update age or recenty of use, or iterate over stale values.
		*/
		forEach(fn, thisp = this) {
			for (const i of this.#indexes()) {
				const v = this.#valList[i];
				const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
				if (value === void 0) continue;
				fn.call(thisp, value, this.#keyList[i], this);
			}
		}
		/**
		* The same as {@link LRUCache.forEach} but items are iterated over in
		* reverse order.  (ie, less recently used items are iterated over first.)
		*/
		rforEach(fn, thisp = this) {
			for (const i of this.#rindexes()) {
				const v = this.#valList[i];
				const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
				if (value === void 0) continue;
				fn.call(thisp, value, this.#keyList[i], this);
			}
		}
		/**
		* Delete any stale entries. Returns true if anything was removed,
		* false otherwise.
		*/
		purgeStale() {
			let deleted = false;
			for (const i of this.#rindexes({ allowStale: true })) if (this.#isStale(i)) {
				this.#delete(this.#keyList[i], "expire");
				deleted = true;
			}
			return deleted;
		}
		/**
		* Get the extended info about a given entry, to get its value, size, and
		* TTL info simultaneously. Returns `undefined` if the key is not present.
		*
		* Unlike {@link LRUCache#dump}, which is designed to be portable and survive
		* serialization, the `start` value is always the current timestamp, and the
		* `ttl` is a calculated remaining time to live (negative if expired).
		*
		* Always returns stale values, if their info is found in the cache, so be
		* sure to check for expirations (ie, a negative {@link LRUCache.Entry#ttl})
		* if relevant.
		*/
		info(key) {
			const i = this.#keyMap.get(key);
			if (i === void 0) return void 0;
			const v = this.#valList[i];
			const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
			if (value === void 0) return void 0;
			const entry = { value };
			if (this.#ttls && this.#starts) {
				const ttl = this.#ttls[i];
				const start = this.#starts[i];
				if (ttl && start) {
					entry.ttl = ttl - (perf.now() - start);
					entry.start = Date.now();
				}
			}
			if (this.#sizes) entry.size = this.#sizes[i];
			return entry;
		}
		/**
		* Return an array of [key, {@link LRUCache.Entry}] tuples which can be
		* passed to {@link LRLUCache#load}.
		*
		* The `start` fields are calculated relative to a portable `Date.now()`
		* timestamp, even if `performance.now()` is available.
		*
		* Stale entries are always included in the `dump`, even if
		* {@link LRUCache.OptionsBase.allowStale} is false.
		*
		* Note: this returns an actual array, not a generator, so it can be more
		* easily passed around.
		*/
		dump() {
			const arr = [];
			for (const i of this.#indexes({ allowStale: true })) {
				const key = this.#keyList[i];
				const v = this.#valList[i];
				const value = this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
				if (value === void 0 || key === void 0) continue;
				const entry = { value };
				if (this.#ttls && this.#starts) {
					entry.ttl = this.#ttls[i];
					const age = perf.now() - this.#starts[i];
					entry.start = Math.floor(Date.now() - age);
				}
				if (this.#sizes) entry.size = this.#sizes[i];
				arr.unshift([key, entry]);
			}
			return arr;
		}
		/**
		* Reset the cache and load in the items in entries in the order listed.
		*
		* The shape of the resulting cache may be different if the same options are
		* not used in both caches.
		*
		* The `start` fields are assumed to be calculated relative to a portable
		* `Date.now()` timestamp, even if `performance.now()` is available.
		*/
		load(arr) {
			this.clear();
			for (const [key, entry] of arr) {
				if (entry.start) {
					const age = Date.now() - entry.start;
					entry.start = perf.now() - age;
				}
				this.set(key, entry.value, entry);
			}
		}
		/**
		* Add a value to the cache.
		*
		* Note: if `undefined` is specified as a value, this is an alias for
		* {@link LRUCache#delete}
		*
		* Fields on the {@link LRUCache.SetOptions} options param will override
		* their corresponding values in the constructor options for the scope
		* of this single `set()` operation.
		*
		* If `start` is provided, then that will set the effective start
		* time for the TTL calculation. Note that this must be a previous
		* value of `performance.now()` if supported, or a previous value of
		* `Date.now()` if not.
		*
		* Options object may also include `size`, which will prevent
		* calling the `sizeCalculation` function and just use the specified
		* number if it is a positive integer, and `noDisposeOnSet` which
		* will prevent calling a `dispose` function in the case of
		* overwrites.
		*
		* If the `size` (or return value of `sizeCalculation`) for a given
		* entry is greater than `maxEntrySize`, then the item will not be
		* added to the cache.
		*
		* Will update the recency of the entry.
		*
		* If the value is `undefined`, then this is an alias for
		* `cache.delete(key)`. `undefined` is never stored in the cache.
		*/
		set(k, v, setOptions = {}) {
			if (v === void 0) {
				this.delete(k);
				return this;
			}
			const { ttl = this.ttl, start, noDisposeOnSet = this.noDisposeOnSet, sizeCalculation = this.sizeCalculation, status } = setOptions;
			let { noUpdateTTL = this.noUpdateTTL } = setOptions;
			const size = this.#requireSize(k, v, setOptions.size || 0, sizeCalculation);
			if (this.maxEntrySize && size > this.maxEntrySize) {
				if (status) {
					status.set = "miss";
					status.maxEntrySizeExceeded = true;
				}
				this.#delete(k, "set");
				return this;
			}
			let index = this.#size === 0 ? void 0 : this.#keyMap.get(k);
			if (index === void 0) {
				index = this.#size === 0 ? this.#tail : this.#free.length !== 0 ? this.#free.pop() : this.#size === this.#max ? this.#evict(false) : this.#size;
				this.#keyList[index] = k;
				this.#valList[index] = v;
				this.#keyMap.set(k, index);
				this.#next[this.#tail] = index;
				this.#prev[index] = this.#tail;
				this.#tail = index;
				this.#size++;
				this.#addItemSize(index, size, status);
				if (status) status.set = "add";
				noUpdateTTL = false;
			} else {
				this.#moveToTail(index);
				const oldVal = this.#valList[index];
				if (v !== oldVal) {
					if (this.#hasFetchMethod && this.#isBackgroundFetch(oldVal)) {
						oldVal.__abortController.abort(/* @__PURE__ */ new Error("replaced"));
						const { __staleWhileFetching: s } = oldVal;
						if (s !== void 0 && !noDisposeOnSet) {
							if (this.#hasDispose) this.#dispose?.(s, k, "set");
							if (this.#hasDisposeAfter) this.#disposed?.push([
								s,
								k,
								"set"
							]);
						}
					} else if (!noDisposeOnSet) {
						if (this.#hasDispose) this.#dispose?.(oldVal, k, "set");
						if (this.#hasDisposeAfter) this.#disposed?.push([
							oldVal,
							k,
							"set"
						]);
					}
					this.#removeItemSize(index);
					this.#addItemSize(index, size, status);
					this.#valList[index] = v;
					if (status) {
						status.set = "replace";
						const oldValue = oldVal && this.#isBackgroundFetch(oldVal) ? oldVal.__staleWhileFetching : oldVal;
						if (oldValue !== void 0) status.oldValue = oldValue;
					}
				} else if (status) status.set = "update";
			}
			if (ttl !== 0 && !this.#ttls) this.#initializeTTLTracking();
			if (this.#ttls) {
				if (!noUpdateTTL) this.#setItemTTL(index, ttl, start);
				if (status) this.#statusTTL(status, index);
			}
			if (!noDisposeOnSet && this.#hasDisposeAfter && this.#disposed) {
				const dt = this.#disposed;
				let task;
				while (task = dt?.shift()) this.#disposeAfter?.(...task);
			}
			return this;
		}
		/**
		* Evict the least recently used item, returning its value or
		* `undefined` if cache is empty.
		*/
		pop() {
			try {
				while (this.#size) {
					const val = this.#valList[this.#head];
					this.#evict(true);
					if (this.#isBackgroundFetch(val)) {
						if (val.__staleWhileFetching) return val.__staleWhileFetching;
					} else if (val !== void 0) return val;
				}
			} finally {
				if (this.#hasDisposeAfter && this.#disposed) {
					const dt = this.#disposed;
					let task;
					while (task = dt?.shift()) this.#disposeAfter?.(...task);
				}
			}
		}
		#evict(free) {
			const head = this.#head;
			const k = this.#keyList[head];
			const v = this.#valList[head];
			if (this.#hasFetchMethod && this.#isBackgroundFetch(v)) v.__abortController.abort(/* @__PURE__ */ new Error("evicted"));
			else if (this.#hasDispose || this.#hasDisposeAfter) {
				if (this.#hasDispose) this.#dispose?.(v, k, "evict");
				if (this.#hasDisposeAfter) this.#disposed?.push([
					v,
					k,
					"evict"
				]);
			}
			this.#removeItemSize(head);
			if (free) {
				this.#keyList[head] = void 0;
				this.#valList[head] = void 0;
				this.#free.push(head);
			}
			if (this.#size === 1) {
				this.#head = this.#tail = 0;
				this.#free.length = 0;
			} else this.#head = this.#next[head];
			this.#keyMap.delete(k);
			this.#size--;
			return head;
		}
		/**
		* Check if a key is in the cache, without updating the recency of use.
		* Will return false if the item is stale, even though it is technically
		* in the cache.
		*
		* Check if a key is in the cache, without updating the recency of
		* use. Age is updated if {@link LRUCache.OptionsBase.updateAgeOnHas} is set
		* to `true` in either the options or the constructor.
		*
		* Will return `false` if the item is stale, even though it is technically in
		* the cache. The difference can be determined (if it matters) by using a
		* `status` argument, and inspecting the `has` field.
		*
		* Will not update item age unless
		* {@link LRUCache.OptionsBase.updateAgeOnHas} is set.
		*/
		has(k, hasOptions = {}) {
			const { updateAgeOnHas = this.updateAgeOnHas, status } = hasOptions;
			const index = this.#keyMap.get(k);
			if (index !== void 0) {
				const v = this.#valList[index];
				if (this.#isBackgroundFetch(v) && v.__staleWhileFetching === void 0) return false;
				if (!this.#isStale(index)) {
					if (updateAgeOnHas) this.#updateItemAge(index);
					if (status) {
						status.has = "hit";
						this.#statusTTL(status, index);
					}
					return true;
				} else if (status) {
					status.has = "stale";
					this.#statusTTL(status, index);
				}
			} else if (status) status.has = "miss";
			return false;
		}
		/**
		* Like {@link LRUCache#get} but doesn't update recency or delete stale
		* items.
		*
		* Returns `undefined` if the item is stale, unless
		* {@link LRUCache.OptionsBase.allowStale} is set.
		*/
		peek(k, peekOptions = {}) {
			const { allowStale = this.allowStale } = peekOptions;
			const index = this.#keyMap.get(k);
			if (index === void 0 || !allowStale && this.#isStale(index)) return;
			const v = this.#valList[index];
			return this.#isBackgroundFetch(v) ? v.__staleWhileFetching : v;
		}
		#backgroundFetch(k, index, options, context) {
			const v = index === void 0 ? void 0 : this.#valList[index];
			if (this.#isBackgroundFetch(v)) return v;
			const ac = new AC();
			const { signal } = options;
			signal?.addEventListener("abort", () => ac.abort(signal.reason), { signal: ac.signal });
			const fetchOpts = {
				signal: ac.signal,
				options,
				context
			};
			const cb = (v, updateCache = false) => {
				const { aborted } = ac.signal;
				const ignoreAbort = options.ignoreFetchAbort && v !== void 0;
				if (options.status) {
					if (aborted && !updateCache) {
						options.status.fetchAborted = true;
						options.status.fetchError = ac.signal.reason;
						if (ignoreAbort) options.status.fetchAbortIgnored = true;
					} else options.status.fetchResolved = true;
				}
				if (aborted && !ignoreAbort && !updateCache) return fetchFail(ac.signal.reason);
				const bf = p;
				if (this.#valList[index] === p) {
					if (v === void 0) {
						if (bf.__staleWhileFetching) this.#valList[index] = bf.__staleWhileFetching;
						else this.#delete(k, "fetch");
					} else {
						if (options.status) options.status.fetchUpdated = true;
						this.set(k, v, fetchOpts.options);
					}
				}
				return v;
			};
			const eb = (er) => {
				if (options.status) {
					options.status.fetchRejected = true;
					options.status.fetchError = er;
				}
				return fetchFail(er);
			};
			const fetchFail = (er) => {
				const { aborted } = ac.signal;
				const allowStaleAborted = aborted && options.allowStaleOnFetchAbort;
				const allowStale = allowStaleAborted || options.allowStaleOnFetchRejection;
				const noDelete = allowStale || options.noDeleteOnFetchRejection;
				const bf = p;
				if (this.#valList[index] === p) {
					if (!noDelete || bf.__staleWhileFetching === void 0) this.#delete(k, "fetch");
					else if (!allowStaleAborted) this.#valList[index] = bf.__staleWhileFetching;
				}
				if (allowStale) {
					if (options.status && bf.__staleWhileFetching !== void 0) options.status.returnedStale = true;
					return bf.__staleWhileFetching;
				} else if (bf.__returned === bf) throw er;
			};
			const pcall = (res, rej) => {
				const fmp = this.#fetchMethod?.(k, v, fetchOpts);
				if (fmp && fmp instanceof Promise) fmp.then((v) => res(v === void 0 ? void 0 : v), rej);
				ac.signal.addEventListener("abort", () => {
					if (!options.ignoreFetchAbort || options.allowStaleOnFetchAbort) {
						res(void 0);
						if (options.allowStaleOnFetchAbort) res = (v) => cb(v, true);
					}
				});
			};
			if (options.status) options.status.fetchDispatched = true;
			const p = new Promise(pcall).then(cb, eb);
			const bf = Object.assign(p, {
				__abortController: ac,
				__staleWhileFetching: v,
				__returned: void 0
			});
			if (index === void 0) {
				this.set(k, bf, {
					...fetchOpts.options,
					status: void 0
				});
				index = this.#keyMap.get(k);
			} else this.#valList[index] = bf;
			return bf;
		}
		#isBackgroundFetch(p) {
			if (!this.#hasFetchMethod) return false;
			const b = p;
			return !!b && b instanceof Promise && b.hasOwnProperty("__staleWhileFetching") && b.__abortController instanceof AC;
		}
		async fetch(k, fetchOptions = {}) {
			const { allowStale = this.allowStale, updateAgeOnGet = this.updateAgeOnGet, noDeleteOnStaleGet = this.noDeleteOnStaleGet, ttl = this.ttl, noDisposeOnSet = this.noDisposeOnSet, size = 0, sizeCalculation = this.sizeCalculation, noUpdateTTL = this.noUpdateTTL, noDeleteOnFetchRejection = this.noDeleteOnFetchRejection, allowStaleOnFetchRejection = this.allowStaleOnFetchRejection, ignoreFetchAbort = this.ignoreFetchAbort, allowStaleOnFetchAbort = this.allowStaleOnFetchAbort, context, forceRefresh = false, status, signal } = fetchOptions;
			if (!this.#hasFetchMethod) {
				if (status) status.fetch = "get";
				return this.get(k, {
					allowStale,
					updateAgeOnGet,
					noDeleteOnStaleGet,
					status
				});
			}
			const options = {
				allowStale,
				updateAgeOnGet,
				noDeleteOnStaleGet,
				ttl,
				noDisposeOnSet,
				size,
				sizeCalculation,
				noUpdateTTL,
				noDeleteOnFetchRejection,
				allowStaleOnFetchRejection,
				allowStaleOnFetchAbort,
				ignoreFetchAbort,
				status,
				signal
			};
			let index = this.#keyMap.get(k);
			if (index === void 0) {
				if (status) status.fetch = "miss";
				const p = this.#backgroundFetch(k, index, options, context);
				return p.__returned = p;
			} else {
				const v = this.#valList[index];
				if (this.#isBackgroundFetch(v)) {
					const stale = allowStale && v.__staleWhileFetching !== void 0;
					if (status) {
						status.fetch = "inflight";
						if (stale) status.returnedStale = true;
					}
					return stale ? v.__staleWhileFetching : v.__returned = v;
				}
				const isStale = this.#isStale(index);
				if (!forceRefresh && !isStale) {
					if (status) status.fetch = "hit";
					this.#moveToTail(index);
					if (updateAgeOnGet) this.#updateItemAge(index);
					if (status) this.#statusTTL(status, index);
					return v;
				}
				const p = this.#backgroundFetch(k, index, options, context);
				const staleVal = p.__staleWhileFetching !== void 0 && allowStale;
				if (status) {
					status.fetch = isStale ? "stale" : "refresh";
					if (staleVal && isStale) status.returnedStale = true;
				}
				return staleVal ? p.__staleWhileFetching : p.__returned = p;
			}
		}
		async forceFetch(k, fetchOptions = {}) {
			const v = await this.fetch(k, fetchOptions);
			if (v === void 0) throw new Error("fetch() returned undefined");
			return v;
		}
		memo(k, memoOptions = {}) {
			const memoMethod = this.#memoMethod;
			if (!memoMethod) throw new Error("no memoMethod provided to constructor");
			const { context, forceRefresh, ...options } = memoOptions;
			const v = this.get(k, options);
			if (!forceRefresh && v !== void 0) return v;
			const vv = memoMethod(k, v, {
				options,
				context
			});
			this.set(k, vv, options);
			return vv;
		}
		/**
		* Return a value from the cache. Will update the recency of the cache
		* entry found.
		*
		* If the key is not found, get() will return `undefined`.
		*/
		get(k, getOptions = {}) {
			const { allowStale = this.allowStale, updateAgeOnGet = this.updateAgeOnGet, noDeleteOnStaleGet = this.noDeleteOnStaleGet, status } = getOptions;
			const index = this.#keyMap.get(k);
			if (index !== void 0) {
				const value = this.#valList[index];
				const fetching = this.#isBackgroundFetch(value);
				if (status) this.#statusTTL(status, index);
				if (this.#isStale(index)) {
					if (status) status.get = "stale";
					if (!fetching) {
						if (!noDeleteOnStaleGet) this.#delete(k, "expire");
						if (status && allowStale) status.returnedStale = true;
						return allowStale ? value : void 0;
					} else {
						if (status && allowStale && value.__staleWhileFetching !== void 0) status.returnedStale = true;
						return allowStale ? value.__staleWhileFetching : void 0;
					}
				} else {
					if (status) status.get = "hit";
					if (fetching) return value.__staleWhileFetching;
					this.#moveToTail(index);
					if (updateAgeOnGet) this.#updateItemAge(index);
					return value;
				}
			} else if (status) status.get = "miss";
		}
		#connect(p, n) {
			this.#prev[n] = p;
			this.#next[p] = n;
		}
		#moveToTail(index) {
			if (index !== this.#tail) {
				if (index === this.#head) this.#head = this.#next[index];
				else this.#connect(this.#prev[index], this.#next[index]);
				this.#connect(this.#tail, index);
				this.#tail = index;
			}
		}
		/**
		* Deletes a key out of the cache.
		*
		* Returns true if the key was deleted, false otherwise.
		*/
		delete(k) {
			return this.#delete(k, "delete");
		}
		#delete(k, reason) {
			let deleted = false;
			if (this.#size !== 0) {
				const index = this.#keyMap.get(k);
				if (index !== void 0) {
					deleted = true;
					if (this.#size === 1) this.#clear(reason);
					else {
						this.#removeItemSize(index);
						const v = this.#valList[index];
						if (this.#isBackgroundFetch(v)) v.__abortController.abort(/* @__PURE__ */ new Error("deleted"));
						else if (this.#hasDispose || this.#hasDisposeAfter) {
							if (this.#hasDispose) this.#dispose?.(v, k, reason);
							if (this.#hasDisposeAfter) this.#disposed?.push([
								v,
								k,
								reason
							]);
						}
						this.#keyMap.delete(k);
						this.#keyList[index] = void 0;
						this.#valList[index] = void 0;
						if (index === this.#tail) this.#tail = this.#prev[index];
						else if (index === this.#head) this.#head = this.#next[index];
						else {
							const pi = this.#prev[index];
							this.#next[pi] = this.#next[index];
							const ni = this.#next[index];
							this.#prev[ni] = this.#prev[index];
						}
						this.#size--;
						this.#free.push(index);
					}
				}
			}
			if (this.#hasDisposeAfter && this.#disposed?.length) {
				const dt = this.#disposed;
				let task;
				while (task = dt?.shift()) this.#disposeAfter?.(...task);
			}
			return deleted;
		}
		/**
		* Clear the cache entirely, throwing away all values.
		*/
		clear() {
			return this.#clear("delete");
		}
		#clear(reason) {
			for (const index of this.#rindexes({ allowStale: true })) {
				const v = this.#valList[index];
				if (this.#isBackgroundFetch(v)) v.__abortController.abort(/* @__PURE__ */ new Error("deleted"));
				else {
					const k = this.#keyList[index];
					if (this.#hasDispose) this.#dispose?.(v, k, reason);
					if (this.#hasDisposeAfter) this.#disposed?.push([
						v,
						k,
						reason
					]);
				}
			}
			this.#keyMap.clear();
			this.#valList.fill(void 0);
			this.#keyList.fill(void 0);
			if (this.#ttls && this.#starts) {
				this.#ttls.fill(0);
				this.#starts.fill(0);
			}
			if (this.#sizes) this.#sizes.fill(0);
			this.#head = 0;
			this.#tail = 0;
			this.#free.length = 0;
			this.#calculatedSize = 0;
			this.#size = 0;
			if (this.#hasDisposeAfter && this.#disposed) {
				const dt = this.#disposed;
				let task;
				while (task = dt?.shift()) this.#disposeAfter?.(...task);
			}
		}
	};
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/utils.js
var require_utils = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.makeObjectWithoutPrototype = exports.isObject = exports.isEmptyObject = exports.isEmpty = exports.isDate = exports.hasOwnProperty = void 0;
	var isDate = (d) => d instanceof Date;
	exports.isDate = isDate;
	var isEmpty = (o) => Object.keys(o).length === 0;
	exports.isEmpty = isEmpty;
	var isObject = (o) => o != null && typeof o === "object";
	exports.isObject = isObject;
	var hasOwnProperty = (o, ...args) => Object.prototype.hasOwnProperty.call(o, ...args);
	exports.hasOwnProperty = hasOwnProperty;
	var isEmptyObject = (o) => isObject(o) && isEmpty(o);
	exports.isEmptyObject = isEmptyObject;
	var makeObjectWithoutPrototype = () => Object.create(null);
	exports.makeObjectWithoutPrototype = makeObjectWithoutPrototype;
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/diff.js
var require_diff = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = void 0;
	var _utils = require_utils();
	var diff = (lhs, rhs) => {
		if (lhs === rhs) return {};
		if (!(0, _utils.isObject)(lhs) || !(0, _utils.isObject)(rhs)) return rhs;
		const deletedValues = Object.keys(lhs).reduce((acc, key) => {
			if (!(0, _utils.hasOwnProperty)(rhs, key)) acc[key] = void 0;
			return acc;
		}, (0, _utils.makeObjectWithoutPrototype)());
		if ((0, _utils.isDate)(lhs) || (0, _utils.isDate)(rhs)) {
			if (lhs.valueOf() == rhs.valueOf()) return {};
			return rhs;
		}
		return Object.keys(rhs).reduce((acc, key) => {
			if (!(0, _utils.hasOwnProperty)(lhs, key)) {
				acc[key] = rhs[key];
				return acc;
			}
			const difference = diff(lhs[key], rhs[key]);
			if ((0, _utils.isEmptyObject)(difference) && !(0, _utils.isDate)(difference) && ((0, _utils.isEmptyObject)(lhs[key]) || !(0, _utils.isEmptyObject)(rhs[key]))) return acc;
			acc[key] = difference;
			return acc;
		}, deletedValues);
	};
	exports.default = diff;
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/added.js
var require_added = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = void 0;
	var _utils = require_utils();
	var addedDiff = (lhs, rhs) => {
		if (lhs === rhs || !(0, _utils.isObject)(lhs) || !(0, _utils.isObject)(rhs)) return {};
		return Object.keys(rhs).reduce((acc, key) => {
			if ((0, _utils.hasOwnProperty)(lhs, key)) {
				const difference = addedDiff(lhs[key], rhs[key]);
				if ((0, _utils.isObject)(difference) && (0, _utils.isEmpty)(difference)) return acc;
				acc[key] = difference;
				return acc;
			}
			acc[key] = rhs[key];
			return acc;
		}, (0, _utils.makeObjectWithoutPrototype)());
	};
	exports.default = addedDiff;
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/deleted.js
var require_deleted = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = void 0;
	var _utils = require_utils();
	var deletedDiff = (lhs, rhs) => {
		if (lhs === rhs || !(0, _utils.isObject)(lhs) || !(0, _utils.isObject)(rhs)) return {};
		return Object.keys(lhs).reduce((acc, key) => {
			if ((0, _utils.hasOwnProperty)(rhs, key)) {
				const difference = deletedDiff(lhs[key], rhs[key]);
				if ((0, _utils.isObject)(difference) && (0, _utils.isEmpty)(difference)) return acc;
				acc[key] = difference;
				return acc;
			}
			acc[key] = void 0;
			return acc;
		}, (0, _utils.makeObjectWithoutPrototype)());
	};
	exports.default = deletedDiff;
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/updated.js
var require_updated = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = void 0;
	var _utils = require_utils();
	var updatedDiff = (lhs, rhs) => {
		if (lhs === rhs) return {};
		if (!(0, _utils.isObject)(lhs) || !(0, _utils.isObject)(rhs)) return rhs;
		if ((0, _utils.isDate)(lhs) || (0, _utils.isDate)(rhs)) {
			if (lhs.valueOf() == rhs.valueOf()) return {};
			return rhs;
		}
		return Object.keys(rhs).reduce((acc, key) => {
			if ((0, _utils.hasOwnProperty)(lhs, key)) {
				const difference = updatedDiff(lhs[key], rhs[key]);
				if ((0, _utils.isEmptyObject)(difference) && !(0, _utils.isDate)(difference) && ((0, _utils.isEmptyObject)(lhs[key]) || !(0, _utils.isEmptyObject)(rhs[key]))) return acc;
				acc[key] = difference;
				return acc;
			}
			return acc;
		}, (0, _utils.makeObjectWithoutPrototype)());
	};
	exports.default = updatedDiff;
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/detailed.js
var require_detailed = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	exports.default = void 0;
	var _added = _interopRequireDefault(require_added());
	var _deleted = _interopRequireDefault(require_deleted());
	var _updated = _interopRequireDefault(require_updated());
	function _interopRequireDefault(obj) {
		return obj && obj.__esModule ? obj : { default: obj };
	}
	var detailedDiff = (lhs, rhs) => ({
		added: (0, _added.default)(lhs, rhs),
		deleted: (0, _deleted.default)(lhs, rhs),
		updated: (0, _updated.default)(lhs, rhs)
	});
	exports.default = detailedDiff;
}));
//#endregion
//#region node_modules/deep-object-diff/cjs/index.js
var require_cjs = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	Object.defineProperty(exports, "addedDiff", {
		enumerable: true,
		get: function() {
			return _added.default;
		}
	});
	Object.defineProperty(exports, "deletedDiff", {
		enumerable: true,
		get: function() {
			return _deleted.default;
		}
	});
	Object.defineProperty(exports, "detailedDiff", {
		enumerable: true,
		get: function() {
			return _detailed.default;
		}
	});
	Object.defineProperty(exports, "diff", {
		enumerable: true,
		get: function() {
			return _diff.default;
		}
	});
	Object.defineProperty(exports, "updatedDiff", {
		enumerable: true,
		get: function() {
			return _updated.default;
		}
	});
	var _diff = _interopRequireDefault(require_diff());
	var _added = _interopRequireDefault(require_added());
	var _deleted = _interopRequireDefault(require_deleted());
	var _updated = _interopRequireDefault(require_updated());
	var _detailed = _interopRequireDefault(require_detailed());
	function _interopRequireDefault(obj) {
		return obj && obj.__esModule ? obj : { default: obj };
	}
}));
//#endregion
//#region node_modules/picocolors/picocolors.js
var require_picocolors = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	var p = process || {};
	var argv = p.argv || [];
	var env = p.env || {};
	var isColorSupported = !(!!env.NO_COLOR || argv.includes("--no-color")) && (!!env.FORCE_COLOR || argv.includes("--color") || p.platform === "win32" || (p.stdout || {}).isTTY && env.TERM !== "dumb" || !!env.CI);
	var formatter = (open, close, replace = open) => (input) => {
		let string = "" + input, index = string.indexOf(close, open.length);
		return ~index ? open + replaceClose(string, close, replace, index) + close : open + string + close;
	};
	var replaceClose = (string, close, replace, index) => {
		let result = "", cursor = 0;
		do {
			result += string.substring(cursor, index) + replace;
			cursor = index + close.length;
			index = string.indexOf(close, cursor);
		} while (~index);
		return result + string.substring(cursor);
	};
	var createColors = (enabled = isColorSupported) => {
		let f = enabled ? formatter : () => String;
		return {
			isColorSupported: enabled,
			reset: f("\x1B[0m", "\x1B[0m"),
			bold: f("\x1B[1m", "\x1B[22m", "\x1B[22m\x1B[1m"),
			dim: f("\x1B[2m", "\x1B[22m", "\x1B[22m\x1B[2m"),
			italic: f("\x1B[3m", "\x1B[23m"),
			underline: f("\x1B[4m", "\x1B[24m"),
			inverse: f("\x1B[7m", "\x1B[27m"),
			hidden: f("\x1B[8m", "\x1B[28m"),
			strikethrough: f("\x1B[9m", "\x1B[29m"),
			black: f("\x1B[30m", "\x1B[39m"),
			red: f("\x1B[31m", "\x1B[39m"),
			green: f("\x1B[32m", "\x1B[39m"),
			yellow: f("\x1B[33m", "\x1B[39m"),
			blue: f("\x1B[34m", "\x1B[39m"),
			magenta: f("\x1B[35m", "\x1B[39m"),
			cyan: f("\x1B[36m", "\x1B[39m"),
			white: f("\x1B[37m", "\x1B[39m"),
			gray: f("\x1B[90m", "\x1B[39m"),
			bgBlack: f("\x1B[40m", "\x1B[49m"),
			bgRed: f("\x1B[41m", "\x1B[49m"),
			bgGreen: f("\x1B[42m", "\x1B[49m"),
			bgYellow: f("\x1B[43m", "\x1B[49m"),
			bgBlue: f("\x1B[44m", "\x1B[49m"),
			bgMagenta: f("\x1B[45m", "\x1B[49m"),
			bgCyan: f("\x1B[46m", "\x1B[49m"),
			bgWhite: f("\x1B[47m", "\x1B[49m"),
			blackBright: f("\x1B[90m", "\x1B[39m"),
			redBright: f("\x1B[91m", "\x1B[39m"),
			greenBright: f("\x1B[92m", "\x1B[39m"),
			yellowBright: f("\x1B[93m", "\x1B[39m"),
			blueBright: f("\x1B[94m", "\x1B[39m"),
			magentaBright: f("\x1B[95m", "\x1B[39m"),
			cyanBright: f("\x1B[96m", "\x1B[39m"),
			whiteBright: f("\x1B[97m", "\x1B[39m"),
			bgBlackBright: f("\x1B[100m", "\x1B[49m"),
			bgRedBright: f("\x1B[101m", "\x1B[49m"),
			bgGreenBright: f("\x1B[102m", "\x1B[49m"),
			bgYellowBright: f("\x1B[103m", "\x1B[49m"),
			bgBlueBright: f("\x1B[104m", "\x1B[49m"),
			bgMagentaBright: f("\x1B[105m", "\x1B[49m"),
			bgCyanBright: f("\x1B[106m", "\x1B[49m"),
			bgWhiteBright: f("\x1B[107m", "\x1B[49m")
		};
	};
	module.exports = createColors();
	module.exports.createColors = createColors;
}));
//#endregion
//#region node_modules/deepmerge-ts/dist/index.cjs
var require_dist = /* @__PURE__ */ __commonJSMin(((exports) => {
	/**
	* Special values that tell deepmerge to perform a certain action.
	*/
	var actions = {
		defaultMerge: Symbol("deepmerge-ts: default merge"),
		skip: Symbol("deepmerge-ts: skip")
	};
	/**
	* Special values that tell deepmergeInto to perform a certain action.
	*/
	var actionsInto = { defaultMerge: actions.defaultMerge };
	/**
	* Returns an empty container of the same outward type as `value`. Used when
	* `deepmergeInto` recurses through a property the target does not have, so
	* the recursion has a place to write its result without aliasing any source's
	* nested array/set/map.
	*
	* @param value - A representative value (the kind to copy structurally).
	* @returns A fresh `Array` / `Set` / `Map` / `Record` (or `value` itself if it
	* is not one of those types).
	*/
	function emptyLike(value) {
		if (Array.isArray(value)) return [];
		if (value instanceof Set) return /* @__PURE__ */ new Set();
		if (value instanceof Map) return /* @__PURE__ */ new Map();
		if (typeof value === "object" && value !== null) return {};
		return value;
	}
	/**
	* The default function to update meta data.
	*
	* It builds and updates the hierarchy tree.
	*
	* @param previousMeta - The previous meta data.
	* @param mergeInfo - Meta information about the current merge state.
	* @returns The updated meta data.
	*/
	function defaultMetaDataUpdater(previousMeta, mergeInfo) {
		const ancestor = {
			key: mergeInfo.key,
			parents: mergeInfo.parents,
			values: mergeInfo.values,
			result: mergeInfo.result
		};
		const prevHierarchy = previousMeta?.hierarchy;
		return {
			...ancestor,
			hierarchy: prevHierarchy === void 0 ? [ancestor] : [...prevHierarchy, ancestor]
		};
	}
	/**
	* The default function to update meta data in fast mode.
	*
	* It doesn't track any meta data.
	*
	* @param previousMeta - The previous meta data.
	* @param mergeInfo - Meta information about the current merge state.
	* @returns The updated meta data (undefined).
	*/
	function defaultMetaDataUpdaterFast(previousMeta, mergeInfo) {}
	/**
	* The default function to filter values.
	*
	* It filters out undefined values.
	*
	* @param values - The values to filter.
	* @param meta - The meta data.
	* @returns The filtered values.
	*/
	function defaultFilterValues(values, meta) {
		return values.includes(void 0) ? values.filter((value) => value !== void 0) : values;
	}
	/**
	* Check if the custom merge result should fall back to the default merge function.
	*
	* @param utils - The utils.
	* @param fallback - The name of the fallback merge function.
	* @param result - The result of the custom merge function.
	* @returns Whether to use the default merge function.
	*/
	function shouldFallbackToDefault(utils, fallback, result) {
		return result === actions.defaultMerge || utils.useImplicitDefaultMerging && result === void 0 && utils.mergeFunctions[fallback] !== utils.defaultMergeFunctions[fallback];
	}
	/**
	* Resolve custom merge functions from user options.
	*
	* @param options - The options passed by the user.
	* @param defaultMergeFunctions - The default merge functions.
	* @returns The resolved merge functions.
	*/
	function resolveCustomMergeFunctions(options, defaultMergeFunctions) {
		return {
			...defaultMergeFunctions,
			...Object.fromEntries(Object.entries(options).filter(([key]) => Object.hasOwn(defaultMergeFunctions, key)).map(([key, option]) => option === false ? [key, defaultMergeFunctions.mergeOthers] : typeof option === "function" ? [key, option] : [key, defaultMergeFunctions[key]]))
		};
	}
	/**
	* The default strategy to merge arrays.
	*
	* @param values - The arrays.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged array.
	*/
	function mergeArrays$1(values, utils, meta) {
		return values.flat();
	}
	/**
	* The default strategy to merge sets.
	*
	* @param values - The sets.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged set.
	*/
	function mergeSets$1(values, utils, meta) {
		const result = /* @__PURE__ */ new Set();
		for (const set of values) for (const element of set) result.add(element);
		return result;
	}
	/**
	* The default strategy to merge other things.
	*
	* @param values - The other things.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged value.
	*/
	function mergeOthers$1(values, utils, meta) {
		return values.at(-1);
	}
	/**
	* The default strategy to merge arrays into a target array.
	*
	* @param mut_target - The target to merge into.
	* @param values - The arrays (including the target's value if there is one).
	*/
	function mergeArraysInto$1(mut_target, values) {
		const result = [];
		for (const value of values) {
			const arr = value;
			for (const element of arr) result.push(element);
		}
		const target = mut_target.value;
		target.splice(0, target.length, ...result);
	}
	/**
	* The default strategy to merge sets into a target set.
	*
	* @param mut_target - The target to merge into.
	* @param values - The sets (including the target's value if there is one).
	*/
	function mergeSetsInto$1(mut_target, values) {
		const result = /* @__PURE__ */ new Set();
		for (const value_ of values) for (const value of value_) result.add(value);
		const target = mut_target.value;
		target.clear();
		for (const value of result) target.add(value);
	}
	/**
	* The default strategy to merge other things into a target.
	*
	* @param mut_target - The target to merge into.
	* @param values - The other things.
	*/
	function mergeOthersInto$1(mut_target, values) {
		mut_target.value = values.at(-1);
	}
	/**
	* The different types of objects deepmerge-ts support.
	*/
	var ObjectType;
	(function(ObjectType) {
		ObjectType[ObjectType["NOT"] = 0] = "NOT";
		ObjectType[ObjectType["RECORD"] = 1] = "RECORD";
		ObjectType[ObjectType["ARRAY"] = 2] = "ARRAY";
		ObjectType[ObjectType["SET"] = 3] = "SET";
		ObjectType[ObjectType["MAP"] = 4] = "MAP";
		ObjectType[ObjectType["OTHER"] = 5] = "OTHER";
	})(ObjectType || (ObjectType = {}));
	/**
	* Get the type of the given object.
	*
	* @param object - The object to get the type of.
	* @returns The type of the given object.
	*/
	function getObjectType(object) {
		if (typeof object !== "object" || object === null) return ObjectType.NOT;
		if (Array.isArray(object)) return ObjectType.ARRAY;
		if (isRecord(object)) return ObjectType.RECORD;
		if (object instanceof Set) return ObjectType.SET;
		if (object instanceof Map) return ObjectType.MAP;
		return ObjectType.OTHER;
	}
	/**
	* Get the keys of the given object(s) including symbol keys.
	* If an array is given, the keys of all the objects within the array are returned.
	*
	* Note: Only keys to enumerable properties are returned.
	*
	* @deprecated Use `getKeysOfObjects` instead.
	* @param objects - An array of objects to get the keys of.
	* @returns A set containing all the keys of all the given objects.
	*/
	var getKeys = getKeysOfObjects;
	/**
	* Get the keys of the given objects including symbol keys.
	*
	* Note: Only keys to enumerable properties are returned.
	*
	* @param objects - An array of objects to get the keys of.
	* @returns A set containing all the keys of all the given objects.
	*/
	function getKeysOfObjects(objects) {
		const keys = /* @__PURE__ */ new Set();
		for (const currentObject of objects) {
			const stringKeys = Object.keys(currentObject);
			for (const stringKey of stringKeys) keys.add(stringKey);
			const symbols = Object.getOwnPropertySymbols(currentObject);
			if (symbols.length > 0) {
				for (const symbol of symbols) if (Object.prototype.propertyIsEnumerable.call(currentObject, symbol)) keys.add(symbol);
			}
		}
		return keys;
	}
	/**
	* Get the keys of the given object.
	*
	* Note: Only keys to enumerable properties are returned.
	*
	* @param object - The object to get the keys of.
	* @returns The keys of the given object.
	*/
	function getKeysOfObject(object) {
		const symbols = Object.getOwnPropertySymbols(object).filter((symbol) => Object.prototype.propertyIsEnumerable.call(object, symbol));
		return [...Object.keys(object), ...symbols];
	}
	/**
	* Does the given object have the given property.
	*
	* @param object - The object to test.
	* @param property - The property to test.
	* @returns Whether the object has the property.
	*/
	function objectHasProperty(object, property) {
		return typeof object === "object" && Object.prototype.propertyIsEnumerable.call(object, property);
	}
	/**
	* Does the given object appear to be a record.
	*
	* @param value - The object to check.
	* @returns Whether the object is a record.
	*/
	function isRecord(value) {
		const prototype = Object.getPrototypeOf(value);
		if (prototype === null || prototype === Object.prototype) return true;
		const objectToString = Object.prototype.toString.call(value);
		if (objectToString !== "[object Object]" && objectToString !== "[object Module]") return false;
		const { constructor } = value;
		if (constructor === void 0) return true;
		const constructorPrototype = constructor.prototype;
		if (constructorPrototype === null || typeof constructorPrototype !== "object") return false;
		const constructorToString = Object.prototype.toString.call(constructorPrototype);
		if (constructorToString !== "[object Object]" && constructorToString !== "[object Module]") return false;
		if (!Object.hasOwn(constructorPrototype, "isPrototypeOf")) return false;
		return true;
	}
	/**
	* If the given object is a cyclic reference in its ancestor tree, return how far down the ancestor tree the object is from its first occurrence. Otherwise, return 0.
	*
	* @param object - The object to check.
	* @param hierarchy - The hierarchy of the object.
	* @param index - The index of the object (or ancestor of) within the original values passed to the merge function.
	* @returns The cyclic reference depth of the object if it is a cyclic reference, or 0 if it is not.
	*/
	function getCyclicReferenceDepth(object, hierarchy, index) {
		if (hierarchy === void 0 || hierarchy.length === 0) return 0;
		let mut_depth = 1;
		for (let mut_index = hierarchy.length - 1; mut_index >= 0; mut_index--) {
			const { parents } = hierarchy[mut_index];
			if (parents[index] === object || parents.includes(object)) return mut_depth;
			mut_depth += 1;
		}
		return 0;
	}
	/**
	* Get the hierarchy array from the given meta data if present.
	*
	* @param meta - The meta data.
	* @returns The hierarchy array or undefined.
	*/
	function getMetaDataHierarchy(meta) {
		return meta?.hierarchy;
	}
	/**
	* The default strategy to merge records.
	*
	* @param values - The records.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged records.
	*/
	function mergeRecords$1(values, utils, meta) {
		if (values.length === 2) {
			const result = {};
			const mergeProperty = (key, propValues) => {
				const propertyResult = mergeUnknowns(propValues, utils, utils.metaDataUpdater(meta, {
					key,
					parents: values,
					values: propValues,
					result
				}));
				if (propertyResult === actions.skip) return;
				if (key === "__proto__") Object.defineProperty(result, key, {
					value: propertyResult,
					configurable: true,
					enumerable: true,
					writable: true
				});
				else result[key] = propertyResult;
			};
			const firstValue = values[0];
			const secondValue = values[1];
			for (const key of getKeysOfObject(firstValue)) mergeProperty(key, objectHasProperty(secondValue, key) ? [firstValue[key], secondValue[key]] : [firstValue[key]]);
			for (const key of getKeysOfObject(secondValue)) if (!objectHasProperty(firstValue, key)) mergeProperty(key, [secondValue[key]]);
			return result;
		}
		return mergeRecordsGeneral(values, utils, meta);
	}
	/**
	* The default strategy to merge 3 or more records.
	*
	* @param values - The records.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged records.
	*/
	function mergeRecordsGeneral(values, utils, meta) {
		const result = {};
		for (const key of getKeysOfObjects(values)) {
			const propValues = [];
			for (const value of values) if (objectHasProperty(value, key)) propValues.push(value[key]);
			const propertyResult = mergeUnknowns(propValues, utils, utils.metaDataUpdater(meta, {
				key,
				parents: values,
				values: propValues,
				result
			}));
			if (propertyResult === actions.skip) continue;
			if (key === "__proto__") Object.defineProperty(result, key, {
				value: propertyResult,
				configurable: true,
				enumerable: true,
				writable: true
			});
			else result[key] = propertyResult;
		}
		return result;
	}
	/**
	* The default strategy to merge maps.
	*
	* @param values - The maps.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged map.
	*/
	function mergeMaps$1(values, utils, meta) {
		const result = /* @__PURE__ */ new Map();
		const valuesByKey = /* @__PURE__ */ new Map();
		for (const map of values) for (const [key, value] of map) {
			const mut_keyValues = valuesByKey.get(key);
			if (mut_keyValues === void 0) valuesByKey.set(key, [value]);
			else mut_keyValues.push(value);
		}
		for (const [key, keyValues] of valuesByKey) {
			const keyResult = mergeUnknowns(keyValues, utils, utils.metaDataUpdater(meta, {
				key,
				parents: values,
				values: keyValues,
				result
			}));
			if (keyResult === actions.skip) continue;
			result.set(key, keyResult);
		}
		return result;
	}
	/**
	* Resolve any cyclic references within a non-cyclic object pointing to ancestors in meta.hierarchy.
	*
	* @param value - The value to resolve circular references for.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The resolved value.
	*/
	function resolveCyclicReferences(value, utils, meta) {
		if (typeof value !== "object" || value === null) return value;
		const hierarchy = getMetaDataHierarchy(meta);
		const depth = getCyclicReferenceDepth(value, hierarchy, 0);
		if (hierarchy !== void 0 && depth > 0) return hierarchy[hierarchy.length - depth]?.result;
		if (getObjectType(value) === ObjectType.RECORD) {
			const record = value;
			let mut_changed = false;
			const result = {};
			for (const key of getKeysOfObject(record)) {
				const propVal = record[key];
				const resolvedProp = resolveCyclicReferences(propVal, utils, utils.metaDataUpdater(meta, {
					key,
					parents: [record],
					values: [propVal],
					result
				}));
				if (resolvedProp !== propVal) mut_changed = true;
				if (key === "__proto__") Object.defineProperty(result, key, {
					value: resolvedProp,
					configurable: true,
					enumerable: true,
					writable: true
				});
				else result[key] = resolvedProp;
			}
			return mut_changed ? result : value;
		}
		return value;
	}
	/**
	* The default strategy to merge circular references.
	*
	* @param values - The circular references.
	* @param cyclicDepths - The depth of each circular reference.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged circular references.
	*/
	function mergeCircularReferences$1(values, cyclicDepths, utils, meta) {
		const depth = cyclicDepths[0];
		const hierarchy = getMetaDataHierarchy(meta);
		for (let mut_index = 1; mut_index < values.length; mut_index++) if (cyclicDepths[mut_index] !== depth) {
			const lastCyclicDepth = cyclicDepths.at(-1);
			return lastCyclicDepth === 0 ? resolveCyclicReferences(values.at(-1), utils, meta) : hierarchy?.[hierarchy.length - lastCyclicDepth]?.result;
		}
		return hierarchy?.[hierarchy.length - depth]?.result;
	}
	/**
	* The merge functions.
	*/
	var mergeFunctions = {
		mergeRecords: mergeRecords$1,
		mergeArrays: mergeArrays$1,
		mergeSets: mergeSets$1,
		mergeMaps: mergeMaps$1,
		mergeCircularReferences: mergeCircularReferences$1,
		mergeOthers: mergeOthers$1
	};
	var defaultDeepmerge = /* #__PURE__ */ deepmergeCustom();
	/**
	* Deeply merge objects.
	*
	* @param objects - The objects to merge.
	* @returns The merged result.
	*/
	function deepmerge(...objects) {
		return defaultDeepmerge(...objects);
	}
	function deepmergeCustom(options = {}, rootMetaData) {
		const utils = getUtils$1(options, customizedDeepmerge);
		/**
		* The customized deepmerge function.
		*
		* @param objects - The objects to merge.
		* @returns The merged result.
		*/
		function customizedDeepmerge(...objects) {
			return mergeUnknowns(objects, utils, rootMetaData ?? void 0);
		}
		return customizedDeepmerge;
	}
	/**
	* Get the utils that are available to the merge functions.
	*
	* @param options - The options the user specified.
	* @param customizedDeepmerge - The customized deepmerge function.
	* @returns The merge utils.
	*/
	function getUtils$1(options, customizedDeepmerge) {
		const defaultMergeFns = mergeFunctions;
		const defaultMetaDataUpd = defaultMetaDataUpdater;
		return {
			defaultMergeFunctions: defaultMergeFns,
			mergeFunctions: resolveCustomMergeFunctions(options, defaultMergeFns),
			metaDataUpdater: typeof options.metaDataUpdater === "function" ? options.metaDataUpdater : defaultMetaDataUpd,
			deepmerge: customizedDeepmerge,
			useImplicitDefaultMerging: options.enableImplicitDefaultMerging ?? false,
			filterValues: options.filterValues === false ? void 0 : typeof options.filterValues === "function" ? options.filterValues : defaultFilterValues,
			maxDepth: typeof options.maxDepth === "number" && !Number.isNaN(options.maxDepth) && options.maxDepth >= 0 ? options.maxDepth : 1e3,
			actions
		};
	}
	/**
	* Merge unknown things.
	*
	* @param values - The values.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeUnknowns(values, utils, meta) {
		const filteredValues = utils.filterValues?.(values, meta) ?? values;
		if (filteredValues.length === 0) return;
		const hierarchy = getMetaDataHierarchy(meta);
		const currentDepth = hierarchy?.length ?? (typeof meta === "number" ? meta : meta?.depth ?? 0);
		if (utils.maxDepth !== void 0 && currentDepth >= utils.maxDepth) return mergeOthers(filteredValues, utils, meta);
		if (filteredValues.length === 1) {
			if (hierarchy !== void 0) {
				const depth = getCyclicReferenceDepth(filteredValues[0], hierarchy, 0);
				if (depth > 0) return hierarchy[hierarchy.length - depth]?.result ?? hierarchy[hierarchy.length - depth]?.parents[0];
			}
			return mergeOthers(filteredValues, utils, meta);
		}
		const type = getObjectType(filteredValues[0]);
		if (type !== ObjectType.NOT && type !== ObjectType.OTHER) {
			if (filteredValues.length === 2) {
				if (getObjectType(filteredValues[1]) !== type) return mergeOthers(filteredValues, utils, meta);
				const d0 = getCyclicReferenceDepth(filteredValues[0], hierarchy, 0);
				const d1 = getCyclicReferenceDepth(filteredValues[1], hierarchy, 1);
				if (d0 !== 0 || d1 !== 0) return mergeCircularReferences(filteredValues, [d0, d1], utils, meta);
			} else {
				const cyclicDepths = new Array(filteredValues.length);
				cyclicDepths[0] = getCyclicReferenceDepth(filteredValues[0], hierarchy, 0);
				for (let mut_index = 1; mut_index < filteredValues.length; mut_index++) {
					if (getObjectType(filteredValues[mut_index]) !== type) return mergeOthers(filteredValues, utils, meta);
					cyclicDepths[mut_index] = getCyclicReferenceDepth(filteredValues[mut_index], hierarchy, mut_index);
				}
				if (cyclicDepths.some((depth) => depth !== 0)) return mergeCircularReferences(filteredValues, cyclicDepths, utils, meta);
			}
		}
		switch (type) {
			case ObjectType.RECORD: return mergeRecords(filteredValues, utils, meta);
			case ObjectType.ARRAY: return mergeArrays(filteredValues, utils, meta);
			case ObjectType.SET: return mergeSets(filteredValues, utils, meta);
			case ObjectType.MAP: return mergeMaps(filteredValues, utils, meta);
			default: return mergeOthers(filteredValues, utils, meta);
		}
	}
	/**
	* Merge records.
	*
	* @param values - The records.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeRecords(values, utils, meta) {
		const result = utils.mergeFunctions.mergeRecords(values, utils, meta);
		if (shouldFallbackToDefault(utils, "mergeRecords", result)) return utils.defaultMergeFunctions.mergeRecords(values, utils, meta);
		return result;
	}
	/**
	* Merge arrays.
	*
	* @param values - The arrays.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeArrays(values, utils, meta) {
		const result = utils.mergeFunctions.mergeArrays(values, utils, meta);
		if (shouldFallbackToDefault(utils, "mergeArrays", result)) return utils.defaultMergeFunctions.mergeArrays(values);
		return result;
	}
	/**
	* Merge sets.
	*
	* @param values - The sets.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeSets(values, utils, meta) {
		const result = utils.mergeFunctions.mergeSets(values, utils, meta);
		if (shouldFallbackToDefault(utils, "mergeSets", result)) return utils.defaultMergeFunctions.mergeSets(values);
		return result;
	}
	/**
	* Merge maps.
	*
	* @param values - The maps.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeMaps(values, utils, meta) {
		const result = utils.mergeFunctions.mergeMaps(values, utils, meta);
		if (shouldFallbackToDefault(utils, "mergeMaps", result)) return utils.defaultMergeFunctions.mergeMaps(values, utils, meta);
		return result;
	}
	/**
	* Merge circular references.
	*
	* @param values - The circular references.
	* @param cyclicDepths - The depth of each circular reference.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeCircularReferences(values, cyclicDepths, utils, meta) {
		const result = utils.mergeFunctions.mergeCircularReferences(values, cyclicDepths, utils, meta);
		if (shouldFallbackToDefault(utils, "mergeCircularReferences", result)) return utils.defaultMergeFunctions.mergeCircularReferences(values, cyclicDepths, utils, meta);
		return result;
	}
	/**
	* Merge other things.
	*
	* @param values - The other things.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The merged result.
	*/
	function mergeOthers(values, utils, meta) {
		const result = utils.mergeFunctions.mergeOthers(values, utils, meta);
		if (shouldFallbackToDefault(utils, "mergeOthers", result)) return utils.defaultMergeFunctions.mergeOthers(values);
		return result;
	}
	/**
	* The fast default strategy to merge records without circular reference checks or depth limits.
	*
	* Assumes input is trusted and non-circular.
	*
	* @param values - The records.
	* @param utils - The utils.
	* @returns The merged records.
	*/
	function mergeRecordsFast$1(values, utils) {
		if (values.length === 2) {
			const result = {};
			const mergeProperty = (key, propValues) => {
				const propertyResult = mergeUnknownsFast(propValues, utils);
				if (propertyResult === actions.skip) return;
				result[key] = propertyResult;
			};
			const firstValue = values[0];
			const secondValue = values[1];
			for (const key of getKeysOfObject(firstValue)) mergeProperty(key, objectHasProperty(secondValue, key) ? [firstValue[key], secondValue[key]] : [firstValue[key]]);
			for (const key of getKeysOfObject(secondValue)) if (!objectHasProperty(firstValue, key)) mergeProperty(key, [secondValue[key]]);
			return result;
		}
		return mergeRecordsFastGeneral(values, utils);
	}
	/**
	* The fast default strategy to merge 3 or more records without circular reference checks or depth limits.
	*
	* Assumes input is trusted and non-circular.
	*
	* @param values - The records.
	* @param utils - The utils.
	* @returns The merged records.
	*/
	function mergeRecordsFastGeneral(values, utils) {
		const result = {};
		for (const key of getKeysOfObjects(values)) {
			const propValues = [];
			for (const value of values) if (objectHasProperty(value, key)) propValues.push(value[key]);
			const propertyResult = mergeUnknownsFast(propValues, utils);
			if (propertyResult === actions.skip) continue;
			result[key] = propertyResult;
		}
		return result;
	}
	/**
	* The fast default strategy to merge maps without circular reference checks or depth limits.
	*
	* Assumes input is trusted and non-circular.
	*
	* @param values - The maps.
	* @param utils - The utils.
	* @returns The merged map.
	*/
	function mergeMapsFast$1(values, utils) {
		const result = /* @__PURE__ */ new Map();
		const valuesByKey = /* @__PURE__ */ new Map();
		for (const map of values) for (const [key, value] of map) {
			const mut_keyValues = valuesByKey.get(key);
			if (mut_keyValues === void 0) valuesByKey.set(key, [value]);
			else mut_keyValues.push(value);
		}
		for (const [key, keyValues] of valuesByKey) {
			const keyResult = mergeUnknownsFast(keyValues, utils);
			if (keyResult === actions.skip) continue;
			result.set(key, keyResult);
		}
		return result;
	}
	/**
	* The fast merge functions without circular reference checks.
	*/
	var mergeFunctionsFast = {
		mergeRecords: mergeRecordsFast$1,
		mergeArrays: mergeArrays$1,
		mergeSets: mergeSets$1,
		mergeMaps: mergeMapsFast$1,
		mergeOthers: mergeOthers$1
	};
	var defaultDeepmergeFastUnsafe = /* #__PURE__ */ deepmergeFastUnsafeCustom();
	/**
	* Deeply merge objects using a high-performance strategy.
	*
	* Differences from `deepmerge` (standard version):
	* - **No circular reference detection:** Does not track object hierarchies or detect cyclic references. Circular structures will result in a stack overflow.
	* - **No recursion depth limits:** Does not enforce a `maxDepth` limit (standard version defaults to 1000).
	* - **No metadata tracking:** Metadata updates and custom metadata tracking are bypassed, avoiding metadata object allocations.
	* - **No prototype pollution interception:** Assumes trusted data and directly assigns properties.
	*
	* @warning Only use this function with **trusted, non-circular data**.
	* Using this function with untrusted user data can result in serious security vulnerabilities:
	* - **Prototype pollution:** Prototype pollution safeguards are omitted for speed; malicious keys like `__proto__` can pollute object prototypes.
	* - **Denial of Service (DoS):** Circular reference detection and recursion depth limits are disabled; cyclic or deeply nested input will cause infinite recursion and crash via stack overflow.
	* @param objects - The objects to merge.
	* @returns The merged result.
	*/
	function deepmergeFastUnsafe(...objects) {
		return defaultDeepmergeFastUnsafe(...objects);
	}
	function deepmergeFastUnsafeCustom(options = {}) {
		const utils = getUtilsFast$1(options, customizedDeepmergeFast);
		function customizedDeepmergeFast(...objects) {
			return mergeUnknownsFast(objects, utils);
		}
		return customizedDeepmergeFast;
	}
	/**
	* Get the utils that are available to the merge functions in fast mode.
	*
	* @param options - The options the user specified.
	* @param customizedDeepmergeFast - The customized deepmergeFastUnsafe function.
	* @returns The fast merge utils.
	*/
	function getUtilsFast$1(options, customizedDeepmergeFast) {
		const defaultMergeFns = mergeFunctionsFast;
		const defaultMetaDataUpd = defaultMetaDataUpdaterFast;
		return {
			defaultMergeFunctions: defaultMergeFns,
			mergeFunctions: resolveCustomMergeFunctions(options, defaultMergeFns),
			metaDataUpdater: defaultMetaDataUpd,
			deepmerge: customizedDeepmergeFast,
			useImplicitDefaultMerging: options.enableImplicitDefaultMerging ?? false,
			filterValues: options.filterValues === false ? void 0 : typeof options.filterValues === "function" ? options.filterValues : defaultFilterValues,
			maxDepth: void 0,
			actions
		};
	}
	/**
	* Merge unknown things in fast mode without checking for circular references or depth limits.
	*
	* @param values - The values.
	* @param utils - The utils.
	* @returns The merged result.
	*/
	function mergeUnknownsFast(values, utils) {
		const filteredValues = utils.filterValues?.(values, void 0) ?? values;
		if (filteredValues.length === 0) return;
		if (filteredValues.length === 1) return mergeOthersFast(filteredValues, utils);
		const type = getObjectType(filteredValues[0]);
		if (type !== ObjectType.NOT && type !== ObjectType.OTHER) {
			if (filteredValues.length === 2) {
				if (getObjectType(filteredValues[1]) !== type) return mergeOthersFast(filteredValues, utils);
			} else for (let mut_index = 1; mut_index < filteredValues.length; mut_index++) if (getObjectType(filteredValues[mut_index]) !== type) return mergeOthersFast(filteredValues, utils);
		}
		switch (type) {
			case ObjectType.RECORD: return mergeRecordsFast(filteredValues, utils);
			case ObjectType.ARRAY: return mergeArraysFast(filteredValues, utils);
			case ObjectType.SET: return mergeSetsFast(filteredValues, utils);
			case ObjectType.MAP: return mergeMapsFast(filteredValues, utils);
			default: return mergeOthersFast(filteredValues, utils);
		}
	}
	/**
	* Merge records in fast mode.
	*
	* @param values - The records.
	* @param utils - The utils.
	* @returns The merged result.
	*/
	function mergeRecordsFast(values, utils) {
		const result = utils.mergeFunctions.mergeRecords(values, utils, void 0);
		if (shouldFallbackToDefault(utils, "mergeRecords", result)) return utils.defaultMergeFunctions.mergeRecords(values, utils, void 0);
		return result;
	}
	/**
	* Merge arrays in fast mode.
	*
	* @param values - The arrays.
	* @param utils - The utils.
	* @returns The merged result.
	*/
	function mergeArraysFast(values, utils) {
		const result = utils.mergeFunctions.mergeArrays(values, utils, void 0);
		if (shouldFallbackToDefault(utils, "mergeArrays", result)) return utils.defaultMergeFunctions.mergeArrays(values);
		return result;
	}
	/**
	* Merge sets in fast mode.
	*
	* @param values - The sets.
	* @param utils - The utils.
	* @returns The merged result.
	*/
	function mergeSetsFast(values, utils) {
		const result = utils.mergeFunctions.mergeSets(values, utils, void 0);
		if (shouldFallbackToDefault(utils, "mergeSets", result)) return utils.defaultMergeFunctions.mergeSets(values);
		return result;
	}
	/**
	* Merge maps in fast mode.
	*
	* @param values - The maps.
	* @param utils - The utils.
	* @returns The merged result.
	*/
	function mergeMapsFast(values, utils) {
		const result = utils.mergeFunctions.mergeMaps(values, utils, void 0);
		if (shouldFallbackToDefault(utils, "mergeMaps", result)) return utils.defaultMergeFunctions.mergeMaps(values, utils, void 0);
		return result;
	}
	/**
	* Merge other things in fast mode.
	*
	* @param values - The other things.
	* @param utils - The utils.
	* @returns The merged result.
	*/
	function mergeOthersFast(values, utils) {
		const result = utils.mergeFunctions.mergeOthers(values, utils, void 0);
		if (shouldFallbackToDefault(utils, "mergeOthers", result)) return utils.defaultMergeFunctions.mergeOthers(values);
		return result;
	}
	/**
	* The default strategy to merge records into a target record.
	*
	* @param mut_target - The target to merge into.
	* @param values - The records (including the target's value if there is one).
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeRecordsInto$1(mut_target, values, utils, meta) {
		if (values.length === 2) {
			const mergeProperty = (key, propValues) => {
				const updatedMeta = utils.metaDataUpdater(meta, {
					key,
					parents: values,
					values: propValues,
					result: mut_target.value
				});
				const propertyTarget = objectHasProperty(mut_target.value, key) ? { value: propValues[0] } : { value: emptyLike(propValues[0]) };
				mergeUnknownsInto(propertyTarget, propValues, utils, updatedMeta);
				if (key === "__proto__") Object.defineProperty(mut_target.value, key, {
					value: propertyTarget.value,
					configurable: true,
					enumerable: true,
					writable: true
				});
				else mut_target.value[key] = propertyTarget.value;
			};
			const firstValue = values[0];
			const secondValue = values[1];
			for (const key of getKeysOfObject(firstValue)) mergeProperty(key, objectHasProperty(secondValue, key) ? [firstValue[key], secondValue[key]] : [firstValue[key]]);
			for (const key of getKeysOfObject(secondValue)) if (!objectHasProperty(firstValue, key)) mergeProperty(key, [secondValue[key]]);
			return;
		}
		mergeRecordsIntoGeneral(mut_target, values, utils, meta);
	}
	/**
	* The default strategy to merge 3 or more records into a target record.
	*
	* @param mut_target - The target to merge into.
	* @param values - The records (including the target's value if there is one).
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeRecordsIntoGeneral(mut_target, values, utils, meta) {
		for (const key of getKeysOfObjects(values)) {
			const propValues = [];
			for (const value of values) if (objectHasProperty(value, key)) propValues.push(value[key]);
			const updatedMeta = utils.metaDataUpdater(meta, {
				key,
				parents: values,
				values: propValues,
				result: mut_target.value
			});
			const propertyTarget = objectHasProperty(mut_target.value, key) ? { value: propValues[0] } : { value: emptyLike(propValues[0]) };
			mergeUnknownsInto(propertyTarget, propValues, utils, updatedMeta);
			if (key === "__proto__") Object.defineProperty(mut_target.value, key, {
				value: propertyTarget.value,
				configurable: true,
				enumerable: true,
				writable: true
			});
			else mut_target.value[key] = propertyTarget.value;
		}
	}
	/**
	* The default strategy to merge maps into a target map.
	*
	* @param mut_target - The target to merge into.
	* @param values - The maps (including the target's value if there is one).
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeMapsInto$1(mut_target, values, utils, meta) {
		const valuesByKey = /* @__PURE__ */ new Map();
		for (const value of values) {
			if (value === mut_target.value) continue;
			for (const [key, entryValue] of value) {
				const mut_keyValues = valuesByKey.get(key);
				if (mut_keyValues === void 0) valuesByKey.set(key, [entryValue]);
				else mut_keyValues.push(entryValue);
			}
		}
		const target = mut_target.value;
		for (const [key, keyValues] of valuesByKey) {
			const targetValue = target.get(key);
			const allValues = targetValue === void 0 ? keyValues : [targetValue, ...keyValues];
			const updatedMeta = utils.metaDataUpdater(meta, {
				key,
				parents: values,
				values: allValues,
				result: mut_target.value
			});
			const propTarget = targetValue === void 0 ? { value: emptyLike(allValues[0]) } : { value: targetValue };
			mergeUnknownsInto(propTarget, allValues, utils, updatedMeta);
			target.set(key, propTarget.value);
		}
	}
	/**
	* Resolve any cyclic references within a non-cyclic object pointing to ancestors in meta.hierarchy.
	*
	* @param value - The value to resolve circular references for.
	* @param utils - The utils.
	* @param meta - The meta data.
	* @returns The resolved value.
	*/
	function resolveCyclicReferencesInto(value, utils, meta) {
		if (typeof value !== "object" || value === null) return value;
		const hierarchy = getMetaDataHierarchy(meta);
		const depth = getCyclicReferenceDepth(value, hierarchy, 0);
		if (hierarchy !== void 0 && depth > 0) return hierarchy[hierarchy.length - depth]?.result ?? hierarchy[hierarchy.length - depth]?.parents[0];
		if (getObjectType(value) === ObjectType.RECORD) {
			const record = value;
			let mut_changed = false;
			const result = {};
			for (const key of getKeysOfObject(record)) {
				const propVal = record[key];
				const resolvedProp = resolveCyclicReferencesInto(propVal, utils, utils.metaDataUpdater(meta, {
					key,
					parents: [record],
					values: [propVal],
					result
				}));
				if (resolvedProp !== propVal) mut_changed = true;
				if (key === "__proto__") Object.defineProperty(result, key, {
					value: resolvedProp,
					configurable: true,
					enumerable: true,
					writable: true
				});
				else result[key] = resolvedProp;
			}
			return mut_changed ? result : value;
		}
		return value;
	}
	/**
	* The default strategy to merge circular references into a target.
	*
	* @param mut_target - The target to merge into.
	* @param values - The circular references.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeCircularReferencesInto$1(mut_target, values, utils, meta) {
		const hierarchy = getMetaDataHierarchy(meta);
		const cyclicDepths = values.map((v, i) => getCyclicReferenceDepth(v, hierarchy, i));
		const depth = cyclicDepths[0];
		for (let mut_index = 1; mut_index < values.length; mut_index++) if (cyclicDepths[mut_index] !== depth) {
			const lastCyclicDepth = cyclicDepths.at(-1);
			mut_target.value = lastCyclicDepth === 0 ? resolveCyclicReferencesInto(values.at(-1), utils, meta) : hierarchy?.[hierarchy.length - lastCyclicDepth]?.result ?? hierarchy?.[hierarchy.length - lastCyclicDepth]?.parents[0];
			return;
		}
		mut_target.value = hierarchy?.[hierarchy.length - depth]?.result ?? hierarchy?.[hierarchy.length - depth]?.parents[0];
	}
	/**
	* The merge functions.
	*/
	var mergeIntoFunctions = {
		mergeRecords: mergeRecordsInto$1,
		mergeArrays: mergeArraysInto$1,
		mergeSets: mergeSetsInto$1,
		mergeMaps: mergeMapsInto$1,
		mergeCircularReferences: mergeCircularReferencesInto$1,
		mergeOthers: mergeOthersInto$1
	};
	var defaultDeepmergeInto = /* #__PURE__ */ deepmergeIntoCustom();
	function deepmergeInto(target, ...objects) {
		defaultDeepmergeInto(target, ...objects);
	}
	function deepmergeIntoCustom(options = {}, rootMetaData) {
		const utils = getUtils(options, customizedDeepmergeInto);
		/**
		* The customized deepmergeInto function.
		*
		* @param target - The target object to merge into.
		* @param objects - The objects to merge into the target.
		*/
		function customizedDeepmergeInto(target, ...objects) {
			mergeUnknownsInto({ value: target }, [target, ...objects], utils, rootMetaData);
		}
		return customizedDeepmergeInto;
	}
	/**
	* Get the utils that are available to the merge functions.
	*
	* @param options - The options the user specified.
	* @param customizedDeepmergeInto - The customized deepmergeInto function.
	* @returns The merge into utils.
	*/
	function getUtils(options, customizedDeepmergeInto) {
		const defaultMergeFns = mergeIntoFunctions;
		const defaultMetaDataUpd = defaultMetaDataUpdater;
		return {
			defaultMergeFunctions: defaultMergeFns,
			mergeFunctions: resolveCustomMergeFunctions(options, defaultMergeFns),
			metaDataUpdater: typeof options.metaDataUpdater === "function" ? options.metaDataUpdater : defaultMetaDataUpd,
			deepmergeInto: customizedDeepmergeInto,
			filterValues: options.filterValues === false ? void 0 : typeof options.filterValues === "function" ? options.filterValues : defaultFilterValues,
			maxDepth: typeof options.maxDepth === "number" && !Number.isNaN(options.maxDepth) && options.maxDepth >= 0 ? options.maxDepth : 1e3,
			actions: actionsInto
		};
	}
	/**
	* Merge unknown things into a target.
	*
	* @param mut_target - The target to merge into.
	* @param values - The values.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeUnknownsInto(mut_target, values, utils, meta) {
		const filteredValues = utils.filterValues?.(values, meta) ?? values;
		if (filteredValues.length === 0) return;
		const hierarchy = getMetaDataHierarchy(meta);
		const currentDepth = hierarchy?.length ?? (typeof meta === "number" ? meta : meta?.depth ?? 0);
		if (utils.maxDepth !== void 0 && currentDepth >= utils.maxDepth) {
			mergeOthersInto(mut_target, filteredValues, utils, meta);
			return;
		}
		if (filteredValues.length === 1) {
			if (hierarchy !== void 0) {
				const depth = getCyclicReferenceDepth(filteredValues[0], hierarchy, 0);
				if (depth > 0) {
					mut_target.value = hierarchy[hierarchy.length - depth]?.result ?? hierarchy[hierarchy.length - depth]?.parents[0];
					return;
				}
			}
			mergeOthersInto(mut_target, filteredValues, utils, meta);
			return;
		}
		const type = getObjectType(mut_target.value);
		if (type !== ObjectType.NOT && type !== ObjectType.OTHER) {
			if (filteredValues.length === 2) {
				if (getObjectType(filteredValues[1]) !== type) {
					mergeOthersInto(mut_target, filteredValues, utils, meta);
					return;
				}
				const d0 = getCyclicReferenceDepth(filteredValues[0], hierarchy, 0);
				const d1 = getCyclicReferenceDepth(filteredValues[1], hierarchy, 1);
				if (d0 !== 0 || d1 !== 0) {
					mergeCircularReferencesInto(mut_target, filteredValues, utils, meta);
					return;
				}
			} else {
				const cyclicDepths = new Array(filteredValues.length);
				cyclicDepths[0] = getCyclicReferenceDepth(filteredValues[0], hierarchy, 0);
				for (let mut_index = 1; mut_index < filteredValues.length; mut_index++) {
					if (getObjectType(filteredValues[mut_index]) !== type) {
						mergeOthersInto(mut_target, filteredValues, utils, meta);
						return;
					}
					cyclicDepths[mut_index] = getCyclicReferenceDepth(filteredValues[mut_index], hierarchy, mut_index);
				}
				if (cyclicDepths.some((depth) => depth !== 0)) {
					mergeCircularReferencesInto(mut_target, filteredValues, utils, meta);
					return;
				}
			}
		}
		switch (type) {
			case ObjectType.RECORD:
				mergeRecordsInto(mut_target, filteredValues, utils, meta);
				return;
			case ObjectType.ARRAY:
				mergeArraysInto(mut_target, filteredValues, utils, meta);
				return;
			case ObjectType.SET:
				mergeSetsInto(mut_target, filteredValues, utils, meta);
				return;
			case ObjectType.MAP:
				mergeMapsInto(mut_target, filteredValues, utils, meta);
				return;
			default:
				mergeOthersInto(mut_target, filteredValues, utils, meta);
				return;
		}
	}
	/**
	* Merge records into a target record.
	*
	* @param mut_target - The target to merge into.
	* @param values - The records.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeRecordsInto(mut_target, values, utils, meta) {
		if (utils.mergeFunctions.mergeRecords(mut_target, values, utils, meta) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeRecords(mut_target, values, utils, meta);
	}
	/**
	* Merge arrays into a target array.
	*
	* @param mut_target - The target to merge into.
	* @param values - The arrays.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeArraysInto(mut_target, values, utils, meta) {
		if (utils.mergeFunctions.mergeArrays(mut_target, values, utils, meta) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeArrays(mut_target, values);
	}
	/**
	* Merge sets into a target set.
	*
	* @param mut_target - The target to merge into.
	* @param values - The sets.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeSetsInto(mut_target, values, utils, meta) {
		if (utils.mergeFunctions.mergeSets(mut_target, values, utils, meta) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeSets(mut_target, values);
	}
	/**
	* Merge maps into a target map.
	*
	* @param mut_target - The target to merge into.
	* @param values - The maps.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeMapsInto(mut_target, values, utils, meta) {
		if (utils.mergeFunctions.mergeMaps(mut_target, values, utils, meta) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeMaps(mut_target, values, utils, meta);
	}
	/**
	* Merge circular references into a target.
	*
	* @param mut_target - The target to merge into.
	* @param values - The circular references.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeCircularReferencesInto(mut_target, values, utils, meta) {
		if (utils.mergeFunctions.mergeCircularReferences(mut_target, values, utils, meta) === actionsInto.defaultMerge || mut_target.value === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeCircularReferences(mut_target, values, utils, meta);
	}
	/**
	* Merge other things into a target.
	*
	* @param mut_target - The target to merge into.
	* @param values - The other things.
	* @param utils - The utils.
	* @param meta - The meta data.
	*/
	function mergeOthersInto(mut_target, values, utils, meta) {
		if (utils.mergeFunctions.mergeOthers(mut_target, values, utils, meta) === actionsInto.defaultMerge || mut_target.value === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeOthers(mut_target, values);
	}
	/**
	* The fast default strategy to merge records into a target record without circular reference checks or depth limits.
	*
	* Assumes input is trusted and non-circular.
	*
	* @param mut_target - The target to merge into.
	* @param values - The records (including the target's value if there is one).
	* @param utils - The utils.
	*/
	function mergeRecordsIntoFast$1(mut_target, values, utils) {
		if (values.length === 2) {
			const mergeProperty = (key, propValues) => {
				const propertyTarget = objectHasProperty(mut_target.value, key) ? { value: propValues[0] } : { value: emptyLike(propValues[0]) };
				mergeUnknownsIntoFast(propertyTarget, propValues, utils);
				mut_target.value[key] = propertyTarget.value;
			};
			const firstValue = values[0];
			const secondValue = values[1];
			for (const key of getKeysOfObject(firstValue)) mergeProperty(key, objectHasProperty(secondValue, key) ? [firstValue[key], secondValue[key]] : [firstValue[key]]);
			for (const key of getKeysOfObject(secondValue)) if (!objectHasProperty(firstValue, key)) mergeProperty(key, [secondValue[key]]);
			return;
		}
		mergeRecordsIntoFastGeneral(mut_target, values, utils);
	}
	/**
	* The fast default strategy to merge 3 or more records into a target record without circular reference checks or depth limits.
	*
	* Assumes input is trusted and non-circular.
	*
	* @param mut_target - The target to merge into.
	* @param values - The records (including the target's value if there is one).
	* @param utils - The utils.
	*/
	function mergeRecordsIntoFastGeneral(mut_target, values, utils) {
		for (const key of getKeysOfObjects(values)) {
			const propValues = [];
			for (const value of values) if (objectHasProperty(value, key)) propValues.push(value[key]);
			const propertyTarget = objectHasProperty(mut_target.value, key) ? { value: propValues[0] } : { value: emptyLike(propValues[0]) };
			mergeUnknownsIntoFast(propertyTarget, propValues, utils);
			mut_target.value[key] = propertyTarget.value;
		}
	}
	/**
	* The fast default strategy to merge maps into a target map without circular reference checks or depth limits.
	*
	* Assumes input is trusted and non-circular.
	*
	* @param mut_target - The target to merge into.
	* @param values - The maps (including the target's value if there is one).
	* @param utils - The utils.
	*/
	function mergeMapsIntoFast$1(mut_target, values, utils) {
		const valuesByKey = /* @__PURE__ */ new Map();
		for (const value of values) {
			if (value === mut_target.value) continue;
			for (const [key, entryValue] of value) {
				const mut_keyValues = valuesByKey.get(key);
				if (mut_keyValues === void 0) valuesByKey.set(key, [entryValue]);
				else mut_keyValues.push(entryValue);
			}
		}
		const target = mut_target.value;
		for (const [key, keyValues] of valuesByKey) {
			const targetValue = target.get(key);
			const allValues = targetValue === void 0 ? keyValues : [targetValue, ...keyValues];
			const propTarget = targetValue === void 0 ? { value: emptyLike(allValues[0]) } : { value: targetValue };
			mergeUnknownsIntoFast(propTarget, allValues, utils);
			target.set(key, propTarget.value);
		}
	}
	/**
	* The fast merge functions without circular reference checks.
	*/
	var mergeIntoFunctionsFast = {
		mergeRecords: mergeRecordsIntoFast$1,
		mergeArrays: mergeArraysInto$1,
		mergeSets: mergeSetsInto$1,
		mergeMaps: mergeMapsIntoFast$1,
		mergeOthers: mergeOthersInto$1
	};
	var defaultDeepmergeIntoFastUnsafe = /* #__PURE__ */ deepmergeIntoFastUnsafeCustom();
	function deepmergeIntoFastUnsafe(target, ...objects) {
		defaultDeepmergeIntoFastUnsafe(target, ...objects);
	}
	function deepmergeIntoFastUnsafeCustom(options = {}) {
		const utils = getUtilsFast(options, customizedDeepmergeIntoFast);
		function customizedDeepmergeIntoFast(target, ...objects) {
			mergeUnknownsIntoFast({ value: target }, [target, ...objects], utils);
		}
		return customizedDeepmergeIntoFast;
	}
	/**
	* Get the utils that are available to the merge functions in fast mode.
	*
	* @param options - The options the user specified.
	* @param customizedDeepmergeIntoFast - The customized deepmergeIntoFastUnsafe function.
	* @returns The fast merge into utils.
	*/
	function getUtilsFast(options, customizedDeepmergeIntoFast) {
		const defaultMergeFns = mergeIntoFunctionsFast;
		const defaultMetaDataUpd = defaultMetaDataUpdaterFast;
		return {
			defaultMergeFunctions: defaultMergeFns,
			mergeFunctions: resolveCustomMergeFunctions(options, defaultMergeFns),
			metaDataUpdater: defaultMetaDataUpd,
			deepmergeInto: customizedDeepmergeIntoFast,
			filterValues: options.filterValues === false ? void 0 : typeof options.filterValues === "function" ? options.filterValues : defaultFilterValues,
			maxDepth: void 0,
			actions: actionsInto
		};
	}
	/**
	* Merge unknown things into a target in fast mode without checking for circular references or depth limits.
	*
	* @param mut_target - The target to merge into.
	* @param values - The values.
	* @param utils - The utils.
	*/
	function mergeUnknownsIntoFast(mut_target, values, utils) {
		const filteredValues = utils.filterValues?.(values, void 0) ?? values;
		if (filteredValues.length === 0) return;
		if (filteredValues.length === 1) {
			mergeOthersIntoFast(mut_target, filteredValues, utils);
			return;
		}
		const type = getObjectType(mut_target.value);
		if (type !== ObjectType.NOT && type !== ObjectType.OTHER) {
			if (filteredValues.length === 2) {
				if (getObjectType(filteredValues[1]) !== type) {
					mergeOthersIntoFast(mut_target, filteredValues, utils);
					return;
				}
			} else for (let mut_index = 1; mut_index < filteredValues.length; mut_index++) if (getObjectType(filteredValues[mut_index]) !== type) {
				mergeOthersIntoFast(mut_target, filteredValues, utils);
				return;
			}
		}
		switch (type) {
			case ObjectType.RECORD:
				mergeRecordsIntoFast(mut_target, filteredValues, utils);
				return;
			case ObjectType.ARRAY:
				mergeArraysIntoFast(mut_target, filteredValues, utils);
				return;
			case ObjectType.SET:
				mergeSetsIntoFast(mut_target, filteredValues, utils);
				return;
			case ObjectType.MAP:
				mergeMapsIntoFast(mut_target, filteredValues, utils);
				return;
			default:
				mergeOthersIntoFast(mut_target, filteredValues, utils);
				return;
		}
	}
	/**
	* Merge records into a target record in fast mode.
	*
	* @param mut_target - The target to merge into.
	* @param values - The records.
	* @param utils - The utils.
	*/
	function mergeRecordsIntoFast(mut_target, values, utils) {
		if (utils.mergeFunctions.mergeRecords(mut_target, values, utils, void 0) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeRecords(mut_target, values, utils, void 0);
	}
	/**
	* Merge arrays into a target array in fast mode.
	*
	* @param mut_target - The target to merge into.
	* @param values - The arrays.
	* @param utils - The utils.
	*/
	function mergeArraysIntoFast(mut_target, values, utils) {
		if (utils.mergeFunctions.mergeArrays(mut_target, values, utils, void 0) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeArrays(mut_target, values);
	}
	/**
	* Merge sets into a target set in fast mode.
	*
	* @param mut_target - The target to merge into.
	* @param values - The sets.
	* @param utils - The utils.
	*/
	function mergeSetsIntoFast(mut_target, values, utils) {
		if (utils.mergeFunctions.mergeSets(mut_target, values, utils, void 0) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeSets(mut_target, values);
	}
	/**
	* Merge maps into a target map in fast mode.
	*
	* @param mut_target - The target to merge into.
	* @param values - The maps.
	* @param utils - The utils.
	*/
	function mergeMapsIntoFast(mut_target, values, utils) {
		if (utils.mergeFunctions.mergeMaps(mut_target, values, utils, void 0) === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeMaps(mut_target, values, utils, void 0);
	}
	/**
	* Merge other things into a target in fast mode.
	*
	* @param mut_target - The target to merge into.
	* @param values - The other things.
	* @param utils - The utils.
	*/
	function mergeOthersIntoFast(mut_target, values, utils) {
		if (utils.mergeFunctions.mergeOthers(mut_target, values, utils, void 0) === actionsInto.defaultMerge || mut_target.value === actionsInto.defaultMerge) utils.defaultMergeFunctions.mergeOthers(mut_target, values);
	}
	exports.deepmerge = deepmerge;
	exports.deepmergeCustom = deepmergeCustom;
	exports.deepmergeFastUnsafe = deepmergeFastUnsafe;
	exports.deepmergeFastUnsafeCustom = deepmergeFastUnsafeCustom;
	exports.deepmergeInto = deepmergeInto;
	exports.deepmergeIntoCustom = deepmergeIntoCustom;
	exports.deepmergeIntoFastUnsafe = deepmergeIntoFastUnsafe;
	exports.deepmergeIntoFastUnsafeCustom = deepmergeIntoFastUnsafeCustom;
	exports.getKeys = getKeys;
	exports.getKeysOfObjects = getKeysOfObjects;
	exports.getObjectType = getObjectType;
	exports.objectHasProperty = objectHasProperty;
}));
//#endregion
//#region node_modules/@vanilla-extract/css/dist/vanilla-extract-css.cjs.prod.js
var require_vanilla_extract_css_cjs_prod = /* @__PURE__ */ __commonJSMin(((exports) => {
	Object.defineProperty(exports, "__esModule", { value: true });
	var injectStyles_dist_vanillaExtractCssInjectStyles = require_vanilla_extract_css_injectStyles_cjs_prod();
	var transformCss_dist_vanillaExtractCssTransformCss = require_transformCss_7fbca312_cjs_prod();
	var adapter_dist_vanillaExtractCssAdapter = require_vanilla_extract_css_adapter_cjs_prod();
	require_emotion_hash_cjs();
	require_vanilla_extract_css_fileScope_cjs_prod();
	var lruCache = require_commonjs();
	var _private = __toCommonJS(vanilla_extract_private_esm_exports);
	require_cjs();
	require_picocolors();
	require_taggedTemplateLiteral_0bfb2e96_cjs_prod();
	require_dedent();
	var deepmergeTs = require_dist();
	require_dist$1();
	init_es();
	init_media_query_parser_esm();
	var localClassNames = /* @__PURE__ */ new Set();
	var composedClassLists = [];
	var bufferedCSSObjs = [];
	var browserRuntimeAdapter = {
		appendCss: (cssObj) => {
			bufferedCSSObjs.push(cssObj);
		},
		registerClassName: (className) => {
			localClassNames.add(className);
		},
		registerComposition: (composition) => {
			composedClassLists.push(composition);
		},
		markCompositionUsed: () => {},
		onEndFileScope: (fileScope) => {
			var css = transformCss_dist_vanillaExtractCssTransformCss.transformCss({
				localClassNames: Array.from(localClassNames),
				composedClassLists,
				cssObjs: bufferedCSSObjs
			}).join("\n");
			injectStyles_dist_vanillaExtractCssInjectStyles.injectStyles({
				fileScope,
				css
			});
			bufferedCSSObjs = [];
		},
		getIdentOption: () => "short"
	};
	if (typeof window !== "undefined") adapter_dist_vanillaExtractCssAdapter.setAdapterIfNotSet(browserRuntimeAdapter);
	var getLastSlashBeforeIndex = (path, index) => {
		var pathIndex = index - 1;
		while (pathIndex >= 0) {
			if (path[pathIndex] === "/") return pathIndex;
			pathIndex--;
		}
		return -1;
	};
	/**
	* Assumptions:
	* - The path is always normalized to use posix file separators (/) (see `addFileScope`)
	* - The path is always relative to the project root, i.e. there will never be a leading slash (see `addFileScope`)
	* - As long as `.css` is there, we have a valid `.css.*` file path, because otherwise there wouldn't
	*   be a file scope to begin with
	*
	* The LRU cache we use can't cache undefined/null values, so we opt to return an empty string,
	* rather than using a custom Symbol or something similar.
	*/
	var _getDebugFileName = (path) => {
		var file;
		var lastIndexOfDotCss = path.lastIndexOf(".css");
		if (lastIndexOfDotCss === -1) return "";
		var lastSlashIndex = getLastSlashBeforeIndex(path, lastIndexOfDotCss);
		file = path.slice(lastSlashIndex + 1, lastIndexOfDotCss);
		if (lastSlashIndex === -1) return file;
		var secondLastSlashIndex = getLastSlashBeforeIndex(path, lastSlashIndex - 1);
		var dir = path.slice(secondLastSlashIndex + 1, lastSlashIndex);
		return (file !== "index" ? file : dir).replace(/\./g, "_");
	};
	var memoizedGetDebugFileName = () => {
		var cache = new lruCache.LRUCache({ max: 500 });
		return (path) => {
			var cachedResult = cache.get(path);
			if (cachedResult) return cachedResult;
			var result = _getDebugFileName(path);
			cache.set(path, result);
			return result;
		};
	};
	memoizedGetDebugFileName();
	function createGlobalThemeContract(tokens, mapFn) {
		return _private.walkObject(tokens, (value, path) => {
			var rawVarName = typeof mapFn === "function" ? mapFn(value, path) : value;
			var varName = typeof rawVarName === "string" ? rawVarName.replace(/^--/, "") : null;
			if (typeof varName !== "string" || varName !== transformCss_dist_vanillaExtractCssTransformCss.cssesc(varName, { isIdentifier: true })) throw new Error("Invalid variable name for \"".concat(path.join("."), "\": ").concat(varName));
			return "var(--".concat(varName, ")");
		});
	}
	deepmergeTs.deepmergeCustom({
		mergeArrays: false,
		filterValues: false
	});
	exports.createGlobalThemeContract = createGlobalThemeContract;
}));
//#endregion
//#region node_modules/@vanilla-extract/css/dist/vanilla-extract-css.cjs.js
var require_vanilla_extract_css_cjs = /* @__PURE__ */ __commonJSMin(((exports, module) => {
	module.exports = require_vanilla_extract_css_cjs_prod();
}));
//#endregion
//#region node_modules/@mysten/dapp-kit/dist/index.mjs
var import_vanilla_extract_dynamic_cjs = require_vanilla_extract_dynamic_cjs();
var import_vanilla_extract_css_cjs = require_vanilla_extract_css_cjs();
var __typeError = (msg) => {
	throw TypeError(msg);
};
var __accessCheck = (obj, member, msg) => member.has(obj) || __typeError("Cannot " + msg);
var __privateGet = (obj, member, getter) => (__accessCheck(obj, member, "read from private field"), getter ? getter.call(obj) : member.get(obj));
var __privateAdd = (obj, member, value) => member.has(obj) ? __typeError("Cannot add the same private member more than once") : member instanceof WeakSet ? member.add(obj) : member.set(obj, value);
function createInMemoryStore() {
	const store = /* @__PURE__ */ new Map();
	return {
		getItem(key) {
			return store.get(key);
		},
		setItem(key, value) {
			store.set(key, value);
		},
		removeItem(key) {
			store.delete(key);
		}
	};
}
var SUI_WALLET_NAME = "Sui Wallet";
var DEFAULT_STORAGE = typeof window !== "undefined" && window.localStorage ? localStorage : createInMemoryStore();
var DEFAULT_STORAGE_KEY = "sui-dapp-kit:wallet-connection-info";
var SIGN_FEATURES = ["sui:signTransaction", "sui:signTransactionBlock"];
var DEFAULT_WALLET_FILTER = (wallet) => SIGN_FEATURES.some((feature) => wallet.features[feature]);
var DEFAULT_PREFERRED_WALLETS = [SUI_WALLET_NAME, SLUSH_WALLET_NAME];
var walletMutationKeys = {
	all: { baseScope: "wallet" },
	connectWallet: formMutationKeyFn("connect-wallet"),
	autoconnectWallet: formMutationKeyFn("autoconnect-wallet"),
	disconnectWallet: formMutationKeyFn("disconnect-wallet"),
	signPersonalMessage: formMutationKeyFn("sign-personal-message"),
	signTransaction: formMutationKeyFn("sign-transaction"),
	signAndExecuteTransaction: formMutationKeyFn("sign-and-execute-transaction"),
	switchAccount: formMutationKeyFn("switch-account")
};
function formMutationKeyFn(baseEntity) {
	return function mutationKeyFn(additionalKeys = []) {
		return [{
			...walletMutationKeys.all,
			baseEntity
		}, ...additionalKeys];
	};
}
var WalletContext = (0, import_react.createContext)(null);
function useWalletStore(selector) {
	const store = (0, import_react.useContext)(WalletContext);
	if (!store) throw new Error("Could not find WalletContext. Ensure that you have set up the WalletProvider.");
	return useStore(store, selector);
}
function useConnectWallet({ mutationKey, ...mutationOptions } = {}) {
	const setWalletConnected = useWalletStore((state) => state.setWalletConnected);
	const setConnectionStatus = useWalletStore((state) => state.setConnectionStatus);
	return useMutation({
		mutationKey: walletMutationKeys.connectWallet(mutationKey),
		mutationFn: async ({ wallet, accountAddress, ...connectArgs }) => {
			try {
				setConnectionStatus("connecting");
				const connectResult = await wallet.features["standard:connect"].connect(connectArgs);
				let supportedIntents = connectResult.supportedIntents;
				if (!supportedIntents && wallet.features["sui:getCapabilities"]) supportedIntents = (await wallet.features["sui:getCapabilities"].getCapabilities()).supportedIntents ?? [];
				const connectedSuiAccounts = connectResult.accounts.filter((account) => account.chains.some((chain) => chain.split(":")[0] === "sui"));
				const selectedAccount = getSelectedAccount(connectedSuiAccounts, accountAddress);
				setWalletConnected(wallet, connectedSuiAccounts, selectedAccount, supportedIntents);
				return { accounts: connectedSuiAccounts };
			} catch (error) {
				setConnectionStatus("disconnected");
				throw error;
			}
		},
		...mutationOptions
	});
}
function getSelectedAccount(connectedAccounts, accountAddress) {
	if (connectedAccounts.length === 0) return null;
	if (accountAddress) return connectedAccounts.find((account) => account.address === accountAddress) ?? connectedAccounts[0];
	return connectedAccounts[0];
}
function useWallets() {
	return useWalletStore((state) => state.wallets);
}
function getRegisteredWallets(preferredWallets, walletFilter) {
	const suiWallets = getWallets().get().filter((wallet) => isWalletWithRequiredFeatureSet(wallet) && (!walletFilter || walletFilter(wallet)));
	return [...preferredWallets.map((name) => suiWallets.find((wallet) => wallet.name === name)).filter(Boolean), ...suiWallets.filter((wallet) => !preferredWallets.includes(wallet.name))];
}
function getWalletUniqueIdentifier(wallet) {
	return wallet?.id ?? wallet?.name;
}
function BackIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: 24,
		height: 24,
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M7.57 12.262c0 .341.13.629.403.895l5.175 5.059c.204.205.45.307.751.307.609 0 1.101-.485 1.101-1.087 0-.293-.123-.574-.349-.8L10.14 12.27l4.511-4.375A1.13 1.13 0 0 0 15 7.087C15 6.485 14.508 6 13.9 6c-.295 0-.54.103-.752.308l-5.175 5.058c-.28.28-.404.56-.404.896Z",
			fill: "currentColor"
		})
	});
}
function CloseIcon(props) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("svg", {
		width: 10,
		height: 10,
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...props,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("path", {
			d: "M9.708.292a.999.999 0 0 0-1.413 0l-3.289 3.29L1.717.291A.999.999 0 0 0 .305 1.705l3.289 3.289-3.29 3.289a.999.999 0 1 0 1.413 1.412l3.29-3.289 3.288 3.29a.999.999 0 0 0 1.413-1.413l-3.29-3.29 3.29-3.288a.999.999 0 0 0 0-1.413Z",
			fill: "currentColor"
		})
	});
}
var styleDataAttributeName = "data-dapp-kit";
var styleDataAttributeSelector = `[${styleDataAttributeName}]`;
var styleDataAttribute = { [styleDataAttributeName]: "" };
var StyleMarker = (0, import_react.forwardRef)(({ children, ...props }, forwardedRef) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot$1, {
	ref: forwardedRef,
	...props,
	...styleDataAttribute,
	children
}));
StyleMarker.displayName = "StyleMarker";
var headingVariants = (0, import_vanilla_extract_recipes_createRuntimeFn_cjs.createRuntimeFn)({
	defaultClassName: "Heading__1aa835k0",
	variantClassNames: {
		size: {
			sm: "Heading_headingVariants_size_sm__1aa835k1",
			md: "Heading_headingVariants_size_md__1aa835k2",
			lg: "Heading_headingVariants_size_lg__1aa835k3",
			xl: "Heading_headingVariants_size_xl__1aa835k4"
		},
		weight: {
			normal: "Heading_headingVariants_weight_normal__1aa835k5",
			bold: "Heading_headingVariants_weight_bold__1aa835k6"
		},
		truncate: { true: "Heading_headingVariants_truncate_true__1aa835k7" }
	},
	defaultVariants: {
		size: "lg",
		weight: "bold"
	},
	compoundVariants: []
});
var Heading = (0, import_react.forwardRef)(({ children, className, asChild = false, as: Tag = "h1", size, weight, truncate, ...headingProps }, forwardedRef) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot$1, {
		...headingProps,
		ref: forwardedRef,
		className: clsx(headingVariants({
			size,
			weight,
			truncate
		}), className),
		children: asChild ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children })
	});
});
Heading.displayName = "Heading";
var container = "IconButton_container__s6n7bq0";
var IconButton = (0, import_react.forwardRef)(({ className, asChild = false, ...props }, forwardedRef) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot$1 : "button", {
		...props,
		className: clsx(container, className),
		ref: forwardedRef
	});
});
IconButton.displayName = "Button";
var backButtonContainer = "ConnectModal_backButtonContainer__gz8z96";
var closeButtonContainer = "ConnectModal_closeButtonContainer__gz8z97";
var content = "ConnectModal_content__gz8z92";
var overlay = "ConnectModal_overlay__gz8z90";
var selectedViewContainer = "ConnectModal_selectedViewContainer__gz8z95";
var title = "ConnectModal_title__gz8z91";
var viewContainer = "ConnectModal_viewContainer__gz8z94";
var walletListContainer = "ConnectModal_walletListContainer__gz8z99";
var walletListContainerWithViewSelected = "ConnectModal_walletListContainerWithViewSelected__gz8z9a";
var walletListContent = "ConnectModal_walletListContent__gz8z98";
var whatIsAWalletButton = "ConnectModal_whatIsAWalletButton__gz8z93";
var buttonVariants = (0, import_vanilla_extract_recipes_createRuntimeFn_cjs.createRuntimeFn)({
	defaultClassName: "Button_buttonVariants__x1s81q0",
	variantClassNames: {
		variant: {
			primary: "Button_buttonVariants_variant_primary__x1s81q1",
			outline: "Button_buttonVariants_variant_outline__x1s81q2"
		},
		size: {
			md: "Button_buttonVariants_size_md__x1s81q3",
			lg: "Button_buttonVariants_size_lg__x1s81q4"
		}
	},
	defaultVariants: {
		variant: "primary",
		size: "md"
	},
	compoundVariants: []
});
var Button = (0, import_react.forwardRef)(({ className, variant, size, asChild = false, ...props }, forwardedRef) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(asChild ? Slot$1 : "button", {
		...props,
		className: clsx(buttonVariants({
			variant,
			size
		}), className),
		ref: forwardedRef
	});
});
Button.displayName = "Button";
var textVariants = (0, import_vanilla_extract_recipes_createRuntimeFn_cjs.createRuntimeFn)({
	defaultClassName: "Text__2bv1ur0",
	variantClassNames: {
		size: { sm: "Text_textVariants_size_sm__2bv1ur1" },
		weight: {
			normal: "Text_textVariants_weight_normal__2bv1ur2",
			medium: "Text_textVariants_weight_medium__2bv1ur3",
			bold: "Text_textVariants_weight_bold__2bv1ur4"
		},
		color: {
			muted: "Text_textVariants_color_muted__2bv1ur5",
			danger: "Text_textVariants_color_danger__2bv1ur6"
		},
		mono: { true: "Text_textVariants_mono_true__2bv1ur7" }
	},
	defaultVariants: {
		size: "sm",
		weight: "normal"
	},
	compoundVariants: []
});
var Text = (0, import_react.forwardRef)(({ children, className, asChild = false, as: Tag = "div", size, weight, color, mono, ...textProps }, forwardedRef) => {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Slot$1, {
		...textProps,
		ref: forwardedRef,
		className: clsx(textVariants({
			size,
			weight,
			color,
			mono
		}), className),
		children: asChild ? children : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Tag, { children })
	});
});
Text.displayName = "Text";
var connectionStatus = "ConnectionStatus_connectionStatus__nckm2d3";
var container2 = "ConnectionStatus_container__nckm2d0";
var retryButtonContainer = "ConnectionStatus_retryButtonContainer__nckm2d4";
var title2 = "ConnectionStatus_title__nckm2d2";
var walletIcon = "ConnectionStatus_walletIcon__nckm2d1";
function ConnectionStatus({ selectedWallet, hadConnectionError, onRetryConnection }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: container2,
		children: [
			selectedWallet.icon && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: walletIcon,
				src: selectedWallet.icon,
				alt: `${selectedWallet.name} logo`
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: title2,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Heading, {
					as: "h2",
					size: "xl",
					children: ["Opening ", selectedWallet.name]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: connectionStatus,
				children: hadConnectionError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					color: "danger",
					children: "Connection failed"
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
					color: "muted",
					children: "Confirm connection in the wallet..."
				})
			}),
			hadConnectionError ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: retryButtonContainer,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					type: "button",
					variant: "outline",
					onClick: () => onRetryConnection(selectedWallet),
					children: "Retry Connection"
				})
			}) : null
		]
	});
}
var container3 = "InfoSection_container__1wtioi70";
function InfoSection({ title: title3, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: container3,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
			as: "h3",
			size: "sm",
			weight: "normal",
			children: title3
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Text, {
			weight: "medium",
			color: "muted",
			children
		})]
	});
}
var container4 = "GettingStarted_container__1fp07e10";
var content2 = "GettingStarted_content__1fp07e11";
var installButtonContainer = "GettingStarted_installButtonContainer__1fp07e12";
function GettingStarted() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: container4,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
			as: "h2",
			children: "Get Started with Sui"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: content2,
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoSection, {
					title: "Install the Slush Extension",
					children: "We recommend pinning Slush to your taskbar for quicker access."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoSection, {
					title: "Create or Import a Wallet",
					children: "Be sure to back up your wallet using a secure method. Never share your secret phrase with anyone."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoSection, {
					title: "Refresh Your Browser",
					children: "Once you set up your wallet, refresh this window browser to load up the extension."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: installButtonContainer,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						variant: "outline",
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("a", {
							href: "https://chromewebstore.google.com/detail/slush-%E2%80%94-a-sui-wallet/opcgpfmipidbgpenhmajoajpbobppdi",
							target: "_blank",
							rel: "noreferrer",
							children: "Install Wallet Extension"
						})
					})
				})
			]
		})]
	});
}
var container5 = "WhatIsAWallet_container__1ktpkq90";
var content3 = "WhatIsAWallet_content__1ktpkq91";
function WhatIsAWallet() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: container5,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
			as: "h2",
			children: "What is a Wallet"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: content3,
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoSection, {
				title: "Easy Login",
				children: "No need to create new accounts and passwords for every website. Just connect your wallet and get going."
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InfoSection, {
				title: "Store your Digital Assets",
				children: "Send, receive, store, and display your digital assets like NFTs & coins."
			})]
		})]
	});
}
var container6 = "WalletList_container__1v2s6cz0";
var container7 = "WalletListItem_container__1dqqtqs0";
var selectedWalletItem = "WalletListItem_selectedWalletItem__1dqqtqs2";
var walletIcon2 = "WalletListItem_walletIcon__1dqqtqs3";
var walletItem = "WalletListItem_walletItem__1dqqtqs1";
function WalletListItem({ name, icon, onClick, isSelected = false }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
		className: container7,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			className: clsx(walletItem, { [selectedWalletItem]: isSelected }),
			type: "button",
			onClick,
			children: [icon && typeof icon === "string" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("img", {
				className: walletIcon2,
				src: icon,
				alt: `${name} logo`
			}) : icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
				size: "md",
				truncate: true,
				asChild: true,
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { children: name })
			})]
		})
	});
}
function WalletList({ selectedWalletName, onPlaceholderClick, onSelect, wallets }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
		className: container6,
		children: wallets.length > 0 ? wallets.map((wallet) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletListItem, {
			name: wallet.name,
			icon: wallet.icon,
			isSelected: getWalletUniqueIdentifier(wallet) === selectedWalletName,
			onClick: () => onSelect(wallet)
		}, getWalletUniqueIdentifier(wallet))) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletListItem, {
			name: SLUSH_WALLET_NAME,
			icon: SLUSH_WALLET_ICON,
			onClick: onPlaceholderClick,
			isSelected: true
		})
	});
}
function ConnectModal({ trigger, open, defaultOpen, onOpenChange, walletFilter = DEFAULT_WALLET_FILTER }) {
	const [isModalOpen, setModalOpen] = (0, import_react.useState)(open ?? defaultOpen);
	const [currentView, setCurrentView] = (0, import_react.useState)();
	const [selectedWallet, setSelectedWallet] = (0, import_react.useState)();
	const wallets = useWallets().filter(walletFilter);
	const { mutate, isError } = useConnectWallet();
	const resetSelection = () => {
		setSelectedWallet(void 0);
		setCurrentView(void 0);
	};
	const handleOpenChange = (open2) => {
		if (!open2) resetSelection();
		setModalOpen(open2);
		onOpenChange?.(open2);
	};
	const connectWallet = (wallet) => {
		setCurrentView("connection-status");
		mutate({ wallet }, { onSuccess: () => handleOpenChange(false) });
	};
	let modalContent;
	switch (currentView) {
		case "what-is-a-wallet":
			modalContent = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatIsAWallet, {});
			break;
		case "getting-started":
			modalContent = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(GettingStarted, {});
			break;
		case "connection-status":
			modalContent = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ConnectionStatus, {
				selectedWallet,
				hadConnectionError: isError,
				onRetryConnection: connectWallet
			});
			break;
		default: modalContent = /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WhatIsAWallet, {});
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open: open ?? isModalOpen,
		onOpenChange: handleOpenChange,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: trigger
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StyleMarker, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
			className: overlay,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
				className: content,
				"aria-describedby": void 0,
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: clsx(walletListContainer, { [walletListContainerWithViewSelected]: !!currentView }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: walletListContent,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
								className: title,
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Heading, {
									as: "h2",
									children: "Connect a Wallet"
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletList, {
								wallets,
								selectedWalletName: getWalletUniqueIdentifier(selectedWallet),
								onPlaceholderClick: () => setCurrentView("getting-started"),
								onSelect: (wallet) => {
									if (getWalletUniqueIdentifier(selectedWallet) !== getWalletUniqueIdentifier(wallet)) {
										setSelectedWallet(wallet);
										connectWallet(wallet);
									}
								}
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							className: whatIsAWalletButton,
							onClick: () => setCurrentView("what-is-a-wallet"),
							type: "button",
							children: "What is a Wallet?"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: clsx(viewContainer, { [selectedViewContainer]: !!currentView }),
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: backButtonContainer,
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								type: "button",
								"aria-label": "Back",
								onClick: () => resetSelection(),
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BackIcon, {})
							})
						}), modalContent]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogClose, {
						className: closeButtonContainer,
						asChild: true,
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							type: "button",
							"aria-label": "Close",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(CloseIcon, {})
						})
					})
				]
			})
		}) }) })]
	});
}
function useCurrentAccount() {
	return useWalletStore((state) => state.currentAccount);
}
var SuiClientContext = (0, import_react.createContext)(null);
var DEFAULT_NETWORKS = { localnet: { url: getJsonRpcFullnodeUrl("localnet") } };
var DEFAULT_CREATE_CLIENT = function createClient(_name, config) {
	if (isSuiJsonRpcClient(config)) return config;
	return new SuiJsonRpcClient(config);
};
function SuiClientProvider(props) {
	const { onNetworkChange, network, children } = props;
	const networks = props.networks ?? DEFAULT_NETWORKS;
	const createClient2 = props.createClient ?? DEFAULT_CREATE_CLIENT;
	const [selectedNetwork, setSelectedNetwork] = (0, import_react.useState)(props.network ?? props.defaultNetwork ?? Object.keys(networks)[0]);
	const currentNetwork = props.network ?? selectedNetwork;
	const client = (0, import_react.useMemo)(() => {
		return createClient2(currentNetwork, networks[currentNetwork]);
	}, [
		createClient2,
		currentNetwork,
		networks
	]);
	const ctx = (0, import_react.useMemo)(() => {
		return {
			client,
			networks,
			network: currentNetwork,
			config: networks[currentNetwork] instanceof SuiJsonRpcClient ? null : networks[currentNetwork],
			selectNetwork: (newNetwork) => {
				if (currentNetwork === newNetwork) return;
				if (!network && newNetwork !== selectedNetwork) setSelectedNetwork(newNetwork);
				onNetworkChange?.(newNetwork);
			}
		};
	}, [
		client,
		networks,
		selectedNetwork,
		currentNetwork,
		network,
		onNetworkChange
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SuiClientContext.Provider, {
		value: ctx,
		children
	});
}
function useSuiClientContext() {
	const suiClient = (0, import_react.useContext)(SuiClientContext);
	if (!suiClient) throw new Error("Could not find SuiClientContext. Ensure that you have set up the SuiClientProvider");
	return suiClient;
}
function useSuiClient() {
	return useSuiClientContext().client;
}
var WalletNotConnectedError = class extends Error {};
var WalletNoAccountSelectedError = class extends Error {};
var WalletFeatureNotSupportedError = class extends Error {};
function useCurrentWallet() {
	const currentWallet = useWalletStore((state) => state.currentWallet);
	const connectionStatus2 = useWalletStore((state) => state.connectionStatus);
	const supportedIntents = useWalletStore((state) => state.supportedIntents);
	switch (connectionStatus2) {
		case "connecting": return {
			connectionStatus: connectionStatus2,
			currentWallet: null,
			isDisconnected: false,
			isConnecting: true,
			isConnected: false,
			supportedIntents: []
		};
		case "disconnected": return {
			connectionStatus: connectionStatus2,
			currentWallet: null,
			isDisconnected: true,
			isConnecting: false,
			isConnected: false,
			supportedIntents: []
		};
		case "connected": return {
			connectionStatus: connectionStatus2,
			currentWallet,
			isDisconnected: false,
			isConnecting: false,
			isConnected: true,
			supportedIntents
		};
	}
}
function useDisconnectWallet({ mutationKey, ...mutationOptions } = {}) {
	const { currentWallet } = useCurrentWallet();
	const setWalletDisconnected = useWalletStore((state) => state.setWalletDisconnected);
	return useMutation({
		mutationKey: walletMutationKeys.disconnectWallet(mutationKey),
		mutationFn: async () => {
			if (!currentWallet) throw new WalletNotConnectedError("No wallet is connected.");
			try {
				await currentWallet.features["standard:disconnect"]?.disconnect();
			} catch (error) {
				console.error("Failed to disconnect the application from the current wallet.", error);
			}
			setWalletDisconnected();
		},
		...mutationOptions
	});
}
function useAutoConnectWallet() {
	const { mutateAsync: connectWallet } = useConnectWallet();
	const autoConnectEnabled = useWalletStore((state) => state.autoConnectEnabled);
	const lastConnectedWalletName = useWalletStore((state) => state.lastConnectedWalletName);
	const lastConnectedAccountAddress = useWalletStore((state) => state.lastConnectedAccountAddress);
	const wallets = useWallets();
	const { isConnected } = useCurrentWallet();
	const [clientOnly, setClientOnly] = (0, import_react.useState)(false);
	(typeof window !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect)(() => {
		setClientOnly(true);
	}, []);
	const { data, isError } = useQuery({
		queryKey: [
			"@mysten/dapp-kit",
			"autoconnect",
			{
				isConnected,
				autoConnectEnabled,
				lastConnectedWalletName,
				lastConnectedAccountAddress,
				walletCount: wallets.length
			}
		],
		queryFn: async () => {
			if (!autoConnectEnabled) return "disabled";
			if (!lastConnectedWalletName || !lastConnectedAccountAddress || isConnected) return "attempted";
			const wallet = wallets.find((wallet2) => getWalletUniqueIdentifier(wallet2) === lastConnectedWalletName);
			if (wallet) await connectWallet({
				wallet,
				accountAddress: lastConnectedAccountAddress,
				silent: true
			});
			return "attempted";
		},
		enabled: autoConnectEnabled,
		persister: void 0,
		gcTime: 0,
		staleTime: 0,
		networkMode: "always",
		retry: false,
		retryOnMount: false,
		refetchInterval: false,
		refetchIntervalInBackground: false,
		refetchOnMount: false,
		refetchOnReconnect: false,
		refetchOnWindowFocus: false
	});
	if (!autoConnectEnabled) return "disabled";
	if (!clientOnly) return "idle";
	if (isConnected) return "attempted";
	if (!lastConnectedWalletName) return "attempted";
	return isError ? "attempted" : data ?? "idle";
}
function useSlushWallet(config) {
	(typeof window !== "undefined" ? import_react.useLayoutEffect : import_react.useEffect)(() => {
		if (!config?.name) return;
		let cleanup;
		let isMounted = true;
		try {
			const result = registerSlushWallet(config.name, { origin: config.origin });
			if (isMounted && result) cleanup = result.unregister;
			else if (result) result.unregister();
		} catch (error) {
			console.error("Failed to register Slush wallet:", error);
		}
		return () => {
			isMounted = false;
			if (cleanup) cleanup();
		};
	}, [config?.name, config?.origin]);
}
var WALLET_NAME = "Unsafe Burner Wallet";
function useUnsafeBurnerWallet(enabled) {
	const suiClient = useSuiClient();
	(0, import_react.useEffect)(() => {
		if (!enabled) return;
		return registerUnsafeBurnerWallet(suiClient);
	}, [enabled, suiClient]);
}
function registerUnsafeBurnerWallet(suiClient) {
	var _on, _connect, _signPersonalMessage, _signTransactionBlock, _signTransaction, _signAndExecuteTransactionBlock, _signAndExecuteTransaction;
	const walletsApi = getWallets();
	if (walletsApi.get().find((wallet) => wallet.name === WALLET_NAME)) {
		console.warn("registerUnsafeBurnerWallet: Unsafe Burner Wallet already registered, skipping duplicate registration.");
		return;
	}
	console.warn("Your application is currently using the unsafe burner wallet. Make sure that this wallet is disabled in production.");
	const keypair = new Ed25519Keypair();
	const account = new ReadonlyWalletAccount({
		address: keypair.getPublicKey().toSuiAddress(),
		publicKey: keypair.getPublicKey().toSuiBytes(),
		chains: ["sui:unknown"],
		features: [
			"sui:signAndExecuteTransactionBlock",
			"sui:signTransactionBlock",
			"sui:signTransaction",
			"sui:signAndExecuteTransaction"
		]
	});
	class UnsafeBurnerWallet {
		constructor() {
			__privateAdd(this, _on, () => {
				return () => {};
			});
			__privateAdd(this, _connect, async () => {
				return { accounts: this.accounts };
			});
			__privateAdd(this, _signPersonalMessage, async (messageInput) => {
				const { bytes, signature } = await keypair.signPersonalMessage(messageInput.message);
				return {
					bytes,
					signature
				};
			});
			__privateAdd(this, _signTransactionBlock, async (transactionInput) => {
				const { bytes, signature } = await transactionInput.transactionBlock.sign({
					client: suiClient,
					signer: keypair
				});
				return {
					transactionBlockBytes: bytes,
					signature
				};
			});
			__privateAdd(this, _signTransaction, async (transactionInput) => {
				const { bytes, signature } = await Transaction.from(await transactionInput.transaction.toJSON()).sign({
					client: suiClient,
					signer: keypair
				});
				transactionInput.signal?.throwIfAborted();
				return {
					bytes,
					signature
				};
			});
			__privateAdd(this, _signAndExecuteTransactionBlock, async (transactionInput) => {
				const { bytes, signature } = await transactionInput.transactionBlock.sign({
					client: suiClient,
					signer: keypair
				});
				return suiClient.executeTransactionBlock({
					signature,
					transactionBlock: bytes,
					options: transactionInput.options
				});
			});
			__privateAdd(this, _signAndExecuteTransaction, async (transactionInput) => {
				const { bytes, signature } = await Transaction.from(await transactionInput.transaction.toJSON()).sign({
					client: suiClient,
					signer: keypair
				});
				transactionInput.signal?.throwIfAborted();
				const { rawEffects, digest } = await suiClient.executeTransactionBlock({
					signature,
					transactionBlock: bytes,
					options: { showRawEffects: true }
				});
				return {
					bytes,
					signature,
					digest,
					effects: toBase64(new Uint8Array(rawEffects))
				};
			});
		}
		get version() {
			return "1.0.0";
		}
		get name() {
			return WALLET_NAME;
		}
		get icon() {
			return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAADwAAAA8CAYAAAA6/NlyAAAJrElEQVR42tWbe2xT1x3H7UxAyD3XrdrSbGXlUbKWsq5rWdVuVOMRSEqSOmnVRZMmJqZNYv1nf3R/jWmVmVrtRRM/YwPd1nVTNcrE3pQCoikrIRAC4VVNY0hlD9ZOo1uCfe3ra9979v0dcy3s5Pper76Oh/STE+495/4+5/c85zqe2f7HAx5vKsS+monJj/CdHi/f4/HWW4f6AwdblmXjTM0NyS+movKtw9v+j6C5gKhyTMTTpA2x15Qwy+Pz75motOGdgKep8WF5ATgVZIt5NeO2wMqD0hfVGNPh3oYaYflsjG0l63PeyLCDnqbsLpZIhaRNFI+Ox+Le5KB0RybK8gDmJOkI07U4i/FhT1NDQl8Me5rUIfaDfELOJ0NsFa/SJQHm1WLsHcDqRWiy9BCL8s0N5t6UWWFVvxplejYm60hC91cNjPtzCTZsAptCVoeLP8PDDQJNCSodap6H+LtE8ZcdkvVkkD38vwDn4/Jvy4EhBhZSvRaUHiTXn31gJJxkUPoClBKKFizM+inhVA2cYIdM4HJouPvoe9s9H+KzDhyGK6KkmIqitBhww2C11rjQL2L4kgUwFxk8yPyzauUA3Pk/353XnA6zKbKCaQ2UlMvJF6W5uF5F8yHfZWZpC9HRmBziaEpm1bpY9XvhxuWJRldC7Mt03WlZwpjnkZUNa2DMG2EaPj9MGd2l2mofd0hQ7ZSopsXckHxVCUp32fXGdD0ZktrgFUmMqwhcWFjp87RArsD+9bn585IRaSHAKgBL3SZwOTRc8BKg7yYoskp5OJDiiPmF2Sj7ox0siYJ7lJA04EqvzZ9B1xSVt6PlW0IxZgUMJdZYAJuWngLQt9IRuZXmoTEkmci8ZtTXTViUKyasA9FRun5d8z6bfw0gYWm9mmCXxZatQgxfC7I2NVpRYQOxKWppLs4mcgn5NcibgL1K40xYp8CYY5TXEpjcb3LAJ0OZyyg3+2nySm6fjEtzkEz+7VBx3RTb+60z9dma7pkvwO2QQL5HzTtAdpKF7euw/HuzfrosBHy+ZsBimzbQshjWTVMDgez53B5MbjcGbr1ZjdUJOM5O0SLXzJ2R+uOA1dMAVoLsm5zb73JSId8t8Aa1LsAJdoTCrCaw6e3NC2DdFMUXWRg173mysJNOSUNskUJ1cOlXa2LhcbgmSszXYSn9hl3KSxTDjrZ2cbbfbWDyumsh9m3e7zCG7a3ETt+gtI7fx6lEOanZKDVvuA2cjYmt5xNOd2Louz3IQ12UZ2Zo3lkb9cDlvSs6m4Vk5Yqlabs0B97wT7PUuCXQz0Bnt9QxMPTW4iwBtmUlY8hFsHJPlzcQ1xuG75CVK1kXofCUGnU9fg1aVD7kfE9MoabtYkcAvIUYS2op3Hc3TTrDQzIAeojugTVLFolWDR6wFPtY0R66n6HltwjCIawnE2ymresk9NtN+pfUUi0mX6RJLfrh9zMRaRPOqubSA8W2MNzC0mHpK7j2ruuw5mYkxl5+2+HGQeg4yNYg7vNg+xMxFsuRMuiTsRJZG3cysAl4D9n4aC4un8L9qUyVvbCyYwFXX1nGUxFf1cCiEQqy75O+TpMwYKNKSPQUqhLyyWLsRbESLctx0YnixgfphRWA8pOPc+N4F9d+eV9V4OlCX/As5w5g+wtGhJGukp5go2R3D7EW9rSDcnGL56YgJHj+8GcFND/Vy41jj/H0jxc6HU/AA2QlR01UlH3D7CmITQnJq4lVWBi1yl8XYEh278c5H++F+Iui7r7bYR8tH/gbqoJN7fVODUhLYVVxzmYCEyOxFg7RUVa0egCHZZ55eRHnp/tKgMna6s/bbMdTxZgMzl9CCcmq7k690OzDfaeSN4QcsREjsQpgXHwyWyfg9K5WE7hc6JqTWjyihObfygOFOkv6i5K5TZx8LsL1sVS4NL8ItiB7sgAcEKcWHfUCVhK3kUVnBNbfXIs4l5xAv5sJs234eTUy93L0Au2otQOw5ORMyfQ6WwexFupVSHowG6uThXfebmlhWojMS3fazmMeGxEI6S2SUti6RAo2vKohVuH3qUG5FWm/PjH8kzutgSH5g58xrVwzIbZkxHf7OFjFC+wrMDXcpOqOKX/g01U/XPvVJyxdWsiJblqYmnZoWbDxAcR56X5WPuh4ewcL5PY9JBRUYjc7fzjG6Uc3mHBWbg23X1BLaFHOSnrw4bWiNAXSEWcWRntIignXTP/oDsfKZX66mMbZAPfhviU1AyYmJLYAMZa/QXjUSeIiixpj3UUFtd884KytjN7EjdGNNMbWwtlf3FvbQ4OQtIoYSzbxqVDLXMTxP8jnnbiyKcaJLvueGLD6kXW2sKZov1tpn7hwXf3ZUvq0K2FXOM7Op/Xgb6PhxsWIErYGVuK3WGXWkkwMMZVCVl5kWtax5A6usgemvnx4DelUcYcFC0eIbcbXKzggeyBjeXIhkftaKknJKLtnuSg7KmKQsrH+1nqbmLWY6w/tBGy/8xrruR5SM99LLIjfT/4ZbNZnQEPssIVb21rKTGRIPDagNoLdFMKgcuLc/TF6Bulk6c7ovg4TU+XvS6FNw1tDfVqH9MOPmBDui0hcK6wz744FlDjNe0m3aVldJYagtI6YbF+3ZGPsQHlN1vbeh8lJofqJ+uo9Zi4wXZxKFiXKGxbHT7pNq71oNg4Qi6MviE0FpRVqjGXILYoJ4tCjdYU1rWeMdPLc/ochj3B9pGNGL4NupGPRlUl35KMVxFLNO6ZnxYlBsUPqoMkbUqAb6VhMVKQ7MVT1dYdrL8hzEAcjpmvjHKphgaFb0ZVJZw7dwVD9q5fkgPTRbBxnzmGfgRLQsMCkG+moQdcp6GzzZsL2MGyllvBNGWM9RqMCk26kI7aBK526csVShZTfzid6FEzeiNAGP92jpCPQEbrW7EW5MbZxAz/fN9lg0IbQaaxrQ83/VoKPb/HqJx67Hw+43CDQBPsX0gm6ufXNvH4vP9rZapzx7+Nn+oxZAjfo2caZ3n350c5W6FSEdQ86sNarj3c/jRV+H42AXsdGRBfPPIlnb/mUtxzWXfALn/PmRze2Gud6E/xsXwYtnlsWN8Tc5/oyxjn/jvyJrlY82xLUfWuPr/TqxzuXQZkIP9M7CXiyuP4B4WmsTnNhzinjrD+WO9bRhmdZWLXe4EKRtV5tpN3Hx3s2G+d79/MJf4qff0LnE72kfFEs4ITQvWLMab8C131dP9n9Je1Yx000Nz2jAf+UJwCBchc3NvGR1Qx71XXY2Ww1Jvx7YalzAPkX9rp5E5Z+pv+ja8bE43uN491b9dHO9Xx4lUxziLn21Nai/wXWM6t9vkvtrwAAAABJRU5ErkJggg==";
		}
		get chains() {
			return SUI_CHAINS;
		}
		get accounts() {
			return [account];
		}
		get features() {
			return {
				"standard:connect": {
					version: "1.0.0",
					connect: __privateGet(this, _connect)
				},
				"standard:events": {
					version: "1.0.0",
					on: __privateGet(this, _on)
				},
				"sui:signPersonalMessage": {
					version: "1.1.0",
					signPersonalMessage: __privateGet(this, _signPersonalMessage)
				},
				"sui:signTransactionBlock": {
					version: "1.0.0",
					signTransactionBlock: __privateGet(this, _signTransactionBlock)
				},
				"sui:signAndExecuteTransactionBlock": {
					version: "1.0.0",
					signAndExecuteTransactionBlock: __privateGet(this, _signAndExecuteTransactionBlock)
				},
				"sui:signTransaction": {
					version: "2.0.0",
					signTransaction: __privateGet(this, _signTransaction)
				},
				"sui:signAndExecuteTransaction": {
					version: "2.0.0",
					signAndExecuteTransaction: __privateGet(this, _signAndExecuteTransaction)
				}
			};
		}
	}
	_on = /* @__PURE__ */ new WeakMap();
	_connect = /* @__PURE__ */ new WeakMap();
	_signPersonalMessage = /* @__PURE__ */ new WeakMap();
	_signTransactionBlock = /* @__PURE__ */ new WeakMap();
	_signTransaction = /* @__PURE__ */ new WeakMap();
	_signAndExecuteTransactionBlock = /* @__PURE__ */ new WeakMap();
	_signAndExecuteTransaction = /* @__PURE__ */ new WeakMap();
	return walletsApi.register(new UnsafeBurnerWallet());
}
function useWalletPropertiesChanged() {
	const { currentWallet } = useCurrentWallet();
	const updateWalletAccounts = useWalletStore((state) => state.updateWalletAccounts);
	(0, import_react.useEffect)(() => {
		return currentWallet?.features["standard:events"].on("change", ({ accounts }) => {
			if (accounts) updateWalletAccounts(accounts);
		});
	}, [currentWallet?.features, updateWalletAccounts]);
}
function useWalletsChanged(preferredWallets, walletFilter) {
	const setWalletRegistered = useWalletStore((state) => state.setWalletRegistered);
	const setWalletUnregistered = useWalletStore((state) => state.setWalletUnregistered);
	(0, import_react.useEffect)(() => {
		const walletsApi = getWallets();
		setWalletRegistered(getRegisteredWallets(preferredWallets, walletFilter));
		const unsubscribeFromRegister = walletsApi.on("register", () => {
			setWalletRegistered(getRegisteredWallets(preferredWallets, walletFilter));
		});
		const unsubscribeFromUnregister = walletsApi.on("unregister", (unregisteredWallet) => {
			setWalletUnregistered(getRegisteredWallets(preferredWallets, walletFilter), unregisteredWallet);
		});
		return () => {
			unsubscribeFromRegister();
			unsubscribeFromUnregister();
		};
	}, [
		preferredWallets,
		walletFilter,
		setWalletRegistered,
		setWalletUnregistered
	]);
}
var lightTheme = {
	blurs: { modalOverlay: "blur(0)" },
	backgroundColors: {
		primaryButton: "#F6F7F9",
		primaryButtonHover: "#F0F2F5",
		outlineButtonHover: "#F4F4F5",
		modalOverlay: "rgba(24 36 53 / 20%)",
		modalPrimary: "white",
		modalSecondary: "#F7F8F8",
		iconButton: "transparent",
		iconButtonHover: "#F0F1F2",
		dropdownMenu: "#FFFFFF",
		dropdownMenuSeparator: "#F3F6F8",
		walletItemSelected: "white",
		walletItemHover: "#3C424226"
	},
	borderColors: { outlineButton: "#E4E4E7" },
	colors: {
		primaryButton: "#373737",
		outlineButton: "#373737",
		iconButton: "#000000",
		body: "#182435",
		bodyMuted: "#767A81",
		bodyDanger: "#FF794B"
	},
	radii: {
		small: "6px",
		medium: "8px",
		large: "12px",
		xlarge: "16px"
	},
	shadows: {
		primaryButton: "0px 4px 12px rgba(0, 0, 0, 0.1)",
		walletItemSelected: "0px 2px 6px rgba(0, 0, 0, 0.05)"
	},
	fontWeights: {
		normal: "400",
		medium: "500",
		bold: "600"
	},
	fontSizes: {
		small: "14px",
		medium: "16px",
		large: "18px",
		xlarge: "20px"
	},
	typography: {
		fontFamily: "ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, \"Helvetica Neue\", Arial, \"Noto Sans\", sans-serif, \"Apple Color Emoji\", \"Segoe UI Emoji\", \"Segoe UI Symbol\", \"Noto Color Emoji\"",
		fontStyle: "normal",
		lineHeight: "1.3",
		letterSpacing: "1"
	}
};
function createWalletStore({ wallets, storage, storageKey, autoConnectEnabled }) {
	return createStore()(persist((set, get) => ({
		autoConnectEnabled,
		wallets,
		accounts: [],
		currentWallet: null,
		currentAccount: null,
		lastConnectedAccountAddress: null,
		lastConnectedWalletName: null,
		connectionStatus: "disconnected",
		supportedIntents: [],
		setConnectionStatus(connectionStatus2) {
			set(() => ({ connectionStatus: connectionStatus2 }));
		},
		setWalletConnected(wallet, connectedAccounts, selectedAccount, supportedIntents = []) {
			set(() => ({
				accounts: connectedAccounts,
				currentWallet: wallet,
				currentAccount: selectedAccount,
				lastConnectedWalletName: getWalletUniqueIdentifier(wallet),
				lastConnectedAccountAddress: selectedAccount?.address,
				connectionStatus: "connected",
				supportedIntents
			}));
		},
		setWalletDisconnected() {
			set(() => ({
				accounts: [],
				currentWallet: null,
				currentAccount: null,
				lastConnectedWalletName: null,
				lastConnectedAccountAddress: null,
				connectionStatus: "disconnected",
				supportedIntents: []
			}));
		},
		setAccountSwitched(selectedAccount) {
			set(() => ({
				currentAccount: selectedAccount,
				lastConnectedAccountAddress: selectedAccount.address
			}));
		},
		setWalletRegistered(updatedWallets) {
			set(() => ({ wallets: updatedWallets }));
		},
		setWalletUnregistered(updatedWallets, unregisteredWallet) {
			if (unregisteredWallet === get().currentWallet) set(() => ({
				wallets: updatedWallets,
				accounts: [],
				currentWallet: null,
				currentAccount: null,
				lastConnectedWalletName: null,
				lastConnectedAccountAddress: null,
				connectionStatus: "disconnected",
				supportedIntents: []
			}));
			else set(() => ({ wallets: updatedWallets }));
		},
		updateWalletAccounts(accounts) {
			const currentAccount = get().currentAccount;
			set(() => ({
				accounts,
				currentAccount: currentAccount && accounts.find(({ address }) => address === currentAccount.address) || accounts[0]
			}));
		}
	}), {
		name: storageKey,
		storage: createJSONStorage(() => storage),
		partialize: ({ lastConnectedWalletName, lastConnectedAccountAddress }) => ({
			lastConnectedWalletName,
			lastConnectedAccountAddress
		})
	}));
}
var themeVars = (0, import_vanilla_extract_css_cjs.createGlobalThemeContract)({
	blurs: { modalOverlay: "" },
	backgroundColors: {
		primaryButton: "",
		primaryButtonHover: "",
		outlineButtonHover: "",
		walletItemHover: "",
		walletItemSelected: "",
		modalOverlay: "",
		modalPrimary: "",
		modalSecondary: "",
		iconButton: "",
		iconButtonHover: "",
		dropdownMenu: "",
		dropdownMenuSeparator: ""
	},
	borderColors: { outlineButton: "" },
	colors: {
		primaryButton: "",
		outlineButton: "",
		body: "",
		bodyMuted: "",
		bodyDanger: "",
		iconButton: ""
	},
	radii: {
		small: "",
		medium: "",
		large: "",
		xlarge: ""
	},
	shadows: {
		primaryButton: "",
		walletItemSelected: ""
	},
	fontWeights: {
		normal: "",
		medium: "",
		bold: ""
	},
	fontSizes: {
		small: "",
		medium: "",
		large: "",
		xlarge: ""
	},
	typography: {
		fontFamily: "",
		fontStyle: "",
		lineHeight: "",
		letterSpacing: ""
	}
}, (_, path) => `dapp-kit-${path.join("-")}`);
function InjectedThemeStyles({ theme }) {
	const themeStyles = Array.isArray(theme) ? getDynamicThemeStyles(theme) : getStaticThemeStyles(theme);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("style", {
		precedence: "default",
		href: "mysten-dapp-kit-theme",
		dangerouslySetInnerHTML: { __html: themeStyles }
	});
}
function getDynamicThemeStyles(themes) {
	return themes.map(({ mediaQuery, selector, variables }) => {
		const themeStyles = getStaticThemeStyles(variables);
		const themeStylesWithSelectorPrefix = selector ? `${selector} ${themeStyles}` : themeStyles;
		return mediaQuery ? `@media ${mediaQuery}{${themeStylesWithSelectorPrefix}}` : themeStylesWithSelectorPrefix;
	}).join(" ");
}
function getStaticThemeStyles(theme) {
	return `${styleDataAttributeSelector} {${cssStringFromTheme(theme)}}`;
}
function cssStringFromTheme(theme) {
	return Object.entries((0, import_vanilla_extract_dynamic_cjs.assignInlineVars)(themeVars, theme)).map(([key, value]) => `${key}:${value};`).join("");
}
function WalletProvider({ preferredWallets = DEFAULT_PREFERRED_WALLETS, walletFilter = DEFAULT_WALLET_FILTER, storage = DEFAULT_STORAGE, storageKey = DEFAULT_STORAGE_KEY, enableUnsafeBurner = false, autoConnect = false, slushWallet, theme = lightTheme, children }) {
	const storeRef = (0, import_react.useRef)(createWalletStore({
		autoConnectEnabled: autoConnect,
		wallets: getRegisteredWallets(preferredWallets, walletFilter),
		storage: storage || createInMemoryStore(),
		storageKey
	}));
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(WalletContext.Provider, {
		value: storeRef.current,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(WalletConnectionManager, {
			preferredWallets,
			walletFilter,
			enableUnsafeBurner,
			slushWallet,
			children: [theme ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(InjectedThemeStyles, { theme }) : null, children]
		})
	});
}
function WalletConnectionManager({ preferredWallets = DEFAULT_PREFERRED_WALLETS, walletFilter = DEFAULT_WALLET_FILTER, enableUnsafeBurner = false, slushWallet, children }) {
	useWalletsChanged(preferredWallets, walletFilter);
	useWalletPropertiesChanged();
	useSlushWallet(slushWallet);
	useUnsafeBurnerWallet(enableUnsafeBurner);
	useAutoConnectWallet();
	return children;
}
function useSignAndExecuteTransaction({ mutationKey, execute, ...mutationOptions } = {}) {
	const { currentWallet, supportedIntents } = useCurrentWallet();
	const currentAccount = useCurrentAccount();
	const { client, network } = useSuiClientContext();
	const executeTransaction = execute ?? (async ({ bytes, signature }) => {
		const { digest, rawEffects } = await client.executeTransactionBlock({
			transactionBlock: bytes,
			signature,
			options: { showRawEffects: true }
		});
		return {
			digest,
			rawEffects,
			effects: toBase64(new Uint8Array(rawEffects)),
			bytes,
			signature
		};
	});
	return useMutation({
		mutationKey: walletMutationKeys.signAndExecuteTransaction(mutationKey),
		mutationFn: async ({ transaction, ...signTransactionArgs }) => {
			if (!currentWallet) throw new WalletNotConnectedError("No wallet is connected.");
			const signerAccount = signTransactionArgs.account ?? currentAccount;
			if (!signerAccount) throw new WalletNoAccountSelectedError("No wallet account is selected to sign the transaction with.");
			if (!currentWallet.features["sui:signTransaction"] && !currentWallet.features["sui:signTransactionBlock"]) throw new WalletFeatureNotSupportedError("This wallet doesn't support the `signTransaction` feature.");
			if (typeof transaction !== "string" && "setSenderIfNotSet" in transaction) transaction.setSenderIfNotSet(signerAccount.address);
			const chain = signTransactionArgs.chain ?? `sui:${network}`;
			const { signature, bytes } = await signTransaction(currentWallet, {
				...signTransactionArgs,
				transaction: { async toJSON() {
					return typeof transaction === "string" ? transaction : await transaction.toJSON({
						supportedIntents,
						client
					});
				} },
				account: signerAccount,
				chain
			});
			return await executeTransaction({
				bytes,
				signature
			});
		},
		...mutationOptions
	});
}
//#endregion
export { require_react as A, skipToken as C, hmac as D, sha256 as E, require_react_dom as O, resolveQueryValue as S, useQueryClient as T, hashQueryKeyByOptions as _, useDisconnectWallet as a, noop as b, useQuery as c, onlineManager as d, notifyManager as f, hashKey as g, functionalUpdate as h, useCurrentAccount as i, Transaction as j, require_jsx_runtime as k, Mutation as l, Subscribable as m, SuiClientProvider as n, useSignAndExecuteTransaction as o, focusManager as p, WalletProvider as r, useMutation as s, ConnectModal as t, Query as u, matchMutation as v, QueryClientProvider as w, partialMatchKey as x, matchQuery as y };
