//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-Cy_Xz8LV.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/docs",
			"/login",
			"/api/verify-x",
			"/api/auth/$",
			"/api/v1/bite",
			"/api/v1/lure",
			"/api/v1/tape",
			"/api/v1/coins/$ticker",
			"/api/v1/coins/"
		],
		preloads: ["/assets/index-C5aCJzni.js", "/assets/react-DB-4Zxce.js"],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-C5aCJzni.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-BVu_mSEY.js",
			"/assets/shell-kJb19EZN.js",
			"/assets/verify-x-CmLpBeWc.js"
		]
	},
	"/docs": {
		filePath: "/workspace/src/routes/docs.tsx",
		children: void 0,
		preloads: ["/assets/docs-BQujCRv8.js", "/assets/shell-kJb19EZN.js"]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DvLPraR8.js",
			"/assets/shell-kJb19EZN.js",
			"/assets/verify-x-CmLpBeWc.js"
		]
	}
} });
//#endregion
export { tsrStartManifest };
