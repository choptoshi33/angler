const KEY = "angler-trench";

export function getTrench(): string {
  const existing = localStorage.getItem(KEY);
  if (existing && /^[A-Za-z0-9_-]{8,64}$/.test(existing)) return existing;
  const id = crypto.randomUUID();
  localStorage.setItem(KEY, id);
  return id;
}
