import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import type { AddResult, BiteResult, LureState, NightCastResult, XMe } from "@/lib/lure/types";

export const getLure = createServerFn({ method: "GET" }).handler(async (): Promise<LureState> => {
  const { getLureState } = await import("./core.server");
  return getLureState();
});

export const throwBite = createServerFn({ method: "POST" })
  .validator((data: unknown) => data)
  .handler(async ({ data }): Promise<BiteResult> => {
    const { placeBite } = await import("./core.server");
    return placeBite(data);
  });

export const whoamiX = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<XMe> => {
    const { xIdentity } = await import("./core.server");
    return xIdentity(context.userId);
  });

export const throwVerifiedBite = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => data)
  .handler(async ({ data, context }): Promise<BiteResult> => {
    const { loadXVoter, placeBite } = await import("./core.server");
    const voter = await loadXVoter(context.userId);
    if (!voter) {
      return { ok: false, status: 403, error: "Sign in with X to put your profile on this vote." };
    }
    return placeBite(data, voter);
  });

export const myNight = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }): Promise<{ voted: boolean }> => {
    const { loadXVoter } = await import("./core.server");
    const { alreadyVoted } = await import("./night.server");
    const voter = await loadXVoter(context.userId);
    if (!voter) return { voted: false };
    return { voted: await alreadyVoted(voter.accountId) };
  });

export const castNightVote = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((data: unknown) => data)
  .handler(async ({ data, context }): Promise<NightCastResult> => {
    const { loadXVoter } = await import("./core.server");
    const { placeNightVote } = await import("./night.server");
    const voter = await loadXVoter(context.userId);
    if (!voter) {
      return { ok: false, status: 403, error: "Sign in with X before you pay 1 SUI." };
    }
    return placeNightVote(data, voter);
  });

export const listCoin = createServerFn({ method: "POST" })
  .validator((data: unknown) => data)
  .handler(async ({ data }): Promise<AddResult> => {
    const { addCoin } = await import("./core.server");
    return addCoin(data);
  });
