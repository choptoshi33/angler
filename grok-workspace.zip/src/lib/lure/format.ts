export function shortCa(contract: string): string {
  const parts = contract.split("::");
  const head = contract.slice(0, 6);
  const tail = parts.slice(1).join("::");
  return tail ? `${head}…${tail}` : `${head}…`;
}

export function chartUrl(contract: string): string {
  return `https://dexscreener.com/sui/${encodeURI(contract)}`;
}

export function scanUrl(contract: string): string {
  return `https://suiscan.xyz/mainnet/coin/${encodeURI(contract)}`;
}

export function joinOr(names: string[]): string {
  if (names.length === 0) return "";
  if (names.length === 1) return names[0] ?? "";
  if (names.length === 2) return `${names[0]} or ${names[1]}`;
  return `${names.slice(0, -1).join(", ")}, or ${names[names.length - 1]}`;
}

export function ago(iso: string): string {
  const then = new Date(iso).getTime();
  if (Number.isNaN(then)) return "";
  const s = Math.max(0, Math.round((Date.now() - then) / 1000));
  if (s < 60) return `${s}s`;
  const m = Math.round(s / 60);
  if (m < 60) return `${m}m`;
  return `${Math.round(m / 60)}h`;
}
