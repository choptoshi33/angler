const CLOCK = "0x0000000000000000000000000000000000000000000000000000000000000006";
const GRAPHQL = "https://graphql.mainnet.sui.io/graphql";

/** Milliseconds from the shared Clock at 0x6. Null if Sui doesn't answer. */
export async function readChainClockMs(): Promise<number | null> {
  try {
    const res = await fetch(GRAPHQL, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        query: `{ object(address: "${CLOCK}") { asMoveObject { contents { json } } } }`,
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return null;
    const json = (await res.json()) as {
      data?: { object?: { asMoveObject?: { contents?: { json?: { timestamp_ms?: unknown } } } } };
    };
    const raw = json.data?.object?.asMoveObject?.contents?.json?.timestamp_ms;
    const ms = typeof raw === "string" || typeof raw === "number" ? Number(raw) : NaN;
    return Number.isFinite(ms) && ms > 1_000_000_000_000 ? ms : null;
  } catch {
    return null;
  }
}
