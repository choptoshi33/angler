import { env } from "@/lib/env.server";
import { getSql } from "@/lib/db";
import { readChainClockMs } from "@/lib/lure/clock.server";
import { POT_ADDRESS } from "@/lib/lure/treasury";
import { BUY_GAP_MIN, BUY_SLICES, type BuySlice, type Fail, type NightCastResult, type NightStanding, type NightState, type NightVoter, type SettledNight } from "@/lib/lure/types";

const DAY_MS = 24 * 60 * 60 * 1000;
const SLICE_GAP_MS = BUY_GAP_MIN * 60 * 1000;
const ONE_SUI = 1_000_000_000n;
const SUI_COIN = "0x2::sui::SUI";
const ADDRESS = /^0x[a-f0-9]{64}$/;
const DIGEST = /^[1-9A-HJ-NP-Za-km-z]{32,64}$/;
const TICKER = /^[A-Z0-9]{2,10}$/;
const TRENCH = /^[A-Za-z0-9_-]{8,64}$/;
const RPC = "https://fullnode.mainnet.sui.io:443";

export type NightVoterInput = { userId: string; accountId: string; name: string };

type VoteRow = {
  ticker: string;
  coin_name: string;
  sender: string;
  x_account_id: string;
  x_name: string;
};

function fail(status: number, error: string): Fail {
  return { ok: false, status, error };
}

function asRecord(v: unknown): Record<string, unknown> | null {
  if (!v || typeof v !== "object" || Array.isArray(v)) return null;
  return v as Record<string, unknown>;
}

function asIso(v: unknown): string {
  if (v instanceof Date) return v.toISOString();
  if (typeof v === "string") {
    const d = new Date(v);
    if (!Number.isNaN(d.getTime())) return d.toISOString();
  }
  return new Date(0).toISOString();
}

function nightOf(ms: number): { start: Date; end: Date } {
  const startMs = Math.floor(ms / DAY_MS) * DAY_MS;
  return { start: new Date(startMs), end: new Date(startMs + DAY_MS) };
}

export function treasuryAddress(): string | null {
  const raw = (env("SUI_TREASURY_ADDRESS") || POT_ADDRESS).trim().toLowerCase();
  return ADDRESS.test(raw) ? raw : null;
}

function profileOf(accountId: string): string | null {
  const handle = accountId.replace(/^@/, "");
  if (/^[A-Za-z0-9_]{1,15}$/.test(handle)) return `https://x.com/${handle}`;
  return null;
}

function toVoter(row: VoteRow): NightVoter {
  return {
    name: row.x_name,
    profile: profileOf(row.x_account_id),
    wallet: row.sender,
    ticker: row.ticker,
  };
}

async function settleClosed(sql: Awaited<ReturnType<typeof getSql>>, clockMs: number): Promise<void> {
  const clockIso = new Date(clockMs).toISOString();
  const due = await sql<{ night_start: unknown }>`
    select distinct v.night_start as night_start
    from night_votes v
    where v.night_start + interval '24 hours' <= ${clockIso}
      and not exists (
        select 1 from night_settlements s where s.night_start = v.night_start
      )
  `;
  for (const row of due) {
    const start = asIso(row.night_start);
    const ranked = await sql<{ ticker: string }>`
      select ticker
      from night_votes
      where night_start = ${start}
      group by ticker
      order by count(*) desc, min(created_at) asc, ticker asc
      limit 1
    `;
    const counted = await sql<{ n: number | string }>`
      select count(*) as n from night_votes where night_start = ${start}
    `;
    const endMs = new Date(start).getTime() + DAY_MS;
    const end = new Date(endMs).toISOString();
    const winner = ranked[0]?.ticker ?? null;
    const potVotes = Number(counted[0]?.n) || 0;
    await sql`
      insert into night_settlements (night_start, ends_at, winner, pot_votes)
      values (${start}, ${end}, ${winner}, ${potVotes})
      on conflict (night_start) do nothing
    `;
    if (!winner || potVotes < 1) continue;
    const totalMist = potVotes * 1_000_000_000;
    const base = Math.floor(totalMist / BUY_SLICES);
    const remainder = totalMist - base * BUY_SLICES;
    for (let index = 1; index <= BUY_SLICES; index += 1) {
      const mist = base + (index === BUY_SLICES ? remainder : 0);
      const opens = new Date(endMs + (index - 1) * SLICE_GAP_MS).toISOString();
      await sql`
        insert into night_slices (night_start, slice_index, opens_at, sui_mist, status)
        values (${start}, ${index}, ${opens}, ${mist}, 'scheduled')
        on conflict (night_start, slice_index) do nothing
      `;
    }
  }
  await sql`
    update night_slices
    set status = 'due'
    where status = 'scheduled' and opens_at <= ${clockIso}
  `;
}

function suiFromMist(mist: number): number {
  return Math.round((mist / 1_000_000_000) * 10_000) / 10_000;
}

export async function loadNight(): Promise<NightState> {
  const sql = await getSql();
  const clockMs = await readChainClockMs();
  if (clockMs != null) await settleClosed(sql, clockMs);
  const now = nightOf(clockMs ?? Date.now());
  const start = now.start.toISOString();
  const rows = await sql<VoteRow>`
    select v.ticker, c.name as coin_name, v.sender, v.x_account_id, v.x_name
    from night_votes v
    join coins c on c.ticker = v.ticker
    where v.night_start = ${start}
    order by v.created_at asc
  `;
  const byTicker = new Map<string, NightStanding>();
  for (const row of rows) {
    const slot = byTicker.get(row.ticker) ?? { ticker: row.ticker, name: row.coin_name, votes: 0 };
    slot.votes += 1;
    byTicker.set(row.ticker, slot);
  }
  const standings = [...byTicker.values()].sort(
    (a, b) => b.votes - a.votes || a.ticker.localeCompare(b.ticker),
  );
  const lastRows = await sql<{
    ends_at: unknown;
    winner: string | null;
    pot_votes: number | string;
    winner_name: string | null;
    night_start: unknown;
  }>`
    select s.night_start, s.ends_at, s.winner, s.pot_votes, c.name as winner_name
    from night_settlements s
    left join coins c on c.ticker = s.winner
    order by s.night_start desc
    limit 1
  `;
  let last: SettledNight | null = null;
  if (lastRows[0]) {
    const lastStart = asIso(lastRows[0].night_start);
    const winner = lastRows[0].winner;
    const shareRows = winner
      ? await sql<VoteRow>`
          select v.ticker, c.name as coin_name, v.sender, v.x_account_id, v.x_name
          from night_votes v
          join coins c on c.ticker = v.ticker
          where v.night_start = ${lastStart}
            and v.ticker = ${winner}
          order by v.created_at asc
        `
      : [];
    const sliceRows = await sql<{
      slice_index: number | string;
      opens_at: unknown;
      sui_mist: number | string;
      status: string;
    }>`
      select slice_index, opens_at, sui_mist, status
      from night_slices
      where night_start = ${lastStart}
      order by slice_index asc
    `;
    const slices: BuySlice[] = sliceRows.map((slice) => ({
      index: Number(slice.slice_index),
      opensAt: asIso(slice.opens_at),
      sui: suiFromMist(Number(slice.sui_mist) || 0),
      status: slice.status === "bought" ? "bought" : slice.status === "due" ? "due" : "scheduled",
    }));
    last = {
      winner: winner,
      winnerName: lastRows[0].winner_name,
      potSui: Number(lastRows[0].pot_votes) || 0,
      voters: shareRows.length,
      endedAt: asIso(lastRows[0].ends_at),
      shares: shareRows.map(toVoter),
      slices,
    };
  }
  return {
    voteSui: 1,
    startsAt: start,
    endsAt: now.end.toISOString(),
    potSui: rows.length,
    verifiedVotes: rows.length,
    treasury: treasuryAddress(),
    leader: standings[0] ?? null,
    standings,
    voters: rows.map(toVoter),
    last,
    clockOk: clockMs != null,
  };
}

export async function alreadyVoted(accountId: string): Promise<boolean> {
  const sql = await getSql();
  const start = nightOf(Date.now()).start.toISOString();
  const rows = await sql<{ n: number | string }>`
    select count(*) as n from night_votes
    where x_account_id = ${accountId} and night_start = ${start}
  `;
  return (Number(rows[0]?.n) || 0) > 0;
}

type RpcTx = {
  timestampMs?: string | null;
  effects?: { status?: { status?: string } };
  balanceChanges?: { owner?: unknown; coinType?: string; amount?: string }[];
  transaction?: { data?: { sender?: string } };
};

function ownerAddress(owner: unknown): string | null {
  if (!owner || typeof owner !== "object") return null;
  const value = (owner as { AddressOwner?: unknown }).AddressOwner;
  return typeof value === "string" ? value.toLowerCase() : null;
}

async function readPayment(digest: string, treasury: string): Promise<{ sender: string; at: number } | "down" | "bad"> {
  try {
    const res = await fetch(env("SUI_RPC_URL") || RPC, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({
        jsonrpc: "2.0",
        id: 1,
        method: "sui_getTransactionBlock",
        params: [digest, { showEffects: true, showInput: true, showBalanceChanges: true }],
      }),
      signal: AbortSignal.timeout(8000),
    });
    if (!res.ok) return "down";
    const json = (await res.json()) as { result?: RpcTx | null; error?: unknown };
    if (json.error || !json.result) return json.error ? "down" : "bad";
    const tx = json.result;
    if (tx.effects?.status?.status !== "success") return "bad";
    const sender = tx.transaction?.data?.sender?.toLowerCase() ?? "";
    if (!ADDRESS.test(sender)) return "bad";
    let received = 0n;
    for (const change of tx.balanceChanges ?? []) {
      if (change.coinType !== SUI_COIN) continue;
      if (ownerAddress(change.owner) !== treasury) continue;
      try {
        received += BigInt(change.amount ?? "0");
      } catch {
        return "bad";
      }
    }
    if (received !== ONE_SUI) return "bad";
    const at = Number(tx.timestampMs);
    if (!Number.isFinite(at)) return "bad";
    return { sender, at };
  } catch {
    return "down";
  }
}

export async function placeNightVote(input: unknown, voter: NightVoterInput): Promise<NightCastResult> {
  try {
    const body = asRecord(input);
    if (!body) return fail(400, "Send the coin you hold, the coin you back, and the payment.");
    const from = typeof body.from === "string" ? body.from.trim().toUpperCase() : "";
    const to = typeof body.to === "string" ? body.to.trim().toUpperCase() : "";
    const trench = typeof body.trench === "string" ? body.trench.trim() : "";
    const digest = typeof body.digest === "string" ? body.digest.trim() : "";
    if (!TICKER.test(from) || !TICKER.test(to)) return fail(400, "Tickers are 2–10 letters or numbers.");
    if (from === to) return fail(400, "You can't vote for the coin you hold.");
    if (!TRENCH.test(trench)) return fail(400, "Id must be 8–64 letters, numbers, _ or -.");
    if (!DIGEST.test(digest)) return fail(400, "That doesn't look like a Sui transaction.");

    const treasury = treasuryAddress();
    if (!treasury) return fail(503, "The pot address isn't set, so a vote can't take 1 SUI yet.");

    const sql = await getSql();
    const known = await sql<{ ticker: string }>`select ticker from coins where ticker in (${from}, ${to})`;
    const have = new Set(known.map((row) => row.ticker));
    if (!have.has(from)) return fail(404, `$${from} isn't on the board yet.`);
    if (!have.has(to)) return fail(404, `$${to} isn't on the board yet.`);

    const payment = await readPayment(digest, treasury);
    if (payment === "down") return fail(503, "Sui didn't answer. If you already paid, submit the same transaction again.");
    if (payment === "bad") return fail(400, "That transaction isn't a 1 SUI payment into the pot.");

    const night = nightOf(payment.at);
    if (payment.at > Date.now() + 2 * 60 * 1000) return fail(400, "That payment is timestamped in the future.");
    const settled = await sql<{ n: number | string }>`
      select count(*) as n from night_settlements where night_start = ${night.start.toISOString()}
    `;
    if ((Number(settled[0]?.n) || 0) > 0) {
      return fail(400, "That night already closed. This payment can't be counted.");
    }

    const start = night.start.toISOString();
    const dupAccount = await sql<{ n: number | string }>`
      select count(*) as n from night_votes
      where x_account_id = ${voter.accountId} and night_start = ${start}
    `;
    if ((Number(dupAccount[0]?.n) || 0) > 0) return fail(409, "This X account already voted tonight.");
    const dupWallet = await sql<{ n: number | string }>`
      select count(*) as n from night_votes
      where sender = ${payment.sender} and night_start = ${start}
    `;
    if ((Number(dupWallet[0]?.n) || 0) > 0) return fail(409, "This wallet already voted tonight.");

    try {
      await sql`
        insert into night_votes (digest, sender, ticker, x_user_id, x_account_id, x_name, night_start)
        values (
          ${digest},
          ${payment.sender},
          ${to},
          ${voter.userId},
          ${voter.accountId},
          ${voter.name},
          ${start}
        )
      `;
    } catch (error) {
      const message = error instanceof Error ? error.message : "";
      if (/unique|duplicate/i.test(message)) return fail(409, "That payment is already on the board.");
      throw error;
    }

    const { placeBite } = await import("./core.server");
    const bite = await placeBite({ from, to, trench }, voter);
    const { getLureState } = await import("./core.server");
    const lure = bite.ok ? bite.lure : await getLureState();
    return {
      ok: true,
      lure,
      ticker: to,
      note: `1 SUI is in for $${to}. If it is ahead at midnight, the buys start then, in small slices. Only wallets that voted for the winner are paid.`,
    };
  } catch (error) {
    console.error(error);
    return fail(500, "Something broke. If you already paid, submit the same transaction again.");
  }
}
