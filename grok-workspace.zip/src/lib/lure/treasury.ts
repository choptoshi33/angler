/** Public pot wallet. Not a secret. Votes pay 1 SUI here. */
export const POT_ADDRESS = "0x8647ea399259b43f7b3b277c5ce009f2be358fb5c3c45d6b6a35f0f3b6742f33";
