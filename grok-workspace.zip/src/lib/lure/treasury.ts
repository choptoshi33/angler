/** Public pot wallet. Not a secret. Leave blank until the address is known. */
export const POT_ADDRESS = "";
