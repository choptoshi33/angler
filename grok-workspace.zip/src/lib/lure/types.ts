export const WINDOW_HOURS = 6;

export const HEAT_NAME = ["Quiet", "Spark", "Warm", "Buy", "Hot", "Burn", "Fire"] as const;

export type SchoolStatus = "dark" | "lonely" | "circling" | "schooled" | "hot" | "burn" | "fire";

export type VerifiedVote = {
  name: string;
  profile: string | null;
};

export type CoinCard = {
  ticker: string;
  name: string;
  contract: string;
  about: string | null;
  website: string | null;
  x: string | null;
  telegram: string | null;
  bites: number;
  schools: number;
  score: number;
  heat: number;
  status: SchoolStatus;
  feeders: string[];
  verified: VerifiedVote[];
};

export type Bite = {
  id: string;
  from: string;
  to: string;
  at: string;
  opening: boolean;
  verified: VerifiedVote | null;
};

export type NightStanding = {
  ticker: string;
  name: string;
  votes: number;
};

export type NightVoter = {
  name: string;
  profile: string | null;
  wallet: string;
  ticker: string;
};

export const BUY_SLICES = 12;
export const BUY_GAP_MIN = 5;
export const SLIPPAGE_BPS = 100;

export type BuySlice = {
  index: number;
  opensAt: string;
  sui: number;
  status: "scheduled" | "due" | "bought";
};

export type SettledNight = {
  winner: string | null;
  winnerName: string | null;
  potSui: number;
  voters: number;
  endedAt: string;
  shares: NightVoter[];
  slices: BuySlice[];
};

export type NightState = {
  voteSui: 1;
  startsAt: string;
  endsAt: string;
  potSui: number;
  verifiedVotes: number;
  treasury: string | null;
  leader: NightStanding | null;
  standings: NightStanding[];
  voters: NightVoter[];
  last: SettledNight | null;
  clockOk: boolean;
};

export type SlicePrepareResult = { ok: true; tx: string } | Fail;

export type SliceConfirmResult = { ok: true; lure: LureState; note: string } | Fail;

export type LureState = {
  windowHours: number;
  catch: CoinCard | null;
  coins: CoinCard[];
  tape: Bite[];
  night: NightState;
};

export type NightCastResult =
  | { ok: true; lure: LureState; ticker: string; note: string }
  | Fail;

export type BiteOk = {
  ok: true;
  bite: Bite;
  lure: LureState;
  newSchool: boolean;
  justLit: boolean;
  heat: number;
};

export type AddOk = {
  ok: true;
  already: boolean;
  ticker: string;
  name: string;
  lure: LureState;
};

export type Fail = {
  ok: false;
  status: number;
  error: string;
  retryAfterSec?: number;
};

export type BiteResult = BiteOk | Fail;
export type AddResult = AddOk | Fail;

export type XMe = { ok: true; name: string; profile: string | null } | { ok: false };
