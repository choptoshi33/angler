import { authClient } from "@/lib/auth/client";

const BEARER_KEY = "grok-auth.bearer-token";

type PopupMessage = { source: "angler-x"; token: string | null; error?: string };

/** Open X sign-in in a popup and keep it on the current session when one exists. */
export function verifyWithX(): Promise<void> {
  const popup = window.open(
    `${window.location.origin}/api/verify-x`,
    `angler-x-${Date.now()}`,
    "popup,width=520,height=700",
  );
  if (!popup) {
    return Promise.reject(new Error("Pop-up blocked. Allow pop-ups and try again."));
  }
  return waitForVerify(popup).then(async (message) => {
    if (message.error) throw new Error(message.error);
    if (!message.token) throw new Error("X verification did not finish.");
    try {
      window.sessionStorage.setItem(BEARER_KEY, message.token);
    } catch {
      /* the cookie path still works outside the preview iframe */
    }
    await authClient.getSession();
  });
}

function waitForVerify(popup: Window): Promise<PopupMessage> {
  return new Promise((resolve) => {
    const origin = window.location.origin;
    let settled = false;
    let closeTimer: number | undefined;
    const settle = (message: PopupMessage) => {
      if (settled) return;
      settled = true;
      window.clearInterval(pollTimer);
      if (closeTimer !== undefined) window.clearTimeout(closeTimer);
      window.removeEventListener("message", onMessage);
      resolve(message);
    };
    const onMessage = (event: MessageEvent) => {
      if (event.origin !== origin) return;
      const data = event.data as PopupMessage | undefined;
      if (!data || data.source !== "angler-x") return;
      settle(data);
    };
    const pollTimer = window.setInterval(() => {
      if (!popup.closed) return;
      window.clearInterval(pollTimer);
      closeTimer = window.setTimeout(
        () => settle({ source: "angler-x", token: null, error: "X window was closed." }),
        400,
      );
    }, 300);
    window.addEventListener("message", onMessage);
  });
}
