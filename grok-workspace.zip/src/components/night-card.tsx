import { useEffect, useState } from "react";
import { BUY_GAP_MIN, BUY_SLICES, SLIPPAGE_BPS, type NightState, type NightVoter } from "@/lib/lure/types";

function shortWallet(wallet: string): string {
  if (wallet.length < 12) return wallet;
  return `${wallet.slice(0, 6)}…${wallet.slice(-4)}`;
}

function Dawn({ endsAt }: { endsAt: string }) {
  const [label, setLabel] = useState("midnight UTC");
  useEffect(() => {
    const tick = () => {
      const ms = new Date(endsAt).getTime() - Date.now();
      if (ms <= 0) {
        setLabel("Now");
        return;
      }
      const hours = Math.floor(ms / 3_600_000);
      const minutes = Math.floor((ms % 3_600_000) / 60_000);
      const seconds = Math.floor((ms % 60_000) / 1000);
      setLabel(`${hours}h ${String(minutes).padStart(2, "0")}m ${String(seconds).padStart(2, "0")}s`);
    };
    tick();
    const id = setInterval(tick, 1000);
    return () => clearInterval(id);
  }, [endsAt]);
  return <span className="tabular-nums">{label}</span>;
}

function Person({ voter }: { voter: NightVoter }) {
  const wallet = shortWallet(voter.wallet);
  return (
    <span>
      {voter.profile ? (
        <a className="text-hot underline decoration-line underline-offset-2" href={voter.profile} target="_blank" rel="noreferrer">
          {voter.name}
        </a>
      ) : (
        <span className="text-hot">{voter.name}</span>
      )}
      <span className="text-mist"> · {wallet}</span>
    </span>
  );
}

export function NightCard({ night }: { night: NightState }) {
  const treasury = night.treasury;
  const max = night.standings[0]?.votes ?? 0;
  const share = night.leader && night.leader.votes > 0 ? `1/${night.leader.votes}` : "—";
  return (
    <section className="rounded-card border border-line bg-deep p-4 sm:p-6">
      <div className="flex items-start justify-between gap-3">
        <p className="font-display text-xs tracking-widest text-mist">TONIGHT</p>
        <p className="font-display text-xs tracking-widest text-lure">
          CLOSES <Dawn endsAt={night.endsAt} />
        </p>
      </div>
      {night.leader ? (
        <>
          <h1 className="mt-2 font-display text-5xl font-bold text-foam sm:text-6xl">${night.leader.ticker}</h1>
          <p className="mt-1 text-mist">{night.leader.name}</p>
          <p className="mt-3 text-base text-foam">
            {night.leader.votes} verified {night.leader.votes === 1 ? "vote" : "votes"}. If it is still ahead at midnight,
            the buys of ${night.leader.ticker} start then. {BUY_SLICES} buys, {BUY_GAP_MIN} minutes apart, each within{" "}
            {SLIPPAGE_BPS / 100}% of the first. Only wallets that voted for it are paid.
          </p>
        </>
      ) : (
        <>
          <h1 className="mt-2 font-display text-4xl font-bold text-foam sm:text-5xl">No leader yet</h1>
          <p className="mt-3 text-base text-foam">
            Nobody has paid tonight. The first verified vote puts 1 SUI in the pot and names a coin.
          </p>
        </>
      )}
      <dl className="mt-4 grid grid-cols-3 gap-2">
        <div className="rounded-2xl bg-panel px-3 py-2">
          <dt className="text-xs text-mist">Pot</dt>
          <dd className="font-display text-2xl font-bold tabular-nums">{night.potSui} SUI</dd>
        </div>
        <div className="rounded-2xl bg-panel px-3 py-2">
          <dt className="text-xs text-mist">Votes</dt>
          <dd className="font-display text-2xl font-bold tabular-nums">{night.verifiedVotes}</dd>
        </div>
        <div className="rounded-2xl bg-panel px-3 py-2">
          <dt className="text-xs text-mist">Winner share</dt>
          <dd className="font-display text-2xl font-bold tabular-nums">{share}</dd>
        </div>
      </dl>
      {night.standings.length ? (
        <ol className="mt-4 flex flex-col gap-3">
          {night.standings.map((row) => (
            <li key={row.ticker}>
              <div className="flex items-baseline justify-between gap-3">
                <span className="font-display text-lg font-bold">${row.ticker}</span>
                <span className="text-sm tabular-nums text-mist">
                  {row.votes} {row.votes === 1 ? "vote" : "votes"}
                </span>
              </div>
              <div className="mt-1 h-1.5 overflow-hidden rounded-full bg-panel" aria-hidden="true">
                <div className="h-full rounded-full bg-lure" style={{ width: `${max ? (row.votes / max) * 100 : 0}%` }} />
              </div>
            </li>
          ))}
        </ol>
      ) : null}
      {treasury ? (
        <p className="mt-4 text-xs text-mist">
          1 SUI goes to{" "}
          <a
            className="text-foam underline decoration-line underline-offset-2"
            href={`https://suiscan.xyz/mainnet/account/${treasury}`}
            target="_blank"
            rel="noreferrer"
          >
            {shortWallet(treasury)}
          </a>
          . One vote per X account. One per wallet.
        </p>
      ) : (
        <p className="mt-4 text-xs text-mist">The pot wallet is not saved yet. A vote cannot take 1 SUI until that address is in.</p>
      )}
      <p className="mt-2 text-xs text-mist">
        {night.clockOk
          ? `Midnight is the Sui clock. ${BUY_SLICES} buys start then, one every ${BUY_GAP_MIN} minutes, capped at ${SLIPPAGE_BPS / 100}% slippage. Any wallet can send the next buy. Only the winner's voters are paid.`
          : "The Sui clock didn't answer, so no buy can open."}
      </p>
      {night.last && night.last.potSui > 0 ? (
        <div className="mt-4 border-t border-line pt-4">
          <p className="font-display text-xs tracking-widest text-mist">LAST NIGHT</p>
          <p className="mt-2 text-sm text-foam">
            {night.last.winner
              ? `$${night.last.winner} won. ${night.last.voters} ${night.last.voters === 1 ? "wallet that voted for it is paid" : "wallets that voted for it are paid"}. Other votes are not.`
              : "That night closed with no votes."}
          </p>
          {night.last.slices.length ? (
            <ol className="mt-2">
              {night.last.slices.map((slice) => (
                <li key={slice.index} className="flex items-baseline justify-between gap-3 border-b border-line py-1.5 text-sm">
                  <span>Buy {slice.index}</span>
                  <span className="tabular-nums text-mist">
                    {slice.sui} SUI · {slice.status === "due" ? "Open" : "Waiting"}
                  </span>
                </li>
              ))}
            </ol>
          ) : null}
          {night.last.shares.length ? (
            <p className="mt-2 text-sm text-mist">
              Paid to:{" "}
              {night.last.shares.map((voter, index) => (
                <span key={`${voter.wallet}-share`}>
                  {index > 0 ? " · " : null}
                  <Person voter={voter} />
                </span>
              ))}
            </p>
          ) : null}
        </div>
      ) : null}
    </section>
  );
}
