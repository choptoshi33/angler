import { ConnectModal, SuiClientProvider, WalletProvider, useCurrentAccount, useDisconnectWallet, useSignAndExecuteTransaction } from "@mysten/dapp-kit";
import { Transaction } from "@mysten/sui/transactions";
import { useState } from "react";
import "@mysten/dapp-kit/dist/index.css";
import { castNightVote } from "@/lib/lure/functions";
import type { PayProps } from "@/components/pay-vote-slot";

const RPC = "https://fullnode.mainnet.sui.io:443";
const ONE_SUI = 1_000_000_000;

export function PayVote(props: PayProps) {
  return (
    <SuiClientProvider networks={{ mainnet: { url: RPC, network: "mainnet" } }} defaultNetwork="mainnet">
      <WalletProvider autoConnect>
        <PayForm {...props} />
      </WalletProvider>
    </SuiClientProvider>
  );
}

function PayForm({ treasury, hold, feed, trench, ready, onResult }: PayProps) {
  const account = useCurrentAccount();
  const disconnect = useDisconnectWallet();
  const sign = useSignAndExecuteTransaction();
  const [busy, setBusy] = useState(false);
  const [digest, setDigest] = useState("");
  const canPay = Boolean(ready && treasury && hold && feed && hold !== feed && trench && account && !busy);

  async function submit(paidDigest: string) {
    if (!hold || !feed || !trench) return;
    setBusy(true);
    try {
      const result = await castNightVote({
        data: { from: hold, to: feed, trench, digest: paidDigest },
      });
      onResult(result);
      if (result.ok) setDigest("");
    } catch {
      onResult({ ok: false, status: 500, error: "The vote didn't go through. If you paid, paste the transaction below." });
    } finally {
      setBusy(false);
    }
  }

  async function pay() {
    if (!treasury || !canPay) return;
    setBusy(true);
    try {
      const tx = new Transaction();
      const [coin] = tx.splitCoins(tx.gas, [ONE_SUI]);
      tx.transferObjects([coin], treasury);
      const result = await sign.mutateAsync({ transaction: tx });
      setBusy(false);
      await submit(result.digest);
    } catch (error) {
      setBusy(false);
      const message = error instanceof Error ? error.message : "The wallet didn't finish the payment.";
      onResult({ ok: false, status: 400, error: message });
    }
  }

  return (
    <div className="mt-4">
      {account ? (
        <button type="button" className="bite-btn" disabled={!canPay} onClick={() => void pay()}>
          {busy ? "Waiting for the wallet…" : feed ? `Pay 1 SUI and vote for $${feed}` : "Pay 1 SUI and vote"}
        </button>
      ) : (
        <ConnectModal
          trigger={
            <button type="button" className="bite-btn" disabled={!ready || busy}>
              Connect a Sui wallet
            </button>
          }
        />
      )}
      {account ? (
        <button
          type="button"
          className="mt-2 block text-sm text-mist underline decoration-line underline-offset-2"
          onClick={() => disconnect.mutate()}
        >
          {account.address.slice(0, 6)}…{account.address.slice(-4)} · disconnect
        </button>
      ) : null}
      <label className="mt-3 block text-xs text-mist" htmlFor="paid-digest">
        Already paid? Paste the transaction id.
      </label>
      <div className="mt-1 flex flex-col gap-2 sm:flex-row">
        <input
          id="paid-digest"
          value={digest}
          onChange={(event) => setDigest(event.target.value)}
          placeholder="Transaction id"
          className="min-h-11 w-full rounded-full border border-line bg-panel px-4 text-sm text-foam outline-none"
          spellCheck={false}
        />
        <button
          type="button"
          className="chip shrink-0"
          disabled={!ready || !hold || !feed || hold === feed || !trench || digest.trim().length < 32 || busy}
          onClick={() => void submit(digest.trim())}
        >
          Submit payment
        </button>
      </div>
    </div>
  );
}
