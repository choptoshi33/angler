import { SuiClientProvider, WalletProvider, useCurrentAccount, useSignAndExecuteTransaction } from "@mysten/dapp-kit";
import { Transaction } from "@mysten/sui/transactions";
import { useEffect, useRef, useState } from "react";
import "@mysten/dapp-kit/dist/index.css";
import { confirmSliceBuy, prepareSliceBuy } from "@/lib/lure/functions";
import type { NightState } from "@/lib/lure/types";

const RPC = "https://fullnode.mainnet.sui.io:443";

export function AutoBuy({ night, onDone }: { night: NightState; onDone: () => void }) {
  return (
    <SuiClientProvider networks={{ mainnet: { url: RPC, network: "mainnet" } }} defaultNetwork="mainnet">
      <WalletProvider autoConnect>
        <Watch night={night} onDone={onDone} />
      </WalletProvider>
    </SuiClientProvider>
  );
}

function Watch({ night, onDone }: { night: NightState; onDone: () => void }) {
  const account = useCurrentAccount();
  const sign = useSignAndExecuteTransaction();
  const [line, setLine] = useState<string | null>(null);
  const busy = useRef(false);
  const tried = useRef<number | null>(null);
  const due = night.last?.slices.find((slice) => slice.status === "due") ?? null;
  const treasury = night.treasury;

  useEffect(() => {
    if (!due || !treasury || !account) return;
    if (account.address.toLowerCase() !== treasury) return;
    if (busy.current || tried.current === due.index) return;
    busy.current = true;
    tried.current = due.index;
    const slice = due.index;
    void (async () => {
      setLine(`Sending buy ${slice}…`);
      try {
        const prepared = await prepareSliceBuy();
        if (!prepared.ok) {
          setLine(prepared.error);
          return;
        }
        const result = await sign.mutateAsync({ transaction: Transaction.from(prepared.tx) });
        const confirmed = await confirmSliceBuy({ data: { digest: result.digest } });
        if (!confirmed.ok) {
          setLine(confirmed.error);
          return;
        }
        setLine(confirmed.note);
        onDone();
      } catch (error) {
        const message = error instanceof Error ? error.message : "The pot wallet didn't approve the buy.";
        setLine(message);
      } finally {
        busy.current = false;
      }
    })();
  }, [account, due, onDone, sign, treasury]);

  if (!line) return null;
  return <p className="text-sm text-mist">{line}</p>;
}
