import { Link, useRouterState } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { UserButton } from "@/lib/auth/gates";

export function Shell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (s) => s.location.pathname });
  return (
    <div className="min-h-screen bg-abyss text-foam">
      <header className="sticky top-0 z-20 border-b border-line bg-abyss/90 backdrop-blur-md">
        <div className="mx-auto flex w-full max-w-5xl flex-wrap items-center justify-between gap-x-3 gap-y-2 px-4 py-3 sm:px-6">
          <Link to="/" className="flex min-h-11 items-center gap-2">
            <span className="live-dot" aria-hidden="true" />
            <span className="font-display text-lg font-bold tracking-wide">ANGLER</span>
            <span className="hidden text-sm text-mist sm:inline">One night. One coin.</span>
          </Link>
          <nav className="flex items-center gap-1 text-sm">
            <Link
              to="/"
              className={`inline-flex min-h-11 items-center rounded-full px-3 ${path === "/" ? "text-foam" : "text-mist"}`}
            >
              Board
            </Link>
            <Link
              to="/docs"
              className={`inline-flex min-h-11 items-center rounded-full px-3 ${path === "/docs" ? "text-foam" : "text-mist"}`}
            >
              API
            </Link>
            <a
              href="https://github.com/choptoshi33/angler"
              target="_blank"
              rel="noreferrer"
              className="inline-flex min-h-11 items-center rounded-full px-3 text-mist"
            >
              GitHub
            </a>
            <UserButton />
          </nav>
        </div>
      </header>
      <main className="mx-auto w-full max-w-5xl px-4 py-5 sm:px-6 sm:py-8">{children}</main>
    </div>
  );
}
