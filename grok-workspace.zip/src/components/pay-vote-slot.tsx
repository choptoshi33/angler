import { useEffect, useState, type ComponentType } from "react";
import type { NightCastResult } from "@/lib/lure/types";

export type PayProps = {
  treasury: string | null;
  hold: string | null;
  feed: string | null;
  trench: string | null;
  ready: boolean;
  onResult: (result: NightCastResult) => void;
};

export function PayVoteSlot(props: PayProps) {
  const [Comp, setComp] = useState<ComponentType<PayProps> | null>(null);
  useEffect(() => {
    if (!props.treasury) return;
    void import("./pay-vote").then((mod) => setComp(() => mod.PayVote));
  }, [props.treasury]);

  if (!props.treasury) {
    return (
      <button type="button" className="bite-btn mt-4" disabled>
        Pot wallet isn't saved yet
      </button>
    );
  }
  if (!Comp) {
    return (
      <button type="button" className="bite-btn mt-4" disabled>
        Pay 1 SUI and vote
      </button>
    );
  }
  return <Comp {...props} />;
}
