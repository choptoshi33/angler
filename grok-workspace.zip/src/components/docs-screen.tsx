import { useEffect, useState, type ReactNode } from "react";
import type { NightState } from "@/lib/lure/types";

export function DocsScreen() {
  const [origin, setOrigin] = useState("");
  const [out, setOut] = useState("Response shows up here.");
  const [busy, setBusy] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const [night, setNight] = useState<NightState | null>(null);

  useEffect(() => {
    setOrigin(window.location.origin);
    void fetch("/api/v1/lure")
      .then((res) => res.json())
      .then((body: { night?: NightState }) => {
        if (body.night) setNight(body.night);
      })
      .catch(() => setOut("Couldn't reach /api/v1/lure."));
  }, []);

  const base = origin || "";

  async function copy(label: string, text: string) {
    try {
      await navigator.clipboard.writeText(text);
      setCopied(label);
      setTimeout(() => setCopied((cur) => (cur === label ? null : cur)), 1200);
    } catch {
      setCopied(null);
    }
  }

  async function send(path: string, init?: RequestInit) {
    setBusy(true);
    try {
      const res = await fetch(path, init);
      const text = await res.text();
      let pretty = text;
      try {
        pretty = JSON.stringify(JSON.parse(text), null, 2);
      } catch {
        /* keep raw */
      }
      setOut(`${res.status}\n${pretty}`);
    } catch {
      setOut("Request failed.");
    } finally {
      setBusy(false);
    }
  }

  return (
    <div className="flex flex-col gap-5">
      <header>
        <p className="font-display text-xs tracking-widest text-mist">THE API</p>
        <h1 className="mt-2 font-display text-4xl font-bold sm:text-5xl">Read the night.</h1>
        <p className="mt-3 max-w-2xl text-base text-mist">
          One score. A verified vote costs 1 SUI, and you cannot vote for the coin you hold. At midnight on the Sui clock
          the buys start: twelve of them, five minutes apart, each within 1% of the first. Only wallets that voted for
          the winning coin are paid, in that same transaction. The pot wallet sends the buy from the board. There is no
          separate payout.
        </p>
      </header>

      <section className="grid gap-3 sm:grid-cols-3">
        <Rule n="01" title="Not your coin" body="You can't vote for the coin you hold." />
        <Rule n="02" title="1 SUI" body="Verify X, connect a wallet, pay 1 SUI. One vote per account and per wallet." />
        <Rule n="03" title="Midnight" body="The Sui clock opens 12 buys, five minutes apart. The pot wallet sends each one. Only the winner's voters are paid." />
      </section>

      <Endpoint
        method="GET"
        path="/api/v1/lure"
        body="The night: pot, leader, standings, who paid, and when it closes. Coins are ranked by tonight's votes."
        copied={copied === "lure"}
        onCopy={() => copy("lure", `curl -s ${base}/api/v1/lure`)}
      />
      <Endpoint
        method="GET"
        path="/api/v1/tape"
        body="Who paid tonight. Name, wallet, and the coin they voted for."
        copied={copied === "tape"}
        onCopy={() => copy("tape", `curl -s ${base}/api/v1/tape`)}
      />
      <Endpoint
        method="GET"
        path="/api/v1/coins"
        body="Every coin, ranked by votes tonight."
        copied={copied === "coins"}
        onCopy={() => copy("coins", `curl -s ${base}/api/v1/coins`)}
      />
      <Endpoint
        method="GET"
        path="/api/v1/coins/AXOL"
        body="One coin: name, contract, and links."
        copied={copied === "one"}
        onCopy={() => copy("one", `curl -s ${base}/api/v1/coins/AXOL`)}
      />
      <Endpoint
        method="POST"
        path="/api/v1/coins"
        body="Add a Sui coin. Mainnet metadata is checked before it joins the night."
        copied={copied === "add"}
        onCopy={() =>
          copy(
            "add",
            `curl -s -X POST ${base}/api/v1/coins -H 'content-type: application/json' -d '{"ticker":"EXAMPLE","contract":"0x…::module::NAME"}'`,
          )
        }
      />
      <section className="rounded-card border border-line bg-deep p-4 sm:p-5">
        <h2 className="font-display text-lg font-bold">Tonight, from the API</h2>
        <p className="mt-1 text-sm text-mist">
          {night
            ? night.leader
              ? `$${night.leader.ticker} leads with ${night.leader.votes}. The pot is ${night.potSui} SUI.`
              : "No paid votes yet. The pot is empty."
            : "Loading the night…"}
        </p>
        <button type="button" className="bite-btn mt-3 sm:max-w-xs" disabled={busy} onClick={() => void send("/api/v1/lure")}>
          {busy ? "Reading…" : "GET lure"}
        </button>
        <pre className="mt-4 max-h-80 overflow-auto rounded-xl bg-abyss p-3 font-mono text-xs text-foam">{out}</pre>
      </section>
    </div>
  );
}

function Rule({ n, title, body }: { n: string; title: string; body: string }) {
  return (
    <article className="rounded-card border border-line bg-deep p-4">
      <p className="font-display text-sm text-lure">{n}</p>
      <h2 className="mt-1 font-display text-lg font-bold">{title}</h2>
      <p className="mt-1 text-sm text-mist">{body}</p>
    </article>
  );
}

function Endpoint({
  method,
  path,
  body,
  onCopy,
  copied,
  extra,
}: {
  method: string;
  path: string;
  body: string;
  onCopy: () => void;
  copied: boolean;
  extra?: ReactNode;
}) {
  return (
    <article className="rounded-card border border-line bg-panel p-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="font-mono text-sm">
          <span className="text-lure">{method}</span> <span className="text-foam">{path}</span>
        </p>
        <button type="button" className="chip" onClick={onCopy}>
          {copied ? "Copied" : "Copy curl"}
        </button>
      </div>
      <p className="mt-2 text-sm text-mist">{body}</p>
      {extra}
    </article>
  );
}
