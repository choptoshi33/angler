import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { useEffect, useState } from "react";
import alUrl from "@/assets/al.jpg";
import { AutoBuy } from "@/components/auto-buy";
import { NightCard } from "@/components/night-card";
import { PayVoteSlot } from "@/components/pay-vote-slot";
import { verifyWithX } from "@/lib/verify-x";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { listCoin, getLure, myNight, whoamiX } from "@/lib/lure/functions";
import { chartUrl, scanUrl, shortCa } from "@/lib/lure/format";
import { type CoinCard, type LureState, type NightCastResult } from "@/lib/lure/types";
import { getTrench } from "@/lib/trench";

function votesTonight(lure: LureState, ticker: string): number {
  return lure.night.standings.find((row) => row.ticker === ticker)?.votes ?? 0;
}

export function HomeScreen({ initial }: { initial: LureState }) {
  const queryClient = useQueryClient();
  const lureQuery = useQuery({
    queryKey: ["lure"],
    queryFn: () => getLure(),
    initialData: initial,
    initialDataUpdatedAt: 0,
    refetchInterval: 8000,
  });
  const lure = lureQuery.data;
  const [trench, setTrench] = useState<string | null>(null);
  const [hold, setHold] = useState<string | null>(null);
  const [feed, setFeed] = useState<string | null>(null);
  const [note, setNote] = useState<string | null>(null);
  const [snap, setSnap] = useState(false);
  const [lockUntil, setLockUntil] = useState(0);
  const [now, setNow] = useState(0);
  const [copied, setCopied] = useState<string | null>(null);
  const [mounted, setMounted] = useState(false);
  const { user, isPending: sessionPending } = useCurrentUserState();
  const xQuery = useQuery({
    queryKey: ["x-me", user?.id ?? "signed-out"],
    queryFn: () => whoamiX(),
    enabled: Boolean(user),
    retry: false,
  });
  const xReady = Boolean(xQuery.data?.ok);
  const mineQuery = useQuery({
    queryKey: ["my-night", user?.id ?? "signed-out"],
    queryFn: () => myNight(),
    enabled: xReady,
  });
  const alreadyVoted = Boolean(mineQuery.data?.voted);

  useEffect(() => {
    setTrench(getTrench());
    setMounted(true);
  }, []);

  useEffect(() => {
    if (!lockUntil) return;
    const id = setInterval(() => {
      if (Date.now() >= lockUntil) setLockUntil(0);
      else setNow(Date.now());
    }, 250);
    return () => clearInterval(id);
  }, [lockUntil]);

  useEffect(() => {
    if (!snap) return;
    const id = setTimeout(() => setSnap(false), 450);
    return () => clearInterval(id);
  }, [snap]);

  function onPaid(result: NightCastResult) {
    if (!result.ok) {
      setNote(result.error);
      if (result.retryAfterSec) {
        const until = Date.now() + result.retryAfterSec * 1000;
        setLockUntil(until);
        setNow(Date.now());
      }
      return;
    }
    queryClient.setQueryData(["lure"], result.lure);
    void queryClient.invalidateQueries({ queryKey: ["my-night"] });
    setSnap(true);
    setFeed(null);
    setNote(result.note);
  }

  const wait = lockUntil ? Math.max(0, Math.ceil((lockUntil - now) / 1000)) : 0;
  const maxVotes = lure.night.standings[0]?.votes ?? 0;

  async function copyCa(coin: CoinCard) {
    try {
      await navigator.clipboard.writeText(coin.contract);
      setCopied(coin.ticker);
      setTimeout(() => setCopied((cur) => (cur === coin.ticker ? null : cur)), 1400);
    } catch {
      setNote("Couldn't copy that contract.");
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="grid items-start gap-5 lg:grid-cols-3">
        <div className="overflow-hidden rounded-card border border-line bg-deep lg:col-span-1">
          <img
            src={alUrl}
            alt="Al, an angler fish, lure glowing in the dark"
            width={1152}
            height={1728}
            className={`w-full ${snap ? "jaw-snap" : ""}`}
          />
          <div className="border-t border-line p-4 sm:p-5">
            <p className="font-display text-xs tracking-widest text-mist">AL</p>
            <p className="mt-2 text-sm text-foam">
              Charts can be painted. Al doesn't watch candles. He watches a wallet spend 1 SUI on a coin it does not
              hold. That is the only light he can see in the dark. At midnight the buys start, in small slices, and only
              the wallets that voted for the winner are paid.
            </p>
          </div>
        </div>

        <div className="flex flex-col gap-4 lg:col-span-2">
          <NightCard night={lure.night} />
          <AutoBuy
            night={lure.night}
            onDone={() => {
              void queryClient.invalidateQueries({ queryKey: ["lure"] });
            }}
          />

          <section className="rounded-card border border-line bg-panel p-4 sm:p-6">
            <h2 className="font-display text-lg font-bold">Vote</h2>
            <p className="mt-1 text-sm text-mist">
              Pick the coin you hold. Then pick a different coin. That second coin gets the vote. It costs 1 SUI. You are
              paid only if that coin wins.
            </p>
            <XVerify
              pending={!mounted || sessionPending || Boolean(user && xQuery.isLoading)}
              name={xQuery.data?.ok ? xQuery.data.name : null}
              profile={xQuery.data?.ok ? xQuery.data.profile : null}
              onVerified={() => {
                void queryClient.invalidateQueries({ queryKey: ["x-me"] });
              }}
              onError={setNote}
            />

            <p className="mt-4 font-display text-xs tracking-widest text-mist">YOU HOLD</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {lure.coins.map((coin) => (
                <button
                  key={`hold-${coin.ticker}`}
                  type="button"
                  className="chip"
                  data-on={hold === coin.ticker}
                  onClick={() => {
                    setHold(coin.ticker);
                    if (feed === coin.ticker) setFeed(null);
                  }}
                >
                  ${coin.ticker}
                </button>
              ))}
            </div>

            <p className="mt-4 font-display text-xs tracking-widest text-mist">YOU BACK</p>
            <div className="mt-2 flex flex-wrap gap-2">
              {lure.coins.map((coin) => (
                <button
                  key={`feed-${coin.ticker}`}
                  type="button"
                  className="chip"
                  data-on={feed === coin.ticker}
                  disabled={hold === coin.ticker}
                  onClick={() => setFeed(coin.ticker)}
                >
                  ${coin.ticker}
                </button>
              ))}
            </div>

            {alreadyVoted ? (
              <button type="button" className="bite-btn mt-4" disabled>
                You already voted tonight
              </button>
            ) : (
              <PayVoteSlot
                treasury={lure.night.treasury}
                hold={hold}
                feed={feed}
                trench={trench}
                ready={xReady && wait === 0}
                onResult={onPaid}
              />
            )}
            {wait > 0 ? <p className="mt-2 text-sm text-mist">Wait {wait}s</p> : null}
            <p className="mt-3 min-h-5 text-sm text-mist" role="status">
              {note}
            </p>
            <p className="text-xs text-mist">One vote per X account. One vote per wallet. Midnight UTC closes the night.</p>
          </section>
        </div>
      </div>

      <div className="grid gap-5 lg:grid-cols-3">
        <section className="rounded-card border border-line bg-deep p-4 sm:p-5 lg:col-span-1">
          <h2 className="font-display text-lg font-bold">Who paid</h2>
          <p className="mt-1 text-sm text-mist">Only wallets that voted for the winner are paid. A vote for a coin that loses still fills the pot.</p>
          <ol className="mt-2">
            {lure.night.voters.length === 0 ? <li className="py-4 text-sm text-mist">No one has paid tonight.</li> : null}
            {lure.night.voters.map((voter) => (
              <li key={`${voter.wallet}-${voter.ticker}`} className="border-b border-line py-3 text-sm">
                {voter.profile ? (
                  <a className="text-hot underline decoration-line underline-offset-2" href={voter.profile} target="_blank" rel="noreferrer">
                    {voter.name}
                  </a>
                ) : (
                  <span className="text-hot">{voter.name}</span>
                )}
                <span className="text-mist"> voted ${voter.ticker}</span>
              </li>
            ))}
          </ol>
        </section>

        <section className="rounded-card border border-line bg-deep p-4 sm:p-5 lg:col-span-2">
          <h2 className="font-display text-lg font-bold">Coins</h2>
          <p className="mt-1 text-sm text-mist">Ranked by votes tonight. Zero can still win if the votes show up before midnight.</p>
          <ol className="mt-3 flex flex-col">
            {lure.coins.map((coin, index) => {
              const votes = votesTonight(lure, coin.ticker);
              const backers = lure.night.voters.filter((voter) => voter.ticker === coin.ticker);
              return (
                <li key={coin.ticker} className="border-b border-line py-4 last:border-b-0">
                  <div className="flex items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="font-display text-xl font-bold">
                        <span className="mr-2 text-sm text-mist tabular-nums">{String(index + 1).padStart(2, "0")}</span>
                        ${coin.ticker}
                      </p>
                      <p className="mt-0.5 text-sm text-mist">{coin.name}</p>
                    </div>
                    <span className="font-display text-sm tabular-nums text-foam">
                      {votes} {votes === 1 ? "vote" : "votes"}
                    </span>
                  </div>
                  <p className="mt-2 text-sm text-mist">
                    {backers.length
                      ? `Paid by ${backers.map((voter) => voter.name).join(", ")}`
                      : "No paid votes tonight."}
                  </p>
                  <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-panel" aria-hidden="true">
                    <div
                      className="h-full rounded-full bg-lure"
                      style={{ width: `${maxVotes ? (votes / maxVotes) * 100 : 0}%` }}
                    />
                  </div>
                  <div className="mt-3 flex flex-wrap gap-x-4 gap-y-2 text-sm">
                    <button type="button" className="min-h-11 text-lure underline decoration-line underline-offset-2" onClick={() => copyCa(coin)}>
                      {copied === coin.ticker ? "Copied" : "Copy contract"}
                    </button>
                    <a className="inline-flex min-h-11 items-center text-foam underline decoration-line underline-offset-2" href={chartUrl(coin.contract)} target="_blank" rel="noreferrer">
                      Chart
                    </a>
                    <a className="inline-flex min-h-11 items-center text-foam underline decoration-line underline-offset-2" href={scanUrl(coin.contract)} target="_blank" rel="noreferrer">
                      Explorer
                    </a>
                    {coin.website ? (
                      <a className="inline-flex min-h-11 items-center text-foam underline decoration-line underline-offset-2" href={coin.website} target="_blank" rel="noreferrer">
                        Site
                      </a>
                    ) : null}
                  </div>
                  <p className="mt-1 font-mono text-xs text-mist">{shortCa(coin.contract)}</p>
                </li>
              );
            })}
          </ol>
        </section>
      </div>

      <HookForm
        onListed={(next, message) => {
          queryClient.setQueryData(["lure"], next);
          setNote(message);
        }}
      />
    </div>
  );
}

function XVerify({
  pending,
  name,
  profile,
  onVerified,
  onError,
}: {
  pending: boolean;
  name: string | null;
  profile: string | null;
  onVerified: () => void;
  onError: (message: string) => void;
}) {
  const [busy, setBusy] = useState(false);
  const [localError, setLocalError] = useState<string | null>(null);
  if (pending) return <div className="mt-4 h-11 animate-pulse rounded-full bg-deep" />;
  if (name) {
    return (
      <p className="mt-4 text-sm text-foam">
        Voting as{" "}
        {profile ? (
          <a className="text-hot underline decoration-line underline-offset-2" href={profile} target="_blank" rel="noreferrer">
            {name}
          </a>
        ) : (
          <span className="text-hot">{name}</span>
        )}
        . This account can vote once tonight. It costs 1 SUI.
      </p>
    );
  }
  return (
    <div className="mt-4">
      <button
        type="button"
        className="bite-btn"
        disabled={busy}
        onClick={() => {
          setLocalError(null);
          setBusy(true);
          void verifyWithX()
            .then(() => onVerified())
            .catch((err: unknown) => {
              const message = err instanceof Error ? err.message : "Sign-in failed.";
              setLocalError(message);
              onError(message);
            })
            .finally(() => setBusy(false));
        }}
      >
        {busy ? "Waiting for X…" : "Verify with X"}
      </button>
      {localError ? (
        <p className="mt-2 text-sm text-mist" role="status">
          {localError}
        </p>
      ) : (
        <p className="mt-2 text-sm text-mist">Verify with X first. Then you can pay 1 SUI.</p>
      )}
    </div>
  );
}

function HookForm({ onListed }: { onListed: (lure: LureState, message: string) => void }) {
  const [open, setOpen] = useState(false);
  const [ticker, setTicker] = useState("");
  const [contract, setContract] = useState("");
  const [name, setName] = useState("");
  const [about, setAbout] = useState("");
  const [website, setWebsite] = useState("");
  const [error, setError] = useState<string | null>(null);

  const add = useMutation({
    mutationFn: () =>
      listCoin({
        data: { ticker, contract, name, about, website },
      }),
    onSuccess: (result) => {
      if (!result.ok) {
        setError(result.error);
        return;
      }
      setError(null);
      setTicker("");
      setContract("");
      setName("");
      setAbout("");
      setWebsite("");
      onListed(
        result.lure,
        result.already ? `$${result.ticker} is already on the board.` : `$${result.ticker} is on the board. A holder still can't vote for it.`,
      );
    },
  });

  return (
    <section className="rounded-card border border-line bg-deep p-4 sm:p-5">
      <button type="button" className="font-display text-lg font-bold" onClick={() => setOpen((v) => !v)}>
        {open ? "Close" : "Add a coin"}
      </button>
      {open ? (
        <form
          className="mt-3 flex flex-col gap-3"
          onSubmit={(event) => {
            event.preventDefault();
            add.mutate();
          }}
        >
          <label className="text-sm text-mist">
            Ticker
            <input
              value={ticker}
              onChange={(event) => setTicker(event.target.value)}
              className="mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
            />
          </label>
          <label className="text-sm text-mist">
            Coin type
            <input
              value={contract}
              onChange={(event) => setContract(event.target.value)}
              placeholder="0x…::module::NAME"
              className="mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
              spellCheck={false}
            />
          </label>
          <label className="text-sm text-mist">
            Name
            <input
              value={name}
              onChange={(event) => setName(event.target.value)}
              className="mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
            />
          </label>
          <label className="text-sm text-mist">
            About
            <input
              value={about}
              onChange={(event) => setAbout(event.target.value)}
              className="mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
            />
          </label>
          <label className="text-sm text-mist">
            Site
            <input
              value={website}
              onChange={(event) => setWebsite(event.target.value)}
              placeholder="https://"
              className="mt-1 min-h-11 w-full rounded-full border border-line bg-panel px-4 text-foam outline-none"
            />
          </label>
          {error ? <p className="text-sm text-mist">{error}</p> : null}
          <button type="submit" className="bite-btn" disabled={add.isPending}>
            {add.isPending ? "Checking Sui…" : "Add it"}
          </button>
        </form>
      ) : (
        <p className="mt-1 text-sm text-mist">List a Sui coin so it can take votes tonight.</p>
      )}
    </section>
  );
}
