import { createFileRoute } from "@tanstack/react-router";
import { HomeScreen } from "@/components/home-screen";
import { Shell } from "@/components/shell";
import { getLure } from "@/lib/lure/functions";

export const Route = createFileRoute("/")({
  loader: () => getLure(),
  head: () => ({
    meta: [{ title: "Angler — one night, one coin" }],
  }),
  component: Home,
});

function Home() {
  const initial = Route.useLoaderData();
  return (
    <Shell>
      <HomeScreen initial={initial} />
    </Shell>
  );
}
