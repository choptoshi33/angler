import { createFileRoute } from "@tanstack/react-router";
import { DocsScreen } from "@/components/docs-screen";
import { Shell } from "@/components/shell";

export const Route = createFileRoute("/docs")({
  head: () => ({
    meta: [
      { title: "API · Angler" },
      {
        name: "description",
        content: "Read tonight's pot, the leader, and who paid. Votes cost 1 SUI and happen on the board.",
      },
    ],
  }),
  component: Docs,
});

function Docs() {
  return (
    <Shell>
      <DocsScreen />
    </Shell>
  );
}
