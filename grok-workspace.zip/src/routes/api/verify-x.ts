import { createFileRoute } from "@tanstack/react-router";

const SESSION_COOKIE = "__Host-grok-auth.session_token";

export const Route = createFileRoute("/api/verify-x")({
  server: {
    handlers: {
      GET: ({ request }) => startOrFinish(request),
    },
  },
});

async function startOrFinish(request: Request): Promise<Response> {
  const url = new URL(request.url);
  if (url.searchParams.get("done") === "1") {
    const errored = url.searchParams.has("error");
    const raw = url.searchParams.get("error");
    return donePage({
      source: "angler-x",
      token: errored ? null : readCookie(request, SESSION_COOKIE),
      error: errored ? (raw && raw !== "1" ? raw : "X verification was cancelled.") : undefined,
    });
  }

  const done = `${url.origin}/api/verify-x?done=1`;
  const body = {
    providerId: "grok-x",
    callbackURL: done,
    errorCallbackURL: `${done}&error=1`,
  };
  try {
    const { auth } = await import("@/lib/auth/server");
    const sessionRes = await auth.api.getSession({ headers: request.headers, asResponse: true });
    const sessionCookies = sessionRes.headers.getSetCookie();
    const headers = new Headers(request.headers);
    if (sessionCookies.length) {
      const baked = sessionCookies.map((cookie) => cookie.split(";")[0]).join("; ");
      const prev = headers.get("cookie");
      headers.set("cookie", prev ? `${prev}; ${baked}` : baked);
    }
    const session = (await sessionRes.json().catch(() => null)) as { user?: { id: string } } | null;
    const api = auth.api as unknown as {
      oAuth2LinkAccount: (opts: { body: typeof body; headers: Headers; asResponse: true }) => Promise<Response>;
      signInWithOAuth2: (opts: { body: typeof body; headers: Headers; asResponse: true }) => Promise<Response>;
    };
    const apiRes = session?.user
      ? await api.oAuth2LinkAccount({ body, headers, asResponse: true })
      : await api.signInWithOAuth2({ body, headers, asResponse: true });
    if (!apiRes.ok) {
      const detail = (await apiRes.text().catch(() => "")).slice(0, 180);
      return donePage({
        source: "angler-x",
        token: null,
        error: detail || "Couldn't start X verification.",
      });
    }
    const payload = (await apiRes.json().catch(() => null)) as { url?: string } | null;
    if (!payload?.url) {
      return donePage({ source: "angler-x", token: null, error: "X did not return a sign-in link." });
    }
    const redirectHeaders = new Headers({ location: payload.url, "cache-control": "no-store" });
    for (const cookie of sessionCookies) redirectHeaders.append("set-cookie", cookie);
    for (const cookie of apiRes.headers.getSetCookie()) redirectHeaders.append("set-cookie", cookie);
    return new Response(null, { status: 302, headers: redirectHeaders });
  } catch (error) {
    const message = error instanceof Error ? error.message : "X verification failed.";
    return donePage({ source: "angler-x", token: null, error: message });
  }
}

function donePage(message: { source: "angler-x"; token: string | null; error?: string }): Response {
  const payload = JSON.stringify(message).replace(/</g, "\\u003c");
  const html = `<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Verifying X…</title>
<style>
  html,body{margin:0;min-height:100%;background:#07141b;color:#8eada3;font:15px/1.5 Outfit,sans-serif}
  main{min-height:100vh;display:grid;place-items:center;padding:1.5rem;text-align:center}
</style>
</head>
<body>
<main><p>${message.error ? "Could not verify X. You can close this window." : "X verified. You can close this window."}</p></main>
<script type="application/json" id="angler-x-msg">${payload}</script>
<script>
(function () {
  var el = document.getElementById("angler-x-msg");
  var msg = { source: "angler-x", token: null };
  try { if (el && el.textContent) msg = JSON.parse(el.textContent); } catch (e) {}
  try { if (window.opener) window.opener.postMessage(msg, window.location.origin); } catch (e) {}
  try { window.close(); } catch (e) {}
})();
</script>
</body>
</html>`;
  return new Response(html, {
    status: 200,
    headers: { "content-type": "text/html; charset=utf-8", "cache-control": "no-store" },
  });
}

function readCookie(request: Request, name: string): string | null {
  const header = request.headers.get("cookie");
  if (!header) return null;
  for (const part of header.split(";")) {
    const trimmed = part.trim();
    const eq = trimmed.indexOf("=");
    if (eq <= 0) continue;
    if (trimmed.slice(0, eq) !== name) continue;
    const raw = trimmed.slice(eq + 1);
    try {
      return decodeURIComponent(raw);
    } catch {
      return raw;
    }
  }
  return null;
}
