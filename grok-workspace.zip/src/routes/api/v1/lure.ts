import { createFileRoute } from "@tanstack/react-router";
import { apiJson, apiOptions } from "@/lib/lure/http";

export const Route = createFileRoute("/api/v1/lure")({
  server: {
    handlers: {
      OPTIONS: async () => apiOptions(),
      GET: async () => {
        try {
          const { getLureState } = await import("@/lib/lure/core.server");
          return apiJson(await getLureState());
        } catch (error) {
          console.error(error);
          return apiJson({ error: "Something broke. Try again." }, 500);
        }
      },
    },
  },
});
