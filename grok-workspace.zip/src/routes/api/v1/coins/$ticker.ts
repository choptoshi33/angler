import { createFileRoute } from "@tanstack/react-router";
import { apiJson, apiOptions } from "@/lib/lure/http";

export const Route = createFileRoute("/api/v1/coins/$ticker")({
  server: {
    handlers: {
      OPTIONS: async () => apiOptions(),
      GET: async ({ params }) => {
        const { getCoin } = await import("@/lib/lure/core.server");
        const result = await getCoin(params.ticker);
        if (!result.ok) return apiJson({ error: result.error }, result.status);
        return apiJson({ coin: result.coin, recent: result.recent });
      },
    },
  },
});
