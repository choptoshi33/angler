import { createFileRoute } from "@tanstack/react-router";
import { apiJson, apiOptions, badBody, readJson } from "@/lib/lure/http";

export const Route = createFileRoute("/api/v1/coins/")({
  server: {
    handlers: {
      OPTIONS: async () => apiOptions(),
      GET: async () => {
        try {
          const { getLureState } = await import("@/lib/lure/core.server");
          const lure = await getLureState();
          return apiJson({ coins: lure.coins });
        } catch (error) {
          console.error(error);
          return apiJson({ error: "Something broke. Try again." }, 500);
        }
      },
      POST: async ({ request }) => {
        const body = await readJson(request);
        const bad = badBody(body);
        if (bad) return apiJson({ error: bad }, 400);
        const { addCoin } = await import("@/lib/lure/core.server");
        const result = await addCoin(body);
        if (!result.ok) return apiJson({ error: result.error }, result.status);
        return apiJson(
          { already: result.already, ticker: result.ticker, name: result.name },
          result.already ? 200 : 201,
        );
      },
    },
  },
});
