import { createFileRoute } from "@tanstack/react-router";
import { apiJson, apiOptions } from "@/lib/lure/http";

export const Route = createFileRoute("/api/v1/tape")({
  server: {
    handlers: {
      OPTIONS: async () => apiOptions(),
      GET: async () => {
        try {
          const { getLureState } = await import("@/lib/lure/core.server");
          const lure = await getLureState();
          return apiJson({
            votes: lure.night.voters,
            potSui: lure.night.potSui,
            leader: lure.night.leader,
            endsAt: lure.night.endsAt,
          });
        } catch (error) {
          console.error(error);
          return apiJson({ error: "Something broke. Try again." }, 500);
        }
      },
    },
  },
});
