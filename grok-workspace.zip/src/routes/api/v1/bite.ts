import { createFileRoute } from "@tanstack/react-router";
import { apiJson, apiOptions, badBody, readJson } from "@/lib/lure/http";

export const Route = createFileRoute("/api/v1/bite")({
  server: {
    handlers: {
      OPTIONS: async () => apiOptions(),
      POST: async ({ request }) => {
        const body = await readJson(request);
        const bad = badBody(body);
        if (bad) return apiJson({ error: bad }, 400);
        const { placeBite } = await import("@/lib/lure/core.server");
        const result = await placeBite(body);
        if (!result.ok) {
          return apiJson(
            { error: result.error, retryAfterSec: result.retryAfterSec ?? null },
            result.status,
          );
        }
        return apiJson(
          {
            bite: result.bite,
            newSchool: result.newSchool,
            justLit: result.justLit,
            heat: result.heat,
            catch: result.lure.catch,
            coins: result.lure.coins,
          },
          201,
        );
      },
    },
  },
});
