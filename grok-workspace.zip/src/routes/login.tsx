import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Shell } from "@/components/shell";
import { verifyWithX } from "@/lib/verify-x";

export const Route = createFileRoute("/login")({
  component: Login,
});

function Login() {
  const navigate = useNavigate();
  const [error, setError] = useState<string | null>(null);
  return (
    <Shell>
      <main className="mx-auto flex w-full max-w-md flex-col gap-4 py-10">
        <p className="font-display text-xs tracking-widest text-mist">VERIFY</p>
        <h1 className="font-display text-4xl font-bold">Sign in with X</h1>
        <p className="text-mist">
          A verified vote keeps your X profile on the board. Founders can open it and reward the account. The public
          API cannot attach a handle for you.
        </p>
        <button
          type="button"
          className="bite-btn"
          onClick={() => {
            setError(null);
            void verifyWithX()
              .then(() => navigate({ to: "/" }))
              .catch((err: unknown) => {
                setError(err instanceof Error ? err.message : "Sign-in failed.");
              });
          }}
        >
          Continue with X
        </button>
        {error ? (
          <p className="text-sm text-mist" role="status">
            {error}
          </p>
        ) : null}
      </main>
    </Shell>
  );
}
