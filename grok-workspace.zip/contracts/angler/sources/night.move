/// The night pot. Time comes only from the shared Clock at 0x6.
/// There is no AdminCap. After midnight anyone can close the night, then
/// anyone can send the next buy. Each buy is one slice. The same transaction
/// pays only the wallets that voted for the winning coin.
module angler::night;

use sui::balance::{Self, Balance};
use sui::clock::{Self, Clock};
use sui::coin::{Self, Coin};
use sui::event;
use sui::sui::SUI;
use sui::transfer;
use sui::object;
use sui::option;
use sui::tx_context::TxContext;
use sui::type_name::{Self, TypeName};
use sui::vec_map::{Self, VecMap};

const E_STILL_OPEN: u64 = 0;
const E_TOO_EARLY: u64 = 1;
const E_SLIPPAGE: u64 = 2;
const E_NOT_WINNER: u64 = 3;
const E_ALREADY_VOTED: u64 = 4;
const E_WRONG_PAYMENT: u64 = 5;
const E_DRIP_RUNNING: u64 = 6;
const E_NOT_STARTED: u64 = 7;
const E_FINISHED: u64 = 8;

const DAY_MS: u64 = 86_400_000;
const SLICE_COUNT: u64 = 12;
const SLICE_GAP_MS: u64 = 300_000;
const SLIPPAGE_BPS: u64 = 100;
const BPS: u64 = 10_000;
const ONE_SUI: u64 = 1_000_000_000;

public struct Board has key {
    id: UID,
    ends_at_ms: u64,
    open_sui: Balance<SUI>,
    votes: VecMap<address, TypeName>,
    buckets: VecMap<TypeName, vector<address>>,
    leader: Option<TypeName>,
    leader_count: u64,
    drip_active: bool,
    drip_sui: Balance<SUI>,
    drip_winner: Option<TypeName>,
    drip_voters: vector<address>,
    /// Midnight the closed night ended. Slice 0 opens here.
    drip_opens_ms: u64,
    next_slice: u64,
    /// Output per 1 SUI from the first fill, in bps-scaled units. Later slices
    /// must stay within SLIPPAGE_BPS of it. Zero until the first fill.
    rate: u64,
}

/// Hot potato. The SUI from a slice cannot leave the transaction unless
/// `repay` accepts the bought coin.
public struct SliceReceipt {
    sui_in: u64,
    slice: u64,
}

public struct SlicePaid has copy, drop {
    slice: u64,
    sui_in: u64,
    coin_out: u64,
    payees: u64,
}

fun init(ctx: &mut TxContext) {
    transfer::share_object(Board {
        id: object::new(ctx),
        ends_at_ms: 0,
        open_sui: balance::zero<SUI>(),
        votes: vec_map::empty(),
        buckets: vec_map::empty(),
        leader: option::none(),
        leader_count: 0,
        drip_active: false,
        drip_sui: balance::zero<SUI>(),
        drip_winner: option::none(),
        drip_voters: vector[],
        drip_opens_ms: 0,
        next_slice: 0,
        rate: 0,
    });
}

/// Bind the board to the current Sui day. Anyone can call this once.
public fun start(board: &mut Board, clock: &Clock) {
    assert!(board.ends_at_ms == 0, E_DRIP_RUNNING);
    let now = clock::timestamp_ms(clock);
    let start = (now / DAY_MS) * DAY_MS;
    board.ends_at_ms = start + DAY_MS;
}

/// 1 SUI, not for a coin the caller is treated as holding. The type `C` is the coin they back.
/// Rejected once the Clock is at or past midnight.
public fun cast_vote<C>(board: &mut Board, payment: Coin<SUI>, clock: &Clock, ctx: &mut TxContext) {
    assert!(board.ends_at_ms > 0, E_NOT_STARTED);
    let now = clock::timestamp_ms(clock);
    assert!(now < board.ends_at_ms, E_STILL_OPEN);
    assert!(coin::value(&payment) == ONE_SUI, E_WRONG_PAYMENT);
    let sender = ctx.sender();
    assert!(!vec_map::contains(&board.votes, &sender), E_ALREADY_VOTED);
    let name = type_name::get<C>();
    vec_map::insert(&mut board.votes, sender, name);
    if (!vec_map::contains(&board.buckets, &name)) {
        vec_map::insert(&mut board.buckets, name, vector[sender]);
    } else {
        vector::push_back(vec_map::get_mut(&mut board.buckets, &name), sender);
    };
    let count = vector::length(vec_map::get(&board.buckets, &name));
    if (count > board.leader_count) {
        board.leader_count = count;
        board.leader = option::some(name);
    };
    balance::join(&mut board.open_sui, coin::into_balance(payment));
}

/// Freeze the night that just ended and open the next one.
/// Anyone can call it. The Clock must be at or past midnight.
/// Buys of the closed night keep running on `drip_sui`.
public fun close(board: &mut Board, clock: &Clock) {
    assert!(board.ends_at_ms > 0, E_NOT_STARTED);
    assert!(!board.drip_active, E_DRIP_RUNNING);
    let now = clock::timestamp_ms(clock);
    assert!(now >= board.ends_at_ms, E_STILL_OPEN);
    let ended = board.ends_at_ms;
    if (board.leader_count > 0) {
        let winner = *option::borrow(&board.leader);
        board.drip_voters = *vec_map::get(&board.buckets, &winner);
        board.drip_winner = option::some(winner);
        board.drip_opens_ms = ended;
        board.drip_active = true;
        board.next_slice = 0;
        board.rate = 0;
        let pot = balance::value(&board.open_sui);
        balance::join(&mut board.drip_sui, balance::split(&mut board.open_sui, pot));
    };
    board.votes = vec_map::empty();
    board.buckets = vec_map::empty();
    board.leader = option::none();
    board.leader_count = 0;
    // Next midnight after the clock, so a late close does not skip a day of votes.
    let today = (now / DAY_MS) * DAY_MS;
    board.ends_at_ms = if (today + DAY_MS > ended) { today + DAY_MS } else { ended + DAY_MS };
}

/// Pull the next slice of SUI. The first slice opens at midnight.
/// Each later slice opens SLICE_GAP_MS after the one before it.
/// Anyone can call this. The receipt forces the bought coin to come back.
public fun take_slice(board: &mut Board, clock: &Clock, ctx: &mut TxContext): (Coin<SUI>, SliceReceipt) {
    assert!(board.drip_active, E_FINISHED);
    assert!(board.next_slice < SLICE_COUNT, E_FINISHED);
    let now = clock::timestamp_ms(clock);
    let open_at = opened_at(board, board.next_slice);
    assert!(now >= open_at, E_TOO_EARLY);
    let left = SLICE_COUNT - board.next_slice;
    let pot = balance::value(&board.drip_sui);
    let amount = pot / left;
    assert!(amount > 0, E_FINISHED);
    let slice = board.next_slice;
    board.next_slice = slice + 1;
    (
        coin::from_balance(balance::split(&mut board.drip_sui, amount), ctx),
        SliceReceipt { sui_in: amount, slice },
    )
}

/// Finish the slice. `W` must be the winning coin.
/// The fill has to be within 1% of the first slice, so a later buy cannot dump.
/// The bought coin is split evenly across winner voters and sent now.
public fun repay<W>(board: &mut Board, receipt: SliceReceipt, mut bought: Coin<W>, ctx: &mut TxContext) {
    let SliceReceipt { sui_in, slice } = receipt;
    assert!(option::is_some(&board.drip_winner), E_NOT_WINNER);
    assert!(*option::borrow(&board.drip_winner) == type_name::get<W>(), E_NOT_WINNER);
    let out = coin::value(&bought);
    let rate = (((out as u128) * (BPS as u128)) / (sui_in as u128)) as u64;
    if (board.rate == 0) {
        assert!(rate > 0, E_SLIPPAGE);
        board.rate = rate;
    } else {
        let floor = (board.rate as u128) * ((BPS - SLIPPAGE_BPS) as u128) / (BPS as u128);
        assert!((rate as u128) >= floor, E_SLIPPAGE);
    };
    let n = vector::length(&board.drip_voters);
    assert!(n > 0, E_NOT_WINNER);
    let each = out / n;
    assert!(each > 0, E_SLIPPAGE);
    let mut i = 0;
    while (i < n) {
        let who = *vector::borrow(&board.drip_voters, i);
        let share = if (i + 1 == n) { coin::value(&bought) } else { each };
        transfer::public_transfer(coin::split(&mut bought, share, ctx), who);
        i = i + 1;
    };
    coin::destroy_zero(bought);
    if (board.next_slice == SLICE_COUNT) {
        board.drip_active = false;
    };
    event::emit(SlicePaid { slice, sui_in, coin_out: out, payees: n });
}

/// Midnight plus slice * 5 minutes. Slice 0 opens at the close.
fun opened_at(board: &Board, slice: u64): u64 {
    board.drip_opens_ms + slice * SLICE_GAP_MS
}
