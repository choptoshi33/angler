/// Night pot. The Sui clock at 0x6 is the only clock.
/// There is no admin key and no withdraw. SUI sits in this shared object.
/// A buy pays that SUI into a Cetus pool inside this module. The caller never
/// receives it. The winning coin is split to the winner's voters in the same call.
/// The first buy locks the pool. Later buys must use it and stay within 1% of
/// the first fill. After publish, burn the UpgradeCap with `freeze`.
module angler::night;

use cetus_clmm::config::GlobalConfig;
use cetus_clmm::pool::{Self, Pool};
use sui::balance::{Self, Balance};
use sui::clock::{Self, Clock};
use sui::coin::{Self, Coin};
use sui::event;
use sui::object::{Self, ID};
use sui::option::{Self, Option};
use sui::package;
use sui::sui::SUI;
use sui::transfer;
use sui::tx_context::TxContext;
use sui::type_name::{Self, TypeName};
use sui::vec_map::{Self, VecMap};

const E_CLOSED: u64 = 0;
const E_TOO_EARLY: u64 = 1;
const E_SLIPPAGE: u64 = 2;
const E_NOT_WINNER: u64 = 3;
const E_ALREADY_VOTED: u64 = 4;
const E_WRONG_PAYMENT: u64 = 5;
const E_DRIP_RUNNING: u64 = 6;
const E_NOT_STARTED: u64 = 7;
const E_FINISHED: u64 = 8;
const E_ALREADY: u64 = 9;
const E_POOL: u64 = 10;

const DAY_MS: u64 = 86_400_000;
const SLICE_COUNT: u64 = 12;
const SLICE_GAP_MS: u64 = 300_000;
/// A slice that nobody could buy can be returned to the winner's voters after this.
/// It pays them SUI. The caller does not receive it.
const REFUND_AFTER_MS: u64 = 3_600_000;
const SLIPPAGE_BPS: u128 = 100;
const BPS: u128 = 10_000;
const ONE_SUI: u64 = 1_000_000_000;
/// Cetus sqrt-price bounds. Selling coin A uses the floor. Selling coin B uses the ceiling.
const MIN_SQRT_PRICE: u128 = 4_295_048_016;
const MAX_SQRT_PRICE: u128 = 79_226_673_515_401_279_992_447_579_055;

public struct Board has key {
    id: UID,
    ends_at_ms: u64,
    open_sui: Balance<SUI>,
    votes: VecMap<address, TypeName>,
    buckets: VecMap<TypeName, vector<address>>,
    leader: Option<TypeName>,
    leader_count: u64,
    drip_active: bool,
    drip_sui: Balance<SUI>,
    drip_winner: Option<TypeName>,
    drip_voters: vector<address>,
    drip_opens_ms: u64,
    next_slice: u64,
    /// Winning-coin units per 1 raw SUI, scaled by BPS. Zero until the first buy.
    rate: u128,
    /// Cetus pool locked by the first buy. Later buys must pass the same object.
    pool: Option<ID>,
}

public struct SlicePaid has copy, drop {
    slice: u64,
    sui_in: u64,
    coin_out: u64,
    payees: u64,
    refunded: bool,
}

fun init(ctx: &mut TxContext) {
    transfer::share_object(Board {
        id: object::new(ctx),
        ends_at_ms: 0,
        open_sui: balance::zero<SUI>(),
        votes: vec_map::empty(),
        buckets: vec_map::empty(),
        leader: option::none(),
        leader_count: 0,
        drip_active: false,
        drip_sui: balance::zero<SUI>(),
        drip_winner: option::none(),
        drip_voters: vector[],
        drip_opens_ms: 0,
        next_slice: 0,
        rate: 0,
        pool: option::none(),
    });
}

/// Burn the publisher's UpgradeCap. After this the package cannot be changed.
public fun freeze(cap: package::UpgradeCap) {
    package::make_immutable(cap);
}

public fun start(board: &mut Board, clock: &Clock) {
    assert!(board.ends_at_ms == 0, E_ALREADY);
    let now = clock::timestamp_ms(clock);
    let start = (now / DAY_MS) * DAY_MS;
    board.ends_at_ms = start + DAY_MS;
}

public fun cast_vote<C>(board: &mut Board, payment: Coin<SUI>, clock: &Clock, ctx: &mut TxContext) {
    assert!(board.ends_at_ms > 0, E_NOT_STARTED);
    let now = clock::timestamp_ms(clock);
    assert!(now < board.ends_at_ms, E_CLOSED);
    assert!(coin::value(&payment) == ONE_SUI, E_WRONG_PAYMENT);
    let sender = ctx.sender();
    assert!(!vec_map::contains(&board.votes, &sender), E_ALREADY_VOTED);
    let name = type_name::get<C>();
    vec_map::insert(&mut board.votes, sender, name);
    if (!vec_map::contains(&board.buckets, &name)) {
        vec_map::insert(&mut board.buckets, name, vector[sender]);
    } else {
        vector::push_back(vec_map::get_mut(&mut board.buckets, &name), sender);
    };
    let count = vector::length(vec_map::get(&board.buckets, &name));
    if (count > board.leader_count) {
        board.leader_count = count;
        board.leader = option::some(name);
    };
    balance::join(&mut board.open_sui, coin::into_balance(payment));
}

public fun close(board: &mut Board, clock: &Clock) {
    assert!(board.ends_at_ms > 0, E_NOT_STARTED);
    assert!(!board.drip_active, E_DRIP_RUNNING);
    let now = clock::timestamp_ms(clock);
    assert!(now >= board.ends_at_ms, E_TOO_EARLY);
    let ended = board.ends_at_ms;
    if (board.leader_count > 0) {
        let winner = *option::borrow(&board.leader);
        board.drip_voters = *vec_map::get(&board.buckets, &winner);
        board.drip_winner = option::some(winner);
        board.drip_opens_ms = ended;
        board.drip_active = true;
        board.next_slice = 0;
        board.rate = 0;
        board.pool = option::none();
        let pot = balance::value(&board.open_sui);
        balance::join(&mut board.drip_sui, balance::split(&mut board.open_sui, pot));
    };
    board.votes = vec_map::empty();
    board.buckets = vec_map::empty();
    board.leader = option::none();
    board.leader_count = 0;
    let today = (now / DAY_MS) * DAY_MS;
    board.ends_at_ms = if (today + DAY_MS > ended) { today + DAY_MS } else { ended + DAY_MS };
}

/// Pool is `SUI` / winner. Selling SUI.
public fun crank_sui_for_coin<W>(
    board: &mut Board,
    config: &GlobalConfig,
    pool: &mut Pool<SUI, W>,
    clock: &Clock,
    ctx: &mut TxContext,
) {
    assert_winner<W>(board);
    lock_pool(board, object::id(pool));
    assert!(!pool::is_pause(pool), E_POOL);
    if (release_if_dust(board)) return;
    let (slice, mut sui_bal) = pull_slice(board, clock);
    let sui_in = balance::value(&sui_bal);
    let (_sui_side, coin_side) = pool::balances(pool);
    assert!(balance::value(coin_side) > 0, E_POOL);
    let quote = pool::calculate_swap_result(pool, true, true, sui_in);
    assert!(!pool::calculated_swap_result_is_exceed(&quote), E_SLIPPAGE);
    let quoted = pool::calculated_swap_result_amount_out(&quote);
    let (got_a, got_b, receipt) = pool::flash_swap(
        config, pool, true, true, sui_in, MIN_SQRT_PRICE, clock,
    );
    let pay = pool::swap_pay_amount(&receipt);
    let out = balance::value(&got_b);
    check_fill(board, quoted, pay, sui_in, out);
    let pay_a = balance::split(&mut sui_bal, pay);
    balance::join(&mut sui_bal, got_a);
    pool::repay_flash_swap(config, pool, pay_a, balance::zero<W>(), receipt);
    return_sui(board, sui_bal);
    pay_holders(board, coin::from_balance(got_b, ctx), ctx);
    event::emit(SlicePaid { slice, sui_in: pay, coin_out: out, payees: vector::length(&board.drip_voters), refunded: false });
    if (board.next_slice == SLICE_COUNT) finish(board);
}

/// Pool is winner / `SUI`. Selling SUI, which is coin B.
public fun crank_coin_for_sui<W>(
    board: &mut Board,
    config: &GlobalConfig,
    pool: &mut Pool<W, SUI>,
    clock: &Clock,
    ctx: &mut TxContext,
) {
    assert_winner<W>(board);
    lock_pool(board, object::id(pool));
    assert!(!pool::is_pause(pool), E_POOL);
    if (release_if_dust(board)) return;
    let (slice, mut sui_bal) = pull_slice(board, clock);
    let sui_in = balance::value(&sui_bal);
    let (coin_side, _sui_side) = pool::balances(pool);
    assert!(balance::value(coin_side) > 0, E_POOL);
    let quote = pool::calculate_swap_result(pool, false, true, sui_in);
    assert!(!pool::calculated_swap_result_is_exceed(&quote), E_SLIPPAGE);
    let quoted = pool::calculated_swap_result_amount_out(&quote);
    let (got_a, got_b, receipt) = pool::flash_swap(
        config, pool, false, true, sui_in, MAX_SQRT_PRICE, clock,
    );
    let pay = pool::swap_pay_amount(&receipt);
    let out = balance::value(&got_a);
    check_fill(board, quoted, pay, sui_in, out);
    let pay_b = balance::split(&mut sui_bal, pay);
    balance::join(&mut sui_bal, got_b);
    pool::repay_flash_swap(config, pool, balance::zero<W>(), pay_b, receipt);
    return_sui(board, sui_bal);
    pay_holders(board, coin::from_balance(got_a, ctx), ctx);
    event::emit(SlicePaid { slice, sui_in: pay, coin_out: out, payees: vector::length(&board.drip_voters), refunded: false });
    if (board.next_slice == SLICE_COUNT) finish(board);
}

/// If a slice stays open an hour, anyone can send that slice of SUI to the winner's voters.
/// The caller gets nothing. This is only so a dead pool cannot freeze the next night.
public fun refund_slice(board: &mut Board, clock: &Clock, ctx: &mut TxContext) {
    assert!(board.drip_active, E_FINISHED);
    if (release_if_dust(board)) return;
    assert!(board.next_slice < SLICE_COUNT, E_FINISHED);
    let now = clock::timestamp_ms(clock);
    assert!(now >= opened_at(board, board.next_slice) + REFUND_AFTER_MS, E_TOO_EARLY);
    let (slice, sui_bal) = pull_slice(board, clock);
    let sui_in = balance::value(&sui_bal);
    pay_holders(board, coin::from_balance(sui_bal, ctx), ctx);
    event::emit(SlicePaid { slice, sui_in, coin_out: 0, payees: vector::length(&board.drip_voters), refunded: true });
    if (board.next_slice == SLICE_COUNT) finish(board);
}

fun release_if_dust(board: &mut Board): bool {
    if (!board.drip_active || board.next_slice >= SLICE_COUNT) return false;
    let left = SLICE_COUNT - board.next_slice;
    if (balance::value(&board.drip_sui) / left == 0) {
        finish(board);
        return true;
    };
    false
}

fun assert_winner<W>(board: &Board) {
    assert!(option::is_some(&board.drip_winner), E_NOT_WINNER);
    assert!(*option::borrow(&board.drip_winner) == type_name::get<W>(), E_NOT_WINNER);
}

fun lock_pool(board: &mut Board, id: ID) {
    if (option::is_none(&board.pool)) {
        board.pool = option::some(id);
    } else {
        assert!(*option::borrow(&board.pool) == id, E_POOL);
    };
}

fun pull_slice(board: &mut Board, clock: &Clock): (u64, Balance<SUI>) {
    assert!(board.drip_active, E_FINISHED);
    assert!(board.next_slice < SLICE_COUNT, E_FINISHED);
    let now = clock::timestamp_ms(clock);
    let open_at = opened_at(board, board.next_slice);
    assert!(now >= open_at, E_TOO_EARLY);
    let left = SLICE_COUNT - board.next_slice;
    let pot = balance::value(&board.drip_sui);
    let amount = pot / left;
    assert!(amount > 0, E_FINISHED);
    let slice = board.next_slice;
    board.next_slice = slice + 1;
    (slice, balance::split(&mut board.drip_sui, amount))
}

fun check_fill(board: &mut Board, quoted: u64, pay: u64, sui_in: u64, out: u64) {
    assert!(pay > 0 && pay <= sui_in, E_SLIPPAGE);
    assert!(out > 0, E_SLIPPAGE);
    let min_quote = (quoted as u128) * (BPS - SLIPPAGE_BPS) / BPS;
    assert!((out as u128) >= min_quote, E_SLIPPAGE);
    let rate = ((out as u128) * BPS) / (pay as u128);
    if (board.rate == 0) {
        board.rate = rate;
    } else {
        let floor = board.rate * (BPS - SLIPPAGE_BPS) / BPS;
        assert!(rate >= floor, E_SLIPPAGE);
    };
}

fun return_sui(board: &mut Board, mut sui_bal: Balance<SUI>) {
    let left = balance::value(&sui_bal);
    if (left > 0) {
        balance::join(&mut board.drip_sui, balance::split(&mut sui_bal, left));
    };
    balance::destroy_zero(sui_bal);
}

fun pay_holders<T>(board: &Board, mut bought: Coin<T>, ctx: &mut TxContext) {
    let n = vector::length(&board.drip_voters);
    assert!(n > 0, E_NOT_WINNER);
    let each = coin::value(&bought) / n;
    assert!(each > 0, E_SLIPPAGE);
    let mut i = 0;
    while (i < n) {
        let who = *vector::borrow(&board.drip_voters, i);
        let share = if (i + 1 == n) { coin::value(&bought) } else { each };
        transfer::public_transfer(coin::split(&mut bought, share, ctx), who);
        i = i + 1;
    };
    coin::destroy_zero(bought);
}

fun finish(board: &mut Board) {
    board.drip_active = false;
    board.rate = 0;
    board.pool = option::none();
    board.drip_voters = vector[];
    board.drip_winner = option::none();
    let dust = balance::value(&board.drip_sui);
    if (dust > 0) {
        balance::join(&mut board.open_sui, balance::split(&mut board.drip_sui, dust));
    };
}

fun opened_at(board: &Board, slice: u64): u64 {
    board.drip_opens_ms + slice * SLICE_GAP_MS
}
